let TextType = "text";

function reEnableSaveModal() {
    $("#saveFileSubmit").removeClass("btn-danger"), $("#saveFileSubmit").addClass("btn-success"), $("#saveFileSubmit").text("Submit"), $("#saveFileSubmit").prop("disabled", !1), $("#fileNameInput").val("")
}
const getProvider = e => {
        switch (e) {
            case "ai101":
                return "AI 1";
            case "ai102":
                return "AI 2";
            case "ai103":
                return "AI 3";
            case "ai104":
                return "AI 4";
            case "ai105":
                return "AI 5";
            case "ai106":
                return "AI 6";
            case "ai112":
                return "AI 12";
            case "ai113":
                return "AI 13";
            case "openai":
                return "OPENAI";
            case "pro-plus":
                return "Pro+";
            case "pro1":
                return "Pro1";
            case "pro2":
                return "Pro2";
            default:
                return e
        }
    },
    getFileSize = e => 1e9 < e ? Number(e / 1e9).toFixed(2) + " GB" : 1e6 < e ? Number(e / 1e6).toFixed(2) + " MB" : 1e3 < e ? Number(e / 1e3).toFixed(2) + " KB" : e + " B";

function substr_Text(e, a = 30) {
    return e ? .length > a ? (a = e.substring(0, a), getPureText(a) + "...") : getPureText(e)
}
$("#saveModal").on("show.bs.modal", () => {
    reEnableSaveModal()
});
var HtmlEntities = function() {};

function getUrlVars() {
    for (var e, a = [], t = window.location.href.slice(window.location.href.indexOf("?") + 1).split("&"), o = 0; o < t.length; o++) e = t[o].split("="), a.push(e[0]), a[e[0]] = e[1] ? .replace(/[^a-zA-Z0-9]/g, "");
    return a
}

function Format_provider(e, a, t) {
    "advanced_v2" === voice.master_VC ? $("select.sampleRate option").toArray().forEach(e => {
        $(e).removeProp("disabled")
    }) : "standard" == t ? "mp3" == a || "ogg_vorbis" == a ? (e != ProviderTypes.AI101 && e !== ProviderTypes.AI102 || ($("select.sampleRate option[value='24000']").removeAttr("disabled"), $("select.sampleRate option[value='22050']").removeAttr("disabled"), $("select.sampleRate option[value='16000']").removeAttr("disabled"), $("select.sampleRate option[value='8000']").removeAttr("disabled")), e == ProviderTypes.AI101 ? (editSelected || $("select.sampleRate").val("24000").change(), $("select.sampleRate option[value='48000']").attr("disabled", "disabled"), $("select.sampleRate option[value='44100']").attr("disabled", "disabled")) : e === ProviderTypes.AI102 ? (editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='48000']").removeAttr("disabled"), $("select.sampleRate option[value='44100']").removeAttr("disabled")) : e !== ProviderTypes.AI103 && e !== ProviderTypes.PRO1 || ($("select.sampleRate option[value='48000']").removeAttr("disabled"), editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='22050']").attr("disabled", "disabled"), $("select.sampleRate option[value='8000']").attr("disabled", "disabled"), $("select.sampleRate option[value='44100']").attr("disabled", "disabled"))) : "wav" == a && ($("select.sampleRate option[value='16000']").removeAttr("disabled"), $("select.sampleRate option[value='22050']").attr("disabled", "disabled"), $("select.sampleRate option[value='8000']").attr("disabled", "disabled"), $("select.sampleRate option[value='44100']").attr("disabled", "disabled"), e == ProviderTypes.AI101 ? (editSelected || $("select.sampleRate").val("16000").change(), $("select.sampleRate option[value='48000']").attr("disabled", "disabled"), $("select.sampleRate option[value='24000']").attr("disabled", "disabled")) : e === ProviderTypes.AI102 ? ($("select.sampleRate option[value='48000']").removeAttr("disabled"), editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='24000']").removeAttr("disabled"), $("select.sampleRate option[value='22050']").removeAttr("disabled"), $("select.sampleRate option[value='8000']").removeAttr("disabled"), $("select.sampleRate option[value='44100']").removeAttr("disabled")) : e !== ProviderTypes.AI103 && e !== ProviderTypes.PRO1 || ($("select.sampleRate option[value='48000']").removeAttr("disabled"), editSelected) || $("select.sampleRate").val("48000").change()) : "neural" == t && ("mp3" == a || "ogg_vorbis" == a ? ($("select.sampleRate option[value='24000']").removeAttr("disabled"), $("select.sampleRate option[value='22050']").removeAttr("disabled"), $("select.sampleRate option[value='16000']").removeAttr("disabled"), $("select.sampleRate option[value='8000']").removeAttr("disabled"), $("select.sampleRate option[value='48000']").removeAttr("disabled"), e == ProviderTypes.AI101 ? (editSelected || $("select.sampleRate").val("24000").change(), $("select.sampleRate option[value='48000']").attr("disabled", "disabled"), $("select.sampleRate option[value='44100']").attr("disabled", "disabled")) : e == ProviderTypes.AI102 ? (editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='44100']").removeAttr("disabled")) : e === ProviderTypes.AI103 || e === ProviderTypes.PRO1 ? (editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='22050']").attr("disabled", "disabled"), $("select.sampleRate option[value='8000']").attr("disabled", "disabled"), $("select.sampleRate option[value='44100']").attr("disabled", "disabled")) : e == ProviderTypes.AI104 && (editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='22050']").attr("disabled", "disabled"), $("select.sampleRate option[value='16000']").attr("disabled", "disabled"), $("select.sampleRate option[value='8000']").attr("disabled", "disabled"), $("select.sampleRate option[value='44100']").attr("disabled", "disabled"))) : "wav" == a && ($("select.sampleRate option[value='16000']").removeAttr("disabled"), $("select.sampleRate option[value='24000']").removeAttr("disabled"), $("select.sampleRate option[value='22050']").attr("disabled", "disabled"), $("select.sampleRate option[value='8000']").attr("disabled", "disabled"), $("select.sampleRate option[value='44100']").attr("disabled", "disabled"), $("select.sampleRate option[value='48000']").removeAttr("disabled"), e == ProviderTypes.AI101 ? (editSelected || $("select.sampleRate").val("16000").change(), $("select.sampleRate option[value='24000']").attr("disabled", "disabled"), $("select.sampleRate option[value='48000']").attr("disabled", "disabled")) : e == ProviderTypes.AI102 ? (editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='22050']").removeAttr("disabled"), $("select.sampleRate option[value='8000']").removeAttr("disabled"), $("select.sampleRate option[value='44100']").removeAttr("disabled")) : e == ProviderTypes.AI103 ? editSelected || $("select.sampleRate").val("48000").change() : e === ProviderTypes.AI104 && (editSelected || $("select.sampleRate").val("48000").change(), $("select.sampleRate option[value='16000']").attr("disabled", "disabled"))))
}
HtmlEntities.map = {
    "'": "&apos;",
    "<": "&lt;",
    ">": "&gt;"
}, HtmlEntities.encode = function(e) {
    var a, t = HtmlEntities.map;
    for (a in e = (e = e.replace(/&/g, "&amp;")).replace(/"/g, "&quot;"), t) {
        var o = t[a],
            i = new RegExp(a, "g");
        e = e.replace(i, o)
    }
    return e
}, $("#saveFileForm").on("submit", function(e) {
    e.preventDefault();
    var e = $("#fileNameInput").val(),
        a = $("#saveModal #saveFileForm .saveVoiceId").val();
    if (!e) return alert("enter a name");
    e = {
        fileName: e,
        voiceId: a || voice ? ._id
    };
    $("#saveFileSubmit").prop("disabled", !0), $.ajax({
        headers: {
            "CSRF-Token": token
        },
        type: "POST",
        url: "/voice/saveas",
        data: JSON.stringify(e),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        cache: !0,
        success: function(e) {
            if (1 != e.success) return e.name && ($("#saveFileSubmit").text("Failed"), $.notify(" This name exists ", {
                type: "danger",
                icon: "warning"
            })), $.notify(" " + (e ? .message || "Error while uploading Cloud Save"), {
                type: "danger",
                icon: "warning"
            }), setTimeout(() => {
                reEnableSaveModal()
            }, 1e3);
            $("#saveFileSubmit").addClass("btn-success"), $("#saveFileSubmit").text("Saved!"), $.notify(" Cloud file is saved successfully ", {
                type: "success",
                icon: "check"
            }), setTimeout(() => {
                $("#saveModal").modal("hide")
            }, 1e3), voice.path = e.path
        }
    }).catch(e => {
        $.notify(" " + (e.responseText || "Error, Please try again later"), {
            type: "danger",
            icon: "warning"
        })
    })
}), $("#voice-settings-versions-tabs button").on("click", function(e) {
    e.preventDefault(), $(this).tab("show"), voice.master_VC = $(this).attr("aria-controls"), $("#settings-tabContent .tab-pane").removeClass("active show"), $($(this).attr("data-bs-target")).addClass("active show"), handleVoiceSettingsText(voice ? .master_VC), handleVoiceSettingsSampleRate(voice ? .master_VC)
});
const buildPagination = (t, o, e, i, r, s, n) => {
        var l = Math.ceil(o / e);
        if ($(i).show(), 0 !== l) {
            let a = `<li onclick="${1===t?"":r+"(event)"||"onPrev(event)"}" class="page-item page-prev"><button ${1===t?"disabled":""} class="page-link"><i class="fas fa-chevron-left"></i></button></li>`;
            if (7 < Number(l)) {
                var c = t + 4 <= l ? t + 4 : l,
                    o = (o = t <= l - 7 ? 1 === t ? t : 2 === t ? t - 1 : t - 2 : t - 4) <= 0 ? 1 : o;
                (c === l && 1 < o || 1 < t - 7) && (a = a + `<li onclick="${s||"onPageClick"}(event)" class="page-item page-1"><button class="page-link page-nums" page-num="1">1</button></li>` + `<li onclick="${s||"onPageClick"}(event)" class="page-item page-2"><button class="page-link page-nums" page-num="2">...</></li>`);
                for (let e = o; e < c; e++) {
                    var d = `<li onclick="${s||"onPageClick"}(event)" class="page-item page-${e} ${t===e?"active":""}"><button class="page-link page-nums" page-num="${e}">${e}</button></li>`;
                    a += d
                }
                c !== l && (a += `<li onclick="${s||"onPageClick"}(event)" class="page-item page-${l-1}"><button class="page-link page-nums" page-num="${l-1}">...</></li>`)
            } else
                for (let e = 1; e < l; e++) {
                    var p = `<li onclick="${s||"onPageClick"}(event)" class="page-item page-${e} ${t===e?"active":""}"><button class="page-link page-nums" page-num="${e}">${e}</button></li>`;
                    a += p
                }
            a = a + `<li onclick="${s||"onPageClick"}(event)" class="page-item page-${l} ${t===l?"active":""}"><button class="page-link page-nums" page-num="${l}">${l}</button></li>` + `<li onclick="${t===l?"":n+"(event)"||"onNext(event)"}" class="page-item page-next"><button ${t===l?"disabled":""} class="page-link"><i class="fas fa-chevron-right"></i></button></li>`, $("." + (i || "pagination")).html(a), 1 !== Number(t) ? ($(".page-prev").removeClass("disabled"), $(".page-prev button").attr("disabled", !1)) : ($(".page-prev").addClass("disabled"), $(".page-prev button").attr("disabled", !0)), Number(t) !== Number(l) ? ($(".page-next").removeClass("disabled"), $(".page-next button").prop("disabled", !1)) : ($(".page-next").addClass("disabled"), $(".page-next button").prop("disabled", !0)), $(`.${i||"pagination"} li`).removeClass("active"), $(`.${i||"pagination"} li.page-` + t).addClass("active")
        } else {
            e = (e = `<li onclick="${r||"onPrev"}(event)" class="page-item page-prev"><button class="page-link"><i class="fas fa-arrow-left"></i></button></li>`) + `<li onclick="${s||"onPageClick"}(event)" class="page-item page-${l} ${t===l?"active":""}"><button class="page-link page-nums" page-num="${l}">${l}</button></li>` + `<li onclick="${n||"onNext"}(event)" class="page-item page-next"><button class="page-link"><i class="fas fa-arrow-right"></i></button></li>`;
            $("." + (i || "pagination")).html(e), $(".page-next").addClass("disabled"), $(".page-next button").prop("disabled", !0), $(".page-prev").addClass("disabled"), $(".page-prev button").prop("disabled", !0)
        }
    },
    handleTextAreaText = (jQuery.fn.extend({
        focusOnPos: function(o) {
            jQuery.each(this, function(e, a) {
                var t;
                this.createTextRange ? ((t = this.createTextRange()).move("character", o), t.select()) : this.setSelectionRange ? (this.setSelectionRange(o, o), this.focus(), this.setSelectionRange(o, o)) : this.focus()
            })
        }
    }), (e, a) => {
        e && (e = e ? .substring(0, a), $("#main-textarea").val(e), addTextAreaCount(e)), a && $(".jQTAreaValue").html(a), $("#main-textarea").highlightWithinTextarea("update")
    });

function numberWithCommas(e) {
    return e.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
}
const addTextAreaCount = e => {
    let a;
    a = void 0 !== e ? e ? .length || 0 : $("#main-textarea").val().length, $(".jQTAreaCount").html(a), voice.Provider === ProviderTypes.PRO_PLUS ? (voice.proEngine === ProEngineTypes.TURBO ? ($(".pro-chars").html(`(${numberWithCommas(3*a)} pro)`), $(".pro-engine-count").html("3x")) : ($(".pro-chars").html(`(${numberWithCommas(6*a)} pro)`), $(".pro-engine-count").html("6x")), $(".pro-chars").show()) : voice.Provider === ProviderTypes.PRO2 ? ($(".pro-chars").html(`(${numberWithCommas(5*a)} pro)`), $(".pro-chars").show()) : $(".pro-chars").hide()
};

function wrapText(e, a, t) {
    var e = $("#" + e),
        o = e.val().length,
        i = e[0].selectionStart,
        r = e[0].selectionEnd,
        s = e.val().substring(i, r),
        a = a + s + t,
        t = (e.val(e.val().substring(0, i) + a + e.val().substring(r, o)), handleHistoryUpdate(e), e.highlightWithinTextarea("update"), 0 === s ? .length ? r + a ? .length : r + a ? .length - s ? .length);
    e.focusOnPos(t)
}
const insertEffectHandler = (e, a) => {
        let t = "",
            o = "";
        "break" === e && (t = `<break time="${a}"/>`), "duration" === e && (t = `<duration value="${a}"/>`), "lang-skill" === e && (a = String(a).toLocaleLowerCase(), t = `<${a}>`, o = `</${a}>`), "emphasis" === e && (t = `<emphasis level="${a}">`, o = "</emphasis>"), "speed" === e && (t = `<prosody rate="${a}">`, o = "</prosody>"), "pitch" === e && (t = `<prosody pitch="${a}">`, o = "</prosody>"), "volume" === e && (t = `<prosody volume="${a}">`, o = "</prosody>"), "say-as" === e && (t = `<say-as interpret-as="${a}">`, o = "</say-as>"), "other" === e && (t = `<${a}>`, o = `</${a}>`);
        e = $("#main-textarea").val(), a = Number($("#limit").val());
        e ? .length + t ? .length < a && wrapText("main-textarea", t, o)
    },
    closeAllSliders = ($(".insert-effect").click(function() {
        var e = $(this).attr("tag"),
            a = $(this).attr("value");
        insertEffectHandler(e, a)
    }), $('[data-target="#registerModal"]').click(function() {
        $("#loginModal").modal("hide"), $("#forgotModal").modal("hide")
    }), $('[data-target="#loginModal"]').click(function() {
        $("#registerModal").modal("hide"), $("#forgotModal").modal("hide")
    }), $('[data-target="#forgotModal"]').click(function() {
        $("#loginModal").modal("hide"), $("#forgotModal").modal("hide")
    }), $(".audiobook-sliders").on("hide.bs.dropdown", function(e) {
        e.stopPropagation(), e.preventDefault()
    }), $(".main-effect-non-sliders button").on("click", () => {
        closeAllSliders()
    }), e => {
        "duration" !== e && $(".duration-dropdown").removeClass("show"), "pauses" !== e && $(".pauses-dropdown").removeClass("show"), "pitch" !== e && $(".pitch-dropdown").removeClass("show"), "volume" !== e && $(".volume-dropdown").removeClass("show"), "speed" !== e && $(".speed-dropdown").removeClass("show"), "clarity" !== e && $(".clarity-dropdown").removeClass("show"), "stability" !== e && $(".stability-dropdown").removeClass("show"), "style" !== e && $(".style-dropdown").removeClass("show"), "pro1Languages" !== e && $(".pro1Languages-dropdown").removeClass("show")
    }),
    renderLanguagesInPro1Lang = ($("#speed-btn").on("click", () => {
        closeAllSliders("speed")
    }), $("#pause-btn").on("click", () => {
        closeAllSliders("pauses")
    }), $("#duration-btn").on("click", () => {
        closeAllSliders("duration")
    }), $("#pitch-btn").on("click", () => {
        closeAllSliders("pitch")
    }), $("#volume-btn").on("click", () => {
        closeAllSliders("volume")
    }), e => {
        if (e ? .length) {
            let a = "";
            e ? .map(e => {
                a += `<button aria-label="${e?.name}" onclick="insertEffectHandler('lang-skill', '${e?.value}')" class="dropdown-item"
            type="button" id="${e?.value}">${e?.name} <span class="text-muted">(${e?.value})</span></button>`
            }), $(".pro1Languages-menu").html(a)
        } else $(".pro1Languages-menu").html('<div class="pl-4"><small>No language found</small></div>')
    }),
    filterProLanguages = e => {
        if (!e ? .length) return renderLanguagesInPro1Lang(pro1Languages);
        const a = new RegExp(".*" + e, "i");
        e = pro1Languages ? .filter(e => String(e ? .value).match(a) || String(e ? .name).match(a));
        renderLanguagesInPro1Lang(e)
    },
    convertDate = ($(".pro1Languages-dropdown input").on("input", e => {
        e = e.target.value;
        filterProLanguages(e)
    }), $("#pro1Languages-btn").on("click", () => {
        closeAllSliders("pro1Languages");
        var e = $(".pro1Languages-dropdown input").val();
        filterProLanguages(e)
    }), $("#proSettings-btn").on("click", () => {
        closeAllSliders(""), $("#proSettingsModal").modal("show")
    }), $(".pauses-dropdown .submit").on("click", e => {
        e.stopPropagation();
        e = Number($(".ion_pause")[0].value);
        if (0 === e) return $(".pauses-dropdown").toggle();
        wrapText("main-textarea", `<break time="${e<1?1e3*e+"ms":e+"s"}"/>`, ""), $(".pauses-dropdown").removeClass("show")
    }), $(".ion_pause").on("input", a => {
        $(".pauseNumber").toArray().forEach(e => {
            e.value = Number(a.target.value)
        }), $(".ion_pause").toArray().forEach(e => {
            e.value = Number(a.target.value)
        })
    }), $(".pauseNumber").on("input", e => {
        var a = document.getElementsByClassName("ion_pause");
        let t = Number(e.target.value);
        6 < t && (t = 6, $(".pauseNumber").toArray().forEach(e => {
            e.value = 6
        })), a.forEach(e => {
            e.value = t, e.style.backgroundSize = t / 6 * 100 + "% 100%"
        })
    }), $(".pauses-dropdown .cancel").on("click", e => {
        e.stopPropagation(), $(".pauses-dropdown").removeClass("show")
    }), $(".durations-dropdown .submit").on("click", e => {
        e.stopPropagation();
        e = $("#ion_duration").val();
        if ("0" === e) return $(".durations-dropdown").toggle();
        wrapText("main-textarea", `<duration value="${e}s"/>`, ""), $(".durations-dropdown").removeClass("show")
    }), $(".durations-dropdown .cancel").on("click", e => {
        e.stopPropagation(), $(".durations-dropdown").removeClass("show")
    }), $(".speed-dropdown .submit").on("click", e => {
        e.stopPropagation(), wrapText("main-textarea", `<prosody rate="${$("#ion_textarea_speed").val()-100}%">`, "</prosody>"), $(".speed-dropdown").removeClass("show")
    }), $(".speed-dropdown .cancel").on("click", e => {
        e.stopPropagation(), $(".speed-dropdown").removeClass("show")
    }), $(".pitch-dropdown .submit").on("click", e => {
        e.stopPropagation(), wrapText("main-textarea", `<prosody pitch="${$("#ion_textarea_pitch").val()-100}%">`, "</prosody>"), $(".pitch-dropdown").removeClass("show")
    }), $(".pitch-dropdown .cancel").on("click", e => {
        e.stopPropagation(), $(".pitch-dropdown").removeClass("show")
    }), $(".volume-dropdown .submit").on("click", e => {
        e.stopPropagation(), wrapText("main-textarea", `<prosody volume="${$("#ion_textarea_volume").val()-20}%">`, "</prosody>"), $(".volume-dropdown").removeClass("show")
    }), $(".volume-dropdown .cancel").on("click", e => {
        e.stopPropagation(), $(".volume-dropdown").removeClass("show")
    }), e => {
        var e = new Date(e),
            a = 12 < e.getHours() ? 10 <= e.getHours() - 12 ? e.getHours() - 12 : "0" + (e.getHours() - 12) : 10 <= e.getHours() ? e.getHours() : "0" + e.getHours(),
            t = e.getMinutes() < 10 ? "0" + e.getMinutes() : e.getMinutes(),
            o = 12 < e.getHours() ? "pm" : "am";
        return e.getDate() + " " + ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][e.getMonth()] + " " + e.getFullYear() + " " + a + ":" + t + o
    }),
    voiceEffectLabelClick = ($(document).mouseup(function(e) {
        var a = $(".pitch-dropdown"),
            t = $(".volume-dropdown"),
            o = $(".speed-dropdown"),
            i = $(".pauses-dropdown"),
            r = $(".durations-dropdown"),
            s = $("#pitch-btn"),
            n = $("#volume-btn"),
            l = $("#speed-btn"),
            c = $("#pause-btn"),
            d = $("#duration-btn");
        a.is(e.target) || 0 !== a.has(e.target).length || s.is(e.target) || 0 !== s.has(e.target).length || a.dropdown("hide"), t.is(e.target) || 0 !== t.has(e.target).length || n.is(e.target) || 0 !== n.has(e.target).length || t.dropdown("hide"), o.is(e.target) || 0 !== o.has(e.target).length || l.is(e.target) || 0 !== l.has(e.target).length || o.dropdown("hide"), i.is(e.target) || 0 !== i.has(e.target).length || c.is(e.target) || 0 !== c.has(e.target).length || i.dropdown("hide"), r.is(e.target) || 0 !== r.has(e.target).length || d.is(e.target) || 0 !== d.has(e.target).length || r.dropdown("hide")
    }), e => {
        $(e).prev("input").prop("disabled") || $(e).prev("input").prop("checked", !0)
    });

function Voice_effects(e, a) {
    ["breathing", "whispered", "conversational", "news", "drc", "customersupport", "assistant", "narration", "happy", "sad", "angry", "empathic", "calm", "excited", "friendly", "hopeful", "shouting", "terrified", "unfriendly", "feared", "serious", "soft"].map(e => {
        $(`#voice-effects input[id='effect-${e}']`).parent(".radio-control").hide(), $(`#voice-effects input[id='effect-${e}']`).removeAttr("checked"), $(`#${e}_effect`).hide()
    }), e ? .map(e => {
        $(`#voice-effects input[id='effect-${String(e).toLocaleLowerCase()}']`).parent(".radio-control").show(), $(`#voice-effects input[id='effect-${String(e).toLocaleLowerCase()}']`).removeAttr("checked").removeAttr("disabled")
    }), a ? .map(e => {
        $(`#${String(e).toLocaleLowerCase()}_effect`).show()
    }), $('#voice-effects input[id="effect-default"]').prop("checked", !0), 0 === a ? .length ? $("#editor_effect").hide() : $("#editor_effect").show()
}
const resetPauseSettings = () => {
    $(".pauseNumber").toArray().forEach(e => {
        e.value = 3
    }), $(".ion_pause").toArray().forEach(e => {
        e.value = 3, e.style.backgroundSize = "50% 100%"
    })
};

function v_provider(e, a, t, o, i) {
    $("#editor_emphasis").show(), $("#editor_volume").show(), $("#master-v1-voice-volume").show(), $("#basic-v1-voice-volume").show(), $("#voice-settings-versions-tabs li").show(), $("#editor_proSettings").hide(), $(".basic-editor-effect").show(), $(".pro1Lang").hide(), e === ProviderTypes.AI101 || e === ProviderTypes.AI102 || e === ProviderTypes.AI103 || e === ProviderTypes.AI104 ? $(".editor-box .editor-effects").show() : e !== ProviderTypes.AI106 && e !== ProviderTypes.AI112 && e !== ProviderTypes.AI113 && e !== ProviderTypes.PRO_PLUS && e !== ProviderTypes.PRO1 || (toggleVoiceEffects("advanced_v2"), $("#voice-settings-versions-tabs li").hide(), $(".editor-box .editor-effects").hide()), "standard" === t ? e === ProviderTypes.AI101 ? $("#editor_effect").show() : $("#editor_effect").hide() : "neural" === t && (e === ProviderTypes.AI101 ? ($("#master-v1-voice-pitch").hide(), $("#basic-voice-pitch").hide(), $("#basic-voice-pitch select").val("default"), $("#ion_pitch").val(100), handleInputChange("#ion_pitch", 0, "pitch"), $("#editor_pitch").hide(), $("#editor_emphasis").hide(), $('input[name="pitch"]').attr("disabled", "disabled").removeAttr("checked")) : e === ProviderTypes.AI102 || e === ProviderTypes.AI103 || e === ProviderTypes.PRO1 ? ($("#master-v1-voice-pitch").show(), $("#basic-voice-pitch").show(), $("#editor_pitch").show(), $('input[name="pitch"]').removeAttr("disabled")) : e === ProviderTypes.AI104 && ($("#master-v1-voice-pitch").show(), $("#basic-voice-pitch").show(), $("#editor_pitch").show(), $("#editor_emphasis").hide(), $("#editor_volume").hide(), $("#master-v1-voice-volume").hide(), $("#basic-voice-volume").hide(), $('input[name="pitch"]').removeAttr("disabled"))), e === ProviderTypes.PRO1 && $(".pro1Lang").show(), e === ProviderTypes.PRO_PLUS && ($("#editor_proSettings").show(), $(".basic-editor-effect:not(#editor_pauses)").hide()), Format_provider(e, a, t), Voice_effects(o, i), resetPauseSettings()
}

function load_js() {
    var e = document.getElementsByTagName("head")[0],
        a = document.createElement("script");
    a.src = "https://apis.google.com/js/platform.js", e.appendChild(a)
}
$(function() {
    "use strict";
    var e, a, t, o, i = navigator.userAgent;
    e = -1 < i.indexOf("iPhone") || -1 < i.indexOf("iPad") || -1 < i.indexOf("iPod") ? "touchstart" : "mousedown", $(".ripple").on(e, function(e) {
        0 === $(this).find(".ink").length && $(this).prepend("<span class='ink'></span>"), (a = $(this).find(".ink")).removeClass("animate"), a.height() || a.width() || (t = Math.max($(this).outerWidth(), $(this).outerHeight()), a.css({
            height: t,
            width: t
        })), t = e.originalEvent.pageX - $(this).offset().left - a.width() / 2, o = e.originalEvent.pageY - $(this).offset().top - a.height() / 2, a.css({
            top: o + "px",
            left: t + "px"
        }).addClass("animate")
    })
});
const getPureText = e => {
        var a = document.createElement("div");
        return a.innerHTML = e, a.textContent || a.innerText || ""
    },
    mainTextHistory = new window.UndoRedojs(5),
    handleHistoryUpdate = e => {
        mainTextHistory.current() !== e.val() && (1 < e.val().length - mainTextHistory.current().length || e.val().length - mainTextHistory.current().length < -1 || e.val().length - mainTextHistory.current().length == 0 ? mainTextHistory.record(e.val(), !0) : mainTextHistory.record(e.val())), addTextAreaCount(e.val())
    },
    find_unclosed_tags = t => {
        t = t.toLowerCase();
        let o = [],
            i = [];
        return ["new", "speak", "breathing", "soft", "whispered", "prosody", "emphasis", "say-as", "amazon:domain", "mstts:express-as", "amazon:effect"].forEach(function(e) {
            var a = "</" + e + ">";
            0 != (t.match(new RegExp("<" + e + "( |>)", "g")) || []).length - (t.match(new RegExp(a, "g")) || []).length && (i.push(e), o.push("Open/close mismatch for tag (" + e + ")."))
        }), {
            misTags: i,
            misMatches: o
        }
    },
    find_closing_tag = t => {
        t = t.toLowerCase();
        let o = [];
        return ["new", "speak", "breathing", "soft", "whispered", "prosody", "emphasis", "say-as", "amazon:domain", "mstts:express-as", "amazon:effect"].forEach(function(e) {
            var a = "</" + e + ">";
            0 != (t.match(new RegExp(a, "g")) || []).length && o.push(e)
        }), o
    };
let audioBookText = [],
    textAreaErros = [],
    splitCheck = [],
    splitLimit = 2e3,
    checkErrors = [];

function TextareaChange(e, a) {
    let t = a.target.value;
    a = (a.originalEvent || a) ? .clipboardData ? .getData("text/plain"), textAreaErros = [], audioBookText = [], a && (t += a), a = find_unclosed_tags(t).misMatches;
    a && 0 < a.length ? ($(".textarea-error").show(), $(".textarea-error").html(`<div class="alert alert-danger">${a?.join("\n")}</div>`), $(".textarea-error").addClass("show")) : ($(".textarea-error").hide(), $(".textarea-error").html(""), $(".textarea-error").removeClass("show"), (0 < checkErrors ? .length || t ? .length > splitLimit && !splitCheck ? .includes(splitLimit)) && $.ajax({
        type: "POST",
        url: "/voice/tags-validation",
        data: JSON.stringify({
            text: t
        }),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        success: e => {
            checkErrors = [], e ? .success ? ($(".textarea-error").hide(), $(".textarea-error").html(""), $(".textarea-error").removeClass("show")) : (checkErrors.push(`<div class="alert alert-danger">${e?.message}</div>`), $(".textarea-error").show(), $(".textarea-error").html(checkErrors ? .join("\n")), $(".textarea-error").addClass("show")), splitCheck ? .includes(splitLimit - 500) || (splitCheck ? .push(splitLimit), splitLimit += 500)
        }
    }).catch(e => {
        $(".textarea-error").show(), $(".textarea-error").html(`<div class="alert alert-danger">${e?.message}</div>`), $(".textarea-error").addClass("show")
    }))
}
const handleProVoice = e => {
    "pro-plus" === voice.Provider && 1e4 < e ? .length && ($(".textarea-error").show(), $(".textarea-error").html('<div class="alert alert-danger">You have exceeded the Pro+ Voice character support limit. Pro+ Voices only support up to 10000 text characters.</div>'), $(".textarea-error").addClass("show"))
};

function resendOTPCode() {
    var e = {
        username: $("#loginEmail").val(),
        twoFactorAuth: twoFactorAuth
    };
    twoFactorAuth = "phone-email", $(".resend-otp-code").prop("disabled", !0), $(".try-another-2fa").hide(), $(".loginErrors").html(""), $.ajax({
        type: "POST",
        url: "/auth/resend-otp",
        data: JSON.stringify(e),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        cache: !0
    }).done(a => {
        if (a ? .success) {
            let e = "";
            a.email && (e += "email to " + a.email), a.email && a.phone && (e += " and "), a.phone && (e += "a text message to " + a.phone), $("#loginCode").focus(), $(".resend-otp-code").show(), $(".two-factor-text").html(`
                We just sent you a 6-digit authentication code via ${e}, the code will expire in 10 minutes. 
            `), $.notify(" " + a ? .message, {
                type: "success",
                icon: "check"
            })
        } else $.notify(" " + a ? .message, {
            type: "danger",
            icon: "warning"
        });
        setTimeout(() => {
            $(".resend-otp-code").prop("disabled", !1)
        }, 3e3)
    }).catch(e => {
        429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
            type: "danger",
            icon: "warning"
        }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
            type: "danger",
            icon: "warning"
        })
    })
}

function resendVerifyCode() {
    var e = $("#loginEmail").val();
    $.ajax({
        type: "POST",
        url: "/auth/resend",
        data: JSON.stringify({
            email: e
        }),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        cache: !0
    }).done(e => {
        let a;
        a = e ? .success ? `<div class="alert alert-success">${e.message}</div>` : `<div class="alert alert-danger">${e.message}</div>`, $(".loginErrors").html(a)
    }).catch(e => {
        429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
            type: "danger",
            icon: "warning"
        }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
            type: "danger",
            icon: "warning"
        })
    })
}

function resendCodeSignup() {
    var e = $("#registerEmail").val();
    $.ajax({
        type: "POST",
        url: "/auth/resend",
        data: JSON.stringify({
            email: e
        }),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        cache: !0
    }).done(e => {
        let a;
        a = e ? .success ? `<div class="alert alert-success">${e.message}</div>` : `<div class="alert alert-danger">${e.message}</div>`, $(".signupErrors").html(a)
    }).catch(e => {
        429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
            type: "danger",
            icon: "warning"
        }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
            type: "danger",
            icon: "warning"
        })
    })
}
$(document).ready(function(e) {
    $("#main-undo").on("click", e => {
        e.preventDefault(), void 0 !== mainTextHistory.undo(!0) && $("#main-textarea").val(mainTextHistory.undo()), $("#main-textarea").highlightWithinTextarea("update")
    }), $("#main-redo").on("click", () => {
        void 0 !== mainTextHistory.redo(!0) && $("#main-textarea").val(mainTextHistory.redo()), $("#main-textarea").highlightWithinTextarea("update")
    }), $("#main-textarea").on("input paste", function(e) {
        e.target.value;
        handleHistoryUpdate($(this)), TextareaChange(this, e), handleProVoice(e.target.value), $("#main-textarea").highlightWithinTextarea("update")
    }), $("#main-textarea").on("keydown", function(e) {
        90 === e.which && e.ctrlKey && e.shiftKey ? void 0 !== mainTextHistory.redo(!0) && $("#main-textarea").val(mainTextHistory.redo()) : 90 === e.which && e.ctrlKey && void 0 !== mainTextHistory.undo(!0) && $("#main-textarea").val(mainTextHistory.undo()), $("#main-textarea").highlightWithinTextarea("update")
    }), $("#audiobook-synthesis #main-textarea").on("input", function(e) {
        localStorage.setItem("audiobook-text", e.target.value)
    }), $("#standard-synthesis #main-textarea").on("input", function(e) {
        project ? localStorage.setItem(`project-${project?._id}-text`, e.target.value) : localStorage.setItem("main-text", e.target.value)
    }), $("#standard-synthesis #main-textarea").on("focus", function(e) {
        closeAllSliders()
    }), $("#audiobook-synthesis #main-textarea").on("input", function(e) {
        closeAllSliders()
    })
}), $("#loginModal").on("show.bs.modal", () => {
    $("#btnLogin").prop("disabled", !1)
}), $("#formLogin").on("submit", e => {
    e.preventDefault();
    const a = $("#loginEmail").val(),
        t = $("#loginPassword").val(),
        o = "on" === $("#basic_checkbox_1:checked").val();
    $("#btnLogin").prop("disabled", !0), $("#btnLogin").html(ajaxSpinner + " Login"), twoFactorAuth = null, grecaptcha.ready(function() {
        grecaptcha.execute("6LdyG7YZAAAAAP_Qdm5J9FrhPpTZgkasrl4QyO3D", {
            action: "login"
        }).then(function(e) {
            e = {
                username: a,
                password: t,
                token: e,
                rememberMe: o
            };
            $(".loginErrors").html(""), $.ajax({
                type: "POST",
                url: "/auth",
                data: JSON.stringify(e),
                contentType: "application/json",
                processData: !1,
                dataType: "json",
                cache: !0,
                success: function(a) {
                    if (1 == a.success)
                        if (a ? .twoFactor) {
                            if ($("#loginModal").modal("hide"), a ? .appAuth) twoFactorAuth = "app", $(".resend-otp-code").hide(), $(".try-another-2fa").show(), $(".two-factor-text").html(a ? .message);
                            else {
                                let e = "";
                                twoFactorAuth = "phone-email", a.email && (e += "email to " + a.email), a.email && a.phone && (e += " and "), a.phone && (e += "a text message to " + a.phone), $(".try-another-2fa").hide(), $(".resend-otp-code").show(), $(".two-factor-text").html(`
                            We just sent you a 6-digit authentication code via ${e}, the code will expire in 10 minutes. 
                        `)
                            }
                            setTimeout(() => {
                                $("#twoFactorModal").modal("show"), $("#loginCode").focus()
                            }, 100)
                        } else {
                            twoFactorAuth = null;
                            $(".loginErrors").html('<div class="alert alert-success">Logged In, You will be redirected now</div>'), setTimeout(() => {
                                window.location.replace("/")
                            }, 300)
                        }
                    else {
                        let e;
                        e = !0 === a ? .verified ? `<div class="alert alert-danger">
                    ${a.message}, <button type="button" class="btn btn-link p-0" onclick="resendVerifyCode()">Resend Email</button>
                    </div>` : `<div class="alert alert-danger">${a.message}</div>`, $(".loginErrors").html(e)
                    }
                }
            }).done(e => {
                $("#btnLogin").prop("disabled", !1), $("#btnLogin").html("Login")
            }).catch(e => {
                $("#btnLogin").prop("disabled", !1), $("#btnLogin").html("Login"), 429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
                    type: "danger",
                    icon: "warning"
                }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
                    type: "danger",
                    icon: "warning"
                })
            })
        })
    })
}), $("#loginCode").on("input", e => {
    6 !== e.target.value ? .length ? $("#btnTwoFactor").prop("disabled", !0) : $("#btnTwoFactor").prop("disabled", !1)
}), $("#twoFactorLogin").on("submit", e => {
    e.preventDefault();
    const a = $("#loginEmail").val(),
        t = $("#loginPassword").val(),
        o = "on" === $("#basic_checkbox_1:checked").val(),
        i = $("#loginCode").val();
    $("#btnTwoFactor").prop("disabled", !0), $("#btnTwoFactor").html(ajaxSpinner + " Login"), grecaptcha.ready(function() {
        grecaptcha.execute("6LdyG7YZAAAAAP_Qdm5J9FrhPpTZgkasrl4QyO3D", {
            action: "submit"
        }).then(function(e) {
            e = {
                username: a,
                token: e,
                password: t,
                twoFactorAuth: twoFactorAuth,
                rememberMe: o,
                code: i
            };
            $(".loginErrors").html(""), $.ajax({
                type: "POST",
                url: "/auth/two-factor",
                data: JSON.stringify(e),
                contentType: "application/json",
                processData: !1,
                dataType: "json",
                cache: !0,
                success: function(e) {
                    1 == e.success ? (twoFactorAuth = null, $(".loginErrors").html('<div class="alert alert-success">Logged In, You will be redirected now</div>'), setTimeout(() => {
                        window.location.replace("/")
                    }, 300)) : $(".loginErrors").html(`<div class="alert alert-danger">${e?.message}</div>`)
                }
            }).done(e => {
                $("#btnTwoFactor").prop("disabled", !1)
            }).catch(e => {
                429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
                    type: "danger",
                    icon: "warning"
                }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
                    type: "danger",
                    icon: "warning"
                })
            })
        })
    })
}), $("#formForgot").on("submit", e => {
    e.preventDefault();
    e = $("#forgotEmail").val(), $("#btnForgot").prop("disabled", !0), e = {
        email: e
    };
    $.ajax({
        headers: {
            "CSRF-Token": token
        },
        type: "POST",
        url: "/auth/reset-email",
        data: JSON.stringify(e),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        cache: !0,
        success: function(e) {
            var a;
            $("#btnForgot").prop("disabled", !1), 1 == e.success ? (a = `<div class="alert alert-success">${e.message}</div>`, $(".forgotErrors").html(a), $("#forgotEmail").val("")) : (a = `<div class="alert alert-danger">${e.message}</div>`, $(".forgotErrors").html(a))
        }
    }).catch(e => {
        $("#btnForgot").prop("disabled", !1), 429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
            type: "danger",
            icon: "warning"
        }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
            type: "danger",
            icon: "warning"
        })
    })
}), $("#formResetPassword").on("submit", e => {
    e.preventDefault();
    var e = $('[name="email"]').val(),
        a = $('[name="resetPasswordToken"]').val(),
        t = $('[name="newPassword"]').val(),
        o = $('[name="confirmPassword"]').val(),
        e = ($("#btnResetPassword").prop("disabled", !0), {
            email: e,
            resetPasswordToken: a,
            newPassword: t,
            confirmPassword: o
        });
    $.ajax({
        headers: {
            "CSRF-Token": token
        },
        type: "POST",
        url: "/auth/resetPassword",
        data: JSON.stringify(e),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        cache: !0,
        success: function(e) {
            var a;
            $("#btnResetPassword").prop("disabled", !1), 1 == e.success ? (a = `<div class="alert alert-success">${e.message}</div>`, $(".resetErrors").html(a), $("#formResetPassword").hide(), $("#formResetPassword_success").show()) : (a = `<div class="alert alert-danger">${e.message}</div>`, $(".resetErrors").html(a))
        }
    }).catch(e => {
        $("#btnResetPassword").prop("disabled", !1), 429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
            type: "danger",
            icon: "warning"
        }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
            type: "danger",
            icon: "warning"
        })
    })
}), $("#formContact").on("submit", e => {
    e.preventDefault();
    var t = document.getElementById("formContact"),
        e = $('[name="name"]').val(),
        a = $('[name="email"]').val(),
        o = $('[name="message"]').val(),
        i = $('[name="type"]').val(),
        e = ($("#contactBtn").prop("disabled", !0), {
            name: e,
            email: a,
            message: o,
            type: i
        });
    $.ajax({
        headers: {
            "CSRF-Token": token
        },
        type: "POST",
        url: "/auth/contact",
        data: JSON.stringify(e),
        contentType: "application/json",
        processData: !1,
        dataType: "json",
        cache: !0,
        beforeSend: function() {
            $("#contactBtn").prop("disabled", !0)
        },
        success: function(e) {
            var a;
            1 == e.success ? (a = `<p id="my-form-status">${e.message}</p>`, $(".contactErrors").html(a), t.reset(), $("#contactBtn").hide()) : (a = `<div class="alert alert-danger">${e.message}</div>`, $(".contactErrors").html(a), $("#contactBtn").prop("disabled", !1))
        }
    }).done(e => {}).catch(e => {
        $("#contactBtn").prop("disabled", !1), $.notify(" " + (e.responseText || "Error, Please try again later"), {
            type: "danger",
            icon: "warning"
        })
    })
}), $("#registerModal").on("hide.bs.modal", () => {
    $(".registerError").html("")
}), $("#register").click(() => {
    $("#type").val("register")
});
let price;
$("#formSignup").on("submit", e => {
    e.preventDefault();
    let a = $("#registerFirstName").val(),
        t = $("#registerLastName").val(),
        o = $("#registerEmail").val(),
        i = $("#registerPassword").val();
    $("#btnSignup").prop("disabled", !0), grecaptcha.ready(function() {
        grecaptcha.execute("6LdyG7YZAAAAAP_Qdm5J9FrhPpTZgkasrl4QyO3D", {
            action: "register"
        }).then(function(e) {
            data = {
                firstName: a,
                lastName: t,
                email: o,
                password: i,
                token: e,
                nonLoggedVoice: nonLoggedVoice
            }, $.ajax({
                type: "POST",
                url: "/auth/register",
                data: JSON.stringify(data),
                contentType: "application/json",
                processData: !1,
                dataType: "json",
                cache: !0,
                beforeSend: function() {
                    $("#btnSignup").prop("disabled", !0)
                },
                success: function(e) {
                    var a;
                    1 == e.success ? (a = `<div class="alert alert-success">
                ${e.message}, <button type="button" class="btn btn-link p-0" onclick="resendCodeSignup()">Resend Email</button>
                </div>`, $(".signupErrors").html(a)) : (a = `<div class="alert alert-danger">${e.message}</div>`, $(".signupErrors").html(a)), $("#btnSignup").prop("disabled", !1)
                }
            }).done(e => {}).catch(e => {
                429 === e.status ? $.notify(" " + (e ? .responseText || "Too many requests! Please slow down"), {
                    type: "danger",
                    icon: "warning"
                }) : $.notify(" " + (e.responseText || "Error, Please try again later"), {
                    type: "danger",
                    icon: "warning"
                })
            })
        })
    })
}), $(window).on("resize", function() {
    $("#main-textarea").highlightWithinTextarea("update")
}), $(document).ready(async function() {
    document.getElementById("main-textarea") && document.getElementById("main-textarea").select(), $('[data-bs-toggle="tooltip"]').tooltip({
        trigger: "manual",
        tooltipClass: "tooltip"
    }), ("/" === location.pathname ? ($("li.active").removeClass("active"), $('a[href="/standard-synthesis"]')) : ($("li.active").removeClass("active"), $('a[href="' + location.pathname + '"]'))).closest("li").addClass("active"), $("#language-selector").niceSelect({
        search: !0
    });
    !0 === $("#slider-onoffswitch").is(":checked") ? ($(".audiobook-sliders").show(), $(".audiobook-nonslider").hide()) : ($(".audiobook-sliders").hide(), $(".audiobook-nonslider").show()), $(".jQTAreaCount").html("0"), $("#clear-text").on("click", function(e) {
        e.preventDefault(), $(".jQTAreaCount").html("0"), $("textarea").val("")
    }), $('[data-toggle="tooltip"]').tooltip(), $("#registerEmail").keyup(function() {
        this.value = this.value.toLowerCase()
    });
    var e = localStorage.getItem("editor"),
        a = window.location.pathname,
        t = getUrlVars();
    "/" === a && handleMultiVoiceFeature(t ? .project ? "multivoice" : "edit" === t ? .type && t ? .voice ? "legacy" : e), "/audiobook/create" === a && $('.voices-nav button[aria-current="pro-voices"]').hide(), "/" !== a && "/audiobook/create" !== a && "/natural" !== a || (toggleVoiceEffects("advanced_v2"), "/" === a && "edit" === t.type && t.voice ? ($("#convert-button").prop("disabled", !0), await getAllLanguages(!0, voice ? .Engine), await onSingleVoiceEdit(t.voice)) : (addCachedData(), handleVoiceParamsSelect(voice), await getAllLanguages(!0, voice ? .Engine, voice ? .voiceCategory)), $("#convert-button").prop("disabled", !1))
});
const showUpdateMultiVoice = e => {
        clearTimeout(updateMultiVoiceTimeout), saveRunning = !0, $(".loading-spinner").show(), $(".live-update-multivoice").css("bottom", "80px"), $(".checkmark").hide(), $(".checkmark").removeClass("animation"), $(".checkmark__circle").removeClass("animation"), $(".checkmark__check").removeClass("animation"), updateMultiVoice()
    },
    handleVoiceSettingsText = e => {
        "advanced_v1" === e && ($(".voice-settings-mode-text").html("Advanced Settings v1"), $(".voice-settings-mode-tooltip span").html("V1 - Connects directly to AI Engines.")), "advanced_v2" === e && ($(".voice-settings-mode-text").html("Advanced Settings v2"), $(".voice-settings-mode-tooltip span").html("V2 - If voice and text are not updated, we will not charge for characters.")), "basic" === e && ($(".voice-settings-mode-text").html("Basic Settings"), $(".voice-settings-mode-tooltip span").html("Basic - Connects directly to AI Engines."))
    },
    handleVoiceSettingsSampleRate = e => {
        "advanced_v2" === e ? (voice.sampleRate = "48000", $("select.sampleRate option").toArray().forEach(e => {
            $(e).removeAttr("disabled")
        }), $("select.sampleRate").val("48000").change(), $("#sampleRate").val("48000")) : Format_provider(voice ? .Provider, voice.outputFormat, voice ? .Engine)
    },
    toggleVoiceEffects = (e = "advanced_v2") => {
        e = "advanced" === e ? "advanced_v1" : e, voice.master_VC = e;
        var a = $(`#voice-settings-versions-tabs button[aria-controls="${e}"]`);
        $("#voice-settings-versions-tabs button").removeClass("active"), $("#settings-tabContent .tab-pane").removeClass("show active"), $(a.attr("data-bs-target")).addClass("show active"), $(`#voice-settings-versions-tabs button[aria-controls="${e}"]`).addClass("active"), handleVoiceSettingsText(e), handleVoiceSettingsSampleRate(e)
    },
    updateMultiVoice = () => {
        var e = {
            voices: addedMultiVoices,
            projectId: project ? ._id,
            background: multivoiceBackground
        };
        $.ajax({
            headers: {
                "CSRF-Token": token
            },
            type: "PUT",
            url: "/multi-voice/" + project ? ._id,
            data: JSON.stringify(e),
            contentType: "application/json",
            processData: !1,
            dataType: "json",
            success: e => {
                e.success ? ($(".loading-spinner").hide(), $(".checkmark").show(), $(".checkmark").addClass("animation"), $(".checkmark__circle").addClass("animation"), $(".checkmark__check").addClass("animation"), updateMultiVoiceTimeout = setTimeout(() => {
                    $(".live-update-multivoice").css("bottom", "-70px")
                }, 2500)) : $.notify(e ? .message, {
                    type: "danger",
                    icon: "warning"
                }), saveRunning = !1
            }
        }).catch(e => {
            $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    },
    updateProject = async (e, t, o = !0) => {
        var a = { ...t
        };
        await $.ajax({
            headers: {
                "CSRF-Token": token
            },
            type: "PUT",
            url: "/projects/" + e,
            data: JSON.stringify(a),
            contentType: "application/json",
            processData: !1,
            dataType: "json",
            success: a => {
                a.success ? (o && $.notify(" Project updated successfully", {
                    type: "success",
                    icon: "check"
                }), projects = projects ? .map(e => String(e._id) === String(a.data._id) ? a.data : e), project = a.data, renderProjects(), renderProjectData(), t.autoSave && showUpdateMultiVoice()) : $.notify(a ? .message, {
                    type: "danger",
                    icon: "warning"
                })
            }
        }).catch(e => {
            $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    },
    getProjects = (e, a, t, o, i = 1, r = 5) => {
        let s = {};
        return e && (s.name = e), a && (s.sortBy = a), t && (s.sortOrder = t), o && (s.archive = o), i && (s.page = i), r && (s.limit = r), s = new URLSearchParams(s).toString(), $.ajax({
            headers: {
                "CSRF-Token": token
            },
            type: "GET",
            url: "/projects?" + s,
            processData: !1,
            dataType: "json",
            success: e => {
                if (e.success) return e ? .projects;
                handleMultiVoiceFeature("legacy"), e ? .user && $("#loginModal").modal("show"), $.notify(" " + e ? .message, {
                    type: "danger",
                    icon: "warning"
                })
            }
        }).catch(e => {
            $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    },
    getProjectData = e => {
        let o = setTimeout(() => {
            $(".project-long-loading").show()
        }, 2e3);
        $.ajax({
            type: "GET",
            url: "/projects/" + e,
            headers: {
                "CSRF-Token": token
            },
            processData: !1,
            dataType: "json",
            success: e => {
                var a, t;
                $(".page-spinner").hide(), $(".project-spinner").hide(), clearTimeout(o), $(".project-long-loading").hide(), e.success ? (addedMultiVoices = e.data.voices, project = e.data, multivoiceEnabled = !0, $(".multivoice").fadeIn(), $("#standard-synthesis").fadeIn(), $(".projects-list").fadeOut(), renderMultiVoices(), renderProjectData(), e.data.backmusic ? .file ? (multivoiceBackground = e ? .data ? .backmusic, backGroundMusic = e ? .data ? .backmusic, handleBackgroundSubmit({
                    file: {
                        name: e ? .data ? .backmusic ? .name
                    }
                })) : (multivoiceBackground = null, backGroundMusic = null, handleBackgroundSubmit()), renderBackgroundMusic(), a = localStorage.getItem(`project-${project?._id}-text`), t = Number($("#limit").val()), handleTextAreaText(a || " ", t)) : (!0 === e ? .subscription ? handleMultiVoiceFeature("legacy") : (window.history.pushState({
                    path: "/"
                }, "", "/"), handleMultiVoiceFeature("multivoice")), $.notify(" " + e ? .message, {
                    type: "danger",
                    icon: "warning"
                }))
            }
        }).catch(e => {
            $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    },
    addCachedData = () => {
        let e;
        var a = localStorage.getItem("cachedVoice");
        a && (voice = { ...voice,
            ...JSON.parse(a)
        }), "/" === window.location.pathname && (e = localStorage.getItem("main-text")), "/audiobook/create" === window.location.pathname && (e = localStorage.getItem("audiobook-text")), textLimit = Number($("#limit").val()), handleTextAreaText(e, textLimit)
    };
let $audioElement = $("<audio>"),
    playingVoice;
$(window).on("popstate", function() {
    var e = localStorage.getItem("editor"),
        a = window.location.pathname,
        t = getUrlVars();
    "/" === a && handleMultiVoiceFeature(t ? .project ? "multivoice" : e)
});
const handleAudioFormatBetweenEditorTypes = a => {
        $("#audioFormatModal .audioFormat").val("mp3").change(), ["ogg", "aac", "opus"].map(e => {
            a && "" !== a && "legacy" !== a ? $(`#audioFormatModal .audioFormat option[value="${e}"]`).hide() : $(`#audioFormatModal .audioFormat option[value="${e}"]`).show()
        })
    },
    handleMultiVoiceFeature = e => {
        if ($(".page-spinner").hide(), e && "" !== e && "legacy" !== e) {
            if ("multivoice" === e) {
                var a = $("#nav-user-id").val(),
                    t = $("#subType").val();
                if (!a || "" === a) return handleMultiVoiceFeature(), $("#loginModal").modal("show");
                if ("premium" !== t && "business" !== t) return handleMultiVoiceFeature(), $.notify("Your subscription doesn't allow use of projects", {
                    type: "danger",
                    icon: "warning"
                });
                localStorage.setItem("editor", "multivoice"), $(".convert-to-multivoice").hide(), $(".convert-to-legacy").html('<i class="fas fa-layer-group mr-1"></i> Quick Editor'), $(".convert-to-legacy").attr("onclick", "handleMultiVoiceFeature('legacy')"), $(".convert-to-legacy").attr("aria-label", "Quick Editor"), $("#standard-synthesis").hide(), $(".sticky-audio-player").hide(), $("#audioplayer-container").slideUp();
                a = getUrlVars();
                "true" === $("#paidSubscription").val() ? $(".footer").hide() : $(".footer").show(), getStorageAndCharsCount(), a.project ? ($(".page-spinner").show(), getProjectData(a ? .project), $(".projects-list").hide(), $(".projects-list .content").fadeOut()) : ($(".projects-list").fadeIn(), $(".projects-list .content").fadeIn(), window.history.pushState({
                    path: "/"
                }, "", "/"), renderProjects(!0), $(".page-spinner").hide()), textLimit = 3e3, handleTextAreaText($("#main-textarea").val(), textLimit), multivoiceEnabled = !1, project = null, $(".project-details").hide(), $(".multivoice").hide(), $(".multivoice-buttons").show(), $(".single-editor-buttons").hide()
            }
        } else {
            localStorage.setItem("editor", "legacy"), $(".convert-to-multivoice").show(), $(".convert-to-multivoice").html('<i class="fas fa-layer-group mr-1"></i> Multi Editor'), $(".convert-to-multivoice").attr("onclick", "handleMultiVoiceFeature('multivoice')"), $(".convert-to-multivoice").attr("aria-label", "Multi Editor"), $(".projects-list").hide(), $(".projects-list .content").fadeOut(), $("#standard-synthesis").show(), $(".sticky-audio-player").hide(), $("#audioplayer-container").slideUp(), multivoiceEnabled = !1, project = null, textLimit = Number($("#limit").val()), handleTextAreaText(null, textLimit), $(".project-details").hide(), $(".multivoice").hide(), $(".multivoice-buttons").hide(), $(".single-editor-buttons").show();
            t = getUrlVars();
            "edit" === t.type && t.voice || window.history.pushState({
                path: "/"
            }, "", "/"), $(".footer").show()
        }
        handleAudioFormatBetweenEditorTypes(e)
    },
    handleVoicesGender = e => {
        var a = e.filter(e => "Female" === e ? .ai_voiceGender),
            t = e.filter(e => "Male" === e ? .ai_voiceGender),
            e = e.filter(e => String(e ? .ai_voiceGender).match(new RegExp(".*child", "i")));
        $('.gender-nav a[aria-current="male"]').attr("disabled", !1), $('.gender-nav a[aria-current="female"]').attr("disabled", !1), $('.gender-nav a[aria-current="child"]').attr("disabled", !1), 0 === t ? .length && $('.gender-nav a[aria-current="male"]').attr("disabled", !0), 0 === a ? .length && $('.gender-nav a[aria-current="female"]').attr("disabled", !0), 0 === e ? .length && $('.gender-nav a[aria-current="child"]').attr("disabled", !0)
    },
    handleLanguageEngines = e => {
        var a = e ? .voice_names ? .filter(e => "standard" === e ? .ai_engine),
            e = e ? .voice_names ? .filter(e => "neural" === e ? .ai_engine);
        $('.engine-nav a[aria-current="neural"]').attr("disabled", !1), $('.engine-nav a[aria-current="standard"]').attr("disabled", !1), 0 === a ? .length && $('.engine-nav a[aria-current="standard"]').attr("disabled", !0), 0 === e ? .length && $('.engine-nav a[aria-current="neural"]').attr("disabled", !0)
    },
    handleLanguages = (e, a, t) => {
        let o = defaultLanguages;
        t === voiceCategoryTypes.PRO_VOICES ? o = proLanguages : t === voiceCategoryTypes.USER_VOICES ? o = userLanguages : t === voiceCategoryTypes.CUSTOM_VOICES ? o = customLanguages : t === voiceCategoryTypes.DEFAULT_VOICES && (o = defaultLanguages);
        let i = (e && t === voiceCategoryTypes.DEFAULT_VOICES && 0 < favoriteLanguages ? .length ? favoriteLanguages : o) ? .filter(e => filterEngineAndLanguage(e, a));
        return 0 === i ? .length && (i = (i = o ? .filter(e => filterEngineAndLanguage(e, a))) ? .map(e => "en-US" === e ? .value ? { ...e,
            selected: "selected"
        } : e), favoriteLanguages = []), i
    },
    filterEngineAndLanguage = (e, a) => {
        var t = e ? .voice_names ? .filter(e => e.ai_engine === a);
        if (e ? .engine ? .includes(a) && 0 < t ? .length) return e
    },
    addLanguagesToProFilters = e => {
        let a = '<option value="">Language</option>';
        e ? .map(e => {
            a += `<option value="${e?.value}">${e?.name}</option>`
        }), $(".pro-filters .pro-language-select").html(a)
    },
    getAllLanguages = async (e, t, a) => {
        let o = {};
        e && (o.type = "favorite"), a && (o.category = a);
        const i = window.location.pathname;
        return "/audiobook/create" === i && (o.path = "audiobook", $(`.voices-nav button[aria-current="${a}"]`).click()), $(".voice-radio-spinner").show(), $("#voice-radio-group").hide(), $(".lang-loading").html(ajaxSpinner), $("#language-selector").prop("disabled", !0), $("#language-selector").niceSelect("update"), o = new URLSearchParams(o).toString(), $.ajax({
            type: "GET",
            url: "/user/language?" + o,
            headers: {
                "CSRF-Token": token
            },
            processData: !1,
            dataType: "json",
            success: a => {
                if ($("#voice-radio-group").show(), $(".lang-loading").html(""), !0 !== a ? .success) return !1; {
                    let e;
                    allLanguages = a ? .allLanguages || [], defaultLanguages = a ? .allLanguages || [], (proLanguages = a ? .proLangs || []) ? .length && "/audiobook/create" !== window.location.pathname || voice.voiceCategory === voiceCategoryTypes.PRO_VOICES && (e = voiceCategoryTypes.DEFAULT_VOICES), (userLanguages = a ? .userLangs || []) ? .length || voice.voiceCategory === voiceCategoryTypes.USER_VOICES && (e = voiceCategoryTypes.DEFAULT_VOICES), (customLanguages = a ? .customLangs || []) ? .length ? $('.voices-nav button[aria-current="custom-voices"]').show() : ($('.voices-nav button[aria-current="custom-voices"]').hide(), voice.voiceCategory === voiceCategoryTypes.CUSTOM_VOICES && (e = voiceCategoryTypes.DEFAULT_VOICES)), e && $(`.voices-nav button[aria-current="${e}"]`).click(), favoriteLanguages = a ? .favoriteLanguages || [], pro1Languages = a ? .pro1Languages || [], addLanguagesToProFilters(pro1Languages), "/audiobook/create" !== i && (a = Object.values(voiceCategoryTypes).includes(voice ? .voiceCategory) ? voice ? .voiceCategory : voiceCategoryTypes.DEFAULT_VOICES, $(`.voices-nav button[aria-current="${a}"]`).click()), $(`.engine-nav a[aria-current="${t}"]`).click()
                }
            }
        }).catch(e => {
            $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    },
    renderLanguages = e => {
        $("#language-selector-div #language-selector").remove(), $("#language-selector-div").html('<select name="language" id="language-selector" data-placeholder="Choose your Language:"></select>');
        var a = e ? .find(e => voice ? .languageCode === e ? .value) || (0 < e ? .length ? e[0] : null);
        if (e && 0 < e ? .length)
            for (var t = 0; t < e ? .length; t++) $("#language-selector").append(`<option class="d-flex justify-content-between" value="${e[t]?.value}" 
            ${a?.value===e[t]?.value?"selected":""}>
            <span>${e[t]?.name}</span>
            <span>${e?.length>favoriteLanguages?.length&&favoriteLanguages?.map(e=>e?.value)?.includes(e[t]?.value)?"&starf;":""}</span></option>`);
        else $("#language-selector").append('<option data-display="No languages" disabled selected>No languages found</option>');
        return $("#language-selector").prop("disabled", !1), $("#language-selector").niceSelect({
            search: !0
        }), renderVoiceNames(a ? .value, voice.Engine, voice.gender), $(document).on("click.nice_select", "#language-selector-div .nice-select .option:not(.disabled)", function(e) {
            var a = $(this).closest(".nice-select");
            $(".voice-search").val(""), voice.languageCode = a.prev("select").val(), renderVoiceNames(voice.languageCode, voice.Engine, voice.gender)
        }), selectedFavoriteLanguage
    },
    getProviderBKColor = e => {
        switch (e) {
            case "ai101":
                return "#F5A5CA";
            case "ai102":
                return "#F5CCA5";
            case "ai103":
                return "#28a745";
            case "ai104":
                return "#00c5ff";
            case "ai105":
                return "#e288ff";
            case "ai106":
                return "#000000";
            case "ai112":
                return "#ff7f4d";
            case "ai113":
                return "#e9df6c";
            case "pro-plus":
                return "#DC6803";
            case "pro1":
                return "#12B76A";
            case "pro2":
                return "#ff7700";
            case "Default":
                return "#EFF8FF";
            default:
                return "#ff7700"
        }
    },
    getProviderColor = e => {
        switch (e) {
            case "ai101":
                return "#730948";
            case "ai102":
                return "#784304";
            case "ai103":
            case "ai104":
            case "ai105":
            case "ai106":
            case "ai112":
            case "ai113":
            case "pro-plus":
            case "pro1":
            case "pro2":
                return "#fff";
            case "Default":
                return "#175CD3";
            default:
                return "#fff"
        }
    },
    getEngineColor = e => {
        switch (e) {
            case "standard":
                return "#ECFDF3";
            case "neural":
                return "#BDB4FE"
        }
    };

function wrapContentsInMarquee(i) {
    var e = $(i).toArray();
    e && e ? .length && e ? .forEach(a => {
        var t = $(a)[0].scrollWidth,
            o = $(a)[0].offsetWidth;
        if (o < t) {
            let e = t - o;
            i.includes("editor-selected-voice") && (e += 6), $(a).hover(function() {
                $(this).children(".marquee").css({
                    transform: `translateX(calc(-${e}px))`
                })
            }, function() {
                $(this).children(".marquee").css({
                    transform: "translateX(0)"
                })
            })
        } else $(a).hover(function() {
            $(this).children(".marquee").css({
                transform: "translateX(-1px)"
            })
        }, function() {
            $(this).children(".marquee").css({
                transform: "translateX(0)"
            })
        })
    })
}
const filterProVoices = (e, a) => e = a && Object.values(a).length && (a ? .category && (e = e.filter(e => e.pro_usecase === a.category)), a ? .language && (e = e.filter(e => String(e.pro_language).toLocaleLowerCase() === a.language)), a ? .gender && (e = e.filter(e => e.pro_age ? .includes(a ? .gender))), a ? .age && (e = e.filter(e => e.pro_age ? .includes(a ? .age))), a ? .name) ? e.filter(e => String(e.ai_voiceWebname).toLocaleLowerCase() ? .includes(a ? .name ? .toLocaleLowerCase())) : e,
    renderVoiceNames = async (a, t, o, i, r) => {
        $("#voicesModal .card-body .voices .row.voices-list").html("");
        let s = "";
        Array(18).fill(0).map(e => s += '<div class="col-md-4 mb-2 voice-loading"><div></div></div>'), $("#voicesModal .card-body .voices .row.voices-list").html(s);
        var e = allLanguages ? .find(e => e ? .value === a),
            n = (handleLanguageEngines(e), $(".voices-nav button.active").attr("aria-current"));
        if (voices = e ? .voice_names || [], t && n !== voiceCategoryTypes.USER_VOICES && (voices = voices.filter(e => e.ai_engine ? .includes(t))), i && (voices = voices ? .filter(e => String(e ? .ai_voiceWebname).match(new RegExp(".*" + i, "i")))), handleVoicesGender(voices), o) {
            let e = [];
            "male" === o || "female" === o ? e = voices.filter(e => e ? .ai_voiceGender === String(o[0]).toUpperCase() + String(o).substring(1)) : "child" === o && (e = voices ? .filter(e => String(e ? .ai_voiceGender).match(new RegExp(".*child", "i")))), 0 < e ? .length ? voices = e : ($(".gender-nav a").removeClass("active"), $('.gender-nav a[title="all"]').addClass("active"))
        }
        voices = voices ? .sort((e, a) => e.ai_provider < a.ai_provider ? -1 : 1);
        let l = "",
            c;
        if (0 < voices ? .length) {
            c = voices ? .find(e => voice ? .voiceApiname === e ? .ai_voiceApiname) || voices[0];
            let t = [],
                s = [];
            voices.map(a => {
                var e = t.findIndex(e => e.provider === a.ai_provider);
                a ? .custom ? t.push({
                    provider: "custom",
                    voices: [a]
                }) : -1 !== e ? t[e] ? .voices.push(a) : a ? .custom ? t.push({
                    provider: "custom",
                    voices: [a]
                }) : t.push({
                    provider: a.ai_provider,
                    voices: [a]
                })
            }), t ? .map(e => {
                var a = "pro-plus" === e ? .provider || "pro1" === e ? .provider,
                    t = "custom" === e ? .provider,
                    o = s.findIndex(e => "pro" === e ? .category),
                    i = s.findIndex(e => "default" === e ? .category),
                    r = s.findIndex(e => "custom" === e ? .category);
                a ? -1 !== o ? s[o] ? .providers ? .push(e) : s.push({
                    category: "pro",
                    providers: [e]
                }) : t ? -1 !== r ? s[r] ? .providers ? .push(e) : s.push({
                    category: "custom",
                    providers: [e]
                }) : -1 !== i ? s[i] ? .providers ? .push(e) : s.push({
                    category: "default",
                    providers: [e]
                })
            }), s = s.sort((e, a) => "pro" === e.category ? -1 : 1);
            const d = voice["voiceCategory"];
            s ? .map(e => {
                let a = 0;
                e ? .providers ? .map(e => a += e ? .voices ? .length), d === voiceCategoryTypes.USER_VOICES && (l += `<div class="col-md-12 p-0 mt-2 mb-2">
                    <div class="d-flex justify-content-between align-items-center voice-category ${"pro"===e?.category?"yellow":"blue"}">
                    <div>
                    ${"pro"===e?.category?'<svg class="vm_icon_pro_voice-2" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.75002 18.3333V14.1667M3.75002 5.83334V1.66667M1.66669 3.75001H5.83335M1.66669 16.25H5.83335M10.8334 2.50001L9.38821 6.25739C9.1532 6.86842 9.03569 7.17393 8.85296 7.43091C8.69101 7.65867 8.49202 7.85766 8.26426 8.01961C8.00728 8.20234 7.70176 8.31985 7.09074 8.55486L3.33335 10L7.09074 11.4452C7.70176 11.6802 8.00728 11.7977 8.26426 11.9804C8.49202 12.1423 8.69101 12.3413 8.85296 12.5691C9.03569 12.8261 9.1532 13.1316 9.38821 13.7426L10.8334 17.5L12.2785 13.7426C12.5135 13.1316 12.631 12.8261 12.8137 12.5691C12.9757 12.3413 13.1747 12.1423 13.4025 11.9804C13.6594 11.7977 13.9649 11.6802 14.576 11.4452L18.3334 10L14.576 8.55486C13.9649 8.31985 13.6594 8.20234 13.4024 8.01961C13.1747 7.85766 12.9757 7.65867 12.8137 7.43091C12.631 7.17393 12.5135 6.86842 12.2785 6.25739L10.8334 2.50001Z" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"></path></svg>':`<svg class="white-svgs-stroke" width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 8L1 12M5.5 4L5.5 16M10 1V19M14.5 4V16M19 8V12" stroke="#404040" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>`}
                    <b class="ml-1">${String(e?.category).charAt(0).toUpperCase()+String(e?.category).substring(1)} Voices</b></div>
                        <div class="badge count-badge">${a}</div>
                    </div>
                </div>`), d === voiceCategoryTypes.PRO_VOICES && (e.providers = e ? .providers ? .map(e => (e.voices = filterProVoices(e.voices, r), e))), e ? .providers ? .forEach(e => {
                    "pro-plus" === e.provider ? l += `<div class="col-md-12 p-0 pb-2 pr-2" id="sticky-div">
                        <div class="d-flex align-items-center">
                            <div class="voice-category-provider" style="background-color: ${getProviderBKColor(e?.provider)}; color: ${getProviderColor(e?.provider)}">
                            ${proIcon}
                            ${getProvider(e?.provider)}</div> 
                            <div class="ml-2 life-like-speech remove-in-mobile">Life-like speech in 30 languages</div>
                            ${"pro-plus"===e?.provider?`<div class="voice-category-text ml-auto">Pro+ Voices<span class="remove-in-mobile"> will</span> count <span class="pro-engine-count">6x</span> char<span class="remove-in-mobile">acter</span>s
                                <div class="tooltip-cont pro-plus-tooltip d-inline-block">
                                    <i class="fa fa-info-circle ml-1"></i>
                                    <div class="tooltip-text left-bottom">
                                        Turbo will charge 3x characters
                                    </div>
                                </div>
                                </div>`:""}
                        </div>
                    </div>` : "pro1" === e.provider && (l += `<div class="col-md-12 p-0 pb-2" id="sticky-div">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="voice-category-provider" style="background-color: ${getProviderBKColor(e?.provider)}; color: ${getProviderColor(e?.provider)}">
                            ${proIcon}
                            Pro V1
                            </div>
                            <div class="ml-2 life-like-speech remove-in-mobile">Realistic speech in 70+ languages</div>
                            <div class="voice-category-text ml-auto">Pro V1 Voices<span class="remove-in-mobile"> will</span> count 1x char<span class="remove-in-mobile">acter</span>s</div>
                        </div>
                    </div>`), e ? .voices ? .map((e, a) => {
                        var t, o, i;
                        e ? .pro ? l += `<div class="col-md-6 ${""} p-0 pr-1">
                                <div class="voice pro ${c?c?.ai_voiceApiname===e?.ai_voiceApiname?"active":"":0===a?"active":""}" apiname="${e?.ai_voiceApiname}" onclick='onVoiceSelect("${e?.ai_voiceApiname}", this, true)'>
                                    <div class="content d-flex bd-highlight">
                                        <div class="flex-grow-1 bd-highlight">
                                            <div class="d-flex align-items-center">
                                                <div onclick='onPlay("${e?.path}", this)' pro="true" class="mr-4 ml-3"><i class="fas fa-lg fa-play"></i></div>
                                                <div class="" style="width: 100%">
                                                    <h5 class="textBox"><span class="marquee">${e.ai_voiceWebname}</span></h5>
                                                    <h6 class="m-0 text-muted">${e.pro_age||""}</h6>
                                                </div>
                                            </div>
                                            <hr class="mt-3" />
                                            <div class="d-flex align-items-center justify-content-between ml-1">
                                                <div class="pro-description-cont">
                                                    <div class="align-items-center">
                                                        ${e?.pro_language?`<span class="badge badge-pro-language mr-1 d-inline-block" title="Pro Language">${e?.pro_language}</span>`:""}
                                                        ${e?.pro_usecase?`<span class="badge badge-pro-style mr-1 d-inline-block" title="Pro Style">${e?.pro_usecase}</span>`:""}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>` : (t = getProvider(e ? .ai_provider), o = getProviderBKColor(e.ai_provider), i = getProviderColor(e.ai_provider), l += `<div class="col-md-4">
                            <div class="voice ${c?c?.ai_voiceApiname===e?.ai_voiceApiname?"active":"":0===a?"active":""}" apiname="${e?.ai_voiceApiname}" onclick='onVoiceSelect("${e?.ai_voiceApiname}", this, true)'>
                                <div class="content d-flex bd-highlight">
                                    <div class="flex-grow-1 bd-highlight">
                                        <div class="">
                                            <div class="textBox"><span class="marquee">${e.ai_voiceWebname}<span class="text-muted ml-2"><small>${e.ai_voiceGender}</small></span></span></div>
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <span class="badge badge-warning px-2 py-1 m-0 mr-1" style="background-color: ${o}; color: ${i}">${t} ${e?.pro?'<i class="fas fa-star fa-xs ml-1"></i>':""}</span>
                                            ${0<e?.sound_effects?.length?'<span class="badge badge-secondary badge-secondary-2 px-2 py-1 m-0 mr-1" title="Apply effects">E</span>':""}
                                            ${e?.premium?'<span class="badge badge-warning px-2 py-1 m-0" title="Premium">P</span>':""}
                                        </div>
                                    </div>
                                    <div class="mt-1 ml-2">
                                        <div onclick='onPlay("${e?.path}", this)' class="play-btn"><i class="fas fa-lg fa-play-circle"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>`)
                    })
                })
            })
        } else {
            e = window.location.pathname;
            l = "/audiobook/create" === e ? `<div class="text-center p-3 no-voices-found">Pro voices don't work on audiobook page</div>` : '<div class="text-center p-3 no-voices-found">No voices found</div>'
        }
        $("#voicesModal .card-body .voices .row.voices-list").html(l), onVoiceSelect(c ? .ai_voiceApiname, null, !0)
    },
    descriptionOnHover = (e, a) => {
        "enter" === e && $(a).next("span").fadeIn(), "leave" === e && $(a).fadeOut()
    },
    handleVoiceEffectsUpdate = ($(window).on("resize", function() {
        wrapContentsInMarquee(".textBox"), wrapContentsInMarquee(".editor-selected-voice .selected")
    }), (e = "", a, t, o) => {
        $("#ion_speed" + e).val(Number(a) || 0), handleInputChange("#ion_speed" + e, Number(a) || 0, "speed"), $("#ion_volume" + e).val(Number(t) || 0), handleInputChange("#ion_volume" + e, Number(t) || 0, "volume"), $("#ion_pitch" + e).val(Number(o) || 0), handleInputChange("#ion_pitch" + e, Number(o) || 0, "pitch")
    }),
    handleVoiceParamsSelect = e => {
        var a, t, o, i, r, s, n, l, c, d, p, u;
        e && ({
            sampleRate: a,
            effect: t,
            master_VC: u,
            master_volume: o,
            pitch: i,
            outputFormat: r,
            speed: s,
            clarity: n,
            stability: l,
            style: c,
            speakerBoost: d,
            proEngine: p
        } = e, "basic" === (u = u && "" !== u ? u : "advanced_v1") && "" !== s && "" !== o && "" !== i ? ($("#basic-voice-speed select").val(s), $("#basic-voice-volume select").val(o), $("#basic-voice-pitch select").val(i)) : "advanced_v1" === u ? (voice.master_VC = "advanced_v1", handleVoiceEffectsUpdate("", s, o, i)) : "advanced_v2" === u && handleVoiceEffectsUpdate("_v2", s, o, i), toggleVoiceEffects(u), $(`#voice-effects input[value="${t}"]`).prop("checked", !0), $(".audioFormat").val(r || "mp3").change(), $(".sampleRate").val(a || "24000").change(), audioFormat = r, l && handleInputChange("#ion_pro_stability", Number(l), "stability"), n && handleInputChange("#ion_pro_clarity", Number(n), "clarity"), c && handleInputChange("#ion_pro_style", Number(c), "style"), void 0 !== d && $("#speakerBoost").prop("checked", d), p && $(`.turbo-con .taeb[taeb-value="${p}"]`).click(), e ? .text && (textLimit = Number($("#limit").val()), handleTextAreaText(e ? .text, textLimit)), e ? .path && ($("#audioplayer")[0].src = e ? .path), allLanguages = allLanguages ? .map(e => (e.selected = null, e)), voice = { ...voice,
            ...e
        })
    },
    pauseRunningVoices = e => {
        "backgroundAudio" !== e && $backgroundAudio && 0 < $backgroundAudio ? .length && $backgroundAudio[0].pause(), "multivVoiceFile" !== e && $multiVoiceFileAudio && 0 < $multiVoiceFileAudio ? .length && $multiVoiceFileAudio[0].pause(), "multiVoiceAudio" !== e && $multiVoiceAudio && 0 < $multiVoiceAudio ? .length && $multiVoiceAudio[0].pause(), "projectsAudio" !== e && $projectsAudio && 0 < $projectsAudio ? .length && $projectsAudio[0].pause(), "voicesModalAudio" !== e && $voicesModalAudio && 0 < $voicesModalAudio ? .length && $voicesModalAudio[0].pause(), "stickyAudio" !== e && $stickyAudio && 0 < $stickyAudio ? .length && $stickyAudio[0].pause(), "mainAudio" !== e && $mainAudioplayer && 0 < $mainAudioplayer ? .length && $mainAudioplayer[0].pause(), "pronunciationAudio" !== e && $pronunciationAudio && 0 < $pronunciationAudio ? .length && $pronunciationAudio[0].pause()
    },
    checkAbilityToChangeAudioFormat = a => {
        var e = localStorage.getItem("editor");
        if ("multivoice" === e && (("mp3" === a || "wav" === a) && addedMultiVoices ? .length)) return (e = addedMultiVoices ? .filter(e => e.outputFormat === a)) ? .length ? (e ? .length, void addedMultiVoices ? .length) : $.notify(` You already have tracks with (${"mp3"===a?"wav":"mp3"}) format, you can't combine multible formats `, {
            type: "danger",
            icon: "warning"
        })
    },
    handleTextSubmit = () => {
        voice.effect = $('#voice-effects input[name="effect"]:checked').val();
        const a = $("#voicesModal .voices-list .voice.active").attr("apiname"),
            t = voices ? .find(e => e ? .ai_voiceApiname === a);
        var e = defaultLanguages ? .find(e => e ? .value === t ? .language);
        if (!t) throw $.notify(" Please choose voice ", {
            type: "danger",
            icon: "warning"
        }), new Error("");
        voice = { ...voice,
            voiceApiname: t ? .ai_voiceApiname,
            voice: t ? .ai_voiceWebname,
            Provider: t ? .ai_provider,
            Engine: t ? .ai_engine,
            languageCode: e ? .value,
            language: e ? .name,
            gender: t ? .ai_voiceGender
        };
        var e = Math.ceil(1e7 * Math.random()),
            o = ("basic" === voice.master_VC ? (voice.speed = $("#basic-voice-speed select").val(), voice.master_volume = $("#basic-voice-volume select").val(), voice.pitch = $("#basic-voice-pitch select").val()) : "advanced_v1" === voice.master_VC ? (voice.speed = Number($("#ion_speed").val()) - 100, voice.master_volume = Number($("#ion_volume").val()) - 20, voice.pitch = Number($("#ion_pitch").val()) - 100) : "advanced_v2" === voice ? .master_VC && (voice.speed = Number($("#ion_speed_v2").val()) - 100, voice.master_volume = Number($("#ion_volume_v2").val()) - 20, voice.pitch = Number($("#ion_pitch_v2").val()) - 100), voice.Provider === ProviderTypes.PRO_PLUS && (voice.stability = $("#ion_pro_stability").val() ? .length ? Number($("#ion_pro_stability").val()) : 0, voice.clarity = $("#ion_pro_clarity").val() ? .length ? Number($("#ion_pro_clarity").val()) : 0, voice.style = $("#ion_pro_style").val() ? .length ? Number($("#ion_pro_style").val()) : 0, voice.speakerBoost = Boolean($("#speakerBoost:checked").val()), voice.proEngine = $(".turbo-con").find(".taeb.active").attr("taeb-value")), $("#main-textarea").val());
        if (!o || 0 === o ? .length) throw $.notify(" Please add text ", {
            type: "danger",
            icon: "warning"
        }), new Error("");
        var i, r, s, n, l, c, d, p, u, v, g, m, h, b = find_unclosed_tags(o)["misMatches"];
        if (!(b && 0 < b.length)) return $(".textarea-error").html(""), voice.text = o, voice.textType = TextType, voice._id = e, voice.type = "voice", project && (voice.project = project ? ._id), {
            Engine: o,
            languageCode: e,
            sampleRate: i,
            effect: r,
            master_volume: s,
            pitch: n,
            outputFormat: l,
            speed: c,
            voiceApiname: d,
            master_VC: p,
            voiceCategory: u,
            style: v,
            clarity: g,
            stability: m,
            proEngine: h
        } = voice, o = {
            voice: voice.voice,
            Engine: o,
            voiceApiname: d,
            languageCode: e,
            sampleRate: i,
            effect: r,
            master_VC: p,
            master_volume: s,
            pitch: n,
            style: v,
            clarity: g,
            stability: m,
            proEngine: h,
            outputFormat: l,
            speed: c,
            voiceCategory: u || "default-voices"
        }, localStorage.setItem("cachedVoice", JSON.stringify(o)), { ...voice
        };
        $(".textarea-error").html(""), b.forEach(e => {
            $(".textarea-error").append(`<div class="alert alert-danger">${e}</div>`)
        })
    },
    isPrevVoiceAbleToBeUpdated = (e, a) => {
        if (e ? .voice === a ? .voice && e ? .text === a ? .text && e ? .effect === a ? .effect && e ? .Engine === a ? .Engine && e ? .master_VC === a ? .master_VC && "advanced_v2" === e ? .master_VC) return !0
    },
    convertText = (e, t, a) => {
        if ($("#convert-button").prop("disabled", !0), $("#convert-button").html(ajaxSpinner), $(".multi-edit").prop("disabled", !0), $(".multi-cancel").prop("disabled", !0), project ? .archive) return $("#convert-button").prop("disabled", !0);
        isPrevVoiceAbleToBeUpdated(e, prevVoice) && (e.updatedVoice = prevVoice._id, e.prevVoice = !0), editSelected && (e.updatedVoice = editSelected._id), multivoiceEnabled || $("#audioplayer-container").slideUp(), $.ajax({
            headers: {
                "CSRF-Token": token
            },
            type: "POST",
            url: "/voice/standard",
            data: JSON.stringify(e),
            contentType: "application/json",
            processData: !1,
            dataType: "json",
            cache: !0,
            timeout: 0,
            success: function(e) {
                if (pauseRunningVoices("mainAudioplayer"), !0 === e.success) $("#not-subscribe-error").html(""), $("#audioplayer-container").slideDown(), voice = { ...e.voice,
                    ...voice,
                    error: !1,
                    _id: e ? .voice ? ._id,
                    path: e.path
                }, a || (prevVoice = { ...voice
                }), ($mainAudioplayer = $("#audioplayer"))[0].src = e.path, $mainAudioplayer[0].play(), $(".grecaptcha-badge").css("visibility", "hidden"), nonLoggedVoice = e ? .voice ? ._id, $(".standard-download-btn").prop("data-value", e ? .path), $(".standard-edit-btn").attr("onclick", `onSingleVoiceEdit('${e?.voice?._id}', this)`);
                else {
                    if ($("#convert-button").prop("disabled", !1), $.notify(" " + (e.message || "Error, Please try again later"), {
                            type: "danger",
                            icon: "warning",
                            forever: !0
                        }), editSelected ? $("#convert-button").html('<i class="fa fa-play mr-2"></i>Update') : $("#convert-button").html('<i class="fa fa-play mr-2"></i>Convert to Speech'), !0 === e.account) return $("#registerModal").modal("show");
                    !0 !== e.subscribe && $(".grecaptcha-badge").css("visibility", "visible")
                }
            }
        }).done(a => {
            $("#convert-button").prop("disabled", !1), editSelected ? $("#convert-button").html('<i class="fa fa-play mr-2"></i>Update') : $("#convert-button").html('<i class="fa fa-play mr-2"></i>Convert to Speech'), $(".multi-edit").prop("disabled", !1), $(".multi-cancel").prop("disabled", !1), t && t(), !0 === a.success && (editSelected ? (addedMultiVoices = addedMultiVoices ? .map(e => String(e ? ._id) === String(editSelected ? ._id) ? { ...a ? .voice,
                language : voice ? .language,
                languageCode: voice ? .languageCode,
                voice: voice ? .voice,
                voiceApiname: voice ? .voiceApiname,
                gender: voice ? .gender,
                error: !1,
                path: a ? .path,
                _id: e ? ._id,
                type: "voice"
            } : e), prevVoice = null, editSelected = null, $(".standard-add-track").prop("disabled", !0), renderMultiVoices()) : $(".standard-add-track").prop("disabled", !1), $(".multi-slider").css("display", "none"), $("#convert-button").prop("disabled", !1), $("#convert-button").html('<i class="fa fa-play mr-2"></i>Convert to Speech'))
        }).catch(e => {
            $("#convert-button").prop("disabled", !1), $("#convert-button").html('<i class="fa fa-play mr-2"></i>Convert to Speech'), $.notify(" " + (429 === e ? .status ? e.responseText : "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    },
    addNewTrackUpdate = async (e, a) => {
        return $.ajax({
            headers: {
                "CSRF-Token": token
            },
            type: "PUT",
            url: "/voice/path",
            data: JSON.stringify({
                voice: e,
                project: a
            }),
            contentType: "application/json",
            processData: !1,
            dataType: "json",
            cache: !0,
            timeout: 0,
            success: function(e) {
                return e ? .success && (voice.path = e ? .data, voice.originalPath = e ? .originalPath, $(".standard-download-btn").prop("data-value", e ? .data)), e
            }
        }).catch(e => {
            $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    },
    resetVoiceEffects = () => {
        $("#ion_speed").val(100), $("#ion_volume").val(20), $("#ion_pitch").val(100), handleInputChange("#ion_speed", 0, "speed"), handleInputChange("#ion_volume", 0, "volume"), handleInputChange("#ion_pitch", 0, "pitch"), $("#ion_speed_v2").val(100), $("#ion_volume_v2").val(20), $("#ion_pitch_v2").val(100), handleInputChange("#ion_speed_v2", 0, "speed"), handleInputChange("#ion_volume_v2", 0, "volume"), handleInputChange("#ion_pitch_v2", 0, "pitch"), $("#basic-voice-speed select").val("normal"), $("#basic-voice-volume select").val("medium"), $("#basic-voice-pitch select").val("default")
    },
    getVoiceFile = async e => $.ajax({
        headers: {
            "CSRF-Token": token
        },
        type: "GET",
        url: "/voice/" + e,
        success: e => e
    }),
    onSingleVoiceEdit = async (e, a) => {
        a && $(a).html(ajaxSpinner), $(".editor-selected-voice .selected").html("<div></div>");
        var t, o = (await getVoiceFile(e)) ? .data;
        if (!o) return $.notify("Error, No voice found", {
            type: "danger",
            icon: "warning"
        });
        editSelected = o, prevVoice = null, (await checkFileExist(o ? .path)) ? .exist ? (voice = o, $("#convert-button").html('<i class="fa fa-play mr-2"></i>Update'), handleVoiceParamsSelect(o), $(`.voices-nav button[aria-current="${voice?.voiceCategory}"]`).click(), t = favoriteLanguages ? .map(e => e ? .value).includes(voice ? .languageCode), t = handleLanguages(t, voice ? .Engine, o ? .voiceCategory), renderLanguages(t), $("#audioplayer-container").slideDown(), ($mainAudioplayer = $("#audioplayer"))[0].src = voice.path, $mainAudioplayer[0].play(), $(".grecaptcha-badge").css("visibility", "hidden"), $(".standard-download-btn").prop("data-value", voice ? .path), $(".standard-edit-btn").attr("onclick", `onSingleVoiceEdit('${voice?._id}', this)`)) : (handleVoiceParamsSelect(o), $(`.voices-nav button[aria-current="${voice?.voiceCategory}"]`).click(), t = favoriteLanguages ? .map(e => e ? .value).includes(voice ? .languageCode), t = handleLanguages(t, voice ? .Engine, o ? .voiceCategory), renderLanguages(t), editSelected = { ...o,
            _id: e
        }, convertText(editSelected)), a && $(a).html('<i class="fas fa-pencil-alt"></i>'), $("#convert-button").prop("disabled", !1)
    };
$(document).ready(function(e) {
    $(".standard-add-track").on("click", async function() {
        prevVoice = null;
        var e = $("#nav-user-id").val();
        return e && "" !== e ? !editSelected && multivoiceEnabled && 10 <= addedMultiVoices ? .length ? $.notify(" You can't add more than 10 tracks", {
            type: "danger",
            icon: "warning"
        }) : void(voice.path && ($(this).prop("disabled", !0), $(this).html(ajaxSpinner + '<span class="ml-1">Add New Track</span>'), $("#convert-button").prop("disabled", !1), await addNewTrackUpdate(voice ? ._id, project ? ._id), multivoiceEnabled = !0, $(".multivoice").fadeIn(), (e = { ...voice
        }).index = addedMultiVoices ? .length + 1, addedMultiVoices.push(e), renderMultiVoices(), showUpdateMultiVoice(), $(this).html('<i class="fas fa-plus"></i> Add New Track'), voice.path = null, voice.project = null)) : $("#loginModal").modal("show")
    });
    $("#convert-button").on("click", async e => {
        var a = handleTextSubmit();
        if (!a) return $.notify(" Error, Please try again later", {
            type: "danger",
            icon: "warning"
        });
        if (!a.text || 0 === a.text ? .length) return $.notify(" You have to enter your text", {
            type: "danger",
            icon: "warning"
        }), null;
        var t = (t = $("#nav-user-id").val()) && "" !== t ? t : null,
            o = (o = $("#subType").val()) && "" !== o ? o : null;
        if (editSelected && !0 === (e => {
                const {
                    textType: a,
                    ...t
                } = { ...e,
                    _id: editSelected ? ._id,
                    index: editSelected ? .index,
                    color: editSelected ? .color,
                    path: editSelected ? .path
                };
                let o = !0;
                return ["languageCode", "Engine", "master_VC", "master_volume", "pitch", "sampleRate", "speed", "text", "voice"].forEach(e => {
                    editSelected && void 0 !== editSelected[e] && void 0 !== t[e] && String(editSelected[e]) !== String(t[e]) && (o = !1)
                }), o
            })(a)) return $("#convert-button").html('<i class="fa fa-play mr-2"></i> Convert to Speech'), editSelected = null, $(".multi-slider").css("display", "none"), renderMultiVoices();
        $("#convert-button").prop("disabled", !0), $("#convert-button").html(ajaxSpinner), t && o && "free" !== o || (t = await grecaptcha.execute("6LdyG7YZAAAAAP_Qdm5J9FrhPpTZgkasrl4QyO3D", {
            action: "submit"
        }), a.token = t), convertText(a)
    }), $("#sendEmail").on("click", function() {
        var e = "You can download your audio file from here:%0d%0a%0d%0a" + speech_link.replace("./uploads/", "https://voicemaker.in/uploads/") + "%0d%0a%0d%0a Ps. This file will be unavailable within 24 hours.";
        window.location.href = "mailto:?subject=Download your file - Voicemaker&body=" + e
    }), $("#audiobook-preview").click(e => {
        e.preventDefault();
        e = handleTextSubmit("audiobook");
        $.ajax({
            headers: {
                "CSRF-Token": token
            },
            type: "POST",
            url: "/voice/audiobook-preview",
            data: JSON.stringify(e),
            contentType: "application/json",
            processData: !1,
            dataType: "json",
            cache: !0,
            timeout: 0,
            beforeSend: function() {
                $("#audiobook-preview").prop("disabled", !0), $("#audiobook-preview").html(ajaxSpinner)
            },
            success: function(e) {
                if ($("#audiobook-preview").prop("disabled", !1), $("#audiobook-preview").html('<i class="fa fa-play-circle mr-2 my-2"></i>Preview'), !0 === e.success) {
                    $("#not-subscribe-error").html(""), $("#audioplayer-container").slideDown(), speech_link = "." + e.path;
                    var a = $("#audioplayer");
                    a[0].src = "." + e.path, a[0].play(), $("#audioplayer").addClass("audioplayer-playing"), $(".audio-samples > .audioplayer").removeClass("audioplayer-playing"), $(".textarea-error").html(""), saveFileParams = e.params, $(".grecaptcha-badge").css("visibility", "hidden"), $(".audiobook_preview").hide()
                } else {
                    if ($.notify(" " + (e.message || "Error, Please try again later"), {
                            type: "danger",
                            icon: "warning"
                        }), !0 === e.account) return $("#registerModal").modal("show");
                    $(".grecaptcha-badge").css("visibility", "visible")
                }
            },
            error: function(e) {
                $("#audiobook-preview").prop("disabled", !1), $("#audiobook-preview").html('<i class="fa fa-play-circle mr-2 my-2"></i>Preview')
            }
        }).catch(e => {
            $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    }), $("#audiobook-button").on("click", function(e) {
        e.preventDefault();
        e = handleTextSubmit("audiobook");
        $.ajax({
            headers: {
                "CSRF-Token": token
            },
            type: "POST",
            url: "/voice/audiobook",
            data: JSON.stringify(e),
            contentType: "application/json",
            processData: !1,
            dataType: "json",
            cache: !0,
            timeout: 0,
            beforeSend: function() {
                $(".convert-button").prop("disabled", !0), $(".convert-button").html(ajaxSpinner)
            },
            success: function(e) {
                if ($(".convert-button").prop("disabled", !1), $(".convert-button").html('<i class="fa fa-play mr-2"></i>Convert Audiobook'), !0 === e.success) {
                    if (e.message) return $("#audioBookModal").modal("show");
                    $("#not-subscribe-error").html(""), $("#audioplayer-container").slideDown();
                    var a = $("#audioplayer");
                    a[0].src = e.path, a[0].play(), $("#audioplayer").addClass("audioplayer-playing"), $(".audio-samples > .audioplayer").removeClass("audioplayer-playing"), $(".textarea-error").html(""), saveFileParams = e.params, $(".grecaptcha-badge").css("visibility", "hidden"), $(".audiobook_preview").show()
                } else {
                    if ($.notify(" " + (e.message || "Error, Please try again later"), {
                            type: "danger",
                            icon: "warning"
                        }), !0 === e.account) return $("#registerModal").modal("show");
                    $.notify(" " + e.message, {
                        type: "danger",
                        icon: "warning"
                    })
                }
            },
            error: function(e) {
                $(".convert-button").prop("disabled", !1), $(".convert-button").html('<i class="fa fa-play mr-2"></i>Convert Audiobook')
            }
        }).catch(e => {
            console.error("ERROR:", new Error(e) ? .message), $.notify(" " + (e.responseText || "Error, Please try again later"), {
                type: "danger",
                icon: "warning"
            })
        })
    })
}), $(document).on("show.bs.modal", ".modal", function() {
    const e = 1040 + 10 * $(".modal:visible").length;
    $(this).css("z-index", e), setTimeout(() => $(".modal-backdrop").not(".modal-stack").css("z-index", e - 1).addClass("modal-stack"))
});