if (! function(t, e) {
        "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : t.Popper = e()
    }(this, function() {
        "use strict";

        function a(t) {
            return t && "[object Function]" === {}.toString.call(t)
        }

        function u(t, e) {
            return 1 !== t.nodeType ? [] : (t = t.ownerDocument.defaultView.getComputedStyle(t, null), e ? t[e] : t)
        }

        function l(t) {
            return "HTML" === t.nodeName ? t : t.parentNode || t.host
        }

        function c(t) {
            if (!t) return document.body;
            switch (t.nodeName) {
                case "HTML":
                case "BODY":
                    return t.ownerDocument.body;
                case "#document":
                    return t.body
            }
            var e = u(t),
                i = e.overflow,
                s = e.overflowX,
                e = e.overflowY;
            return /(auto|scroll|overlay)/.test(i + e + s) ? t : c(l(t))
        }

        function h(t) {
            return t && t.referenceNode ? t.referenceNode : t
        }

        function d(t) {
            return 11 === t ? K : 10 !== t && K || X
        }

        function p(t) {
            if (!t) return document.documentElement;
            for (var e = d(10) ? document.body : null, i = t.offsetParent || null; i === e && t.nextElementSibling;) i = (t = t.nextElementSibling).offsetParent;
            var s = i && i.nodeName;
            return s && "BODY" !== s && "HTML" !== s ? -1 !== ["TH", "TD", "TABLE"].indexOf(i.nodeName) && "static" === u(i, "position") ? p(i) : i : (t ? t.ownerDocument : document).documentElement
        }

        function o(t) {
            return null === t.parentNode ? t : o(t.parentNode)
        }

        function f(t, e) {
            var i, s, n;
            return t && t.nodeType && e && e.nodeType ? (s = (n = t.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING) ? t : e, n = n ? e : t, (i = document.createRange()).setStart(s, 0), i.setEnd(n, 0), t !== (i = i.commonAncestorContainer) && e !== i || s.contains(n) ? "BODY" === (n = (s = i).nodeName) || "HTML" !== n && p(s.firstElementChild) !== s ? p(i) : i : (n = o(t)).host ? f(n.host, e) : f(t, o(e).host)) : document.documentElement
        }

        function m(t, e) {
            var e = "top" === (1 < arguments.length && void 0 !== e ? e : "top") ? "scrollTop" : "scrollLeft",
                i = t.nodeName;
            return ("BODY" === i || "HTML" === i ? (i = t.ownerDocument.documentElement, t.ownerDocument.scrollingElement || i) : t)[e]
        }

        function n(t, e) {
            var e = "x" === e ? "Left" : "Top",
                i = "Left" == e ? "Right" : "Bottom";
            return parseFloat(t["border" + e + "Width"]) + parseFloat(t["border" + i + "Width"])
        }

        function s(t, e, i, s) {
            return N(e["offset" + t], e["scroll" + t], i["client" + t], i["offset" + t], i["scroll" + t], d(10) ? parseInt(i["offset" + t]) + parseInt(s["margin" + ("Height" === t ? "Top" : "Left")]) + parseInt(s["margin" + ("Height" === t ? "Bottom" : "Right")]) : 0)
        }

        function g(t) {
            var e = t.body,
                t = t.documentElement,
                i = d(10) && getComputedStyle(t);
            return {
                height: s("Height", e, t, i),
                width: s("Width", e, t, i)
            }
        }

        function _(t) {
            return O({}, t, {
                right: t.left + t.width,
                bottom: t.top + t.height
            })
        }

        function v(t) {
            var e = {};
            try {
                d(10) ? (e = t.getBoundingClientRect(), i = m(t, "top"), s = m(t, "left"), e.top += i, e.left += s, e.bottom += i, e.right += s) : e = t.getBoundingClientRect()
            } catch (t) {}
            var i = {
                    left: e.left,
                    top: e.top,
                    width: e.right - e.left,
                    height: e.bottom - e.top
                },
                s = "HTML" === t.nodeName ? g(t.ownerDocument) : {},
                e = s.width || t.clientWidth || i.width,
                s = s.height || t.clientHeight || i.height,
                e = t.offsetWidth - e,
                s = t.offsetHeight - s;
            return (e || s) && (e -= n(t = u(t), "x"), s -= n(t, "y"), i.width -= e, i.height -= s), _(i)
        }

        function b(t, e, i) {
            var i = 2 < arguments.length && void 0 !== i && i,
                s = d(10),
                n = "HTML" === e.nodeName,
                o = v(t),
                a = v(e),
                t = c(t),
                r = u(e),
                l = parseFloat(r.borderTopWidth),
                h = parseFloat(r.borderLeftWidth),
                a = (i && n && (a.top = N(a.top, 0), a.left = N(a.left, 0)), _({
                    top: o.top - a.top - l,
                    left: o.left - a.left - h,
                    width: o.width,
                    height: o.height
                }));
            return a.marginTop = 0, a.marginLeft = 0, !s && n && (o = parseFloat(r.marginTop), n = parseFloat(r.marginLeft), a.top -= l - o, a.bottom -= l - o, a.left -= h - n, a.right -= h - n, a.marginTop = o, a.marginLeft = n), a = (s && !i ? e.contains(t) : e === t && "BODY" !== t.nodeName) ? function(t, e, i) {
                var i = 2 < arguments.length && void 0 !== i && i,
                    s = m(e, "top"),
                    e = m(e, "left"),
                    i = i ? -1 : 1;
                return t.top += s * i, t.bottom += s * i, t.left += e * i, t.right += e * i, t
            }(a, e) : a
        }

        function y(t) {
            if (!t || !t.parentElement || d()) return document.documentElement;
            for (var e = t.parentElement; e && "none" === u(e, "transform");) e = e.parentElement;
            return e || document.documentElement
        }

        function w(t, e, i, s, n) {
            var o, n = 4 < arguments.length && void 0 !== n && n,
                a = {
                    top: 0,
                    left: 0
                },
                r = n ? y(t) : f(t, h(e)),
                r = ("viewport" === s ? a = function(t, e) {
                    var e = 1 < arguments.length && void 0 !== e && e,
                        i = t.ownerDocument.documentElement,
                        t = b(t, i),
                        s = N(i.clientWidth, window.innerWidth || 0),
                        n = N(i.clientHeight, window.innerHeight || 0),
                        o = e ? 0 : m(i),
                        e = e ? 0 : m(i, "left");
                    return _({
                        top: o - t.top + t.marginTop,
                        left: e - t.left + t.marginLeft,
                        width: s,
                        height: n
                    })
                }(r, n) : ("scrollParent" === s ? "BODY" === (o = c(l(e))).nodeName && (o = t.ownerDocument.documentElement) : o = "window" === s ? t.ownerDocument.documentElement : s, e = b(o, r, n), "HTML" !== o.nodeName || function t(e) {
                    var i = e.nodeName;
                    return "BODY" !== i && "HTML" !== i && ("fixed" === u(e, "position") || !!(i = l(e)) && t(i))
                }(r) ? a = e : (n = (s = g(t.ownerDocument)).height, o = s.width, a.top += e.top - e.marginTop, a.bottom = n + e.top, a.left += e.left - e.marginLeft, a.right = o + e.left)), "number" == typeof(i = i || 0));
            return a.left += r ? i : i.left || 0, a.top += r ? i : i.top || 0, a.right -= r ? i : i.right || 0, a.bottom -= r ? i : i.bottom || 0, a
        }

        function r(t, e, i, s, n, o) {
            var a, o = 5 < arguments.length && void 0 !== o ? o : 0;
            return -1 === t.indexOf("auto") ? t : (s = w(i, s, o, n), a = {
                top: {
                    width: s.width,
                    height: e.top - s.top
                },
                right: {
                    width: s.right - e.right,
                    height: s.height
                },
                bottom: {
                    width: s.width,
                    height: s.bottom - e.bottom
                },
                left: {
                    width: e.left - s.left,
                    height: s.height
                }
            }, (0 < (n = (o = Object.keys(a).map(function(t) {
                return O({
                    key: t
                }, a[t], {
                    area: (t = a[t]).width * t.height
                })
            }).sort(function(t, e) {
                return e.area - t.area
            })).filter(function(t) {
                var e = t.width,
                    t = t.height;
                return e >= i.clientWidth && t >= i.clientHeight
            })).length ? n : o)[0].key + ((e = t.split("-")[1]) ? "-" + e : ""))
        }

        function x(t, e, i, s) {
            s = 3 < arguments.length && void 0 !== s ? s : null;
            return b(i, s ? y(e) : f(e, h(i)), s)
        }

        function C(t) {
            var e = t.ownerDocument.defaultView.getComputedStyle(t),
                i = parseFloat(e.marginTop || 0) + parseFloat(e.marginBottom || 0),
                e = parseFloat(e.marginLeft || 0) + parseFloat(e.marginRight || 0);
            return {
                width: t.offsetWidth + e,
                height: t.offsetHeight + i
            }
        }

        function k(t) {
            var e = {
                left: "right",
                right: "left",
                bottom: "top",
                top: "bottom"
            };
            return t.replace(/left|right|bottom|top/g, function(t) {
                return e[t]
            })
        }

        function D(t, e, i) {
            i = i.split("-")[0];
            var t = C(t),
                s = {
                    width: t.width,
                    height: t.height
                },
                n = -1 !== ["right", "left"].indexOf(i),
                o = n ? "top" : "left",
                a = n ? "left" : "top",
                r = n ? "height" : "width",
                n = n ? "width" : "height";
            return s[o] = e[o] + e[r] / 2 - t[r] / 2, s[a] = i === a ? e[a] - t[n] : e[k(a)], s
        }

        function T(t, e) {
            return Array.prototype.find ? t.find(e) : t.filter(e)[0]
        }

        function E(t, i, e) {
            var s, n;
            return (void 0 === e ? t : t.slice(0, (t = t, s = "name", n = e, Array.prototype.findIndex ? t.findIndex(function(t) {
                return t[s] === n
            }) : (e = T(t, function(t) {
                return t[s] === n
            }), t.indexOf(e))))).forEach(function(t) {
                t.function && console.warn("`modifier.function` is deprecated, use `modifier.fn`!");
                var e = t.function || t.fn;
                t.enabled && a(e) && (i.offsets.popper = _(i.offsets.popper), i.offsets.reference = _(i.offsets.reference), i = e(i, t))
            }), i
        }

        function e(t, i) {
            return t.some(function(t) {
                var e = t.name;
                return t.enabled && e === i
            })
        }

        function S(t) {
            for (var e = [!1, "ms", "Webkit", "Moz", "O"], i = t.charAt(0).toUpperCase() + t.slice(1), s = 0; s < e.length; s++) {
                var n = e[s],
                    n = n ? "" + n + i : t;
                if (void 0 !== document.body.style[n]) return n
            }
            return null
        }

        function z(t) {
            t = t.ownerDocument;
            return t ? t.defaultView : window
        }

        function L(t, e, i, s) {
            i.updateBound = s, z(t).addEventListener("resize", i.updateBound, {
                passive: !0
            });
            s = c(t);
            return function t(e, i, s, n) {
                var o = "BODY" === e.nodeName,
                    e = o ? e.ownerDocument.defaultView : e;
                e.addEventListener(i, s, {
                    passive: !0
                }), o || t(c(e.parentNode), i, s, n), n.push(e)
            }(s, "scroll", i.updateBound, i.scrollParents), i.scrollElement = s, i.eventsEnabled = !0, i
        }

        function W() {
            var t, e;
            this.state.eventsEnabled && (cancelAnimationFrame(this.scheduleUpdate), this.state = (t = this.reference, e = this.state, z(t).removeEventListener("resize", e.updateBound), e.scrollParents.forEach(function(t) {
                t.removeEventListener("scroll", e.updateBound)
            }), e.updateBound = null, e.scrollParents = [], e.scrollElement = null, e.eventsEnabled = !1, e))
        }

        function I(t) {
            return "" !== t && !isNaN(parseFloat(t)) && isFinite(t)
        }

        function P(i, s) {
            Object.keys(s).forEach(function(t) {
                var e = ""; - 1 !== ["width", "height", "top", "right", "bottom", "left"].indexOf(t) && I(s[t]) && (e = "px"), i.style[t] = s[t] + e
            })
        }

        function R(t, e) {
            function i(t) {
                return t
            }
            var s = t.offsets,
                n = s.popper,
                s = s.reference,
                o = q,
                s = o(s.width),
                a = o(n.width),
                r = -1 !== ["left", "right"].indexOf(t.placement),
                t = -1 !== t.placement.indexOf("-"),
                r = e ? r || t || s % 2 == a % 2 ? o : A : i,
                o = e ? o : i;
            return {
                left: r(1 == s % 2 && 1 == a % 2 && !t && e ? n.left - 1 : n.left),
                top: o(n.top),
                bottom: o(n.bottom),
                right: r(n.right)
            }
        }

        function $(t, e, i) {
            var s, n = T(t, function(t) {
                    return t.name === e
                }),
                t = !!n && t.some(function(t) {
                    return t.name === i && t.enabled && t.order < n.order
                });
            return t || (s = "`" + e + "`", console.warn("`" + i + "` modifier is required by " + s + " modifier in order to work, be sure to include it before " + s + "!")), t
        }

        function j(t, e) {
            e = 1 < arguments.length && void 0 !== e && e, t = H.indexOf(t), t = H.slice(t + 1).concat(H.slice(0, t));
            return e ? t.reverse() : t
        }

        function B(t, r, l, e) {
            var n = [0, 0],
                s = -1 !== ["right", "left"].indexOf(e),
                e = t.split(/(\+|\-)/).map(function(t) {
                    return t.trim()
                }),
                t = e.indexOf(T(e, function(t) {
                    return -1 !== t.search(/,|\s/)
                })),
                i = (e[t] && -1 === e[t].indexOf(",") && console.warn("Offsets separated by white space(s) are deprecated, use a comma (,) instead."), /\s*,\s*|\s+/);
            return (-1 === t ? [e] : [e.slice(0, t).concat([e[t].split(i)[0]]), [e[t].split(i)[1]].concat(e.slice(t + 1))]).map(function(t, e) {
                var a = (1 === e ? !s : s) ? "height" : "width",
                    i = !1;
                return t.reduce(function(t, e) {
                    return "" === t[t.length - 1] && -1 !== ["+", "-"].indexOf(e) ? (t[t.length - 1] = e, i = !0, t) : i ? (t[t.length - 1] += e, i = !1, t) : t.concat(e)
                }, []).map(function(t) {
                    return e = a, i = r, s = l, n = +(o = (t = t).match(/((?:\-|\+)?\d*\.?\d*)(.*)/))[1], o = o[2], n ? 0 === o.indexOf("%") ? _("%p" === o ? i : s)[e] / 100 * n : "vh" === o || "vw" === o ? ("vh" === o ? N(document.documentElement.clientHeight, window.innerHeight || 0) : N(document.documentElement.clientWidth, window.innerWidth || 0)) / 100 * n : n : t;
                    var e, i, s, n, o
                })
            }).forEach(function(i, s) {
                i.forEach(function(t, e) {
                    I(t) && (n[s] += t * ("-" === i[e - 1] ? -1 : 1))
                })
            }), n
        }

        function M(t, e, i) {
            return e in t ? Object.defineProperty(t, e, {
                value: i,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = i, t
        }
        var Y = Math.min,
            A = Math.floor,
            q = Math.round,
            N = Math.max,
            i = "undefined" != typeof window && "undefined" != typeof document && "undefined" != typeof navigator,
            U = function() {
                for (var t = ["Edge", "Trident", "Firefox"], e = 0; e < t.length; e += 1)
                    if (i && 0 <= navigator.userAgent.indexOf(t[e])) return 1;
                return 0
            }(),
            V = i && window.Promise ? function(t) {
                var e = !1;
                return function() {
                    e || (e = !0, window.Promise.resolve().then(function() {
                        e = !1, t()
                    }))
                }
            } : function(t) {
                var e = !1;
                return function() {
                    e || (e = !0, setTimeout(function() {
                        e = !1, t()
                    }, U))
                }
            },
            K = i && !(!window.MSInputMethodContext || !document.documentMode),
            X = i && /MSIE 10/.test(navigator.userAgent),
            t = function(t, e, i) {
                return e && et(t.prototype, e), i && et(t, i), t
            },
            O = Object.assign || function(t) {
                for (var e, i = 1; i < arguments.length; i++)
                    for (var s in e = arguments[i]) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
                return t
            },
            Q = i && /Firefox/i.test(navigator.userAgent),
            G = ["auto-start", "auto", "auto-end", "top-start", "top", "top-end", "right-start", "right", "right-end", "bottom-end", "bottom", "bottom-start", "left-end", "left", "left-start"],
            H = G.slice(3),
            J = "flip",
            Z = "clockwise",
            tt = "counterclockwise",
            t = (t(F, [{
                key: "update",
                value: function() {
                    return function() {
                        var t;
                        this.state.isDestroyed || ((t = {
                            instance: this,
                            styles: {},
                            arrowStyles: {},
                            attributes: {},
                            flipped: !1,
                            offsets: {}
                        }).offsets.reference = x(this.state, this.popper, this.reference, this.options.positionFixed), t.placement = r(this.options.placement, t.offsets.reference, this.popper, this.reference, this.options.modifiers.flip.boundariesElement, this.options.modifiers.flip.padding), t.originalPlacement = t.placement, t.positionFixed = this.options.positionFixed, t.offsets.popper = D(this.popper, t.offsets.reference, t.placement), t.offsets.popper.position = this.options.positionFixed ? "fixed" : "absolute", t = E(this.modifiers, t), this.state.isCreated ? this.options.onUpdate(t) : (this.state.isCreated = !0, this.options.onCreate(t)))
                    }.call(this)
                }
            }, {
                key: "destroy",
                value: function() {
                    return function() {
                        return this.state.isDestroyed = !0, e(this.modifiers, "applyStyle") && (this.popper.removeAttribute("x-placement"), this.popper.style.position = "", this.popper.style.top = "", this.popper.style.left = "", this.popper.style.right = "", this.popper.style.bottom = "", this.popper.style.willChange = "", this.popper.style[S("transform")] = ""), this.disableEventListeners(), this.options.removeOnDestroy && this.popper.parentNode.removeChild(this.popper), this
                    }.call(this)
                }
            }, {
                key: "enableEventListeners",
                value: function() {
                    return function() {
                        this.state.eventsEnabled || (this.state = L(this.reference, this.options, this.state, this.scheduleUpdate))
                    }.call(this)
                }
            }, {
                key: "disableEventListeners",
                value: function() {
                    return W.call(this)
                }
            }]), F);

        function F(t, e) {
            var i = this,
                s = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {},
                n = this,
                o = F;
            if (!(n instanceof o)) throw new TypeError("Cannot call a class as a function");
            this.scheduleUpdate = function() {
                return requestAnimationFrame(i.update)
            }, this.update = V(this.update.bind(this)), this.options = O({}, F.Defaults, s), this.state = {
                isDestroyed: !1,
                isCreated: !1,
                scrollParents: []
            }, this.reference = t && t.jquery ? t[0] : t, this.popper = e && e.jquery ? e[0] : e, this.options.modifiers = {}, Object.keys(O({}, F.Defaults.modifiers, s.modifiers)).forEach(function(t) {
                i.options.modifiers[t] = O({}, F.Defaults.modifiers[t] || {}, s.modifiers ? s.modifiers[t] : {})
            }), this.modifiers = Object.keys(this.options.modifiers).map(function(t) {
                return O({
                    name: t
                }, i.options.modifiers[t])
            }).sort(function(t, e) {
                return t.order - e.order
            }), this.modifiers.forEach(function(t) {
                t.enabled && a(t.onLoad) && t.onLoad(i.reference, i.popper, i.options, t, i.state)
            }), this.update();
            n = this.options.eventsEnabled;
            n && this.enableEventListeners(), this.state.eventsEnabled = n
        }

        function et(t, e) {
            for (var i, s = 0; s < e.length; s++)(i = e[s]).enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
        }
        return t.Utils = ("undefined" == typeof window ? global : window).PopperUtils, t.placements = G, t.Defaults = {
            placement: "bottom",
            positionFixed: !1,
            eventsEnabled: !0,
            removeOnDestroy: !1,
            onCreate: function() {},
            onUpdate: function() {},
            modifiers: {
                shift: {
                    order: 100,
                    enabled: !0,
                    fn: function(t) {
                        var e, i, s, n = t.placement,
                            o = n.split("-")[0],
                            n = n.split("-")[1];
                        return n && (e = (i = t.offsets).reference, i = i.popper, s = (o = -1 !== ["bottom", "top"].indexOf(o)) ? "width" : "height", o = {
                            start: M({}, o = o ? "left" : "top", e[o]),
                            end: M({}, o, e[o] + e[s] - i[s])
                        }, t.offsets.popper = O({}, i, o[n])), t
                    }
                },
                offset: {
                    order: 200,
                    enabled: !0,
                    fn: function(t, e) {
                        var e = e.offset,
                            i = t.placement,
                            s = (n = t.offsets).popper,
                            n = n.reference,
                            i = i.split("-")[0],
                            e = I(+e) ? [+e, 0] : B(e, s, n, i);
                        return "left" === i ? (s.top += e[0], s.left -= e[1]) : "right" === i ? (s.top += e[0], s.left += e[1]) : "top" === i ? (s.left += e[0], s.top -= e[1]) : "bottom" === i && (s.left += e[0], s.top += e[1]), t.popper = s, t
                    },
                    offset: 0
                },
                preventOverflow: {
                    order: 300,
                    enabled: !0,
                    fn: function(t, s) {
                        var e = s.boundariesElement || p(t.instance.popper),
                            i = (t.instance.reference === e && (e = p(e)), S("transform")),
                            n = t.instance.popper.style,
                            o = n.top,
                            a = n.left,
                            r = n[i],
                            l = (n.top = "", n.left = "", n[i] = "", w(t.instance.popper, t.instance.reference, s.padding, e, t.positionFixed)),
                            e = (n.top = o, n.left = a, n[i] = r, s.boundaries = l, s.priority),
                            h = t.offsets.popper,
                            c = {
                                primary: function(t) {
                                    var e = h[t];
                                    return h[t] < l[t] && !s.escapeWithReference && (e = N(h[t], l[t])), M({}, t, e)
                                },
                                secondary: function(t) {
                                    var e = "right" === t ? "left" : "top",
                                        i = h[e];
                                    return h[t] > l[t] && !s.escapeWithReference && (i = Y(h[e], l[t] - ("right" === t ? h.width : h.height))), M({}, e, i)
                                }
                            };
                        return e.forEach(function(t) {
                            var e = -1 === ["left", "top"].indexOf(t) ? "secondary" : "primary";
                            h = O({}, h, c[e](t))
                        }), t.offsets.popper = h, t
                    },
                    priority: ["left", "right", "top", "bottom"],
                    padding: 5,
                    boundariesElement: "scrollParent"
                },
                keepTogether: {
                    order: 400,
                    enabled: !0,
                    fn: function(t) {
                        var e = t.offsets,
                            i = e.popper,
                            e = e.reference,
                            s = t.placement.split("-")[0],
                            n = A,
                            s = -1 !== ["top", "bottom"].indexOf(s),
                            o = s ? "right" : "bottom",
                            a = s ? "left" : "top",
                            s = s ? "width" : "height";
                        return i[o] < n(e[a]) && (t.offsets.popper[a] = n(e[a]) - i[s]), i[a] > n(e[o]) && (t.offsets.popper[a] = n(e[o])), t
                    }
                },
                arrow: {
                    order: 500,
                    enabled: !0,
                    fn: function(t, e) {
                        if ($(t.instance.modifiers, "arrow", "keepTogether")) {
                            e = e.element;
                            if ("string" == typeof e) {
                                if (!(e = t.instance.popper.querySelector(e))) return t
                            } else if (!t.instance.popper.contains(e)) return console.warn("WARNING: `arrow.element` must be child of its popper element!"), t;
                            var i = t.placement.split("-")[0],
                                s = t.offsets,
                                n = s.popper,
                                s = s.reference,
                                i = -1 !== ["left", "right"].indexOf(i),
                                o = i ? "height" : "width",
                                a = i ? "Top" : "Left",
                                r = a.toLowerCase(),
                                l = i ? "left" : "top",
                                i = i ? "bottom" : "right",
                                h = C(e)[o],
                                i = (s[i] - h < n[r] && (t.offsets.popper[r] -= n[r] - (s[i] - h)), s[r] + h > n[i] && (t.offsets.popper[r] += s[r] + h - n[i]), t.offsets.popper = _(t.offsets.popper), s[r] + s[o] / 2 - h / 2),
                                s = u(t.instance.popper),
                                c = parseFloat(s["margin" + a]),
                                s = parseFloat(s["border" + a + "Width"]),
                                a = i - t.offsets.popper[r] - c - s,
                                a = N(Y(n[o] - h, a), 0);
                            t.arrowElement = e, t.offsets.arrow = (M(i = {}, r, q(a)), M(i, l, ""), i)
                        }
                        return t
                    },
                    element: "[x-arrow]"
                },
                flip: {
                    order: 600,
                    enabled: !0,
                    fn: function(h, c) {
                        if (!(e(h.instance.modifiers, "inner") || h.flipped && h.placement === h.originalPlacement)) {
                            var u = w(h.instance.popper, h.instance.reference, c.padding, c.boundariesElement, h.positionFixed),
                                d = h.placement.split("-")[0],
                                p = k(d),
                                f = h.placement.split("-")[1] || "",
                                m = [];
                            switch (c.behavior) {
                                case J:
                                    m = [d, p];
                                    break;
                                case Z:
                                    m = j(d);
                                    break;
                                case tt:
                                    m = j(d, !0);
                                    break;
                                default:
                                    m = c.behavior
                            }
                            m.forEach(function(t, e) {
                                if (d !== t || m.length === e + 1) return h;
                                d = h.placement.split("-")[0], p = k(d);
                                var t = h.offsets.popper,
                                    i = h.offsets.reference,
                                    s = A,
                                    i = "left" === d && s(t.right) > s(i.left) || "right" === d && s(t.left) < s(i.right) || "top" === d && s(t.bottom) > s(i.top) || "bottom" === d && s(t.top) < s(i.bottom),
                                    n = s(t.left) < s(u.left),
                                    o = s(t.right) > s(u.right),
                                    a = s(t.top) < s(u.top),
                                    t = s(t.bottom) > s(u.bottom),
                                    s = "left" === d && n || "right" === d && o || "top" === d && a || "bottom" === d && t,
                                    r = -1 !== ["top", "bottom"].indexOf(d),
                                    l = !!c.flipVariations && (r && "start" === f && n || r && "end" === f && o || !r && "start" === f && a || !r && "end" === f && t),
                                    o = !!c.flipVariationsByContent && (r && "start" === f && o || r && "end" === f && n || !r && "start" === f && t || !r && "end" === f && a),
                                    n = l || o;
                                (i || s || n) && (h.flipped = !0, (i || s) && (d = m[e + 1]), n && (f = "end" === (t = f) ? "start" : "start" === t ? "end" : t), h.placement = d + (f ? "-" + f : ""), h.offsets.popper = O({}, h.offsets.popper, D(h.instance.popper, h.offsets.reference, h.placement)), h = E(h.instance.modifiers, h, "flip"))
                            })
                        }
                        return h
                    },
                    behavior: "flip",
                    padding: 5,
                    boundariesElement: "viewport",
                    flipVariations: !1,
                    flipVariationsByContent: !1
                },
                inner: {
                    order: 700,
                    enabled: !1,
                    fn: function(t) {
                        var e = t.placement,
                            i = e.split("-")[0],
                            s = t.offsets,
                            n = s.popper,
                            s = s.reference,
                            o = -1 !== ["left", "right"].indexOf(i),
                            a = -1 === ["top", "left"].indexOf(i);
                        return n[o ? "left" : "top"] = s[i] - (a ? n[o ? "width" : "height"] : 0), t.placement = k(e), t.offsets.popper = _(n), t
                    }
                },
                hide: {
                    order: 800,
                    enabled: !0,
                    fn: function(t) {
                        if ($(t.instance.modifiers, "hide", "preventOverflow")) {
                            var e = t.offsets.reference,
                                i = T(t.instance.modifiers, function(t) {
                                    return "preventOverflow" === t.name
                                }).boundaries;
                            if (e.bottom < i.top || e.left > i.right || e.top > i.bottom || e.right < i.left) {
                                if (!0 === t.hide) return t;
                                t.hide = !0, t.attributes["x-out-of-boundaries"] = ""
                            } else {
                                if (!1 === t.hide) return t;
                                t.hide = !1, t.attributes["x-out-of-boundaries"] = !1
                            }
                        }
                        return t
                    }
                },
                computeStyle: {
                    order: 850,
                    enabled: !0,
                    fn: function(t, e) {
                        var i = e.x,
                            s = e.y,
                            n = t.offsets.popper,
                            o = T(t.instance.modifiers, function(t) {
                                return "applyStyle" === t.name
                            }).gpuAcceleration;
                        void 0 !== o && console.warn("WARNING: `gpuAcceleration` option moved to `computeStyle` modifier and will not be supported in future versions of Popper.js!");
                        var e = void 0 === o ? e.gpuAcceleration : o,
                            o = p(t.instance.popper),
                            a = v(o),
                            n = {
                                position: n.position
                            },
                            r = R(t, window.devicePixelRatio < 2 || !Q),
                            i = "bottom" === i ? "top" : "bottom",
                            s = "right" === s ? "left" : "right",
                            l = S("transform"),
                            h = "bottom" == i ? "HTML" === o.nodeName ? -o.clientHeight + r.bottom : -a.height + r.bottom : r.top,
                            o = "right" == s ? "HTML" === o.nodeName ? -o.clientWidth + r.right : -a.width + r.right : r.left,
                            r = (e && l ? (n[l] = "translate3d(" + o + "px, " + h + "px, 0)", n[i] = 0, n[s] = 0, n.willChange = "transform") : (a = "right" == s ? -1 : 1, n[i] = h * ("bottom" == i ? -1 : 1), n[s] = o * a, n.willChange = i + ", " + s), {
                                "x-placement": t.placement
                            });
                        return t.attributes = O({}, r, t.attributes), t.styles = O({}, n, t.styles), t.arrowStyles = O({}, t.offsets.arrow, t.arrowStyles), t
                    },
                    gpuAcceleration: !0,
                    x: "bottom",
                    y: "right"
                },
                applyStyle: {
                    order: 900,
                    enabled: !0,
                    fn: function(t) {
                        return P(t.instance.popper, t.styles), e = t.instance.popper, i = t.attributes, Object.keys(i).forEach(function(t) {
                            !1 === i[t] ? e.removeAttribute(t) : e.setAttribute(t, i[t])
                        }), t.arrowElement && Object.keys(t.arrowStyles).length && P(t.arrowElement, t.arrowStyles), t;
                        var e, i
                    },
                    onLoad: function(t, e, i, s, n) {
                        n = x(n, e, t, i.positionFixed), n = r(i.placement, n, e, t, i.modifiers.flip.boundariesElement, i.modifiers.flip.padding);
                        return e.setAttribute("x-placement", n), P(e, {
                            position: i.positionFixed ? "fixed" : "absolute"
                        }), i
                    },
                    gpuAcceleration: void 0
                }
            }
        }, t
    }), ! function(t, e) {
        "object" == typeof exports && "undefined" != typeof module ? e(exports, require("jquery"), require("popper.js")) : "function" == typeof define && define.amd ? define(["exports", "jquery", "popper.js"], e) : e((t = "undefined" != typeof globalThis ? globalThis : t || self).bootstrap = {}, t.jQuery, t.Popper)
    }(this, function(t, e, i) {
        "use strict";

        function F(t) {
            return t && "object" == typeof t && "default" in t ? t : {
                default: t
            }
        }
        var c = F(e),
            n = F(i);

        function z(t, e) {
            for (var i = 0; i < e.length; i++) {
                var s = e[i];
                s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(t, s.key, s)
            }
        }

        function s(t, e, i) {
            e && z(t.prototype, e), i && z(t, i)
        }

        function o() {
            return (o = Object.assign || function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var i, s = arguments[e];
                    for (i in s) Object.prototype.hasOwnProperty.call(s, i) && (t[i] = s[i])
                }
                return t
            }).apply(this, arguments)
        }
        var u = {
                TRANSITION_END: "bsTransitionEnd",
                getUID: function(t) {
                    for (; t += ~~(1e6 * Math.random()), document.getElementById(t););
                    return t
                },
                getSelectorFromElement: function(t) {
                    var e, i = t.getAttribute("data-target");
                    i && "#" !== i || (i = (e = t.getAttribute("href")) && "#" !== e ? e.trim() : "");
                    try {
                        return document.querySelector(i) ? i : null
                    } catch (t) {
                        return null
                    }
                },
                getTransitionDurationFromElement: function(t) {
                    var e, i, s;
                    return t && (e = c.default(t).css("transition-duration"), t = c.default(t).css("transition-delay"), i = parseFloat(e), s = parseFloat(t), i || s) ? (e = e.split(",")[0], t = t.split(",")[0], 1e3 * (parseFloat(e) + parseFloat(t))) : 0
                },
                reflow: function(t) {
                    return t.offsetHeight
                },
                triggerTransitionEnd: function(t) {
                    c.default(t).trigger("transitionend")
                },
                supportsTransitionEnd: function() {
                    return Boolean("transitionend")
                },
                isElement: function(t) {
                    return (t[0] || t).nodeType
                },
                typeCheckConfig: function(t, e, i) {
                    for (var s in i)
                        if (Object.prototype.hasOwnProperty.call(i, s)) {
                            var n = i[s],
                                o = e[s],
                                o = o && u.isElement(o) ? "element" : null == (o = o) ? "" + o : {}.toString.call(o).match(/\s([a-z]+)/i)[1].toLowerCase();
                            if (!new RegExp(n).test(o)) throw new Error(t.toUpperCase() + ': Option "' + s + '" provided type "' + o + '" but expected type "' + n + '".')
                        }
                },
                findShadowRoot: function(t) {
                    var e;
                    return document.documentElement.attachShadow ? "function" == typeof t.getRootNode ? (e = t.getRootNode()) instanceof ShadowRoot ? e : null : t instanceof ShadowRoot ? t : t.parentNode ? u.findShadowRoot(t.parentNode) : null : null
                },
                jQueryDetection: function() {
                    if (void 0 === c.default) throw new TypeError("Bootstrap's JavaScript requires jQuery. jQuery must be included before Bootstrap's JavaScript.");
                    var t = c.default.fn.jquery.split(" ")[0].split(".");
                    if (t[0] < 2 && t[1] < 9 || 1 === t[0] && 9 === t[1] && t[2] < 1 || 4 <= t[0]) throw new Error("Bootstrap's JavaScript requires at least jQuery v1.9.1 but less than v4.0.0")
                }
            },
            a = (u.jQueryDetection(), c.default.fn.emulateTransitionEnd = function(t) {
                var e = this,
                    i = !1;
                return c.default(this).one(u.TRANSITION_END, function() {
                    i = !0
                }), setTimeout(function() {
                    i || u.triggerTransitionEnd(e)
                }, t), this
            }, c.default.event.special[u.TRANSITION_END] = {
                bindType: "transitionend",
                delegateType: "transitionend",
                handle: function(t) {
                    if (c.default(t.target).is(this)) return t.handleObj.handler.apply(this, arguments)
                }
            }, "alert"),
            L = c.default.fn[a],
            r = ((e = l.prototype).close = function(t) {
                var e = this._element;
                t && (e = this._getRootElement(t)), this._triggerCloseEvent(e).isDefaultPrevented() || this._removeElement(e)
            }, e.dispose = function() {
                c.default.removeData(this._element, "bs.alert"), this._element = null
            }, e._getRootElement = function(t) {
                var e = u.getSelectorFromElement(t),
                    i = !1;
                return i = (i = e ? document.querySelector(e) : i) || c.default(t).closest(".alert")[0]
            }, e._triggerCloseEvent = function(t) {
                var e = c.default.Event("close.bs.alert");
                return c.default(t).trigger(e), e
            }, e._removeElement = function(e) {
                var t, i = this;
                c.default(e).removeClass("show"), c.default(e).hasClass("fade") ? (t = u.getTransitionDurationFromElement(e), c.default(e).one(u.TRANSITION_END, function(t) {
                    return i._destroyElement(e, t)
                }).emulateTransitionEnd(t)) : this._destroyElement(e)
            }, e._destroyElement = function(t) {
                c.default(t).detach().trigger("closed.bs.alert").remove()
            }, l._jQueryInterface = function(i) {
                return this.each(function() {
                    var t = c.default(this),
                        e = t.data("bs.alert");
                    e || (e = new l(this), t.data("bs.alert", e)), "close" === i && e[i](this)
                })
            }, l._handleDismiss = function(e) {
                return function(t) {
                    t && t.preventDefault(), e.close(this)
                }
            }, s(l, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }]), l);

        function l(t) {
            this._element = t
        }
        c.default(document).on("click.bs.alert.data-api", '[data-dismiss="alert"]', r._handleDismiss(new r)), c.default.fn[a] = r._jQueryInterface, c.default.fn[a].Constructor = r, c.default.fn[a].noConflict = function() {
            return c.default.fn[a] = L, r._jQueryInterface
        };
        var W = c.default.fn.button,
            h = ((i = d.prototype).toggle = function() {
                var t, e = !0,
                    i = !0,
                    s = c.default(this._element).closest('[data-toggle="buttons"]')[0];
                s && (t = this._element.querySelector('input:not([type="hidden"])')) && ("radio" === t.type && (t.checked && this._element.classList.contains("active") ? e = !1 : (s = s.querySelector(".active")) && c.default(s).removeClass("active")), e && ("checkbox" !== t.type && "radio" !== t.type || (t.checked = !this._element.classList.contains("active")), this.shouldAvoidTriggerChange || c.default(t).trigger("change")), t.focus(), i = !1), this._element.hasAttribute("disabled") || this._element.classList.contains("disabled") || (i && this._element.setAttribute("aria-pressed", !this._element.classList.contains("active")), e && c.default(this._element).toggleClass("active"))
            }, i.dispose = function() {
                c.default.removeData(this._element, "bs.button"), this._element = null
            }, d._jQueryInterface = function(i, s) {
                return this.each(function() {
                    var t = c.default(this),
                        e = t.data("bs.button");
                    e || (e = new d(this), t.data("bs.button", e)), e.shouldAvoidTriggerChange = s, "toggle" === i && e[i]()
                })
            }, s(d, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }]), d);

        function d(t) {
            this._element = t, this.shouldAvoidTriggerChange = !1
        }
        c.default(document).on("click.bs.button.data-api", '[data-toggle^="button"]', function(t) {
            var e, i = t.target,
                s = i;
            !(i = c.default(i).hasClass("btn") ? i : c.default(i).closest(".btn")[0]) || i.hasAttribute("disabled") || i.classList.contains("disabled") || (e = i.querySelector('input:not([type="hidden"])')) && (e.hasAttribute("disabled") || e.classList.contains("disabled")) ? t.preventDefault() : "INPUT" !== s.tagName && "LABEL" === i.tagName || h._jQueryInterface.call(c.default(i), "toggle", "INPUT" === s.tagName)
        }).on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]', function(t) {
            var e = c.default(t.target).closest(".btn")[0];
            c.default(e).toggleClass("focus", /^focus(in)?$/.test(t.type))
        }), c.default(window).on("load.bs.button.data-api", function() {
            for (var t = [].slice.call(document.querySelectorAll('[data-toggle="buttons"] .btn')), e = 0, i = t.length; e < i; e++) {
                var s = t[e],
                    n = s.querySelector('input:not([type="hidden"])');
                n.checked || n.hasAttribute("checked") ? s.classList.add("active") : s.classList.remove("active")
            }
            for (var o = 0, a = (t = [].slice.call(document.querySelectorAll('[data-toggle="button"]'))).length; o < a; o++) {
                var r = t[o];
                "true" === r.getAttribute("aria-pressed") ? r.classList.add("active") : r.classList.remove("active")
            }
        }), c.default.fn.button = h._jQueryInterface, c.default.fn.button.Constructor = h, c.default.fn.button.noConflict = function() {
            return c.default.fn.button = W, h._jQueryInterface
        };
        var p = "carousel",
            R = c.default.fn[p],
            $ = {
                interval: 5e3,
                keyboard: !0,
                slide: !1,
                pause: "hover",
                wrap: !0,
                touch: !0
            },
            j = {
                interval: "(number|boolean)",
                keyboard: "boolean",
                slide: "(boolean|string)",
                pause: "(string|boolean)",
                wrap: "boolean",
                touch: "boolean"
            },
            B = {
                TOUCH: "touch",
                PEN: "pen"
            },
            f = ((e = m.prototype).next = function() {
                this._isSliding || this._slide("next")
            }, e.nextWhenVisible = function() {
                var t = c.default(this._element);
                !document.hidden && t.is(":visible") && "hidden" !== t.css("visibility") && this.next()
            }, e.prev = function() {
                this._isSliding || this._slide("prev")
            }, e.pause = function(t) {
                t || (this._isPaused = !0), this._element.querySelector(".carousel-item-next, .carousel-item-prev") && (u.triggerTransitionEnd(this._element), this.cycle(!0)), clearInterval(this._interval), this._interval = null
            }, e.cycle = function(t) {
                t || (this._isPaused = !1), this._interval && (clearInterval(this._interval), this._interval = null), this._config.interval && !this._isPaused && (this._updateInterval(), this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval))
            }, e.to = function(t) {
                var e = this,
                    i = (this._activeElement = this._element.querySelector(".active.carousel-item"), this._getItemIndex(this._activeElement));
                t > this._items.length - 1 || t < 0 || (this._isSliding ? c.default(this._element).one("slid.bs.carousel", function() {
                    return e.to(t)
                }) : i === t ? (this.pause(), this.cycle()) : this._slide(i < t ? "next" : "prev", this._items[t]))
            }, e.dispose = function() {
                c.default(this._element).off(".bs.carousel"), c.default.removeData(this._element, "bs.carousel"), this._items = null, this._config = null, this._element = null, this._interval = null, this._isPaused = null, this._isSliding = null, this._activeElement = null, this._indicatorsElement = null
            }, e._getConfig = function(t) {
                return t = o({}, $, t), u.typeCheckConfig(p, t, j), t
            }, e._handleSwipe = function() {
                var t = Math.abs(this.touchDeltaX);
                t <= 40 || (t = t / this.touchDeltaX, (this.touchDeltaX = 0) < t && this.prev(), t < 0 && this.next())
            }, e._addEventListeners = function() {
                var e = this;
                this._config.keyboard && c.default(this._element).on("keydown.bs.carousel", function(t) {
                    return e._keydown(t)
                }), "hover" === this._config.pause && c.default(this._element).on("mouseenter.bs.carousel", function(t) {
                    return e.pause(t)
                }).on("mouseleave.bs.carousel", function(t) {
                    return e.cycle(t)
                }), this._config.touch && this._addTouchEventListeners()
            }, e._addTouchEventListeners = function() {
                var t, e, i = this;
                this._touchSupported && (t = function(t) {
                    i._pointerEvent && B[t.originalEvent.pointerType.toUpperCase()] ? i.touchStartX = t.originalEvent.clientX : i._pointerEvent || (i.touchStartX = t.originalEvent.touches[0].clientX)
                }, e = function(t) {
                    i._pointerEvent && B[t.originalEvent.pointerType.toUpperCase()] && (i.touchDeltaX = t.originalEvent.clientX - i.touchStartX), i._handleSwipe(), "hover" === i._config.pause && (i.pause(), i.touchTimeout && clearTimeout(i.touchTimeout), i.touchTimeout = setTimeout(function(t) {
                        return i.cycle(t)
                    }, 500 + i._config.interval))
                }, c.default(this._element.querySelectorAll(".carousel-item img")).on("dragstart.bs.carousel", function(t) {
                    return t.preventDefault()
                }), this._pointerEvent ? (c.default(this._element).on("pointerdown.bs.carousel", t), c.default(this._element).on("pointerup.bs.carousel", e), this._element.classList.add("pointer-event")) : (c.default(this._element).on("touchstart.bs.carousel", t), c.default(this._element).on("touchmove.bs.carousel", function(t) {
                    (t = t).originalEvent.touches && 1 < t.originalEvent.touches.length ? i.touchDeltaX = 0 : i.touchDeltaX = t.originalEvent.touches[0].clientX - i.touchStartX
                }), c.default(this._element).on("touchend.bs.carousel", e)))
            }, e._keydown = function(t) {
                if (!/input|textarea/i.test(t.target.tagName)) switch (t.which) {
                    case 37:
                        t.preventDefault(), this.prev();
                        break;
                    case 39:
                        t.preventDefault(), this.next()
                }
            }, e._getItemIndex = function(t) {
                return this._items = t && t.parentNode ? [].slice.call(t.parentNode.querySelectorAll(".carousel-item")) : [], this._items.indexOf(t)
            }, e._getItemByDirection = function(t, e) {
                var i = "next" === t,
                    s = "prev" === t,
                    n = this._getItemIndex(e),
                    o = this._items.length - 1;
                return (s && 0 === n || i && n === o) && !this._config.wrap ? e : -1 == (s = (n + ("prev" === t ? -1 : 1)) % this._items.length) ? this._items[this._items.length - 1] : this._items[s]
            }, e._triggerSlideEvent = function(t, e) {
                var i = this._getItemIndex(t),
                    s = this._getItemIndex(this._element.querySelector(".active.carousel-item")),
                    t = c.default.Event("slide.bs.carousel", {
                        relatedTarget: t,
                        direction: e,
                        from: s,
                        to: i
                    });
                return c.default(this._element).trigger(t), t
            }, e._setActiveIndicatorElement = function(t) {
                var e;
                this._indicatorsElement && (e = [].slice.call(this._indicatorsElement.querySelectorAll(".active")), c.default(e).removeClass("active"), e = this._indicatorsElement.children[this._getItemIndex(t)]) && c.default(e).addClass("active")
            }, e._updateInterval = function() {
                var t = this._activeElement || this._element.querySelector(".active.carousel-item");
                t && ((t = parseInt(t.getAttribute("data-interval"), 10)) ? (this._config.defaultInterval = this._config.defaultInterval || this._config.interval, this._config.interval = t) : this._config.interval = this._config.defaultInterval || this._config.interval)
            }, e._slide = function(t, e) {
                var i, s, n, o = this,
                    a = this._element.querySelector(".active.carousel-item"),
                    r = this._getItemIndex(a),
                    l = e || a && this._getItemByDirection(t, a),
                    e = this._getItemIndex(l),
                    h = Boolean(this._interval),
                    t = "next" === t ? (i = "carousel-item-left", s = "carousel-item-next", "left") : (i = "carousel-item-right", s = "carousel-item-prev", "right");
                l && c.default(l).hasClass("active") ? this._isSliding = !1 : !this._triggerSlideEvent(l, t).isDefaultPrevented() && a && l && (this._isSliding = !0, h && this.pause(), this._setActiveIndicatorElement(l), this._activeElement = l, n = c.default.Event("slid.bs.carousel", {
                    relatedTarget: l,
                    direction: t,
                    from: r,
                    to: e
                }), c.default(this._element).hasClass("slide") ? (c.default(l).addClass(s), u.reflow(l), c.default(a).addClass(i), c.default(l).addClass(i), t = u.getTransitionDurationFromElement(a), c.default(a).one(u.TRANSITION_END, function() {
                    c.default(l).removeClass(i + " " + s).addClass("active"), c.default(a).removeClass("active " + s + " " + i), o._isSliding = !1, setTimeout(function() {
                        return c.default(o._element).trigger(n)
                    }, 0)
                }).emulateTransitionEnd(t)) : (c.default(a).removeClass("active"), c.default(l).addClass("active"), this._isSliding = !1, c.default(this._element).trigger(n)), h) && this.cycle()
            }, m._jQueryInterface = function(s) {
                return this.each(function() {
                    var t = c.default(this).data("bs.carousel"),
                        e = o({}, $, c.default(this).data()),
                        i = ("object" == typeof s && (e = o({}, e, s)), "string" == typeof s ? s : e.slide);
                    if (t || (t = new m(this, e), c.default(this).data("bs.carousel", t)), "number" == typeof s) t.to(s);
                    else if ("string" == typeof i) {
                        if (void 0 === t[i]) throw new TypeError('No method named "' + i + '"');
                        t[i]()
                    } else e.interval && e.ride && (t.pause(), t.cycle())
                })
            }, m._dataApiClickHandler = function(t) {
                var e, i, s = u.getSelectorFromElement(this);
                s && (s = c.default(s)[0]) && c.default(s).hasClass("carousel") && (e = o({}, c.default(s).data(), c.default(this).data()), (i = this.getAttribute("data-slide-to")) && (e.interval = !1), m._jQueryInterface.call(c.default(s), e), i && c.default(s).data("bs.carousel").to(i), t.preventDefault())
            }, s(m, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "Default",
                get: function() {
                    return $
                }
            }]), m);

        function m(t, e) {
            this._items = null, this._interval = null, this._activeElement = null, this._isPaused = !1, this._isSliding = !1, this.touchTimeout = null, this.touchStartX = 0, this.touchDeltaX = 0, this._config = this._getConfig(e), this._element = t, this._indicatorsElement = this._element.querySelector(".carousel-indicators"), this._touchSupported = "ontouchstart" in document.documentElement || 0 < navigator.maxTouchPoints, this._pointerEvent = Boolean(window.PointerEvent || window.MSPointerEvent), this._addEventListeners()
        }
        c.default(document).on("click.bs.carousel.data-api", "[data-slide], [data-slide-to]", f._dataApiClickHandler), c.default(window).on("load.bs.carousel.data-api", function() {
            for (var t = [].slice.call(document.querySelectorAll('[data-ride="carousel"]')), e = 0, i = t.length; e < i; e++) {
                var s = c.default(t[e]);
                f._jQueryInterface.call(s, s.data())
            }
        }), c.default.fn[p] = f._jQueryInterface, c.default.fn[p].Constructor = f, c.default.fn[p].noConflict = function() {
            return c.default.fn[p] = R, f._jQueryInterface
        };
        var g = "collapse",
            Y = c.default.fn[g],
            q = {
                toggle: !0,
                parent: ""
            },
            U = {
                toggle: "boolean",
                parent: "(string|element)"
            },
            _ = ((i = v.prototype).toggle = function() {
                c.default(this._element).hasClass("show") ? this.hide() : this.show()
            }, i.show = function() {
                var t, e, i, s, n = this;
                this._isTransitioning || c.default(this._element).hasClass("show") || (t = this._parent && 0 === (t = [].slice.call(this._parent.querySelectorAll(".show, .collapsing")).filter(function(t) {
                    return "string" == typeof n._config.parent ? t.getAttribute("data-parent") === n._config.parent : t.classList.contains("collapse")
                })).length ? null : t) && (s = c.default(t).not(this._selector).data("bs.collapse")) && s._isTransitioning || (i = c.default.Event("show.bs.collapse"), c.default(this._element).trigger(i), i.isDefaultPrevented() || (t && (v._jQueryInterface.call(c.default(t).not(this._selector), "hide"), s || c.default(t).data("bs.collapse", null)), e = this._getDimension(), c.default(this._element).removeClass("collapse").addClass("collapsing"), this._element.style[e] = 0, this._triggerArray.length && c.default(this._triggerArray).removeClass("collapsed").attr("aria-expanded", !0), this.setTransitioning(!0), i = "scroll" + (e[0].toUpperCase() + e.slice(1)), s = u.getTransitionDurationFromElement(this._element), c.default(this._element).one(u.TRANSITION_END, function() {
                    c.default(n._element).removeClass("collapsing").addClass("collapse show"), n._element.style[e] = "", n.setTransitioning(!1), c.default(n._element).trigger("shown.bs.collapse")
                }).emulateTransitionEnd(s), this._element.style[e] = this._element[i] + "px"))
            }, i.hide = function() {
                var t = this;
                if (!this._isTransitioning && c.default(this._element).hasClass("show")) {
                    var e = c.default.Event("hide.bs.collapse");
                    if (c.default(this._element).trigger(e), !e.isDefaultPrevented()) {
                        var e = this._getDimension(),
                            i = (this._element.style[e] = this._element.getBoundingClientRect()[e] + "px", u.reflow(this._element), c.default(this._element).addClass("collapsing").removeClass("collapse show"), this._triggerArray.length);
                        if (0 < i)
                            for (var s = 0; s < i; s++) {
                                var n = this._triggerArray[s],
                                    o = u.getSelectorFromElement(n);
                                null === o || c.default([].slice.call(document.querySelectorAll(o))).hasClass("show") || c.default(n).addClass("collapsed").attr("aria-expanded", !1)
                            }
                        this.setTransitioning(!0), this._element.style[e] = "";
                        e = u.getTransitionDurationFromElement(this._element);
                        c.default(this._element).one(u.TRANSITION_END, function() {
                            t.setTransitioning(!1), c.default(t._element).removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
                        }).emulateTransitionEnd(e)
                    }
                }
            }, i.setTransitioning = function(t) {
                this._isTransitioning = t
            }, i.dispose = function() {
                c.default.removeData(this._element, "bs.collapse"), this._config = null, this._parent = null, this._element = null, this._triggerArray = null, this._isTransitioning = null
            }, i._getConfig = function(t) {
                return (t = o({}, q, t)).toggle = Boolean(t.toggle), u.typeCheckConfig(g, t, U), t
            }, i._getDimension = function() {
                return c.default(this._element).hasClass("width") ? "width" : "height"
            }, i._getParent = function() {
                var t, i = this,
                    e = (u.isElement(this._config.parent) ? (t = this._config.parent, void 0 !== this._config.parent.jquery && (t = this._config.parent[0])) : t = document.querySelector(this._config.parent), '[data-toggle="collapse"][data-parent="' + this._config.parent + '"]'),
                    e = [].slice.call(t.querySelectorAll(e));
                return c.default(e).each(function(t, e) {
                    i._addAriaAndCollapsedClass(v._getTargetFromElement(e), [e])
                }), t
            }, i._addAriaAndCollapsedClass = function(t, e) {
                t = c.default(t).hasClass("show");
                e.length && c.default(e).toggleClass("collapsed", !t).attr("aria-expanded", t)
            }, v._getTargetFromElement = function(t) {
                t = u.getSelectorFromElement(t);
                return t ? document.querySelector(t) : null
            }, v._jQueryInterface = function(s) {
                return this.each(function() {
                    var t = c.default(this),
                        e = t.data("bs.collapse"),
                        i = o({}, q, t.data(), "object" == typeof s && s ? s : {});
                    if (!e && i.toggle && "string" == typeof s && /show|hide/.test(s) && (i.toggle = !1), e || (e = new v(this, i), t.data("bs.collapse", e)), "string" == typeof s) {
                        if (void 0 === e[s]) throw new TypeError('No method named "' + s + '"');
                        e[s]()
                    }
                })
            }, s(v, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "Default",
                get: function() {
                    return q
                }
            }]), v);

        function v(e, t) {
            this._isTransitioning = !1, this._element = e, this._config = this._getConfig(t), this._triggerArray = [].slice.call(document.querySelectorAll('[data-toggle="collapse"][href="#' + e.id + '"],[data-toggle="collapse"][data-target="#' + e.id + '"]'));
            for (var i = [].slice.call(document.querySelectorAll('[data-toggle="collapse"]')), s = 0, n = i.length; s < n; s++) {
                var o = i[s],
                    a = u.getSelectorFromElement(o),
                    r = [].slice.call(document.querySelectorAll(a)).filter(function(t) {
                        return t === e
                    });
                null !== a && 0 < r.length && (this._selector = a, this._triggerArray.push(o))
            }
            this._parent = this._config.parent ? this._getParent() : null, this._config.parent || this._addAriaAndCollapsedClass(this._element, this._triggerArray), this._config.toggle && this.toggle()
        }
        c.default(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]', function(t) {
            "A" === t.currentTarget.tagName && t.preventDefault();
            var i = c.default(this),
                t = u.getSelectorFromElement(this),
                t = [].slice.call(document.querySelectorAll(t));
            c.default(t).each(function() {
                var t = c.default(this),
                    e = t.data("bs.collapse") ? "toggle" : i.data();
                _._jQueryInterface.call(t, e)
            })
        }), c.default.fn[g] = _._jQueryInterface, c.default.fn[g].Constructor = _, c.default.fn[g].noConflict = function() {
            return c.default.fn[g] = Y, _._jQueryInterface
        };
        var b = "dropdown",
            V = c.default.fn[b],
            K = new RegExp("38|40|27"),
            X = {
                offset: 0,
                flip: !0,
                boundary: "scrollParent",
                reference: "toggle",
                display: "dynamic",
                popperConfig: null
            },
            Q = {
                offset: "(number|string|function)",
                flip: "boolean",
                boundary: "(string|element)",
                reference: "(string|element)",
                display: "string",
                popperConfig: "(null|object)"
            },
            y = ((e = w.prototype).toggle = function() {
                var t;
                this._element.disabled || c.default(this._element).hasClass("disabled") || (t = c.default(this._menu).hasClass("show"), w._clearMenus(), t) || this.show(!0)
            }, e.show = function(t) {
                if (void 0 === t && (t = !1), !(this._element.disabled || c.default(this._element).hasClass("disabled") || c.default(this._menu).hasClass("show"))) {
                    var e = {
                            relatedTarget: this._element
                        },
                        i = c.default.Event("show.bs.dropdown", e),
                        s = w._getParentFromElement(this._element);
                    if (c.default(s).trigger(i), !i.isDefaultPrevented()) {
                        if (!this._inNavbar && t) {
                            if (void 0 === n.default) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org)");
                            i = this._element;
                            "parent" === this._config.reference ? i = s : u.isElement(this._config.reference) && (i = this._config.reference, void 0 !== this._config.reference.jquery) && (i = this._config.reference[0]), "scrollParent" !== this._config.boundary && c.default(s).addClass("position-static"), this._popper = new n.default(i, this._menu, this._getPopperConfig())
                        }
                        "ontouchstart" in document.documentElement && 0 === c.default(s).closest(".navbar-nav").length && c.default(document.body).children().on("mouseover", null, c.default.noop), this._element.focus(), this._element.setAttribute("aria-expanded", !0), c.default(this._menu).toggleClass("show"), c.default(s).toggleClass("show").trigger(c.default.Event("shown.bs.dropdown", e))
                    }
                }
            }, e.hide = function() {
                var t, e, i;
                this._element.disabled || c.default(this._element).hasClass("disabled") || !c.default(this._menu).hasClass("show") || (t = {
                    relatedTarget: this._element
                }, e = c.default.Event("hide.bs.dropdown", t), i = w._getParentFromElement(this._element), c.default(i).trigger(e), e.isDefaultPrevented()) || (this._popper && this._popper.destroy(), c.default(this._menu).toggleClass("show"), c.default(i).toggleClass("show").trigger(c.default.Event("hidden.bs.dropdown", t)))
            }, e.dispose = function() {
                c.default.removeData(this._element, "bs.dropdown"), c.default(this._element).off(".bs.dropdown"), this._element = null, (this._menu = null) !== this._popper && (this._popper.destroy(), this._popper = null)
            }, e.update = function() {
                this._inNavbar = this._detectNavbar(), null !== this._popper && this._popper.scheduleUpdate()
            }, e._addEventListeners = function() {
                var e = this;
                c.default(this._element).on("click.bs.dropdown", function(t) {
                    t.preventDefault(), t.stopPropagation(), e.toggle()
                })
            }, e._getConfig = function(t) {
                return t = o({}, this.constructor.Default, c.default(this._element).data(), t), u.typeCheckConfig(b, t, this.constructor.DefaultType), t
            }, e._getMenuElement = function() {
                var t;
                return this._menu || (t = w._getParentFromElement(this._element)) && (this._menu = t.querySelector(".dropdown-menu")), this._menu
            }, e._getPlacement = function() {
                var t = c.default(this._element.parentNode),
                    e = "bottom-start";
                return t.hasClass("dropup") ? e = c.default(this._menu).hasClass("dropdown-menu-right") ? "top-end" : "top-start" : t.hasClass("dropright") ? e = "right-start" : t.hasClass("dropleft") ? e = "left-start" : c.default(this._menu).hasClass("dropdown-menu-right") && (e = "bottom-end"), e
            }, e._detectNavbar = function() {
                return 0 < c.default(this._element).closest(".navbar").length
            }, e._getOffset = function() {
                var e = this,
                    t = {};
                return "function" == typeof this._config.offset ? t.fn = function(t) {
                    return t.offsets = o({}, t.offsets, e._config.offset(t.offsets, e._element) || {}), t
                } : t.offset = this._config.offset, t
            }, e._getPopperConfig = function() {
                var t = {
                    placement: this._getPlacement(),
                    modifiers: {
                        offset: this._getOffset(),
                        flip: {
                            enabled: this._config.flip
                        },
                        preventOverflow: {
                            boundariesElement: this._config.boundary
                        }
                    }
                };
                return "static" === this._config.display && (t.modifiers.applyStyle = {
                    enabled: !1
                }), o({}, t, this._config.popperConfig)
            }, w._jQueryInterface = function(e) {
                return this.each(function() {
                    var t = c.default(this).data("bs.dropdown");
                    if (t || (t = new w(this, "object" == typeof e ? e : null), c.default(this).data("bs.dropdown", t)), "string" == typeof e) {
                        if (void 0 === t[e]) throw new TypeError('No method named "' + e + '"');
                        t[e]()
                    }
                })
            }, w._clearMenus = function(t) {
                if (!t || 3 !== t.which && ("keyup" !== t.type || 9 === t.which))
                    for (var e = [].slice.call(document.querySelectorAll('[data-toggle="dropdown"]')), i = 0, s = e.length; i < s; i++) {
                        var n, o, a = w._getParentFromElement(e[i]),
                            r = c.default(e[i]).data("bs.dropdown"),
                            l = {
                                relatedTarget: e[i]
                            };
                        t && "click" === t.type && (l.clickEvent = t), r && (n = r._menu, !c.default(a).hasClass("show") || t && ("click" === t.type && /input|textarea/i.test(t.target.tagName) || "keyup" === t.type && 9 === t.which) && c.default.contains(a, t.target) || (o = c.default.Event("hide.bs.dropdown", l), c.default(a).trigger(o), o.isDefaultPrevented()) || ("ontouchstart" in document.documentElement && c.default(document.body).children().off("mouseover", null, c.default.noop), e[i].setAttribute("aria-expanded", "false"), r._popper && r._popper.destroy(), c.default(n).removeClass("show"), c.default(a).removeClass("show").trigger(c.default.Event("hidden.bs.dropdown", l))))
                    }
            }, w._getParentFromElement = function(t) {
                var e, i = u.getSelectorFromElement(t);
                return (e = i ? document.querySelector(i) : e) || t.parentNode
            }, w._dataApiKeydownHandler = function(t) {
                var e, i, s;
                (/input|textarea/i.test(t.target.tagName) ? 32 === t.which || 27 !== t.which && (40 !== t.which && 38 !== t.which || c.default(t.target).closest(".dropdown-menu").length) : !K.test(t.which)) || this.disabled || c.default(this).hasClass("disabled") || (e = w._getParentFromElement(this), !(i = c.default(e).hasClass("show")) && 27 === t.which) || (t.preventDefault(), t.stopPropagation(), i && 27 !== t.which && 32 !== t.which ? 0 !== (i = [].slice.call(e.querySelectorAll(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)")).filter(function(t) {
                    return c.default(t).is(":visible")
                })).length && (s = i.indexOf(t.target), 38 === t.which && 0 < s && s--, 40 === t.which && s < i.length - 1 && s++, i[s = s < 0 ? 0 : s].focus()) : (27 === t.which && c.default(e.querySelector('[data-toggle="dropdown"]')).trigger("focus"), c.default(this).trigger("click")))
            }, s(w, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "Default",
                get: function() {
                    return X
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return Q
                }
            }]), w);

        function w(t, e) {
            this._element = t, this._popper = null, this._config = this._getConfig(e), this._menu = this._getMenuElement(), this._inNavbar = this._detectNavbar(), this._addEventListeners()
        }
        c.default(document).on("keydown.bs.dropdown.data-api", '[data-toggle="dropdown"]', y._dataApiKeydownHandler).on("keydown.bs.dropdown.data-api", ".dropdown-menu", y._dataApiKeydownHandler).on("click.bs.dropdown.data-api keyup.bs.dropdown.data-api", y._clearMenus).on("click.bs.dropdown.data-api", '[data-toggle="dropdown"]', function(t) {
            t.preventDefault(), t.stopPropagation(), y._jQueryInterface.call(c.default(this), "toggle")
        }).on("click.bs.dropdown.data-api", ".dropdown form", function(t) {
            t.stopPropagation()
        }), c.default.fn[b] = y._jQueryInterface, c.default.fn[b].Constructor = y, c.default.fn[b].noConflict = function() {
            return c.default.fn[b] = V, y._jQueryInterface
        };
        var G = c.default.fn.modal,
            J = {
                backdrop: !0,
                keyboard: !0,
                focus: !0,
                show: !0
            },
            Z = {
                backdrop: "(boolean|string)",
                keyboard: "boolean",
                focus: "boolean",
                show: "boolean"
            },
            x = ((i = C.prototype).toggle = function(t) {
                return this._isShown ? this.hide() : this.show(t)
            }, i.show = function(t) {
                var e, i = this;
                this._isShown || this._isTransitioning || (c.default(this._element).hasClass("fade") && (this._isTransitioning = !0), e = c.default.Event("show.bs.modal", {
                    relatedTarget: t
                }), c.default(this._element).trigger(e), this._isShown) || e.isDefaultPrevented() || (this._isShown = !0, this._checkScrollbar(), this._setScrollbar(), this._adjustDialog(), this._setEscapeEvent(), this._setResizeEvent(), c.default(this._element).on("click.dismiss.bs.modal", '[data-dismiss="modal"]', function(t) {
                    return i.hide(t)
                }), c.default(this._dialog).on("mousedown.dismiss.bs.modal", function() {
                    c.default(i._element).one("mouseup.dismiss.bs.modal", function(t) {
                        c.default(t.target).is(i._element) && (i._ignoreBackdropClick = !0)
                    })
                }), this._showBackdrop(function() {
                    return i._showElement(t)
                }))
            }, i.hide = function(t) {
                var e = this;
                t && t.preventDefault(), this._isShown && !this._isTransitioning && (t = c.default.Event("hide.bs.modal"), c.default(this._element).trigger(t), this._isShown) && !t.isDefaultPrevented() && (this._isShown = !1, (t = c.default(this._element).hasClass("fade")) && (this._isTransitioning = !0), this._setEscapeEvent(), this._setResizeEvent(), c.default(document).off("focusin.bs.modal"), c.default(this._element).removeClass("show"), c.default(this._element).off("click.dismiss.bs.modal"), c.default(this._dialog).off("mousedown.dismiss.bs.modal"), t ? (t = u.getTransitionDurationFromElement(this._element), c.default(this._element).one(u.TRANSITION_END, function(t) {
                    return e._hideModal(t)
                }).emulateTransitionEnd(t)) : this._hideModal())
            }, i.dispose = function() {
                [window, this._element, this._dialog].forEach(function(t) {
                    return c.default(t).off(".bs.modal")
                }), c.default(document).off("focusin.bs.modal"), c.default.removeData(this._element, "bs.modal"), this._config = null, this._element = null, this._dialog = null, this._backdrop = null, this._isShown = null, this._isBodyOverflowing = null, this._ignoreBackdropClick = null, this._isTransitioning = null, this._scrollbarWidth = null
            }, i.handleUpdate = function() {
                this._adjustDialog()
            }, i._getConfig = function(t) {
                return t = o({}, J, t), u.typeCheckConfig("modal", t, Z), t
            }, i._triggerBackdropTransition = function() {
                var t, e, i = this,
                    s = c.default.Event("hidePrevented.bs.modal");
                c.default(this._element).trigger(s), s.isDefaultPrevented() || ((t = this._element.scrollHeight > document.documentElement.clientHeight) || (this._element.style.overflowY = "hidden"), this._element.classList.add("modal-static"), e = u.getTransitionDurationFromElement(this._dialog), c.default(this._element).off(u.TRANSITION_END), c.default(this._element).one(u.TRANSITION_END, function() {
                    i._element.classList.remove("modal-static"), t || c.default(i._element).one(u.TRANSITION_END, function() {
                        i._element.style.overflowY = ""
                    }).emulateTransitionEnd(i._element, e)
                }).emulateTransitionEnd(e), this._element.focus())
            }, i._showElement = function(t) {
                function e() {
                    i._config.focus && i._element.focus(), i._isTransitioning = !1, c.default(i._element).trigger(o)
                }
                var i = this,
                    s = c.default(this._element).hasClass("fade"),
                    n = this._dialog ? this._dialog.querySelector(".modal-body") : null,
                    o = (this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE || document.body.appendChild(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), c.default(this._dialog).hasClass("modal-dialog-scrollable") && n ? n.scrollTop = 0 : this._element.scrollTop = 0, s && u.reflow(this._element), c.default(this._element).addClass("show"), this._config.focus && this._enforceFocus(), c.default.Event("shown.bs.modal", {
                        relatedTarget: t
                    }));
                s ? (n = u.getTransitionDurationFromElement(this._dialog), c.default(this._dialog).one(u.TRANSITION_END, e).emulateTransitionEnd(n)) : e()
            }, i._enforceFocus = function() {
                var e = this;
                c.default(document).off("focusin.bs.modal").on("focusin.bs.modal", function(t) {
                    document !== t.target && e._element !== t.target && 0 === c.default(e._element).has(t.target).length && e._element.focus()
                })
            }, i._setEscapeEvent = function() {
                var e = this;
                this._isShown ? c.default(this._element).on("keydown.dismiss.bs.modal", function(t) {
                    e._config.keyboard && 27 === t.which ? (t.preventDefault(), e.hide()) : e._config.keyboard || 27 !== t.which || e._triggerBackdropTransition()
                }) : this._isShown || c.default(this._element).off("keydown.dismiss.bs.modal")
            }, i._setResizeEvent = function() {
                var e = this;
                this._isShown ? c.default(window).on("resize.bs.modal", function(t) {
                    return e.handleUpdate(t)
                }) : c.default(window).off("resize.bs.modal")
            }, i._hideModal = function() {
                var t = this;
                this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._showBackdrop(function() {
                    c.default(document.body).removeClass("modal-open"), t._resetAdjustments(), t._resetScrollbar(), c.default(t._element).trigger("hidden.bs.modal")
                })
            }, i._removeBackdrop = function() {
                this._backdrop && (c.default(this._backdrop).remove(), this._backdrop = null)
            }, i._showBackdrop = function(t) {
                var e, i = this,
                    s = c.default(this._element).hasClass("fade") ? "fade" : "";
                this._isShown && this._config.backdrop ? (this._backdrop = document.createElement("div"), this._backdrop.className = "modal-backdrop", s && this._backdrop.classList.add(s), c.default(this._backdrop).appendTo(document.body), c.default(this._element).on("click.dismiss.bs.modal", function(t) {
                    i._ignoreBackdropClick ? i._ignoreBackdropClick = !1 : t.target === t.currentTarget && ("static" === i._config.backdrop ? i._triggerBackdropTransition() : i.hide())
                }), s && u.reflow(this._backdrop), c.default(this._backdrop).addClass("show"), t && (s ? (s = u.getTransitionDurationFromElement(this._backdrop), c.default(this._backdrop).one(u.TRANSITION_END, t).emulateTransitionEnd(s)) : t())) : !this._isShown && this._backdrop ? (c.default(this._backdrop).removeClass("show"), s = function() {
                    i._removeBackdrop(), t && t()
                }, c.default(this._element).hasClass("fade") ? (e = u.getTransitionDurationFromElement(this._backdrop), c.default(this._backdrop).one(u.TRANSITION_END, s).emulateTransitionEnd(e)) : s()) : t && t()
            }, i._adjustDialog = function() {
                var t = this._element.scrollHeight > document.documentElement.clientHeight;
                !this._isBodyOverflowing && t && (this._element.style.paddingLeft = this._scrollbarWidth + "px"), this._isBodyOverflowing && !t && (this._element.style.paddingRight = this._scrollbarWidth + "px")
            }, i._resetAdjustments = function() {
                this._element.style.paddingLeft = "", this._element.style.paddingRight = ""
            }, i._checkScrollbar = function() {
                var t = document.body.getBoundingClientRect();
                this._isBodyOverflowing = Math.round(t.left + t.right) < window.innerWidth, this._scrollbarWidth = this._getScrollbarWidth()
            }, i._setScrollbar = function() {
                var t, e, n = this;
                this._isBodyOverflowing && (t = [].slice.call(document.querySelectorAll(".fixed-top, .fixed-bottom, .is-fixed, .sticky-top")), e = [].slice.call(document.querySelectorAll(".sticky-top")), c.default(t).each(function(t, e) {
                    var i = e.style.paddingRight,
                        s = c.default(e).css("padding-right");
                    c.default(e).data("padding-right", i).css("padding-right", parseFloat(s) + n._scrollbarWidth + "px")
                }), c.default(e).each(function(t, e) {
                    var i = e.style.marginRight,
                        s = c.default(e).css("margin-right");
                    c.default(e).data("margin-right", i).css("margin-right", parseFloat(s) - n._scrollbarWidth + "px")
                }), t = document.body.style.paddingRight, e = c.default(document.body).css("padding-right"), c.default(document.body).data("padding-right", t).css("padding-right", parseFloat(e) + this._scrollbarWidth + "px")), c.default(document.body).addClass("modal-open")
            }, i._resetScrollbar = function() {
                var t = [].slice.call(document.querySelectorAll(".fixed-top, .fixed-bottom, .is-fixed, .sticky-top")),
                    t = (c.default(t).each(function(t, e) {
                        var i = c.default(e).data("padding-right");
                        c.default(e).removeData("padding-right"), e.style.paddingRight = i || ""
                    }), [].slice.call(document.querySelectorAll(".sticky-top"))),
                    t = (c.default(t).each(function(t, e) {
                        var i = c.default(e).data("margin-right");
                        void 0 !== i && c.default(e).css("margin-right", i).removeData("margin-right")
                    }), c.default(document.body).data("padding-right"));
                c.default(document.body).removeData("padding-right"), document.body.style.paddingRight = t || ""
            }, i._getScrollbarWidth = function() {
                var t = document.createElement("div"),
                    e = (t.className = "modal-scrollbar-measure", document.body.appendChild(t), t.getBoundingClientRect().width - t.clientWidth);
                return document.body.removeChild(t), e
            }, C._jQueryInterface = function(i, s) {
                return this.each(function() {
                    var t = c.default(this).data("bs.modal"),
                        e = o({}, J, c.default(this).data(), "object" == typeof i && i ? i : {});
                    if (t || (t = new C(this, e), c.default(this).data("bs.modal", t)), "string" == typeof i) {
                        if (void 0 === t[i]) throw new TypeError('No method named "' + i + '"');
                        t[i](s)
                    } else e.show && t.show(s)
                })
            }, s(C, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "Default",
                get: function() {
                    return J
                }
            }]), C);

        function C(t, e) {
            this._config = this._getConfig(e), this._element = t, this._dialog = t.querySelector(".modal-dialog"), this._backdrop = null, this._isShown = !1, this._isBodyOverflowing = !1, this._ignoreBackdropClick = !1, this._isTransitioning = !1, this._scrollbarWidth = 0
        }
        c.default(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function(t) {
            var e, i = this,
                s = u.getSelectorFromElement(this),
                s = (s && (e = document.querySelector(s)), c.default(e).data("bs.modal") ? "toggle" : o({}, c.default(e).data(), c.default(this).data())),
                n = ("A" !== this.tagName && "AREA" !== this.tagName || t.preventDefault(), c.default(e).one("show.bs.modal", function(t) {
                    t.isDefaultPrevented() || n.one("hidden.bs.modal", function() {
                        c.default(i).is(":visible") && i.focus()
                    })
                }));
            x._jQueryInterface.call(c.default(e), s, this)
        }), c.default.fn.modal = x._jQueryInterface, c.default.fn.modal.Constructor = x, c.default.fn.modal.noConflict = function() {
            return c.default.fn.modal = G, x._jQueryInterface
        };
        var tt = ["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"],
            et = /^(?:(?:https?|mailto|ftp|tel|file):|[^#&/:?]*(?:[#/?]|$))/gi,
            it = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[\d+/a-z]+=*$/i;

        function st(t, n, e) {
            if (0 === t.length) return t;
            if (e && "function" == typeof e) return e(t);
            for (var e = (new window.DOMParser).parseFromString(t, "text/html"), o = Object.keys(n), a = [].slice.call(e.body.querySelectorAll("*")), i = 0, s = a.length; i < s; i++) ! function(t) {
                var e = a[t],
                    t = e.nodeName.toLowerCase();
                if (-1 === o.indexOf(e.nodeName.toLowerCase())) return e.parentNode.removeChild(e);
                var i = [].slice.call(e.attributes),
                    s = [].concat(n["*"] || [], n[t] || []);
                i.forEach(function(t) {
                    ! function(t, e) {
                        var i = t.nodeName.toLowerCase();
                        if (-1 !== e.indexOf(i)) return -1 === tt.indexOf(i) || Boolean(t.nodeValue.match(et) || t.nodeValue.match(it));
                        for (var s = e.filter(function(t) {
                                return t instanceof RegExp
                            }), n = 0, o = s.length; n < o; n++)
                            if (i.match(s[n])) return 1
                    }(t, s) && e.removeAttribute(t.nodeName)
                })
            }(i);
            return e.body.innerHTML
        }
        var k = "tooltip",
            nt = c.default.fn[k],
            ot = new RegExp("(^|\\s)bs-tooltip\\S+", "g"),
            at = ["sanitize", "whiteList", "sanitizeFn"],
            rt = {
                animation: "boolean",
                template: "string",
                title: "(string|element|function)",
                trigger: "string",
                delay: "(number|object)",
                html: "boolean",
                selector: "(string|boolean)",
                placement: "(string|function)",
                offset: "(number|string|function)",
                container: "(string|element|boolean)",
                fallbackPlacement: "(string|array)",
                boundary: "(string|element)",
                customClass: "(string|function)",
                sanitize: "boolean",
                sanitizeFn: "(null|function)",
                whiteList: "object",
                popperConfig: "(null|object)"
            },
            lt = {
                AUTO: "auto",
                TOP: "top",
                RIGHT: "right",
                BOTTOM: "bottom",
                LEFT: "left"
            },
            ht = {
                animation: !0,
                template: '<div class="tooltip" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>',
                trigger: "hover focus",
                title: "",
                delay: 0,
                html: !1,
                selector: !1,
                placement: "top",
                offset: 0,
                container: !1,
                fallbackPlacement: "flip",
                boundary: "scrollParent",
                customClass: "",
                sanitize: !0,
                sanitizeFn: null,
                whiteList: {
                    "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
                    a: ["target", "href", "title", "rel"],
                    area: [],
                    b: [],
                    br: [],
                    col: [],
                    code: [],
                    div: [],
                    em: [],
                    hr: [],
                    h1: [],
                    h2: [],
                    h3: [],
                    h4: [],
                    h5: [],
                    h6: [],
                    i: [],
                    img: ["src", "srcset", "alt", "title", "width", "height"],
                    li: [],
                    ol: [],
                    p: [],
                    pre: [],
                    s: [],
                    small: [],
                    span: [],
                    sub: [],
                    sup: [],
                    strong: [],
                    u: [],
                    ul: []
                },
                popperConfig: null
            },
            ct = {
                HIDE: "hide.bs.tooltip",
                HIDDEN: "hidden.bs.tooltip",
                SHOW: "show.bs.tooltip",
                SHOWN: "shown.bs.tooltip",
                INSERTED: "inserted.bs.tooltip",
                CLICK: "click.bs.tooltip",
                FOCUSIN: "focusin.bs.tooltip",
                FOCUSOUT: "focusout.bs.tooltip",
                MOUSEENTER: "mouseenter.bs.tooltip",
                MOUSELEAVE: "mouseleave.bs.tooltip"
            },
            D = ((e = T.prototype).enable = function() {
                this._isEnabled = !0
            }, e.disable = function() {
                this._isEnabled = !1
            }, e.toggleEnabled = function() {
                this._isEnabled = !this._isEnabled
            }, e.toggle = function(t) {
                var e, i;
                this._isEnabled && (t ? (e = this.constructor.DATA_KEY, (i = c.default(t.currentTarget).data(e)) || (i = new this.constructor(t.currentTarget, this._getDelegateConfig()), c.default(t.currentTarget).data(e, i)), i._activeTrigger.click = !i._activeTrigger.click, i._isWithActiveTrigger() ? i._enter(null, i) : i._leave(null, i)) : c.default(this.getTipElement()).hasClass("show") ? this._leave(null, this) : this._enter(null, this))
            }, e.dispose = function() {
                clearTimeout(this._timeout), c.default.removeData(this.element, this.constructor.DATA_KEY), c.default(this.element).off(this.constructor.EVENT_KEY), c.default(this.element).closest(".modal").off("hide.bs.modal", this._hideModalHandler), this.tip && c.default(this.tip).remove(), this._isEnabled = null, this._timeout = null, this._hoverState = null, this._activeTrigger = null, this._popper && this._popper.destroy(), this._popper = null, this.element = null, this.config = null, this.tip = null
            }, e.show = function() {
                var e = this;
                if ("none" === c.default(this.element).css("display")) throw new Error("Please use show on visible elements");
                var t, i, s = c.default.Event(this.constructor.Event.SHOW);
                this.isWithContent() && this._isEnabled && (c.default(this.element).trigger(s), i = u.findShadowRoot(this.element), i = c.default.contains(null !== i ? i : this.element.ownerDocument.documentElement, this.element), !s.isDefaultPrevented()) && i && (s = this.getTipElement(), i = u.getUID(this.constructor.NAME), s.setAttribute("id", i), this.element.setAttribute("aria-describedby", i), this.setContent(), this.config.animation && c.default(s).addClass("fade"), i = "function" == typeof this.config.placement ? this.config.placement.call(this, s, this.element) : this.config.placement, i = this._getAttachment(i), this.addAttachmentClass(i), t = this._getContainer(), c.default(s).data(this.constructor.DATA_KEY, this), c.default.contains(this.element.ownerDocument.documentElement, this.tip) || c.default(s).appendTo(t), c.default(this.element).trigger(this.constructor.Event.INSERTED), this._popper = new n.default(this.element, s, this._getPopperConfig(i)), c.default(s).addClass("show"), c.default(s).addClass(this.config.customClass), "ontouchstart" in document.documentElement && c.default(document.body).children().on("mouseover", null, c.default.noop), t = function() {
                    e.config.animation && e._fixTransition();
                    var t = e._hoverState;
                    e._hoverState = null, c.default(e.element).trigger(e.constructor.Event.SHOWN), "out" === t && e._leave(null, e)
                }, c.default(this.tip).hasClass("fade") ? (i = u.getTransitionDurationFromElement(this.tip), c.default(this.tip).one(u.TRANSITION_END, t).emulateTransitionEnd(i)) : t())
            }, e.hide = function(t) {
                function e() {
                    "show" !== i._hoverState && s.parentNode && s.parentNode.removeChild(s), i._cleanTipClass(), i.element.removeAttribute("aria-describedby"), c.default(i.element).trigger(i.constructor.Event.HIDDEN), null !== i._popper && i._popper.destroy(), t && t()
                }
                var i = this,
                    s = this.getTipElement(),
                    n = c.default.Event(this.constructor.Event.HIDE);
                c.default(this.element).trigger(n), n.isDefaultPrevented() || (c.default(s).removeClass("show"), "ontouchstart" in document.documentElement && c.default(document.body).children().off("mouseover", null, c.default.noop), this._activeTrigger.click = !1, this._activeTrigger.focus = !1, this._activeTrigger.hover = !1, c.default(this.tip).hasClass("fade") ? (n = u.getTransitionDurationFromElement(s), c.default(s).one(u.TRANSITION_END, e).emulateTransitionEnd(n)) : e(), this._hoverState = "")
            }, e.update = function() {
                null !== this._popper && this._popper.scheduleUpdate()
            }, e.isWithContent = function() {
                return Boolean(this.getTitle())
            }, e.addAttachmentClass = function(t) {
                c.default(this.getTipElement()).addClass("bs-tooltip-" + t)
            }, e.getTipElement = function() {
                return this.tip = this.tip || c.default(this.config.template)[0], this.tip
            }, e.setContent = function() {
                var t = this.getTipElement();
                this.setElementContent(c.default(t.querySelectorAll(".tooltip-inner")), this.getTitle()), c.default(t).removeClass("fade show")
            }, e.setElementContent = function(t, e) {
                "object" != typeof e || !e.nodeType && !e.jquery ? this.config.html ? (this.config.sanitize && (e = st(e, this.config.whiteList, this.config.sanitizeFn)), t.html(e)) : t.text(e) : this.config.html ? c.default(e).parent().is(t) || t.empty().append(e) : t.text(c.default(e).text())
            }, e.getTitle = function() {
                return this.element.getAttribute("data-original-title") || ("function" == typeof this.config.title ? this.config.title.call(this.element) : this.config.title)
            }, e._getPopperConfig = function(t) {
                var e = this;
                return o({}, {
                    placement: t,
                    modifiers: {
                        offset: this._getOffset(),
                        flip: {
                            behavior: this.config.fallbackPlacement
                        },
                        arrow: {
                            element: ".arrow"
                        },
                        preventOverflow: {
                            boundariesElement: this.config.boundary
                        }
                    },
                    onCreate: function(t) {
                        t.originalPlacement !== t.placement && e._handlePopperPlacementChange(t)
                    },
                    onUpdate: function(t) {
                        return e._handlePopperPlacementChange(t)
                    }
                }, this.config.popperConfig)
            }, e._getOffset = function() {
                var e = this,
                    t = {};
                return "function" == typeof this.config.offset ? t.fn = function(t) {
                    return t.offsets = o({}, t.offsets, e.config.offset(t.offsets, e.element) || {}), t
                } : t.offset = this.config.offset, t
            }, e._getContainer = function() {
                return !1 === this.config.container ? document.body : u.isElement(this.config.container) ? c.default(this.config.container) : c.default(document).find(this.config.container)
            }, e._getAttachment = function(t) {
                return lt[t.toUpperCase()]
            }, e._setListeners = function() {
                var i = this;
                this.config.trigger.split(" ").forEach(function(t) {
                    var e;
                    "click" === t ? c.default(i.element).on(i.constructor.Event.CLICK, i.config.selector, function(t) {
                        return i.toggle(t)
                    }) : "manual" !== t && (e = "hover" === t ? i.constructor.Event.MOUSEENTER : i.constructor.Event.FOCUSIN, t = "hover" === t ? i.constructor.Event.MOUSELEAVE : i.constructor.Event.FOCUSOUT, c.default(i.element).on(e, i.config.selector, function(t) {
                        return i._enter(t)
                    }).on(t, i.config.selector, function(t) {
                        return i._leave(t)
                    }))
                }), this._hideModalHandler = function() {
                    i.element && i.hide()
                }, c.default(this.element).closest(".modal").on("hide.bs.modal", this._hideModalHandler), this.config.selector ? this.config = o({}, this.config, {
                    trigger: "manual",
                    selector: ""
                }) : this._fixTitle()
            }, e._fixTitle = function() {
                var t = typeof this.element.getAttribute("data-original-title");
                !this.element.getAttribute("title") && "string" == t || (this.element.setAttribute("data-original-title", this.element.getAttribute("title") || ""), this.element.setAttribute("title", ""))
            }, e._enter = function(t, e) {
                var i = this.constructor.DATA_KEY;
                (e = e || c.default(t.currentTarget).data(i)) || (e = new this.constructor(t.currentTarget, this._getDelegateConfig()), c.default(t.currentTarget).data(i, e)), t && (e._activeTrigger["focusin" === t.type ? "focus" : "hover"] = !0), c.default(e.getTipElement()).hasClass("show") || "show" === e._hoverState ? e._hoverState = "show" : (clearTimeout(e._timeout), e._hoverState = "show", e.config.delay && e.config.delay.show ? e._timeout = setTimeout(function() {
                    "show" === e._hoverState && e.show()
                }, e.config.delay.show) : e.show())
            }, e._leave = function(t, e) {
                var i = this.constructor.DATA_KEY;
                (e = e || c.default(t.currentTarget).data(i)) || (e = new this.constructor(t.currentTarget, this._getDelegateConfig()), c.default(t.currentTarget).data(i, e)), t && (e._activeTrigger["focusout" === t.type ? "focus" : "hover"] = !1), e._isWithActiveTrigger() || (clearTimeout(e._timeout), e._hoverState = "out", e.config.delay && e.config.delay.hide ? e._timeout = setTimeout(function() {
                    "out" === e._hoverState && e.hide()
                }, e.config.delay.hide) : e.hide())
            }, e._isWithActiveTrigger = function() {
                for (var t in this._activeTrigger)
                    if (this._activeTrigger[t]) return !0;
                return !1
            }, e._getConfig = function(t) {
                var e = c.default(this.element).data();
                return Object.keys(e).forEach(function(t) {
                    -1 !== at.indexOf(t) && delete e[t]
                }), "number" == typeof(t = o({}, this.constructor.Default, e, "object" == typeof t && t ? t : {})).delay && (t.delay = {
                    show: t.delay,
                    hide: t.delay
                }), "number" == typeof t.title && (t.title = t.title.toString()), "number" == typeof t.content && (t.content = t.content.toString()), u.typeCheckConfig(k, t, this.constructor.DefaultType), t.sanitize && (t.template = st(t.template, t.whiteList, t.sanitizeFn)), t
            }, e._getDelegateConfig = function() {
                var t = {};
                if (this.config)
                    for (var e in this.config) this.constructor.Default[e] !== this.config[e] && (t[e] = this.config[e]);
                return t
            }, e._cleanTipClass = function() {
                var t = c.default(this.getTipElement()),
                    e = t.attr("class").match(ot);
                null !== e && e.length && t.removeClass(e.join(""))
            }, e._handlePopperPlacementChange = function(t) {
                this.tip = t.instance.popper, this._cleanTipClass(), this.addAttachmentClass(this._getAttachment(t.placement))
            }, e._fixTransition = function() {
                var t = this.getTipElement(),
                    e = this.config.animation;
                null === t.getAttribute("x-placement") && (c.default(t).removeClass("fade"), this.config.animation = !1, this.hide(), this.show(), this.config.animation = e)
            }, T._jQueryInterface = function(s) {
                return this.each(function() {
                    var t = c.default(this),
                        e = t.data("bs.tooltip"),
                        i = "object" == typeof s && s;
                    if ((e || !/dispose|hide/.test(s)) && (e || (e = new T(this, i), t.data("bs.tooltip", e)), "string" == typeof s)) {
                        if (void 0 === e[s]) throw new TypeError('No method named "' + s + '"');
                        e[s]()
                    }
                })
            }, s(T, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "Default",
                get: function() {
                    return ht
                }
            }, {
                key: "NAME",
                get: function() {
                    return k
                }
            }, {
                key: "DATA_KEY",
                get: function() {
                    return "bs.tooltip"
                }
            }, {
                key: "Event",
                get: function() {
                    return ct
                }
            }, {
                key: "EVENT_KEY",
                get: function() {
                    return ".bs.tooltip"
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return rt
                }
            }]), T);

        function T(t, e) {
            if (void 0 === n.default) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org)");
            this._isEnabled = !0, this._timeout = 0, this._hoverState = "", this._activeTrigger = {}, this._popper = null, this.element = t, this.config = this._getConfig(e), this.tip = null, this._setListeners()
        }
        c.default.fn[k] = D._jQueryInterface, c.default.fn[k].Constructor = D, c.default.fn[k].noConflict = function() {
            return c.default.fn[k] = nt, D._jQueryInterface
        };
        var ut, E = "popover",
            dt = c.default.fn[E],
            pt = new RegExp("(^|\\s)bs-popover\\S+", "g"),
            ft = o({}, D.Default, {
                placement: "right",
                trigger: "click",
                content: "",
                template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>'
            }),
            mt = o({}, D.DefaultType, {
                content: "(string|element|function)"
            }),
            gt = {
                HIDE: "hide.bs.popover",
                HIDDEN: "hidden.bs.popover",
                SHOW: "show.bs.popover",
                SHOWN: "shown.bs.popover",
                INSERTED: "inserted.bs.popover",
                CLICK: "click.bs.popover",
                FOCUSIN: "focusin.bs.popover",
                FOCUSOUT: "focusout.bs.popover",
                MOUSEENTER: "mouseenter.bs.popover",
                MOUSELEAVE: "mouseleave.bs.popover"
            },
            S = (i = ut = D, (e = I).prototype = Object.create(i.prototype), (e.prototype.constructor = e).__proto__ = i, (e = I.prototype).isWithContent = function() {
                return this.getTitle() || this._getContent()
            }, e.addAttachmentClass = function(t) {
                c.default(this.getTipElement()).addClass("bs-popover-" + t)
            }, e.getTipElement = function() {
                return this.tip = this.tip || c.default(this.config.template)[0], this.tip
            }, e.setContent = function() {
                var t = c.default(this.getTipElement()),
                    e = (this.setElementContent(t.find(".popover-header"), this.getTitle()), this._getContent());
                "function" == typeof e && (e = e.call(this.element)), this.setElementContent(t.find(".popover-body"), e), t.removeClass("fade show")
            }, e._getContent = function() {
                return this.element.getAttribute("data-content") || this.config.content
            }, e._cleanTipClass = function() {
                var t = c.default(this.getTipElement()),
                    e = t.attr("class").match(pt);
                null !== e && 0 < e.length && t.removeClass(e.join(""))
            }, I._jQueryInterface = function(i) {
                return this.each(function() {
                    var t = c.default(this).data("bs.popover"),
                        e = "object" == typeof i ? i : null;
                    if ((t || !/dispose|hide/.test(i)) && (t || (t = new I(this, e), c.default(this).data("bs.popover", t)), "string" == typeof i)) {
                        if (void 0 === t[i]) throw new TypeError('No method named "' + i + '"');
                        t[i]()
                    }
                })
            }, s(I, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "Default",
                get: function() {
                    return ft
                }
            }, {
                key: "NAME",
                get: function() {
                    return E
                }
            }, {
                key: "DATA_KEY",
                get: function() {
                    return "bs.popover"
                }
            }, {
                key: "Event",
                get: function() {
                    return gt
                }
            }, {
                key: "EVENT_KEY",
                get: function() {
                    return ".bs.popover"
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return mt
                }
            }]), I);

        function I() {
            return ut.apply(this, arguments) || this
        }
        c.default.fn[E] = S._jQueryInterface, c.default.fn[E].Constructor = S, c.default.fn[E].noConflict = function() {
            return c.default.fn[E] = dt, S._jQueryInterface
        };
        var P = "scrollspy",
            _t = c.default.fn[P],
            vt = {
                offset: 10,
                method: "auto",
                target: ""
            },
            bt = {
                offset: "number",
                method: "string",
                target: "(string|element)"
            },
            M = ((i = A.prototype).refresh = function() {
                var e = this,
                    t = this._scrollElement === this._scrollElement.window ? "offset" : "position",
                    s = "auto" === this._config.method ? t : this._config.method,
                    n = "position" === s ? this._getScrollTop() : 0;
                this._offsets = [], this._targets = [], this._scrollHeight = this._getScrollHeight(), [].slice.call(document.querySelectorAll(this._selector)).map(function(t) {
                    var e, t = u.getSelectorFromElement(t);
                    if (e = t ? document.querySelector(t) : e) {
                        var i = e.getBoundingClientRect();
                        if (i.width || i.height) return [c.default(e)[s]().top + n, t]
                    }
                    return null
                }).filter(function(t) {
                    return t
                }).sort(function(t, e) {
                    return t[0] - e[0]
                }).forEach(function(t) {
                    e._offsets.push(t[0]), e._targets.push(t[1])
                })
            }, i.dispose = function() {
                c.default.removeData(this._element, "bs.scrollspy"), c.default(this._scrollElement).off(".bs.scrollspy"), this._element = null, this._scrollElement = null, this._config = null, this._selector = null, this._offsets = null, this._targets = null, this._activeTarget = null, this._scrollHeight = null
            }, i._getConfig = function(t) {
                var e;
                return "string" != typeof(t = o({}, vt, "object" == typeof t && t ? t : {})).target && u.isElement(t.target) && ((e = c.default(t.target).attr("id")) || (e = u.getUID(P), c.default(t.target).attr("id", e)), t.target = "#" + e), u.typeCheckConfig(P, t, bt), t
            }, i._getScrollTop = function() {
                return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop
            }, i._getScrollHeight = function() {
                return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)
            }, i._getOffsetHeight = function() {
                return this._scrollElement === window ? window.innerHeight : this._scrollElement.getBoundingClientRect().height
            }, i._process = function() {
                var t = this._getScrollTop() + this._config.offset,
                    e = this._getScrollHeight(),
                    i = this._config.offset + e - this._getOffsetHeight();
                if (this._scrollHeight !== e && this.refresh(), i <= t) {
                    e = this._targets[this._targets.length - 1];
                    this._activeTarget !== e && this._activate(e)
                } else if (this._activeTarget && t < this._offsets[0] && 0 < this._offsets[0]) this._activeTarget = null, this._clear();
                else
                    for (var s = this._offsets.length; s--;) this._activeTarget !== this._targets[s] && t >= this._offsets[s] && (void 0 === this._offsets[s + 1] || t < this._offsets[s + 1]) && this._activate(this._targets[s])
            }, i._activate = function(e) {
                this._activeTarget = e, this._clear();
                var t = this._selector.split(",").map(function(t) {
                        return t + '[data-target="' + e + '"],' + t + '[href="' + e + '"]'
                    }),
                    t = c.default([].slice.call(document.querySelectorAll(t.join(","))));
                (t.hasClass("dropdown-item") ? (t.closest(".dropdown").find(".dropdown-toggle").addClass("active"), t) : (t.addClass("active"), t.parents(".nav, .list-group").prev(".nav-link, .list-group-item").addClass("active"), t.parents(".nav, .list-group").prev(".nav-item").children(".nav-link"))).addClass("active"), c.default(this._scrollElement).trigger("activate.bs.scrollspy", {
                    relatedTarget: e
                })
            }, i._clear = function() {
                [].slice.call(document.querySelectorAll(this._selector)).filter(function(t) {
                    return t.classList.contains("active")
                }).forEach(function(t) {
                    return t.classList.remove("active")
                })
            }, A._jQueryInterface = function(e) {
                return this.each(function() {
                    var t = c.default(this).data("bs.scrollspy");
                    if (t || (t = new A(this, "object" == typeof e && e), c.default(this).data("bs.scrollspy", t)), "string" == typeof e) {
                        if (void 0 === t[e]) throw new TypeError('No method named "' + e + '"');
                        t[e]()
                    }
                })
            }, s(A, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "Default",
                get: function() {
                    return vt
                }
            }]), A);

        function A(t, e) {
            var i = this;
            this._element = t, this._scrollElement = "BODY" === t.tagName ? window : t, this._config = this._getConfig(e), this._selector = this._config.target + " .nav-link," + this._config.target + " .list-group-item," + this._config.target + " .dropdown-item", this._offsets = [], this._targets = [], this._activeTarget = null, this._scrollHeight = 0, c.default(this._scrollElement).on("scroll.bs.scrollspy", function(t) {
                return i._process(t)
            }), this.refresh(), this._process()
        }
        c.default(window).on("load.bs.scrollspy.data-api", function() {
            for (var t = [].slice.call(document.querySelectorAll('[data-spy="scroll"]')), e = t.length; e--;) {
                var i = c.default(t[e]);
                M._jQueryInterface.call(i, i.data())
            }
        }), c.default.fn[P] = M._jQueryInterface, c.default.fn[P].Constructor = M, c.default.fn[P].noConflict = function() {
            return c.default.fn[P] = _t, M._jQueryInterface
        };
        var yt = c.default.fn.tab,
            N = ((e = O.prototype).show = function() {
                var t, e, i, s, n, o, a = this;
                this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && c.default(this._element).hasClass("active") || c.default(this._element).hasClass("disabled") || (e = c.default(this._element).closest(".nav, .list-group")[0], i = u.getSelectorFromElement(this._element), e && (n = "UL" === e.nodeName || "OL" === e.nodeName ? "> li > .active" : ".active", s = (s = c.default.makeArray(c.default(e).find(n)))[s.length - 1]), n = c.default.Event("hide.bs.tab", {
                    relatedTarget: this._element
                }), o = c.default.Event("show.bs.tab", {
                    relatedTarget: s
                }), s && c.default(s).trigger(n), c.default(this._element).trigger(o), o.isDefaultPrevented()) || n.isDefaultPrevented() || (i && (t = document.querySelector(i)), this._activate(this._element, e), o = function() {
                    var t = c.default.Event("hidden.bs.tab", {
                            relatedTarget: a._element
                        }),
                        e = c.default.Event("shown.bs.tab", {
                            relatedTarget: s
                        });
                    c.default(s).trigger(t), c.default(a._element).trigger(e)
                }, t ? this._activate(t, t.parentNode, o) : o())
            }, e.dispose = function() {
                c.default.removeData(this._element, "bs.tab"), this._element = null
            }, e._activate = function(t, e, i) {
                function s() {
                    return n._transitionComplete(t, o, i)
                }
                var n = this,
                    o = (!e || "UL" !== e.nodeName && "OL" !== e.nodeName ? c.default(e).children(".active") : c.default(e).find("> li > .active"))[0],
                    e = i && o && c.default(o).hasClass("fade");
                o && e ? (e = u.getTransitionDurationFromElement(o), c.default(o).removeClass("show").one(u.TRANSITION_END, s).emulateTransitionEnd(e)) : s()
            }, e._transitionComplete = function(t, e, i) {
                var s;
                e && (c.default(e).removeClass("active"), (s = c.default(e.parentNode).find("> .dropdown-menu .active")[0]) && c.default(s).removeClass("active"), "tab" === e.getAttribute("role")) && e.setAttribute("aria-selected", !1), c.default(t).addClass("active"), "tab" === t.getAttribute("role") && t.setAttribute("aria-selected", !0), u.reflow(t), t.classList.contains("fade") && t.classList.add("show"), t.parentNode && c.default(t.parentNode).hasClass("dropdown-menu") && ((s = c.default(t).closest(".dropdown")[0]) && (e = [].slice.call(s.querySelectorAll(".dropdown-toggle")), c.default(e).addClass("active")), t.setAttribute("aria-expanded", !0)), i && i()
            }, O._jQueryInterface = function(i) {
                return this.each(function() {
                    var t = c.default(this),
                        e = t.data("bs.tab");
                    if (e || (e = new O(this), t.data("bs.tab", e)), "string" == typeof i) {
                        if (void 0 === e[i]) throw new TypeError('No method named "' + i + '"');
                        e[i]()
                    }
                })
            }, s(O, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }]), O);

        function O(t) {
            this._element = t
        }
        c.default(document).on("click.bs.tab.data-api", '[data-toggle="tab"], [data-toggle="pill"], [data-toggle="list"]', function(t) {
            t.preventDefault(), N._jQueryInterface.call(c.default(this), "show")
        }), c.default.fn.tab = N._jQueryInterface, c.default.fn.tab.Constructor = N, c.default.fn.tab.noConflict = function() {
            return c.default.fn.tab = yt, N._jQueryInterface
        };
        var wt = c.default.fn.toast,
            xt = {
                animation: "boolean",
                autohide: "boolean",
                delay: "number"
            },
            Ct = {
                animation: !0,
                autohide: !0,
                delay: 500
            },
            kt = ((i = H.prototype).show = function() {
                var t, e = this,
                    i = c.default.Event("show.bs.toast");
                c.default(this._element).trigger(i), i.isDefaultPrevented() || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), i = function() {
                    e._element.classList.remove("showing"), e._element.classList.add("show"), c.default(e._element).trigger("shown.bs.toast"), e._config.autohide && (e._timeout = setTimeout(function() {
                        e.hide()
                    }, e._config.delay))
                }, this._element.classList.remove("hide"), u.reflow(this._element), this._element.classList.add("showing"), this._config.animation ? (t = u.getTransitionDurationFromElement(this._element), c.default(this._element).one(u.TRANSITION_END, i).emulateTransitionEnd(t)) : i())
            }, i.hide = function() {
                var t;
                this._element.classList.contains("show") && (t = c.default.Event("hide.bs.toast"), c.default(this._element).trigger(t), t.isDefaultPrevented() || this._close())
            }, i.dispose = function() {
                this._clearTimeout(), this._element.classList.contains("show") && this._element.classList.remove("show"), c.default(this._element).off("click.dismiss.bs.toast"), c.default.removeData(this._element, "bs.toast"), this._element = null, this._config = null
            }, i._getConfig = function(t) {
                return t = o({}, Ct, c.default(this._element).data(), "object" == typeof t && t ? t : {}), u.typeCheckConfig("toast", t, this.constructor.DefaultType), t
            }, i._setListeners = function() {
                var t = this;
                c.default(this._element).on("click.dismiss.bs.toast", '[data-dismiss="toast"]', function() {
                    return t.hide()
                })
            }, i._close = function() {
                function t() {
                    i._element.classList.add("hide"), c.default(i._element).trigger("hidden.bs.toast")
                }
                var e, i = this;
                this._element.classList.remove("show"), this._config.animation ? (e = u.getTransitionDurationFromElement(this._element), c.default(this._element).one(u.TRANSITION_END, t).emulateTransitionEnd(e)) : t()
            }, i._clearTimeout = function() {
                clearTimeout(this._timeout), this._timeout = null
            }, H._jQueryInterface = function(i) {
                return this.each(function() {
                    var t = c.default(this),
                        e = t.data("bs.toast");
                    if (e || (e = new H(this, "object" == typeof i && i), t.data("bs.toast", e)), "string" == typeof i) {
                        if (void 0 === e[i]) throw new TypeError('No method named "' + i + '"');
                        e[i](this)
                    }
                })
            }, s(H, null, [{
                key: "VERSION",
                get: function() {
                    return "4.6.0"
                }
            }, {
                key: "DefaultType",
                get: function() {
                    return xt
                }
            }, {
                key: "Default",
                get: function() {
                    return Ct
                }
            }]), H);

        function H(t, e) {
            this._element = t, this._config = this._getConfig(e), this._timeout = null, this._setListeners()
        }
        c.default.fn.toast = kt._jQueryInterface, c.default.fn.toast.Constructor = kt, c.default.fn.toast.noConflict = function() {
            return c.default.fn.toast = wt, kt._jQueryInterface
        }, t.Alert = r, t.Button = h, t.Carousel = f, t.Collapse = _, t.Dropdown = y, t.Modal = x, t.Popover = S, t.Scrollspy = M, t.Tab = N, t.Toast = kt, t.Tooltip = D, t.Util = u, Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }), ! function(n) {
        n.fn.niceSelect = function(t) {
            function s(t) {
                t.after(n("<div></div>").addClass("nice-select").addClass(t.attr("class") || "").addClass(t.attr("disabled") ? "disabled" : "").attr("tabindex", t.attr("disabled") ? null : "0").html('<span class="current"></span><ul class="list"></ul>'));
                var s = t.next(),
                    e = t.find("option"),
                    t = t.find("option:selected");
                s.find(".current").html(t.data("display") || t.text()), e.each(function(t) {
                    var e = n(this),
                        i = e.data("display");
                    s.find("ul").append(n("<li></li>").attr("data-value", e.val()).attr("data-display", i || null).addClass("option" + (e.is(":selected") ? " selected" : "") + (e.is(":disabled") ? " disabled" : "")).html(e.text()))
                })
            }
            return "string" == typeof t ? "update" == t ? this.each(function() {
                var t = n(this),
                    e = n(this).next(".nice-select"),
                    i = e.hasClass("open");
                e.length && (e.remove(), s(t), i) && t.next().trigger("click")
            }) : "destroy" == t ? (this.each(function() {
                var t = n(this),
                    e = n(this).next(".nice-select");
                e.length && (e.remove(), t.css("display", ""))
            }), 0 == n(".nice-select").length && n(document).off(".nice_select")) : console.log('Method "' + t + '" does not exist.') : (this.hide(), this.each(function() {
                var t = n(this);
                t.next().hasClass("nice-select") || s(t)
            }), n(document).off(".nice_select"), n(document).on("click.nice_select", ".nice-select", function(t) {
                var e = n(this);
                n(".nice-select").not(e).removeClass("open"), e.toggleClass("open"), e.hasClass("open") ? (e.find(".option"), e.find(".focus").removeClass("focus"), e.find(".selected").addClass("focus")) : e.focus()
            }), n(document).on("click.nice_select", function(t) {
                0 === n(t.target).closest(".nice-select").length && n(".nice-select").removeClass("open").find(".option")
            }), n(document).on("click.nice_select", ".nice-select .option:not(.disabled)", function(t) {
                var e = n(this),
                    i = e.closest(".nice-select"),
                    s = (i.find(".selected").removeClass("selected"), e.addClass("selected"), e.data("display") || e.text());
                i.find(".current").text(s), i.prev("select").val(e.data("value")).trigger("change")
            }), n(document).on("keydown.nice_select", ".nice-select", function(t) {
                var e, i = n(this),
                    s = n(i.find(".focus") || i.find(".list .option.selected"));
                if (32 == t.keyCode || 13 == t.keyCode) return (i.hasClass("open") ? s : i).trigger("click"), !1;
                if (40 == t.keyCode) return i.hasClass("open") ? 0 < (e = s.nextAll(".option:not(.disabled)").first()).length && (i.find(".focus").removeClass("focus"), e.addClass("focus")) : i.trigger("click"), !1;
                if (38 == t.keyCode) return i.hasClass("open") ? 0 < (e = s.prevAll(".option:not(.disabled)").first()).length && (i.find(".focus").removeClass("focus"), e.addClass("focus")) : i.trigger("click"), !1;
                if (27 == t.keyCode) i.hasClass("open") && i.trigger("click");
                else if (9 == t.keyCode && i.hasClass("open")) return !1
            }), (t = document.createElement("a").style).cssText = "pointer-events:auto", "auto" !== t.pointerEvents && n("html").addClass("no-csspointerevents")), this
        }
    }(jQuery), ! function(n) {
        n.fn.niceSelect = function(t) {
            return "string" == typeof t ? "update" == t ? this.each(function() {
                var t = n(this),
                    e = n(this).next(".nice-select"),
                    i = e.hasClass("open");
                e.length && (e.remove(), s(t), i) && t.next().trigger("click")
            }) : "destroy" == t && (this.each(function() {
                var t = n(this),
                    e = n(this).next(".nice-select");
                e.length && (e.remove(), t.css("display", ""))
            }), 0 == n(".nice-select").length) && n(document).off(".nice_select") : (this.hide(), this.each(function() {
                var t = n(this);
                t.next().hasClass("nice-select") || s(t)
            }), n(document).off(".nice_select"), n(document).on("click.nice_select", ".nice-select", function(t) {
                var e, i = n(this);
                n(".nice-select").not(i).removeClass("open"), i.toggleClass("open"), i.hasClass("open") ? ((e = i).find(".option"), e.find(".nice-select-search").val(""), e.find(".nice-select-search").focus(), e.find(".focus").removeClass("focus"), e.find(".selected").addClass("focus"), e.find("ul li").show()) : i.focus()
            }), n(document).on("click", ".nice-select-search-box", function(t) {
                return t.stopPropagation(), !1
            }), n(document).on("keyup.nice-select-search", ".nice-select", function() {
                var t = n(this);
                let e = t.find(".nice-select-search").val();
                var s = t.find("ul li");
                if ("" == e) s.show();
                else if (t.hasClass("open")) {
                    e = e.toLowerCase();
                    let i = new RegExp(e);
                    0 < s.length ? s.each(function() {
                        var t = n(this),
                            e = t.text().toLowerCase();
                        i.test(e) ? t.show() : t.hide()
                    }) : s.show()
                }
                t.find(".option"), t.find(".focus").removeClass("focus"), t.find(".selected").addClass("focus")
            }), n(document).on("click.nice_select", function(t) {
                0 === n(t.target).closest(".nice-select").length && n(".nice-select").removeClass("open").find(".option")
            }), n(document).on("click.nice_select", ".nice-select .option:not(.disabled)", function(t) {
                var e = n(this),
                    i = e.closest(".nice-select");
                t.preventDefault(), i.hasClass("has-multiple") ? (e.hasClass("selected") ? (e.removeClass("selected"), e.children("i").remove()) : (e.addClass("selected"), e.append('<i class="fas fa-check position-absolute" style="right: 20px; top: 13px;"></i>')), $selected_html = "", $selected_values = [], $selected_count = 0, i.find(".selected").each(function() {
                    $selected_option = n(this), $selected_count += 1, $selected_values.push($selected_option.data("value"))
                }), $selected_html += `<span>${$selected_count} items selected</span>`, $select_placeholder = ($select_placeholder = i.prev("select").data("js-placeholder") || i.prev("select").attr("js-placeholder")) || "Select", $selected_html = "" === $selected_html ? $select_placeholder : $selected_html, i.find(".multiple-options").html($selected_html), i.prev("select").val($selected_values).trigger("change"), i.click()) : (i.find(".selected").find("i").remove(), i.find(".selected").removeClass("selected"), e.addClass("selected"), e.append('<i class="fas fa-check position-absolute" style="right: 20px; top: 13px;"></i>'), t = e.data("display") || e.text(), i.find(".current").text(t), i.prev("select").val(e.data("value")).trigger("change"))
            }), n(document).on("click", ".remove", function() {
                var t = n(this).parents(".nice-select");
                let s = n(this).parent().data("id");
                t.find(".list li").each(function(t, e) {
                    s == n(e).attr("data-value") && n(e).removeClass("selected")
                }), $selected_values.forEach(function(t, e, i) {
                    t === s && i.splice(e, 1)
                }), n(this).parent().remove()
            }), n(document).on("keydown.nice_select", ".nice-select", function(t) {
                var e, i = n(this),
                    s = n(i.find(".focus") || i.find(".list .option.selected"));
                if (13 != t.keyCode) {
                    if (40 == t.keyCode) return i.hasClass("open") ? 0 < (e = s.nextAll(".option:not(.disabled)").first()).length && (i.find(".focus").removeClass("focus"), e.addClass("focus")) : i.trigger("click"), !1;
                    if (38 == t.keyCode) return i.hasClass("open") ? 0 < (e = s.prevAll(".option:not(.disabled)").first()).length && (i.find(".focus").removeClass("focus"), e.addClass("focus")) : i.trigger("click"), !1;
                    if (27 == t.keyCode) i.hasClass("open") && i.trigger("click");
                    else if (9 == t.keyCode && i.hasClass("open")) return !1
                }
            }), (t = document.createElement("a").style).cssText = "pointer-events:auto", "auto" !== t.pointerEvents && n("html").addClass("no-csspointerevents")), this;

            function s(e) {
                e.after(n("<div></div>").addClass("nice-select").addClass(e.attr("class") || "").addClass(e.attr("disabled") ? "disabled" : "").addClass(e.attr("multiple") ? "has-multiple" : "").attr("tabindex", e.attr("disabled") ? null : "0").html(e.attr("multiple") ? '<span class="multiple-options"></span><div class="nice-select-search-box"><input type="text" class="nice-select-search" placeholder="Search..."/></div><ul class="list"></ul>' : '<span class="current"></span><div class="nice-select-search-box"><input type="text" class="nice-select-search" placeholder="Search..."/></div><ul class="list"></ul>'));
                let s = e.next();
                var t = e.find("option");
                if (e.attr("multiple")) {
                    var i = e.find("option:selected");
                    let t = 0;
                    i.each(function() {
                        $selected_option = n(this), $selected_text = $selected_option.data("display") || $selected_option.text(), $selected_option.val() && (t += 1)
                    }), i = "<span>" + t + " items selected</span>", $select_placeholder = ($select_placeholder = e.data("js-placeholder") || e.attr("js-placeholder")) || "Select", i = i || $select_placeholder, s.find(".multiple-options").html(i)
                } else {
                    i = e.find("option:selected");
                    s.find(".current").html(i.data("display") || i.text())
                }
                t.each(function(t) {
                    var e = n(this),
                        i = e.data("display");
                    s.find("ul").append(n("<li></li>").attr("data-value", e.val()).attr("data-display", i || null).addClass("option" + (e.is(":selected") ? " selected" : "") + (e.is(":disabled") ? " disabled" : "")).addClass("position-relative").html(e.text()).append(e.is(":selected") ? '<i class="fas fa-check position-absolute" style="right: 20px; top: 13px;"></i>' : ""))
                })
            }
        }
    }(jQuery), ! function(w, t, i) {
        function x(t) {
            var e = Math.floor(t / 3600),
                i = Math.floor(t % 3600 / 60),
                t = Math.ceil(t % 3600 % 60);
            return (0 == e ? "" : 0 < e && e.toString().length < 2 ? "0" + e + ":" : e + ":") + (i.toString().length < 2 ? "0" + i : i) + ":" + (t.toString().length < 2 ? "0" + t : t)
        }

        function C(t) {
            var e = i.createElement("audio");
            return !(!e.canPlayType || !e.canPlayType("audio/" + t.split(".").pop().toLowerCase() + ";").replace(/no/, ""))
        }
        var k = "ontouchstart" in t,
            D = k ? "touchstart" : "mousedown",
            T = k ? "touchmove" : "mousemove",
            E = k ? "touchcancel" : "mouseup";
        const S = t => `<svg xmlns="http://www.w3.org/2000/svg" fill="${t}" width="20px" height="20px" viewBox="0 0 576 512"><path d="M215.03 71.05L126.06 160H24c-13.26 0-24 10.74-24 24v144c0 13.25 10.74 24 24 24h102.06l88.97 88.95c15.03 15.03 40.97 4.47 40.97-16.97V88.02c0-21.46-25.96-31.98-40.97-16.97zm233.32-51.08c-11.17-7.33-26.18-4.24-33.51 6.95-7.34 11.17-4.22 26.18 6.95 33.51 66.27 43.49 105.82 116.6 105.82 195.58 0 78.98-39.55 152.09-105.82 195.58-11.17 7.32-14.29 22.34-6.95 33.5 7.04 10.71 21.93 14.56 33.51 6.95C528.27 439.58 576 351.33 576 256S528.27 72.43 448.35 19.97zM480 256c0-63.53-32.06-121.94-85.77-156.24-11.19-7.14-26.03-3.82-33.12 7.46s-3.78 26.21 7.41 33.36C408.27 165.97 432 209.11 432 256s-23.73 90.03-63.48 115.42c-11.19 7.14-14.5 22.07-7.41 33.36 6.51 10.36 21.12 15.14 33.12 7.46C447.94 377.94 480 319.54 480 256zm-141.77-76.87c-11.58-6.33-26.19-2.16-32.61 9.45-6.39 11.61-2.16 26.2 9.45 32.61C327.98 228.28 336 241.63 336 256c0 14.38-8.02 27.72-20.92 34.81-11.61 6.41-15.84 21-9.45 32.61 6.43 11.66 21.05 15.8 32.61 9.45 28.23-15.55 45.77-45 45.77-76.88s-17.54-61.32-45.78-76.86z"/></svg>`,
            I = t => `<svg xmlns="http://www.w3.org/2000/svg" fill="${t}" width="20px" height="20px" viewBox="0 0 384 512"><path d="M215.03 72.04L126.06 161H24c-13.26 0-24 10.74-24 24v144c0 13.25 10.74 24 24 24h102.06l88.97 88.95c15.03 15.03 40.97 4.47 40.97-16.97V89.02c0-21.47-25.96-31.98-40.97-16.98zm123.2 108.08c-11.58-6.33-26.19-2.16-32.61 9.45-6.39 11.61-2.16 26.2 9.45 32.61C327.98 229.28 336 242.62 336 257c0 14.38-8.02 27.72-20.92 34.81-11.61 6.41-15.84 21-9.45 32.61 6.43 11.66 21.05 15.8 32.61 9.45 28.23-15.55 45.77-45 45.77-76.88s-17.54-61.32-45.78-76.87z"/></svg>`,
            P = t => `<svg xmlns="http://www.w3.org/2000/svg" fill="${t}" width="20px" height="20px" viewBox="0 0 256 512"><path d="M215 71l-89 89H24a24 24 0 0 0-24 24v144a24 24 0 0 0 24 24h102.06L215 441c15 15 41 4.47 41-17V88c0-21.47-26-32-41-17z"/></svg>`;
        w.fn.audioPlayer = function(b) {
            var t, b = w.extend({
                    classPrefix: "audioplayer",
                    strPlay: "",
                    strPause: "",
                    strVolume: "",
                    name: "",
                    color: "",
                    hover: "",
                    download: !1,
                    undo: !0
                }, b),
                y = {},
                e = {
                    playPause: "playpause",
                    playing: "playing",
                    time: "time",
                    timeCurrent: "time-current",
                    timeDuration: "time-duration",
                    title: "title",
                    controls: "controls",
                    download: "download",
                    undo: "undo",
                    bar: "bar",
                    barLoaded: "bar-loaded",
                    barPlayed: "bar-played",
                    volume: "volume",
                    volumeButton: "volume-button",
                    volumeAdjust: "volume-adjust",
                    noVolume: "novolume",
                    mute: "mute",
                    mini: "mini"
                };
            for (t in e) y[t] = b.classPrefix + "-" + e[t];
            return this.each(function() {
                if ("audio" != w(this).prop("tagName").toLowerCase()) return !1;
                var e, t, i, s, n, o, a, r, l, h, c, u, d = w(this),
                    p = d.attr("src"),
                    f = "" === (f = d.get(0).getAttribute("autoplay")) || "autoplay" === f,
                    m = "" === (m = d.get(0).getAttribute("loop")) || "loop" === m,
                    g = !1,
                    _ = (void 0 === p ? d.find("source").each(function() {
                        if (void 0 !== (p = w(this).attr("src")) && C(p)) return !(g = !0)
                    }) : C(p) && (g = !0), w('<div class="' + b.classPrefix + '">' + (g ? w("<div>").append(d.eq(0).clone()).html() : '<embed src="' + p + '" width="0" height="0" volume="100" autostart="' + f.toString() + '" loop="' + m.toString() + '" />') + '<div class="' + y.playPause + '" title="' + b.strPlay + '"><a href="#">' + b.strPlay + "</a></div></div>")),
                    v = (v = g ? _.find("audio") : _.find("embed")).get(0);
                g ? (b.color && w(_).get(0).style.setProperty("--color", b.color), b.hover && w(_).get(0).style.setProperty("--hover", b.hover), b.hover && w(_).get(0).style.setProperty("--hoverLight", b.hover + "10"), _.find("audio").css({
                    width: 0,
                    height: 0,
                    display: "none"
                }), _.append(`<div class="${y.time} ${y.timeCurrent}"></div>
                    <div class="${y.bar}">
                        <div class="${y.barLoaded}"></div>
                        <div class="${y.barPlayed}"></div>
                    </div>
                    <div class="${y.time} ${y.timeDuration}"></div>
                    <div class="${y.volume}">
                        <div class="${y.volumeButton}" title="${b.strVolume}">
                            <a href="#">${S(b?.color)}</a>
                        </div>
                        <div class="${y.volumeAdjust}">
                            <div>
                                <div></div>
                            </div>
                        </div>
                    </div>
                    <div class="${y.controls}">
                        ${b?.undo?`<div class="${y.undo}" title="replay">${`<svg xmlns="http://www.w3.org/2000/svg" fill="${b?.color}" width="16px" height="16px" viewBox="0 0 512 512"><path d="M255.545 8c-66.269.119-126.438 26.233-170.86 68.685L48.971 40.971C33.851 25.851 8 36.559 8 57.941V192c0 13.255 10.745 24 24 24h134.059c21.382 0 32.09-25.851 16.971-40.971l-41.75-41.75c30.864-28.899 70.801-44.907 113.23-45.273 92.398-.798 170.283 73.977 169.484 169.442C423.236 348.009 349.816 424 256 424c-41.127 0-79.997-14.678-110.63-41.556-4.743-4.161-11.906-3.908-16.368.553L89.34 422.659c-4.872 4.872-4.631 12.815.482 17.433C133.798 479.813 192.074 504 256 504c136.966 0 247.999-111.033 248-247.998C504.001 119.193 392.354 7.755 255.545 8z"/></svg>`}</div>`:""}
                        ${b?.download?`<a class="${y.download}" title="download" href="${d.attr("src")}">
                            <div>${`<svg xmlns="http://www.w3.org/2000/svg" fill="${b?.color}" width="16px" height="16px" viewBox="0 0 480 512"><path d="m366.56 233.376c-2.592-5.728-8.288-9.376-14.56-9.376h-64v-208c0-8.832-7.168-16-16-16h-64c-8.832 0-16 7.168-16 16v208h-64c-6.272 0-11.968 3.68-14.56 9.376-2.624 5.728-1.6 12.416 2.528 17.152l112 128c3.04 3.488 7.424 5.472 12.032 5.472s8.992-2.016 12.032-5.472l112-128c4.16-4.704 5.12-11.424 2.528-17.152z"></path><path d="m416 352v96h-352v-96h-64v128c0 17.696 14.336 32 32 32h416c17.696 0 32-14.304 32-32v-128z"></path></svg>`}</div>
                        </a>`:""}
                    </div>`), e = _.find("." + y.bar), t = _.find("." + y.barPlayed), i = _.find("." + y.barLoaded), s = _.find("." + y.timeCurrent), n = _.find("." + y.timeDuration), m = _.find("." + y.undo), o = _.find("." + y.volumeButton), a = _.find("." + y.volumeAdjust + " > div"), r = 0, l = function(t) {
                    theRealEvent = k ? t.originalEvent.touches[0] : t, v.currentTime = Math.round(v.duration * (theRealEvent.pageX - e.offset().left) / e.width())
                }, h = function(t) {
                    theRealEvent = k ? t.originalEvent.touches[0] : t, v.volume = 1 - Math.abs((theRealEvent.pageY - a.offset().top) / a.height()), .01 < v.volume && v.volume < .8 ? o.html(`<a href="#">${I(b?.color)}</a>`) : .8 < v.volume && o.html(`<a href="#">${S(b?.color)}</a>`)
                }, c = setInterval(function() {
                    0 < v.buffered.length && (i.width(v.buffered.end(0) / v.duration * 100 + "%"), v.buffered.end(0) >= v.duration) && clearInterval(c)
                }, 100), u = v.volume, v.volume = .111, Math.round(1e3 * v.volume) / 1e3 == .111 ? v.volume = u : _.addClass(y.noVolume), n.html("&hellip;"), s.text(x(0)), v.addEventListener("loadeddata", function() {
                    w("." + y.download).attr("href", w(this).attr("src")), n.text(x(v.duration)), f && _.addClass(y.playing), a.find("div").width(100 * v.volume + "%"), r = v.volume
                }), v.addEventListener("timeupdate", function() {
                    s.text(x(v.currentTime)), t.width(v.currentTime / v.duration * 100 + "%")
                }), v.addEventListener("volumechange", function() {
                    a.find("div").height(100 * v.volume + "%"), 0 < v.volume && _.hasClass(y.mute) && (_.removeClass(y.mute), o.html(`<a href="#">${S(b?.color)}</a>`)), v.volume <= 0 && !_.hasClass(y.mute) && (_.addClass(y.mute), o.html(`<a href="#">${P(b?.color)}</a>`))
                }), v.addEventListener("ended", function() {
                    _.removeClass(y.playing)
                }), v.addEventListener("pause", function() {
                    _.removeClass(y.playing)
                }), v.addEventListener("play", function() {
                    _.addClass(y.playing), pauseRunningVoices(b ? .name)
                }), e.on(D, function(t) {
                    l(t), e.on(T, function(t) {
                        l(t)
                    })
                }).on(E, function() {
                    e.unbind(T)
                }), m.on("click", function() {
                    g ? v.pause() : v.Stop(), v.currentTime = 0, w(this).attr("title", b.strPause).find("a").html(b.strPause), _.addClass(y.playing), g ? v.play() : v.Play()
                }), o.on("click", function() {
                    return _.hasClass(y.mute) ? (.8 < r ? o.html(`<a href="#">${S(b?.color)}</a>`) : o.html(`<a href="#">${I(b?.color)}</a>`), _.removeClass(y.mute), v.volume = r) : (_.addClass(y.mute), r = v.volume, v.volume = 0, o.html(`<a href="#">${P(b?.color)}</a>`)), !1
                }), a.on(D, function(t) {
                    h(t), a.on(T, function(t) {
                        h(t)
                    })
                }).on(E, function() {
                    a.unbind(T)
                })) : _.addClass(y.mini), f && _.addClass(y.playing), _.find("." + y.playPause).on("click", function() {
                    return _.hasClass(y.playing) ? (w(this).attr("title", b.strPlay).find("a").html(b.strPlay), _.removeClass(y.playing), g ? v.pause() : v.Stop()) : (w(this).attr("title", b.strPause).find("a").html(b.strPause), _.addClass(y.playing), g ? v.play() : v.Play()), !1
                }), d.replaceWith(_)
            }), this
        }
    }(jQuery, window, document), (() => {
        class t {
            constructor(t) {
                !t || isNaN(t) || t <= 0 ? this.cooldown = 1 : this.cooldown = t, this.stack = [""], this.currentIndex = 0, this.cooldownState = 0
            }
            record(t, e) {
                this.currentIndex === this.stack.length - 1 ? (this.cooldownState >= this.cooldown || 0 === this.cooldownState) && !0 !== e ? (this.stack.push(t), this.currentIndex++, this.cooldownState = 1) : this.cooldownState < this.cooldown && !0 !== e ? (this.current(t), this.cooldownState++) : !0 === e && (this.stack.push(t), this.currentIndex++, this.cooldownState = this.cooldown) : this.currentIndex < this.stack.length - 1 && (!0 !== e ? (this.stack.length = this.currentIndex + 1, this.stack.push(t), this.currentIndex++, this.cooldownState = 1) : !0 === e && (this.stack.length = this.currentIndex + 1, this.stack.push(t), this.currentIndex++, this.cooldownState = this.cooldown))
            }
            undo(t) {
                if (0 < this.currentIndex) return !0 !== t ? (this.currentIndex--, this.stack[this.currentIndex]) : this.stack[this.currentIndex - 1]
            }
            redo(t) {
                if (this.currentIndex < this.stack.length - 1) return !0 !== t ? (this.currentIndex++, this.stack[this.currentIndex]) : this.stack[this.currentIndex + 1]
            }
            current(t) {
                return t && (this.stack[this.currentIndex] = t), this.stack[this.currentIndex]
            }
        }
        "undefined" != typeof module && void 0 !== module.exports && (module.exports = t), "object" == typeof window && (window.UndoRedojs = t)
    })(), "undefined" == typeof jQuery) throw new Error("JavaScript requires jQuery");
! function() {
    "use strict";
    var t = jQuery.fn.jquery.split(" ")[0].split(".");
    if (t[0] < 2 && t[1] < 9 || 1 == t[0] && 9 == t[1] && t[2] < 1) throw new Error("JavaScript requires jQuery version 1.9.1 or higher")
}(),
function(l) {
    function e(t) {
        l("body").removeClass("notify-open"), l(".notify-backdrop").css("opacity", 0), "" != t.data("animation") ? (t.addClass(t.data("animation")), setTimeout(function() {
            l("body").removeClass("notify-open-drop"), l(".notify-backdrop").remove(), t.remove()
        }, 400)) : (l(".notify-backdrop").remove(), t.remove())
    }
    l.notify = function(t, e) {
        var i = l.extend({
                delay: 3e3,
                type: "default",
                align: "center",
                verticalAlign: "top",
                blur: .2,
                close: !1,
                background: "",
                color: "",
                class: "",
                animation: !0,
                animationType: "drop",
                icon: "",
                buttons: [],
                buttonFunc: [],
                buttonAlign: "center",
                width: "600px"
            }, e),
            s = "",
            n = "",
            o = "",
            e = "";
        i.animation && (s = i.animationType), "" != i.icon && (e = "<i class='icon fa fa-" + i.icon + "'></i>"), !i.close && 0 != i.delay || (n = "<button type='button' class='close' data-close='notify' data-animation='" + s + "'; >Ã—</button>", o = "notify-dismissible");
        var a, r = l("<div data-animation='" + s + "' class='notify " + i.align + " " + i.verticalAlign + " " + s + " " + o + "'><div class='message'>" + e + t + "</div>" + n + "</div>");
        "" != i.background ? r.css("background", i.background) : "" == i.class ? r.addClass("notify-" + i.type) : r.addClass(i.class), "" != i.color && r.css("color", i.color), "drop" == s && l("body").addClass("notify-open-drop"), "middle" == i.verticalAlign ? (r.css("visibility", "hidden"), l("body").append(r), r.css({
            "margin-top": r.innerHeight() / 2 * -1,
            visibility: "visible"
        })) : l("body").append(r), i.animation && setTimeout(function() {
            r.removeClass(s)
        }, 100), 0 == i.delay ? (a = l("<div class='notify-backdrop'></div>"), l("body").append(a).addClass("notify-open"), setTimeout(function() {
            a.css("opacity", i.blur)
        }, 100)) : setTimeout(function() {
            i.animation ? (r.addClass(i.animationType), setTimeout(function() {
                "drop" == i.animation && l("body").removeClass("notify-open-drop"), r.remove()
            }, 400)) : r.remove()
        }, i.delay)
    }, l(document).on("click", ".notify-backdrop", function(t) {
        e(l(".notify"))
    }), l(document).on("click", ".notify-buttons > button", function(t) {
        e(l(this).parent().parent())
    }), l(document).on("click", "[data-close='notify']", function(t) {
        e(l(this).parent())
    })
}(jQuery),
function(t) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], t) : t(jQuery)
}(function(V) {
    "use strict";
    V.ui = V.ui || {}, V.ui.version = "1.13.0";
    var n, s, x, C, o, a, r, l, h, i, t, e, c, H = 0,
        F = Array.prototype.hasOwnProperty,
        z = Array.prototype.slice;

    function L(t, e, i) {
        return [parseFloat(t[0]) * (h.test(t[0]) ? e / 100 : 1), parseFloat(t[1]) * (h.test(t[1]) ? i / 100 : 1)]
    }

    function k(t, e) {
        return parseInt(V.css(t, e), 10) || 0
    }

    function W(t) {
        return null != t && t === t.window
    }
    V.cleanData = (n = V.cleanData, function(t) {
        for (var e, i, s = 0; null != (i = t[s]); s++)(e = V._data(i, "events")) && e.remove && V(i).triggerHandler("remove");
        n(t)
    }), V.widget = function(t, i, e) {
        var s, n, o, a = {},
            r = t.split(".")[0],
            l = r + "-" + (t = t.split(".")[1]);
        return e || (e = i, i = V.Widget), Array.isArray(e) && (e = V.extend.apply(null, [{}].concat(e))), V.expr.pseudos[l.toLowerCase()] = function(t) {
            return !!V.data(t, l)
        }, V[r] = V[r] || {}, s = V[r][t], n = V[r][t] = function(t, e) {
            if (!this._createWidget) return new n(t, e);
            arguments.length && this._createWidget(t, e)
        }, V.extend(n, s, {
            version: e.version,
            _proto: V.extend({}, e),
            _childConstructors: []
        }), (o = new i).options = V.widget.extend({}, o.options), V.each(e, function(e, s) {
            function n() {
                return i.prototype[e].apply(this, arguments)
            }

            function o(t) {
                return i.prototype[e].apply(this, t)
            }
            a[e] = "function" == typeof s ? function() {
                var t, e = this._super,
                    i = this._superApply;
                return this._super = n, this._superApply = o, t = s.apply(this, arguments), this._super = e, this._superApply = i, t
            } : s
        }), n.prototype = V.widget.extend(o, {
            widgetEventPrefix: s && o.widgetEventPrefix || t
        }, a, {
            constructor: n,
            namespace: r,
            widgetName: t,
            widgetFullName: l
        }), s ? (V.each(s._childConstructors, function(t, e) {
            var i = e.prototype;
            V.widget(i.namespace + "." + i.widgetName, n, e._proto)
        }), delete s._childConstructors) : i._childConstructors.push(n), V.widget.bridge(t, n), n
    }, V.widget.extend = function(t) {
        for (var e, i, s = z.call(arguments, 1), n = 0, o = s.length; n < o; n++)
            for (e in s[n]) i = s[n][e], F.call(s[n], e) && void 0 !== i && (V.isPlainObject(i) ? t[e] = V.isPlainObject(t[e]) ? V.widget.extend({}, t[e], i) : V.widget.extend({}, i) : t[e] = i);
        return t
    }, V.widget.bridge = function(o, e) {
        var a = e.prototype.widgetFullName || o;
        V.fn[o] = function(i) {
            var t = "string" == typeof i,
                s = z.call(arguments, 1),
                n = this;
            return t ? this.length || "instance" !== i ? this.each(function() {
                var t, e = V.data(this, a);
                return "instance" === i ? (n = e, !1) : e ? "function" != typeof e[i] || "_" === i.charAt(0) ? V.error("no such method '" + i + "' for " + o + " widget instance") : (t = e[i].apply(e, s)) !== e && void 0 !== t ? (n = t && t.jquery ? n.pushStack(t.get()) : t, !1) : void 0 : V.error("cannot call methods on " + o + " prior to initialization; attempted to call method '" + i + "'")
            }) : n = void 0 : (s.length && (i = V.widget.extend.apply(null, [i].concat(s))), this.each(function() {
                var t = V.data(this, a);
                t ? (t.option(i || {}), t._init && t._init()) : V.data(this, a, new e(i, this))
            })), n
        }
    }, V.Widget = function() {}, V.Widget._childConstructors = [], V.Widget.prototype = {
        widgetName: "widget",
        widgetEventPrefix: "",
        defaultElement: "<div>",
        options: {
            classes: {},
            disabled: !1,
            create: null
        },
        _createWidget: function(t, e) {
            e = V(e || this.defaultElement || this)[0], this.element = V(e), this.uuid = H++, this.eventNamespace = "." + this.widgetName + this.uuid, this.bindings = V(), this.hoverable = V(), this.focusable = V(), this.classesElementLookup = {}, e !== this && (V.data(e, this.widgetFullName, this), this._on(!0, this.element, {
                remove: function(t) {
                    t.target === e && this.destroy()
                }
            }), this.document = V(e.style ? e.ownerDocument : e.document || e), this.window = V(this.document[0].defaultView || this.document[0].parentWindow)), this.options = V.widget.extend({}, this.options, this._getCreateOptions(), t), this._create(), this.options.disabled && this._setOptionDisabled(this.options.disabled), this._trigger("create", null, this._getCreateEventData()), this._init()
        },
        _getCreateOptions: function() {
            return {}
        },
        _getCreateEventData: V.noop,
        _create: V.noop,
        _init: V.noop,
        destroy: function() {
            var i = this;
            this._destroy(), V.each(this.classesElementLookup, function(t, e) {
                i._removeClass(e, t)
            }), this.element.off(this.eventNamespace).removeData(this.widgetFullName), this.widget().off(this.eventNamespace).removeAttr("aria-disabled"), this.bindings.off(this.eventNamespace)
        },
        _destroy: V.noop,
        widget: function() {
            return this.element
        },
        option: function(t, e) {
            var i, s, n, o = t;
            if (0 === arguments.length) return V.widget.extend({}, this.options);
            if ("string" == typeof t)
                if (o = {}, t = (i = t.split(".")).shift(), i.length) {
                    for (s = o[t] = V.widget.extend({}, this.options[t]), n = 0; n < i.length - 1; n++) s[i[n]] = s[i[n]] || {}, s = s[i[n]];
                    if (t = i.pop(), 1 === arguments.length) return void 0 === s[t] ? null : s[t];
                    s[t] = e
                } else {
                    if (1 === arguments.length) return void 0 === this.options[t] ? null : this.options[t];
                    o[t] = e
                }
            return this._setOptions(o), this
        },
        _setOptions: function(t) {
            for (var e in t) this._setOption(e, t[e]);
            return this
        },
        _setOption: function(t, e) {
            return "classes" === t && this._setOptionClasses(e), this.options[t] = e, "disabled" === t && this._setOptionDisabled(e), this
        },
        _setOptionClasses: function(t) {
            var e, i, s;
            for (e in t) s = this.classesElementLookup[e], t[e] !== this.options.classes[e] && s && s.length && (i = V(s.get()), this._removeClass(s, e), i.addClass(this._classes({
                element: i,
                keys: e,
                classes: t,
                add: !0
            })))
        },
        _setOptionDisabled: function(t) {
            this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !!t), t && (this._removeClass(this.hoverable, null, "ui-state-hover"), this._removeClass(this.focusable, null, "ui-state-focus"))
        },
        enable: function() {
            return this._setOptions({
                disabled: !1
            })
        },
        disable: function() {
            return this._setOptions({
                disabled: !0
            })
        },
        _classes: function(n) {
            var o = [],
                a = this;

            function t(t, e) {
                for (var i, s = 0; s < t.length; s++) i = a.classesElementLookup[t[s]] || V(), i = n.add ? (n.element.each(function(t, e) {
                    V.map(a.classesElementLookup, function(t) {
                        return t
                    }).some(function(t) {
                        return t.is(e)
                    }) || a._on(V(e), {
                        remove: "_untrackClassesElement"
                    })
                }), V(V.uniqueSort(i.get().concat(n.element.get())))) : V(i.not(n.element).get()), a.classesElementLookup[t[s]] = i, o.push(t[s]), e && n.classes[t[s]] && o.push(n.classes[t[s]])
            }
            return (n = V.extend({
                element: this.element,
                classes: this.options.classes || {}
            }, n)).keys && t(n.keys.match(/\S+/g) || [], !0), n.extra && t(n.extra.match(/\S+/g) || []), o.join(" ")
        },
        _untrackClassesElement: function(i) {
            var s = this;
            V.each(s.classesElementLookup, function(t, e) {
                -1 !== V.inArray(i.target, e) && (s.classesElementLookup[t] = V(e.not(i.target).get()))
            }), this._off(V(i.target))
        },
        _removeClass: function(t, e, i) {
            return this._toggleClass(t, e, i, !1)
        },
        _addClass: function(t, e, i) {
            return this._toggleClass(t, e, i, !0)
        },
        _toggleClass: function(t, e, i, s) {
            var n = "string" == typeof t || null === t;
            return (i = {
                extra: n ? e : i,
                keys: n ? t : e,
                element: n ? this.element : t,
                add: s = "boolean" == typeof s ? s : i
            }).element.toggleClass(this._classes(i), s), this
        },
        _on: function(n, o, t) {
            var a, r = this;
            "boolean" != typeof n && (t = o, o = n, n = !1), t ? (o = a = V(o), this.bindings = this.bindings.add(o)) : (t = o, o = this.element, a = this.widget()), V.each(t, function(t, e) {
                function i() {
                    if (n || !0 !== r.options.disabled && !V(this).hasClass("ui-state-disabled")) return ("string" == typeof e ? r[e] : e).apply(r, arguments)
                }
                "string" != typeof e && (i.guid = e.guid = e.guid || i.guid || V.guid++);
                var s = t.match(/^([\w:-]*)\s*(.*)$/),
                    t = s[1] + r.eventNamespace;
                (s = s[2]) ? a.on(t, s, i): o.on(t, i)
            })
        },
        _off: function(t, e) {
            e = (e || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, t.off(e), this.bindings = V(this.bindings.not(t).get()), this.focusable = V(this.focusable.not(t).get()), this.hoverable = V(this.hoverable.not(t).get())
        },
        _delay: function(t, e) {
            var i = this;
            return setTimeout(function() {
                return ("string" == typeof t ? i[t] : t).apply(i, arguments)
            }, e || 0)
        },
        _hoverable: function(t) {
            this.hoverable = this.hoverable.add(t), this._on(t, {
                mouseenter: function(t) {
                    this._addClass(V(t.currentTarget), null, "ui-state-hover")
                },
                mouseleave: function(t) {
                    this._removeClass(V(t.currentTarget), null, "ui-state-hover")
                }
            })
        },
        _focusable: function(t) {
            this.focusable = this.focusable.add(t), this._on(t, {
                focusin: function(t) {
                    this._addClass(V(t.currentTarget), null, "ui-state-focus")
                },
                focusout: function(t) {
                    this._removeClass(V(t.currentTarget), null, "ui-state-focus")
                }
            })
        },
        _trigger: function(t, e, i) {
            var s, n, o = this.options[t];
            if (i = i || {}, (e = V.Event(e)).type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), e.target = this.element[0], n = e.originalEvent)
                for (s in n) s in e || (e[s] = n[s]);
            return this.element.trigger(e, i), !("function" == typeof o && !1 === o.apply(this.element[0], [e].concat(i)) || e.isDefaultPrevented())
        }
    }, V.each({
        show: "fadeIn",
        hide: "fadeOut"
    }, function(o, a) {
        V.Widget.prototype["_" + o] = function(e, t, i) {
            var s, n = (t = "string" == typeof t ? {
                effect: t
            } : t) ? !0 !== t && "number" != typeof t && t.effect || a : o;
            "number" == typeof(t = t || {}) ? t = {
                duration: t
            }: !0 === t && (t = {}), s = !V.isEmptyObject(t), t.complete = i, t.delay && e.delay(t.delay), s && V.effects && V.effects.effect[n] ? e[o](t) : n !== o && e[n] ? e[n](t.duration, t.easing, i) : e.queue(function(t) {
                V(this)[o](), i && i.call(e[0]), t()
            })
        }
    }), V.widget, x = Math.max, C = Math.abs, o = /left|center|right/, a = /top|center|bottom/, r = /[\+\-]\d+(\.[\d]+)?%?/, l = /^\w+/, h = /%$/, i = V.fn.position, V.position = {
        scrollbarWidth: function() {
            var t, e, i;
            return void 0 !== s ? s : (i = (e = V("<div style='display:block;position:absolute;width:200px;height:200px;overflow:hidden;'><div style='height:300px;width:auto;'></div></div>")).children()[0], V("body").append(e), t = i.offsetWidth, e.css("overflow", "scroll"), t === (i = i.offsetWidth) && (i = e[0].clientWidth), e.remove(), s = t - i)
        },
        getScrollInfo: function(t) {
            var e = t.isWindow || t.isDocument ? "" : t.element.css("overflow-x"),
                i = t.isWindow || t.isDocument ? "" : t.element.css("overflow-y"),
                e = "scroll" === e || "auto" === e && t.width < t.element[0].scrollWidth;
            return {
                width: "scroll" === i || "auto" === i && t.height < t.element[0].scrollHeight ? V.position.scrollbarWidth() : 0,
                height: e ? V.position.scrollbarWidth() : 0
            }
        },
        getWithinInfo: function(t) {
            var e = V(t || window),
                i = W(e[0]),
                s = !!e[0] && 9 === e[0].nodeType;
            return {
                element: e,
                isWindow: i,
                isDocument: s,
                offset: i || s ? {
                    left: 0,
                    top: 0
                } : V(t).offset(),
                scrollLeft: e.scrollLeft(),
                scrollTop: e.scrollTop(),
                width: e.outerWidth(),
                height: e.outerHeight()
            }
        }
    }, V.fn.position = function(u) {
        var d, p, f, m, g, t, _, v, b, y, w, e;
        return u && u.of ? (_ = "string" == typeof(u = V.extend({}, u)).of ? V(document).find(u.of) : V(u.of), v = V.position.getWithinInfo(u.within), b = V.position.getScrollInfo(v), y = (u.collision || "flip").split(" "), w = {}, e = 9 === (t = (e = _)[0]).nodeType ? {
            width: e.width(),
            height: e.height(),
            offset: {
                top: 0,
                left: 0
            }
        } : W(t) ? {
            width: e.width(),
            height: e.height(),
            offset: {
                top: e.scrollTop(),
                left: e.scrollLeft()
            }
        } : t.preventDefault ? {
            width: 0,
            height: 0,
            offset: {
                top: t.pageY,
                left: t.pageX
            }
        } : {
            width: e.outerWidth(),
            height: e.outerHeight(),
            offset: e.offset()
        }, _[0].preventDefault && (u.at = "left top"), p = e.width, f = e.height, g = V.extend({}, m = e.offset), V.each(["my", "at"], function() {
            var t, e, i = (u[this] || "").split(" ");
            (i = 1 === i.length ? o.test(i[0]) ? i.concat(["center"]) : a.test(i[0]) ? ["center"].concat(i) : ["center", "center"] : i)[0] = o.test(i[0]) ? i[0] : "center", i[1] = a.test(i[1]) ? i[1] : "center", t = r.exec(i[0]), e = r.exec(i[1]), w[this] = [t ? t[0] : 0, e ? e[0] : 0], u[this] = [l.exec(i[0])[0], l.exec(i[1])[0]]
        }), 1 === y.length && (y[1] = y[0]), "right" === u.at[0] ? g.left += p : "center" === u.at[0] && (g.left += p / 2), "bottom" === u.at[1] ? g.top += f : "center" === u.at[1] && (g.top += f / 2), d = L(w.at, p, f), g.left += d[0], g.top += d[1], this.each(function() {
            var i, t, a = V(this),
                r = a.outerWidth(),
                l = a.outerHeight(),
                e = k(this, "marginLeft"),
                s = k(this, "marginTop"),
                n = r + e + k(this, "marginRight") + b.width,
                o = l + s + k(this, "marginBottom") + b.height,
                h = V.extend({}, g),
                c = L(w.my, a.outerWidth(), a.outerHeight());
            "right" === u.my[0] ? h.left -= r : "center" === u.my[0] && (h.left -= r / 2), "bottom" === u.my[1] ? h.top -= l : "center" === u.my[1] && (h.top -= l / 2), h.left += c[0], h.top += c[1], i = {
                marginLeft: e,
                marginTop: s
            }, V.each(["left", "top"], function(t, e) {
                V.ui.position[y[t]] && V.ui.position[y[t]][e](h, {
                    targetWidth: p,
                    targetHeight: f,
                    elemWidth: r,
                    elemHeight: l,
                    collisionPosition: i,
                    collisionWidth: n,
                    collisionHeight: o,
                    offset: [d[0] + c[0], d[1] + c[1]],
                    my: u.my,
                    at: u.at,
                    within: v,
                    elem: a
                })
            }), u.using && (t = function(t) {
                var e = m.left - h.left,
                    i = e + p - r,
                    s = m.top - h.top,
                    n = s + f - l,
                    o = {
                        target: {
                            element: _,
                            left: m.left,
                            top: m.top,
                            width: p,
                            height: f
                        },
                        element: {
                            element: a,
                            left: h.left,
                            top: h.top,
                            width: r,
                            height: l
                        },
                        horizontal: i < 0 ? "left" : 0 < e ? "right" : "center",
                        vertical: n < 0 ? "top" : 0 < s ? "bottom" : "middle"
                    };
                p < r && C(e + i) < p && (o.horizontal = "center"), f < l && C(s + n) < f && (o.vertical = "middle"), x(C(e), C(i)) > x(C(s), C(n)) ? o.important = "horizontal" : o.important = "vertical", u.using.call(this, t, o)
            }), a.offset(V.extend(h, {
                using: t
            }))
        })) : i.apply(this, arguments)
    }, V.ui.position = {
        fit: {
            left: function(t, e) {
                var i = e.within,
                    s = i.isWindow ? i.scrollLeft : i.offset.left,
                    n = i.width,
                    o = t.left - e.collisionPosition.marginLeft,
                    a = s - o,
                    r = o + e.collisionWidth - n - s;
                e.collisionWidth > n ? 0 < a && r <= 0 ? (i = t.left + a + e.collisionWidth - n - s, t.left += a - i) : t.left = !(0 < r && a <= 0) && r < a ? s + n - e.collisionWidth : s : 0 < a ? t.left += a : 0 < r ? t.left -= r : t.left = x(t.left - o, t.left)
            },
            top: function(t, e) {
                var i = e.within,
                    s = i.isWindow ? i.scrollTop : i.offset.top,
                    n = e.within.height,
                    o = t.top - e.collisionPosition.marginTop,
                    a = s - o,
                    r = o + e.collisionHeight - n - s;
                e.collisionHeight > n ? 0 < a && r <= 0 ? (i = t.top + a + e.collisionHeight - n - s, t.top += a - i) : t.top = !(0 < r && a <= 0) && r < a ? s + n - e.collisionHeight : s : 0 < a ? t.top += a : 0 < r ? t.top -= r : t.top = x(t.top - o, t.top)
            }
        },
        flip: {
            left: function(t, e) {
                var i = (l = e.within).offset.left + l.scrollLeft,
                    s = l.width,
                    n = l.isWindow ? l.scrollLeft : l.offset.left,
                    o = (h = t.left - e.collisionPosition.marginLeft) - n,
                    a = h + e.collisionWidth - s - n,
                    r = "left" === e.my[0] ? -e.elemWidth : "right" === e.my[0] ? e.elemWidth : 0,
                    l = "left" === e.at[0] ? e.targetWidth : "right" === e.at[0] ? -e.targetWidth : 0,
                    h = -2 * e.offset[0];
                o < 0 ? ((i = t.left + r + l + h + e.collisionWidth - s - i) < 0 || i < C(o)) && (t.left += r + l + h) : 0 < a && (0 < (n = t.left - e.collisionPosition.marginLeft + r + l + h - n) || C(n) < a) && (t.left += r + l + h)
            },
            top: function(t, e) {
                var i = (l = e.within).offset.top + l.scrollTop,
                    s = l.height,
                    n = l.isWindow ? l.scrollTop : l.offset.top,
                    o = (h = t.top - e.collisionPosition.marginTop) - n,
                    a = h + e.collisionHeight - s - n,
                    r = "top" === e.my[1] ? -e.elemHeight : "bottom" === e.my[1] ? e.elemHeight : 0,
                    l = "top" === e.at[1] ? e.targetHeight : "bottom" === e.at[1] ? -e.targetHeight : 0,
                    h = -2 * e.offset[1];
                o < 0 ? ((i = t.top + r + l + h + e.collisionHeight - s - i) < 0 || i < C(o)) && (t.top += r + l + h) : 0 < a && (0 < (n = t.top - e.collisionPosition.marginTop + r + l + h - n) || C(n) < a) && (t.top += r + l + h)
            }
        },
        flipfit: {
            left: function() {
                V.ui.position.flip.left.apply(this, arguments), V.ui.position.fit.left.apply(this, arguments)
            },
            top: function() {
                V.ui.position.flip.top.apply(this, arguments), V.ui.position.fit.top.apply(this, arguments)
            }
        }
    }, V.ui.position, V.extend(V.expr.pseudos, {
        data: V.expr.createPseudo ? V.expr.createPseudo(function(e) {
            return function(t) {
                return !!V.data(t, e)
            }
        }) : function(t, e, i) {
            return !!V.data(t, i[3])
        }
    }), V.fn.extend({
        disableSelection: (t = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown", function() {
            return this.on(t + ".ui-disableSelection", function(t) {
                t.preventDefault()
            })
        }),
        enableSelection: function() {
            return this.off(".ui-disableSelection")
        }
    }), V.ui.focusable = function(t, e) {
        var i, s, n, o = t.nodeName.toLowerCase();
        return "area" === o ? (i = (n = t.parentNode).name, !(!t.href || !i || "map" !== n.nodeName.toLowerCase()) && 0 < (i = V("img[usemap='#" + i + "']")).length && i.is(":visible")) : (/^(input|select|textarea|button|object)$/.test(o) ? (s = !t.disabled) && (n = V(t).closest("fieldset")[0]) && (s = !n.disabled) : s = "a" === o && t.href || e, s && V(t).is(":visible") && function(t) {
            for (var e = t.css("visibility");
                "inherit" === e;) e = (t = t.parent()).css("visibility");
            return "visible" === e
        }(V(t)))
    }, V.extend(V.expr.pseudos, {
        focusable: function(t) {
            return V.ui.focusable(t, null != V.attr(t, "tabindex"))
        }
    }), V.ui.focusable, V.fn._form = function() {
        return "string" == typeof this[0].form ? this.closest("form") : V(this[0].form)
    }, V.ui.formResetMixin = {
        _formResetHandler: function() {
            var e = V(this);
            setTimeout(function() {
                var t = e.data("ui-form-reset-instances");
                V.each(t, function() {
                    this.refresh()
                })
            })
        },
        _bindFormResetHandler: function() {
            var t;
            this.form = this.element._form(), this.form.length && ((t = this.form.data("ui-form-reset-instances") || []).length || this.form.on("reset.ui-form-reset", this._formResetHandler), t.push(this), this.form.data("ui-form-reset-instances", t))
        },
        _unbindFormResetHandler: function() {
            var t;
            this.form.length && ((t = this.form.data("ui-form-reset-instances")).splice(V.inArray(this, t), 1), t.length ? this.form.data("ui-form-reset-instances", t) : this.form.removeData("ui-form-reset-instances").off("reset.ui-form-reset"))
        }
    }, V.expr.pseudos || (V.expr.pseudos = V.expr[":"]), V.uniqueSort || (V.uniqueSort = V.unique), V.escapeSelector || (e = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g, c = function(t, e) {
        return e ? "\0" === t ? "�" : t.slice(0, -1) + "\\" + t.charCodeAt(t.length - 1).toString(16) + " " : "\\" + t
    }, V.escapeSelector = function(t) {
        return (t + "").replace(e, c)
    }), V.fn.even && V.fn.odd || V.fn.extend({
        even: function() {
            return this.filter(function(t) {
                return t % 2 == 0
            })
        },
        odd: function() {
            return this.filter(function(t) {
                return t % 2 == 1
            })
        }
    }), V.ui.keyCode = {
        BACKSPACE: 8,
        COMMA: 188,
        DELETE: 46,
        DOWN: 40,
        END: 35,
        ENTER: 13,
        ESCAPE: 27,
        HOME: 36,
        LEFT: 37,
        PAGE_DOWN: 34,
        PAGE_UP: 33,
        PERIOD: 190,
        RIGHT: 39,
        SPACE: 32,
        TAB: 9,
        UP: 38
    }, V.fn.labels = function() {
        var t, e, i;
        return this.length ? this[0].labels && this[0].labels.length ? this.pushStack(this[0].labels) : (e = this.eq(0).parents("label"), (t = this.attr("id")) && (i = (i = this.eq(0).parents().last()).add((i.length ? i : this).siblings()), t = "label[for='" + V.escapeSelector(t) + "']", e = e.add(i.find(t).addBack(t))), this.pushStack(e)) : this.pushStack([])
    }, V.fn.scrollParent = function(t) {
        var e = this.css("position"),
            i = "absolute" === e,
            s = t ? /(auto|scroll|hidden)/ : /(auto|scroll)/,
            t = this.parents().filter(function() {
                var t = V(this);
                return (!i || "static" !== t.css("position")) && s.test(t.css("overflow") + t.css("overflow-y") + t.css("overflow-x"))
            }).eq(0);
        return "fixed" !== e && t.length ? t : V(this[0].ownerDocument || document)
    }, V.extend(V.expr.pseudos, {
        tabbable: function(t) {
            var e = V.attr(t, "tabindex"),
                i = null != e;
            return (!i || 0 <= e) && V.ui.focusable(t, i)
        }
    }), V.fn.extend({
        uniqueId: (R = 0, function() {
            return this.each(function() {
                this.id || (this.id = "ui-id-" + ++R)
            })
        }),
        removeUniqueId: function() {
            return this.each(function() {
                /^ui-id-\d+$/.test(this.id) && V(this).removeAttr("id")
            })
        }
    }), V.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase());
    var R, u = !1;

    function $(t, e, i) {
        return e <= t && t < e + i
    }
    V(document).on("mouseup", function() {
        u = !1
    }), V.widget("ui.mouse", {
        version: "1.13.0",
        options: {
            cancel: "input, textarea, button, select, option",
            distance: 1,
            delay: 0
        },
        _mouseInit: function() {
            var e = this;
            this.element.on("mousedown." + this.widgetName, function(t) {
                return e._mouseDown(t)
            }).on("click." + this.widgetName, function(t) {
                if (!0 === V.data(t.target, e.widgetName + ".preventClickEvent")) return V.removeData(t.target, e.widgetName + ".preventClickEvent"), t.stopImmediatePropagation(), !1
            }), this.started = !1
        },
        _mouseDestroy: function() {
            this.element.off("." + this.widgetName), this._mouseMoveDelegate && this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate)
        },
        _mouseDown: function(t) {
            var e, i, s;
            if (!u) return this._mouseMoved = !1, this._mouseStarted && this._mouseUp(t), i = 1 === (this._mouseDownEvent = t).which, s = !("string" != typeof(e = this).options.cancel || !t.target.nodeName) && V(t.target).closest(this.options.cancel).length, !(i && !s && this._mouseCapture(t)) || (this.mouseDelayMet = !this.options.delay, this.mouseDelayMet || (this._mouseDelayTimer = setTimeout(function() {
                e.mouseDelayMet = !0
            }, this.options.delay)), this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = !1 !== this._mouseStart(t), !this._mouseStarted) ? (t.preventDefault(), !0) : (!0 === V.data(t.target, this.widgetName + ".preventClickEvent") && V.removeData(t.target, this.widgetName + ".preventClickEvent"), this._mouseMoveDelegate = function(t) {
                return e._mouseMove(t)
            }, this._mouseUpDelegate = function(t) {
                return e._mouseUp(t)
            }, this.document.on("mousemove." + this.widgetName, this._mouseMoveDelegate).on("mouseup." + this.widgetName, this._mouseUpDelegate), t.preventDefault(), u = !0))
        },
        _mouseMove: function(t) {
            if (this._mouseMoved) {
                if (V.ui.ie && (!document.documentMode || document.documentMode < 9) && !t.button) return this._mouseUp(t);
                if (!t.which)
                    if (t.originalEvent.altKey || t.originalEvent.ctrlKey || t.originalEvent.metaKey || t.originalEvent.shiftKey) this.ignoreMissingWhich = !0;
                    else if (!this.ignoreMissingWhich) return this._mouseUp(t)
            }
            return (t.which || t.button) && (this._mouseMoved = !0), this._mouseStarted ? (this._mouseDrag(t), t.preventDefault()) : (this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = !1 !== this._mouseStart(this._mouseDownEvent, t), this._mouseStarted ? this._mouseDrag(t) : this._mouseUp(t)), !this._mouseStarted)
        },
        _mouseUp: function(t) {
            this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate), this._mouseStarted && (this._mouseStarted = !1, t.target === this._mouseDownEvent.target && V.data(t.target, this.widgetName + ".preventClickEvent", !0), this._mouseStop(t)), this._mouseDelayTimer && (clearTimeout(this._mouseDelayTimer), delete this._mouseDelayTimer), this.ignoreMissingWhich = !1, u = !1, t.preventDefault()
        },
        _mouseDistanceMet: function(t) {
            return Math.max(Math.abs(this._mouseDownEvent.pageX - t.pageX), Math.abs(this._mouseDownEvent.pageY - t.pageY)) >= this.options.distance
        },
        _mouseDelayMet: function() {
            return this.mouseDelayMet
        },
        _mouseStart: function() {},
        _mouseDrag: function() {},
        _mouseStop: function() {},
        _mouseCapture: function() {
            return !0
        }
    }), V.ui.plugin = {
        add: function(t, e, i) {
            var s, n = V.ui[t].prototype;
            for (s in i) n.plugins[s] = n.plugins[s] || [], n.plugins[s].push([e, i[s]])
        },
        call: function(t, e, i, s) {
            var n, o = t.plugins[e];
            if (o && (s || t.element[0].parentNode && 11 !== t.element[0].parentNode.nodeType))
                for (n = 0; n < o.length; n++) t.options[o[n][0]] && o[n][1].apply(t.element, i)
        }
    }, V.ui.safeActiveElement = function(e) {
        var i;
        try {
            i = e.activeElement
        } catch (t) {
            i = e.body
        }
        return (i = i || e.body).nodeName ? i : e.body
    }, V.ui.safeBlur = function(t) {
        t && "body" !== t.nodeName.toLowerCase() && V(t).trigger("blur")
    }, V.widget("ui.draggable", V.ui.mouse, {
        version: "1.13.0",
        widgetEventPrefix: "drag",
        options: {
            addClasses: !0,
            appendTo: "parent",
            axis: !1,
            connectToSortable: !1,
            containment: !1,
            cursor: "auto",
            cursorAt: !1,
            grid: !1,
            handle: !1,
            helper: "original",
            iframeFix: !1,
            opacity: !1,
            refreshPositions: !1,
            revert: !1,
            revertDuration: 500,
            scope: "default",
            scroll: !0,
            scrollSensitivity: 20,
            scrollSpeed: 20,
            snap: !1,
            snapMode: "both",
            snapTolerance: 20,
            stack: !1,
            zIndex: !1,
            drag: null,
            start: null,
            stop: null
        },
        _create: function() {
            "original" === this.options.helper && this._setPositionRelative(), this.options.addClasses && this._addClass("ui-draggable"), this._setHandleClassName(), this._mouseInit()
        },
        _setOption: function(t, e) {
            this._super(t, e), "handle" === t && (this._removeHandleClassName(), this._setHandleClassName())
        },
        _destroy: function() {
            (this.helper || this.element).is(".ui-draggable-dragging") ? this.destroyOnClear = !0 : (this._removeHandleClassName(), this._mouseDestroy())
        },
        _mouseCapture: function(t) {
            var e = this.options;
            return !(this.helper || e.disabled || 0 < V(t.target).closest(".ui-resizable-handle").length || (this.handle = this._getHandle(t), !this.handle) || (this._blurActiveElement(t), this._blockFrames(!0 === e.iframeFix ? "iframe" : e.iframeFix), 0))
        },
        _blockFrames: function(t) {
            this.iframeBlocks = this.document.find(t).map(function() {
                var t = V(this);
                return V("<div>").css("position", "absolute").appendTo(t.parent()).outerWidth(t.outerWidth()).outerHeight(t.outerHeight()).offset(t.offset())[0]
            })
        },
        _unblockFrames: function() {
            this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks)
        },
        _blurActiveElement: function(t) {
            var e = V.ui.safeActiveElement(this.document[0]);
            V(t.target).closest(e).length || V.ui.safeBlur(e)
        },
        _mouseStart: function(t) {
            var e = this.options;
            return this.helper = this._createHelper(t), this._addClass(this.helper, "ui-draggable-dragging"), this._cacheHelperProportions(), V.ui.ddmanager && (V.ui.ddmanager.current = this), this._cacheMargins(), this.cssPosition = this.helper.css("position"), this.scrollParent = this.helper.scrollParent(!0), this.offsetParent = this.helper.offsetParent(), this.hasFixedAncestor = 0 < this.helper.parents().filter(function() {
                return "fixed" === V(this).css("position")
            }).length, this.positionAbs = this.element.offset(), this._refreshOffsets(t), this.originalPosition = this.position = this._generatePosition(t, !1), this.originalPageX = t.pageX, this.originalPageY = t.pageY, e.cursorAt && this._adjustOffsetFromHelper(e.cursorAt), this._setContainment(), !1 === this._trigger("start", t) ? (this._clear(), !1) : (this._cacheHelperProportions(), V.ui.ddmanager && !e.dropBehaviour && V.ui.ddmanager.prepareOffsets(this, t), this._mouseDrag(t, !0), V.ui.ddmanager && V.ui.ddmanager.dragStart(this, t), !0)
        },
        _refreshOffsets: function(t) {
            this.offset = {
                top: this.positionAbs.top - this.margins.top,
                left: this.positionAbs.left - this.margins.left,
                scroll: !1,
                parent: this._getParentOffset(),
                relative: this._getRelativeOffset()
            }, this.offset.click = {
                left: t.pageX - this.offset.left,
                top: t.pageY - this.offset.top
            }
        },
        _mouseDrag: function(t, e) {
            if (this.hasFixedAncestor && (this.offset.parent = this._getParentOffset()), this.position = this._generatePosition(t, !0), this.positionAbs = this._convertPositionTo("absolute"), !e) {
                if (e = this._uiHash(), !1 === this._trigger("drag", t, e)) return this._mouseUp(new V.Event("mouseup", t)), !1;
                this.position = e.position
            }
            return this.helper[0].style.left = this.position.left + "px", this.helper[0].style.top = this.position.top + "px", V.ui.ddmanager && V.ui.ddmanager.drag(this, t), !1
        },
        _mouseStop: function(t) {
            var e = this,
                i = !1;
            return V.ui.ddmanager && !this.options.dropBehaviour && (i = V.ui.ddmanager.drop(this, t)), this.dropped && (i = this.dropped, this.dropped = !1), "invalid" === this.options.revert && !i || "valid" === this.options.revert && i || !0 === this.options.revert || "function" == typeof this.options.revert && this.options.revert.call(this.element, i) ? V(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function() {
                !1 !== e._trigger("stop", t) && e._clear()
            }) : !1 !== this._trigger("stop", t) && this._clear(), !1
        },
        _mouseUp: function(t) {
            return this._unblockFrames(), V.ui.ddmanager && V.ui.ddmanager.dragStop(this, t), this.handleElement.is(t.target) && this.element.trigger("focus"), V.ui.mouse.prototype._mouseUp.call(this, t)
        },
        cancel: function() {
            return this.helper.is(".ui-draggable-dragging") ? this._mouseUp(new V.Event("mouseup", {
                target: this.element[0]
            })) : this._clear(), this
        },
        _getHandle: function(t) {
            return !this.options.handle || !!V(t.target).closest(this.element.find(this.options.handle)).length
        },
        _setHandleClassName: function() {
            this.handleElement = this.options.handle ? this.element.find(this.options.handle) : this.element, this._addClass(this.handleElement, "ui-draggable-handle")
        },
        _removeHandleClassName: function() {
            this._removeClass(this.handleElement, "ui-draggable-handle")
        },
        _createHelper: function(t) {
            var e = this.options,
                i = "function" == typeof e.helper;
            return (t = i ? V(e.helper.apply(this.element[0], [t])) : "clone" === e.helper ? this.element.clone().removeAttr("id") : this.element).parents("body").length || t.appendTo("parent" === e.appendTo ? this.element[0].parentNode : e.appendTo), i && t[0] === this.element[0] && this._setPositionRelative(), t[0] === this.element[0] || /(fixed|absolute)/.test(t.css("position")) || t.css("position", "absolute"), t
        },
        _setPositionRelative: function() {
            /^(?:r|a|f)/.test(this.element.css("position")) || (this.element[0].style.position = "relative")
        },
        _adjustOffsetFromHelper: function(t) {
            "string" == typeof t && (t = t.split(" ")), "left" in (t = Array.isArray(t) ? {
                left: +t[0],
                top: +t[1] || 0
            } : t) && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
        },
        _isRootNode: function(t) {
            return /(html|body)/i.test(t.tagName) || t === this.document[0]
        },
        _getParentOffset: function() {
            var t = this.offsetParent.offset(),
                e = this.document[0];
            return "absolute" === this.cssPosition && this.scrollParent[0] !== e && V.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop()), {
                top: (t = this._isRootNode(this.offsetParent[0]) ? {
                    top: 0,
                    left: 0
                } : t).top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
            }
        },
        _getRelativeOffset: function() {
            var t, e;
            return "relative" !== this.cssPosition ? {
                top: 0,
                left: 0
            } : (t = this.element.position(), e = this._isRootNode(this.scrollParent[0]), {
                top: t.top - (parseInt(this.helper.css("top"), 10) || 0) + (e ? 0 : this.scrollParent.scrollTop()),
                left: t.left - (parseInt(this.helper.css("left"), 10) || 0) + (e ? 0 : this.scrollParent.scrollLeft())
            })
        },
        _cacheMargins: function() {
            this.margins = {
                left: parseInt(this.element.css("marginLeft"), 10) || 0,
                top: parseInt(this.element.css("marginTop"), 10) || 0,
                right: parseInt(this.element.css("marginRight"), 10) || 0,
                bottom: parseInt(this.element.css("marginBottom"), 10) || 0
            }
        },
        _cacheHelperProportions: function() {
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            }
        },
        _setContainment: function() {
            var t, e, i, s = this.options,
                n = this.document[0];
            this.relativeContainer = null, s.containment ? "window" !== s.containment ? "document" !== s.containment ? s.containment.constructor !== Array ? ("parent" === s.containment && (s.containment = this.helper[0].parentNode), (i = (e = V(s.containment))[0]) && (t = /(scroll|auto)/.test(e.css("overflow")), this.containment = [(parseInt(e.css("borderLeftWidth"), 10) || 0) + (parseInt(e.css("paddingLeft"), 10) || 0), (parseInt(e.css("borderTopWidth"), 10) || 0) + (parseInt(e.css("paddingTop"), 10) || 0), (t ? Math.max(i.scrollWidth, i.offsetWidth) : i.offsetWidth) - (parseInt(e.css("borderRightWidth"), 10) || 0) - (parseInt(e.css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left - this.margins.right, (t ? Math.max(i.scrollHeight, i.offsetHeight) : i.offsetHeight) - (parseInt(e.css("borderBottomWidth"), 10) || 0) - (parseInt(e.css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top - this.margins.bottom], this.relativeContainer = e)) : this.containment = s.containment : this.containment = [0, 0, V(n).width() - this.helperProportions.width - this.margins.left, (V(n).height() || n.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top] : this.containment = [V(window).scrollLeft() - this.offset.relative.left - this.offset.parent.left, V(window).scrollTop() - this.offset.relative.top - this.offset.parent.top, V(window).scrollLeft() + V(window).width() - this.helperProportions.width - this.margins.left, V(window).scrollTop() + (V(window).height() || n.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top] : this.containment = null
        },
        _convertPositionTo: function(t, e) {
            e = e || this.position;
            var i = "absolute" === t ? 1 : -1,
                t = this._isRootNode(this.scrollParent[0]);
            return {
                top: e.top + this.offset.relative.top * i + this.offset.parent.top * i - ("fixed" === this.cssPosition ? -this.offset.scroll.top : t ? 0 : this.offset.scroll.top) * i,
                left: e.left + this.offset.relative.left * i + this.offset.parent.left * i - ("fixed" === this.cssPosition ? -this.offset.scroll.left : t ? 0 : this.offset.scroll.left) * i
            }
        },
        _generatePosition: function(t, e) {
            var i, s = this.options,
                n = this._isRootNode(this.scrollParent[0]),
                o = t.pageX,
                a = t.pageY;
            return n && this.offset.scroll || (this.offset.scroll = {
                top: this.scrollParent.scrollTop(),
                left: this.scrollParent.scrollLeft()
            }), {
                top: (a = e && (this.containment && (i = this.relativeContainer ? (i = this.relativeContainer.offset(), [this.containment[0] + i.left, this.containment[1] + i.top, this.containment[2] + i.left, this.containment[3] + i.top]) : this.containment, t.pageX - this.offset.click.left < i[0] && (o = i[0] + this.offset.click.left), t.pageY - this.offset.click.top < i[1] && (a = i[1] + this.offset.click.top), t.pageX - this.offset.click.left > i[2] && (o = i[2] + this.offset.click.left), t.pageY - this.offset.click.top > i[3]) && (a = i[3] + this.offset.click.top), s.grid && (t = s.grid[1] ? this.originalPageY + Math.round((a - this.originalPageY) / s.grid[1]) * s.grid[1] : this.originalPageY, a = !i || t - this.offset.click.top >= i[1] || t - this.offset.click.top > i[3] ? t : t - this.offset.click.top >= i[1] ? t - s.grid[1] : t + s.grid[1], t = s.grid[0] ? this.originalPageX + Math.round((o - this.originalPageX) / s.grid[0]) * s.grid[0] : this.originalPageX, o = !i || t - this.offset.click.left >= i[0] || t - this.offset.click.left > i[2] ? t : t - this.offset.click.left >= i[0] ? t - s.grid[0] : t + s.grid[0]), "y" === s.axis && (o = this.originalPageX), "x" === s.axis) ? this.originalPageY : a) - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.offset.scroll.top : n ? 0 : this.offset.scroll.top),
                left: o - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.offset.scroll.left : n ? 0 : this.offset.scroll.left)
            }
        },
        _clear: function() {
            this._removeClass(this.helper, "ui-draggable-dragging"), this.helper[0] === this.element[0] || this.cancelHelperRemoval || this.helper.remove(), this.helper = null, this.cancelHelperRemoval = !1, this.destroyOnClear && this.destroy()
        },
        _trigger: function(t, e, i) {
            return i = i || this._uiHash(), V.ui.plugin.call(this, t, [e, i, this], !0), /^(drag|start|stop)/.test(t) && (this.positionAbs = this._convertPositionTo("absolute"), i.offset = this.positionAbs), V.Widget.prototype._trigger.call(this, t, e, i)
        },
        plugins: {},
        _uiHash: function() {
            return {
                helper: this.helper,
                position: this.position,
                originalPosition: this.originalPosition,
                offset: this.positionAbs
            }
        }
    }), V.ui.plugin.add("draggable", "connectToSortable", {
        start: function(e, t, i) {
            var s = V.extend({}, t, {
                item: i.element
            });
            i.sortables = [], V(i.options.connectToSortable).each(function() {
                var t = V(this).sortable("instance");
                t && !t.options.disabled && (i.sortables.push(t), t.refreshPositions(), t._trigger("activate", e, s))
            })
        },
        stop: function(e, t, i) {
            var s = V.extend({}, t, {
                item: i.element
            });
            i.cancelHelperRemoval = !1, V.each(i.sortables, function() {
                var t = this;
                t.isOver ? (t.isOver = 0, i.cancelHelperRemoval = !0, t.cancelHelperRemoval = !1, t._storedCSS = {
                    position: t.placeholder.css("position"),
                    top: t.placeholder.css("top"),
                    left: t.placeholder.css("left")
                }, t._mouseStop(e), t.options.helper = t.options._helper) : (t.cancelHelperRemoval = !0, t._trigger("deactivate", e, s))
            })
        },
        drag: function(i, s, n) {
            V.each(n.sortables, function() {
                var t = !1,
                    e = this;
                e.positionAbs = n.positionAbs, e.helperProportions = n.helperProportions, e.offset.click = n.offset.click, e._intersectsWith(e.containerCache) && (t = !0, V.each(n.sortables, function() {
                    return this.positionAbs = n.positionAbs, this.helperProportions = n.helperProportions, this.offset.click = n.offset.click, t = (this === e || !this._intersectsWith(this.containerCache) || !V.contains(e.element[0], this.element[0])) && t
                })), t ? (e.isOver || (e.isOver = 1, n._parent = s.helper.parent(), e.currentItem = s.helper.appendTo(e.element).data("ui-sortable-item", !0), e.options._helper = e.options.helper, e.options.helper = function() {
                    return s.helper[0]
                }, i.target = e.currentItem[0], e._mouseCapture(i, !0), e._mouseStart(i, !0, !0), e.offset.click.top = n.offset.click.top, e.offset.click.left = n.offset.click.left, e.offset.parent.left -= n.offset.parent.left - e.offset.parent.left, e.offset.parent.top -= n.offset.parent.top - e.offset.parent.top, n._trigger("toSortable", i), n.dropped = e.element, V.each(n.sortables, function() {
                    this.refreshPositions()
                }), n.currentItem = n.element, e.fromOutside = n), e.currentItem && (e._mouseDrag(i), s.position = e.position)) : e.isOver && (e.isOver = 0, e.cancelHelperRemoval = !0, e.options._revert = e.options.revert, e.options.revert = !1, e._trigger("out", i, e._uiHash(e)), e._mouseStop(i, !0), e.options.revert = e.options._revert, e.options.helper = e.options._helper, e.placeholder && e.placeholder.remove(), s.helper.appendTo(n._parent), n._refreshOffsets(i), s.position = n._generatePosition(i, !0), n._trigger("fromSortable", i), n.dropped = !1, V.each(n.sortables, function() {
                    this.refreshPositions()
                }))
            })
        }
    }), V.ui.plugin.add("draggable", "cursor", {
        start: function(t, e, i) {
            var s = V("body"),
                i = i.options;
            s.css("cursor") && (i._cursor = s.css("cursor")), s.css("cursor", i.cursor)
        },
        stop: function(t, e, i) {
            (i = i.options)._cursor && V("body").css("cursor", i._cursor)
        }
    }), V.ui.plugin.add("draggable", "opacity", {
        start: function(t, e, i) {
            e = V(e.helper), i = i.options, e.css("opacity") && (i._opacity = e.css("opacity")), e.css("opacity", i.opacity)
        },
        stop: function(t, e, i) {
            (i = i.options)._opacity && V(e.helper).css("opacity", i._opacity)
        }
    }), V.ui.plugin.add("draggable", "scroll", {
        start: function(t, e, i) {
            i.scrollParentNotHidden || (i.scrollParentNotHidden = i.helper.scrollParent(!1)), i.scrollParentNotHidden[0] !== i.document[0] && "HTML" !== i.scrollParentNotHidden[0].tagName && (i.overflowOffset = i.scrollParentNotHidden.offset())
        },
        drag: function(t, e, i) {
            var s = i.options,
                n = !1,
                o = i.scrollParentNotHidden[0],
                a = i.document[0];
            o !== a && "HTML" !== o.tagName ? (s.axis && "x" === s.axis || (i.overflowOffset.top + o.offsetHeight - t.pageY < s.scrollSensitivity ? o.scrollTop = n = o.scrollTop + s.scrollSpeed : t.pageY - i.overflowOffset.top < s.scrollSensitivity && (o.scrollTop = n = o.scrollTop - s.scrollSpeed)), s.axis && "y" === s.axis || (i.overflowOffset.left + o.offsetWidth - t.pageX < s.scrollSensitivity ? o.scrollLeft = n = o.scrollLeft + s.scrollSpeed : t.pageX - i.overflowOffset.left < s.scrollSensitivity && (o.scrollLeft = n = o.scrollLeft - s.scrollSpeed))) : (s.axis && "x" === s.axis || (t.pageY - V(a).scrollTop() < s.scrollSensitivity ? n = V(a).scrollTop(V(a).scrollTop() - s.scrollSpeed) : V(window).height() - (t.pageY - V(a).scrollTop()) < s.scrollSensitivity && (n = V(a).scrollTop(V(a).scrollTop() + s.scrollSpeed))), s.axis && "y" === s.axis || (t.pageX - V(a).scrollLeft() < s.scrollSensitivity ? n = V(a).scrollLeft(V(a).scrollLeft() - s.scrollSpeed) : V(window).width() - (t.pageX - V(a).scrollLeft()) < s.scrollSensitivity && (n = V(a).scrollLeft(V(a).scrollLeft() + s.scrollSpeed)))), !1 !== n && V.ui.ddmanager && !s.dropBehaviour && V.ui.ddmanager.prepareOffsets(i, t)
        }
    }), V.ui.plugin.add("draggable", "snap", {
        start: function(t, e, i) {
            var s = i.options;
            i.snapElements = [], V(s.snap.constructor !== String ? s.snap.items || ":data(ui-draggable)" : s.snap).each(function() {
                var t = V(this),
                    e = t.offset();
                this !== i.element[0] && i.snapElements.push({
                    item: this,
                    width: t.outerWidth(),
                    height: t.outerHeight(),
                    top: e.top,
                    left: e.left
                })
            })
        },
        drag: function(t, e, i) {
            for (var s, n, o, a, r, l, h, c, u, d = i.options, p = d.snapTolerance, f = e.offset.left, m = f + i.helperProportions.width, g = e.offset.top, _ = g + i.helperProportions.height, v = i.snapElements.length - 1; 0 <= v; v--) l = (r = i.snapElements[v].left - i.margins.left) + i.snapElements[v].width, c = (h = i.snapElements[v].top - i.margins.top) + i.snapElements[v].height, m < r - p || l + p < f || _ < h - p || c + p < g || !V.contains(i.snapElements[v].item.ownerDocument, i.snapElements[v].item) ? (i.snapElements[v].snapping && i.options.snap.release && i.options.snap.release.call(i.element, t, V.extend(i._uiHash(), {
                snapItem: i.snapElements[v].item
            })), i.snapElements[v].snapping = !1) : ("inner" !== d.snapMode && (s = Math.abs(h - _) <= p, n = Math.abs(c - g) <= p, o = Math.abs(r - m) <= p, a = Math.abs(l - f) <= p, s && (e.position.top = i._convertPositionTo("relative", {
                top: h - i.helperProportions.height,
                left: 0
            }).top), n && (e.position.top = i._convertPositionTo("relative", {
                top: c,
                left: 0
            }).top), o && (e.position.left = i._convertPositionTo("relative", {
                top: 0,
                left: r - i.helperProportions.width
            }).left), a) && (e.position.left = i._convertPositionTo("relative", {
                top: 0,
                left: l
            }).left), u = s || n || o || a, "outer" !== d.snapMode && (s = Math.abs(h - g) <= p, n = Math.abs(c - _) <= p, o = Math.abs(r - f) <= p, a = Math.abs(l - m) <= p, s && (e.position.top = i._convertPositionTo("relative", {
                top: h,
                left: 0
            }).top), n && (e.position.top = i._convertPositionTo("relative", {
                top: c - i.helperProportions.height,
                left: 0
            }).top), o && (e.position.left = i._convertPositionTo("relative", {
                top: 0,
                left: r
            }).left), a) && (e.position.left = i._convertPositionTo("relative", {
                top: 0,
                left: l - i.helperProportions.width
            }).left), !i.snapElements[v].snapping && (s || n || o || a || u) && i.options.snap.snap && i.options.snap.snap.call(i.element, t, V.extend(i._uiHash(), {
                snapItem: i.snapElements[v].item
            })), i.snapElements[v].snapping = s || n || o || a || u)
        }
    }), V.ui.plugin.add("draggable", "stack", {
        start: function(t, e, i) {
            var s, i = i.options;
            (i = V.makeArray(V(i.stack)).sort(function(t, e) {
                return (parseInt(V(t).css("zIndex"), 10) || 0) - (parseInt(V(e).css("zIndex"), 10) || 0)
            })).length && (s = parseInt(V(i[0]).css("zIndex"), 10) || 0, V(i).each(function(t) {
                V(this).css("zIndex", s + t)
            }), this.css("zIndex", s + i.length))
        }
    }), V.ui.plugin.add("draggable", "zIndex", {
        start: function(t, e, i) {
            e = V(e.helper), i = i.options, e.css("zIndex") && (i._zIndex = e.css("zIndex")), e.css("zIndex", i.zIndex)
        },
        stop: function(t, e, i) {
            (i = i.options)._zIndex && V(e.helper).css("zIndex", i._zIndex)
        }
    }), V.ui.draggable, V.widget("ui.droppable", {
        version: "1.13.0",
        widgetEventPrefix: "drop",
        options: {
            accept: "*",
            addClasses: !0,
            greedy: !1,
            scope: "default",
            tolerance: "intersect",
            activate: null,
            deactivate: null,
            drop: null,
            out: null,
            over: null
        },
        _create: function() {
            var t, e = this.options,
                i = e.accept;
            this.isover = !1, this.isout = !0, this.accept = "function" == typeof i ? i : function(t) {
                return t.is(i)
            }, this.proportions = function() {
                if (!arguments.length) return t = t || {
                    width: this.element[0].offsetWidth,
                    height: this.element[0].offsetHeight
                };
                t = arguments[0]
            }, this._addToManager(e.scope), e.addClasses && this._addClass("ui-droppable")
        },
        _addToManager: function(t) {
            V.ui.ddmanager.droppables[t] = V.ui.ddmanager.droppables[t] || [], V.ui.ddmanager.droppables[t].push(this)
        },
        _splice: function(t) {
            for (var e = 0; e < t.length; e++) t[e] === this && t.splice(e, 1)
        },
        _destroy: function() {
            var t = V.ui.ddmanager.droppables[this.options.scope];
            this._splice(t)
        },
        _setOption: function(t, e) {
            var i;
            "accept" === t ? this.accept = "function" == typeof e ? e : function(t) {
                return t.is(e)
            } : "scope" === t && (i = V.ui.ddmanager.droppables[this.options.scope], this._splice(i), this._addToManager(e)), this._super(t, e)
        },
        _activate: function(t) {
            var e = V.ui.ddmanager.current;
            this._addActiveClass(), e && this._trigger("activate", t, this.ui(e))
        },
        _deactivate: function(t) {
            var e = V.ui.ddmanager.current;
            this._removeActiveClass(), e && this._trigger("deactivate", t, this.ui(e))
        },
        _over: function(t) {
            var e = V.ui.ddmanager.current;
            e && (e.currentItem || e.element)[0] !== this.element[0] && this.accept.call(this.element[0], e.currentItem || e.element) && (this._addHoverClass(), this._trigger("over", t, this.ui(e)))
        },
        _out: function(t) {
            var e = V.ui.ddmanager.current;
            e && (e.currentItem || e.element)[0] !== this.element[0] && this.accept.call(this.element[0], e.currentItem || e.element) && (this._removeHoverClass(), this._trigger("out", t, this.ui(e)))
        },
        _drop: function(e, t) {
            var i = t || V.ui.ddmanager.current,
                s = !1;
            return !(!i || (i.currentItem || i.element)[0] === this.element[0]) && (this.element.find(":data(ui-droppable)").not(".ui-draggable-dragging").each(function() {
                var t = V(this).droppable("instance");
                if (t.options.greedy && !t.options.disabled && t.options.scope === i.options.scope && t.accept.call(t.element[0], i.currentItem || i.element) && V.ui.intersect(i, V.extend(t, {
                        offset: t.element.offset()
                    }), t.options.tolerance, e)) return !(s = !0)
            }), !s) && !!this.accept.call(this.element[0], i.currentItem || i.element) && (this._removeActiveClass(), this._removeHoverClass(), this._trigger("drop", e, this.ui(i)), this.element)
        },
        ui: function(t) {
            return {
                draggable: t.currentItem || t.element,
                helper: t.helper,
                position: t.position,
                offset: t.positionAbs
            }
        },
        _addHoverClass: function() {
            this._addClass("ui-droppable-hover")
        },
        _removeHoverClass: function() {
            this._removeClass("ui-droppable-hover")
        },
        _addActiveClass: function() {
            this._addClass("ui-droppable-active")
        },
        _removeActiveClass: function() {
            this._removeClass("ui-droppable-active")
        }
    }), V.ui.intersect = function(t, e, i, s) {
        if (!e.offset) return !1;
        var n = (t.positionAbs || t.position.absolute).left + t.margins.left,
            o = (t.positionAbs || t.position.absolute).top + t.margins.top,
            a = n + t.helperProportions.width,
            r = o + t.helperProportions.height,
            l = e.offset.left,
            h = e.offset.top,
            c = l + e.proportions().width,
            u = h + e.proportions().height;
        switch (i) {
            case "fit":
                return l <= n && a <= c && h <= o && r <= u;
            case "intersect":
                return l < n + t.helperProportions.width / 2 && a - t.helperProportions.width / 2 < c && h < o + t.helperProportions.height / 2 && r - t.helperProportions.height / 2 < u;
            case "pointer":
                return $(s.pageY, h, e.proportions().height) && $(s.pageX, l, e.proportions().width);
            case "touch":
                return (h <= o && o <= u || h <= r && r <= u || o < h && u < r) && (l <= n && n <= c || l <= a && a <= c || n < l && c < a);
            default:
                return !1
        }
    }, !(V.ui.ddmanager = {
        current: null,
        droppables: {
            default: []
        },
        prepareOffsets: function(t, e) {
            var i, s, n = V.ui.ddmanager.droppables[t.options.scope] || [],
                o = e ? e.type : null,
                a = (t.currentItem || t.element).find(":data(ui-droppable)").addBack();
            t: for (i = 0; i < n.length; i++)
                if (!(n[i].options.disabled || t && !n[i].accept.call(n[i].element[0], t.currentItem || t.element))) {
                    for (s = 0; s < a.length; s++)
                        if (a[s] === n[i].element[0]) {
                            n[i].proportions().height = 0;
                            continue t
                        }
                    n[i].visible = "none" !== n[i].element.css("display"), n[i].visible && ("mousedown" === o && n[i]._activate.call(n[i], e), n[i].offset = n[i].element.offset(), n[i].proportions({
                        width: n[i].element[0].offsetWidth,
                        height: n[i].element[0].offsetHeight
                    }))
                }
        },
        drop: function(t, e) {
            var i = !1;
            return V.each((V.ui.ddmanager.droppables[t.options.scope] || []).slice(), function() {
                this.options && (!this.options.disabled && this.visible && V.ui.intersect(t, this, this.options.tolerance, e) && (i = this._drop.call(this, e) || i), !this.options.disabled) && this.visible && this.accept.call(this.element[0], t.currentItem || t.element) && (this.isout = !0, this.isover = !1, this._deactivate.call(this, e))
            }), i
        },
        dragStart: function(t, e) {
            t.element.parentsUntil("body").on("scroll.droppable", function() {
                t.options.refreshPositions || V.ui.ddmanager.prepareOffsets(t, e)
            })
        },
        drag: function(n, o) {
            n.options.refreshPositions && V.ui.ddmanager.prepareOffsets(n, o), V.each(V.ui.ddmanager.droppables[n.options.scope] || [], function() {
                var t, e, i, s;
                this.options.disabled || this.greedyChild || !this.visible || (s = !(i = V.ui.intersect(n, this, this.options.tolerance, o)) && this.isover ? "isout" : i && !this.isover ? "isover" : null) && (this.options.greedy && (e = this.options.scope, (i = this.element.parents(":data(ui-droppable)").filter(function() {
                    return V(this).droppable("instance").options.scope === e
                })).length) && ((t = V(i[0]).droppable("instance")).greedyChild = "isover" === s), t && "isover" === s && (t.isover = !1, t.isout = !0, t._out.call(t, o)), this[s] = !0, this["isout" === s ? "isover" : "isout"] = !1, this["isover" === s ? "_over" : "_out"].call(this, o), t) && "isout" === s && (t.isout = !1, t.isover = !0, t._over.call(t, o))
            })
        },
        dragStop: function(t, e) {
            t.element.parentsUntil("body").off("scroll.droppable"), t.options.refreshPositions || V.ui.ddmanager.prepareOffsets(t, e)
        }
    }) !== V.uiBackCompat && V.widget("ui.droppable", V.ui.droppable, {
        options: {
            hoverClass: !1,
            activeClass: !1
        },
        _addActiveClass: function() {
            this._super(), this.options.activeClass && this.element.addClass(this.options.activeClass)
        },
        _removeActiveClass: function() {
            this._super(), this.options.activeClass && this.element.removeClass(this.options.activeClass)
        },
        _addHoverClass: function() {
            this._super(), this.options.hoverClass && this.element.addClass(this.options.hoverClass)
        },
        _removeHoverClass: function() {
            this._super(), this.options.hoverClass && this.element.removeClass(this.options.hoverClass)
        }
    }), V.ui.droppable, V.widget("ui.resizable", V.ui.mouse, {
        version: "1.13.0",
        widgetEventPrefix: "resize",
        options: {
            alsoResize: !1,
            animate: !1,
            animateDuration: "slow",
            animateEasing: "swing",
            aspectRatio: !1,
            autoHide: !1,
            classes: {
                "ui-resizable-se": "ui-icon ui-icon-gripsmall-diagonal-se"
            },
            containment: !1,
            ghost: !1,
            grid: !1,
            handles: "e,s,se",
            helper: !1,
            maxHeight: null,
            maxWidth: null,
            minHeight: 10,
            minWidth: 10,
            zIndex: 90,
            resize: null,
            start: null,
            stop: null
        },
        _num: function(t) {
            return parseFloat(t) || 0
        },
        _isNumber: function(t) {
            return !isNaN(parseFloat(t))
        },
        _hasScroll: function(t, e) {
            if ("hidden" === V(t).css("overflow")) return !1;
            var i = e && "left" === e ? "scrollLeft" : "scrollTop",
                e = !1;
            if (0 < t[i]) return !0;
            try {
                t[i] = 1, e = 0 < t[i], t[i] = 0
            } catch (t) {}
            return e
        },
        _create: function() {
            var t, e = this.options,
                i = this;
            this._addClass("ui-resizable"), V.extend(this, {
                _aspectRatio: !!e.aspectRatio,
                aspectRatio: e.aspectRatio,
                originalElement: this.element,
                _proportionallyResizeElements: [],
                _helper: e.helper || e.ghost || e.animate ? e.helper || "ui-resizable-helper" : null
            }), this.element[0].nodeName.match(/^(canvas|textarea|input|select|button|img)$/i) && (this.element.wrap(V("<div class='ui-wrapper'></div>").css({
                overflow: "hidden",
                position: this.element.css("position"),
                width: this.element.outerWidth(),
                height: this.element.outerHeight(),
                top: this.element.css("top"),
                left: this.element.css("left")
            })), this.element = this.element.parent().data("ui-resizable", this.element.resizable("instance")), this.elementIsWrapper = !0, t = {
                marginTop: this.originalElement.css("marginTop"),
                marginRight: this.originalElement.css("marginRight"),
                marginBottom: this.originalElement.css("marginBottom"),
                marginLeft: this.originalElement.css("marginLeft")
            }, this.element.css(t), this.originalElement.css("margin", 0), this.originalResizeStyle = this.originalElement.css("resize"), this.originalElement.css("resize", "none"), this._proportionallyResizeElements.push(this.originalElement.css({
                position: "static",
                zoom: 1,
                display: "block"
            })), this.originalElement.css(t), this._proportionallyResize()), this._setupHandles(), e.autoHide && V(this.element).on("mouseenter", function() {
                e.disabled || (i._removeClass("ui-resizable-autohide"), i._handles.show())
            }).on("mouseleave", function() {
                e.disabled || i.resizing || (i._addClass("ui-resizable-autohide"), i._handles.hide())
            }), this._mouseInit()
        },
        _destroy: function() {
            function t(t) {
                V(t).removeData("resizable").removeData("ui-resizable").off(".resizable")
            }
            var e;
            return this._mouseDestroy(), this._addedHandles.remove(), this.elementIsWrapper && (t(this.element), e = this.element, this.originalElement.css({
                position: e.css("position"),
                width: e.outerWidth(),
                height: e.outerHeight(),
                top: e.css("top"),
                left: e.css("left")
            }).insertAfter(e), e.remove()), this.originalElement.css("resize", this.originalResizeStyle), t(this.originalElement), this
        },
        _setOption: function(t, e) {
            switch (this._super(t, e), t) {
                case "handles":
                    this._removeHandles(), this._setupHandles();
                    break;
                case "aspectRatio":
                    this._aspectRatio = !!e
            }
        },
        _setupHandles: function() {
            var t, e, i, s, n, o = this.options,
                a = this;
            if (this.handles = o.handles || (V(".ui-resizable-handle", this.element).length ? {
                    n: ".ui-resizable-n",
                    e: ".ui-resizable-e",
                    s: ".ui-resizable-s",
                    w: ".ui-resizable-w",
                    se: ".ui-resizable-se",
                    sw: ".ui-resizable-sw",
                    ne: ".ui-resizable-ne",
                    nw: ".ui-resizable-nw"
                } : "e,s,se"), this._handles = V(), this._addedHandles = V(), this.handles.constructor === String)
                for ("all" === this.handles && (this.handles = "n,e,s,w,se,sw,ne,nw"), i = this.handles.split(","), this.handles = {}, e = 0; e < i.length; e++) s = "ui-resizable-" + (t = String.prototype.trim.call(i[e])), n = V("<div>"), this._addClass(n, "ui-resizable-handle " + s), n.css({
                    zIndex: o.zIndex
                }), this.handles[t] = ".ui-resizable-" + t, this.element.children(this.handles[t]).length || (this.element.append(n), this._addedHandles = this._addedHandles.add(n));
            this._renderAxis = function(t) {
                var e, i, s;
                for (e in t = t || this.element, this.handles) this.handles[e].constructor === String ? this.handles[e] = this.element.children(this.handles[e]).first().show() : (this.handles[e].jquery || this.handles[e].nodeType) && (this.handles[e] = V(this.handles[e]), this._on(this.handles[e], {
                    mousedown: a._mouseDown
                })), this.elementIsWrapper && this.originalElement[0].nodeName.match(/^(textarea|input|select|button)$/i) && (i = V(this.handles[e], this.element), s = /sw|ne|nw|se|n|s/.test(e) ? i.outerHeight() : i.outerWidth(), i = ["padding", /ne|nw|n/.test(e) ? "Top" : /se|sw|s/.test(e) ? "Bottom" : /^e$/.test(e) ? "Right" : "Left"].join(""), t.css(i, s), this._proportionallyResize()), this._handles = this._handles.add(this.handles[e])
            }, this._renderAxis(this.element), this._handles = this._handles.add(this.element.find(".ui-resizable-handle")), this._handles.disableSelection(), this._handles.on("mouseover", function() {
                a.resizing || (this.className && (n = this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)), a.axis = n && n[1] ? n[1] : "se")
            }), o.autoHide && (this._handles.hide(), this._addClass("ui-resizable-autohide"))
        },
        _removeHandles: function() {
            this._addedHandles.remove()
        },
        _mouseCapture: function(t) {
            var e, i, s = !1;
            for (e in this.handles)(i = V(this.handles[e])[0]) !== t.target && !V.contains(i, t.target) || (s = !0);
            return !this.options.disabled && s
        },
        _mouseStart: function(t) {
            var e, i, s = this.options,
                n = this.element;
            return this.resizing = !0, this._renderProxy(), e = this._num(this.helper.css("left")), i = this._num(this.helper.css("top")), s.containment && (e += V(s.containment).scrollLeft() || 0, i += V(s.containment).scrollTop() || 0), this.offset = this.helper.offset(), this.position = {
                left: e,
                top: i
            }, this.size = this._helper ? {
                width: this.helper.width(),
                height: this.helper.height()
            } : {
                width: n.width(),
                height: n.height()
            }, this.originalSize = this._helper ? {
                width: n.outerWidth(),
                height: n.outerHeight()
            } : {
                width: n.width(),
                height: n.height()
            }, this.sizeDiff = {
                width: n.outerWidth() - n.width(),
                height: n.outerHeight() - n.height()
            }, this.originalPosition = {
                left: e,
                top: i
            }, this.originalMousePosition = {
                left: t.pageX,
                top: t.pageY
            }, this.aspectRatio = "number" == typeof s.aspectRatio ? s.aspectRatio : this.originalSize.width / this.originalSize.height || 1, s = V(".ui-resizable-" + this.axis).css("cursor"), V("body").css("cursor", "auto" === s ? this.axis + "-resize" : s), this._addClass("ui-resizable-resizing"), this._propagate("start", t), !0
        },
        _mouseDrag: function(t) {
            var e = this.originalMousePosition,
                i = this.axis,
                s = t.pageX - e.left || 0,
                e = t.pageY - e.top || 0,
                i = this._change[i];
            return this._updatePrevProperties(), i && (e = i.apply(this, [t, s, e]), this._updateVirtualBoundaries(t.shiftKey), (this._aspectRatio || t.shiftKey) && (e = this._updateRatio(e, t)), e = this._respectSize(e, t), this._updateCache(e), this._propagate("resize", t), e = this._applyChanges(), !this._helper && this._proportionallyResizeElements.length && this._proportionallyResize(), V.isEmptyObject(e) || (this._updatePrevProperties(), this._trigger("resize", t, this.ui()), this._applyChanges())), !1
        },
        _mouseStop: function(t) {
            this.resizing = !1;
            var e, i, s, n = this.options,
                o = this;
            return this._helper && (s = (e = (i = this._proportionallyResizeElements).length && /textarea/i.test(i[0].nodeName)) && this._hasScroll(i[0], "left") ? 0 : o.sizeDiff.height, i = e ? 0 : o.sizeDiff.width, e = {
                width: o.helper.width() - i,
                height: o.helper.height() - s
            }, i = parseFloat(o.element.css("left")) + (o.position.left - o.originalPosition.left) || null, s = parseFloat(o.element.css("top")) + (o.position.top - o.originalPosition.top) || null, n.animate || this.element.css(V.extend(e, {
                top: s,
                left: i
            })), o.helper.height(o.size.height), o.helper.width(o.size.width), this._helper) && !n.animate && this._proportionallyResize(), V("body").css("cursor", "auto"), this._removeClass("ui-resizable-resizing"), this._propagate("stop", t), this._helper && this.helper.remove(), !1
        },
        _updatePrevProperties: function() {
            this.prevPosition = {
                top: this.position.top,
                left: this.position.left
            }, this.prevSize = {
                width: this.size.width,
                height: this.size.height
            }
        },
        _applyChanges: function() {
            var t = {};
            return this.position.top !== this.prevPosition.top && (t.top = this.position.top + "px"), this.position.left !== this.prevPosition.left && (t.left = this.position.left + "px"), this.size.width !== this.prevSize.width && (t.width = this.size.width + "px"), this.size.height !== this.prevSize.height && (t.height = this.size.height + "px"), this.helper.css(t), t
        },
        _updateVirtualBoundaries: function(t) {
            var e, i, s = this.options,
                n = {
                    minWidth: this._isNumber(s.minWidth) ? s.minWidth : 0,
                    maxWidth: this._isNumber(s.maxWidth) ? s.maxWidth : 1 / 0,
                    minHeight: this._isNumber(s.minHeight) ? s.minHeight : 0,
                    maxHeight: this._isNumber(s.maxHeight) ? s.maxHeight : 1 / 0
                };
            (this._aspectRatio || t) && (e = n.minHeight * this.aspectRatio, i = n.minWidth / this.aspectRatio, s = n.maxHeight * this.aspectRatio, t = n.maxWidth / this.aspectRatio, n.minWidth < e && (n.minWidth = e), n.minHeight < i && (n.minHeight = i), s < n.maxWidth && (n.maxWidth = s), t < n.maxHeight) && (n.maxHeight = t), this._vBoundaries = n
        },
        _updateCache: function(t) {
            this.offset = this.helper.offset(), this._isNumber(t.left) && (this.position.left = t.left), this._isNumber(t.top) && (this.position.top = t.top), this._isNumber(t.height) && (this.size.height = t.height), this._isNumber(t.width) && (this.size.width = t.width)
        },
        _updateRatio: function(t) {
            var e = this.position,
                i = this.size,
                s = this.axis;
            return this._isNumber(t.height) ? t.width = t.height * this.aspectRatio : this._isNumber(t.width) && (t.height = t.width / this.aspectRatio), "sw" === s && (t.left = e.left + (i.width - t.width), t.top = null), "nw" === s && (t.top = e.top + (i.height - t.height), t.left = e.left + (i.width - t.width)), t
        },
        _respectSize: function(t) {
            var e = this._vBoundaries,
                i = this.axis,
                s = this._isNumber(t.width) && e.maxWidth && e.maxWidth < t.width,
                n = this._isNumber(t.height) && e.maxHeight && e.maxHeight < t.height,
                o = this._isNumber(t.width) && e.minWidth && e.minWidth > t.width,
                a = this._isNumber(t.height) && e.minHeight && e.minHeight > t.height,
                r = this.originalPosition.left + this.originalSize.width,
                l = this.originalPosition.top + this.originalSize.height,
                h = /sw|nw|w/.test(i),
                i = /nw|ne|n/.test(i);
            return o && (t.width = e.minWidth), a && (t.height = e.minHeight), s && (t.width = e.maxWidth), n && (t.height = e.maxHeight), o && h && (t.left = r - e.minWidth), s && h && (t.left = r - e.maxWidth), a && i && (t.top = l - e.minHeight), n && i && (t.top = l - e.maxHeight), t.width || t.height || t.left || !t.top ? t.width || t.height || t.top || !t.left || (t.left = null) : t.top = null, t
        },
        _getPaddingPlusBorderDimensions: function(t) {
            for (var e = 0, i = [], s = [t.css("borderTopWidth"), t.css("borderRightWidth"), t.css("borderBottomWidth"), t.css("borderLeftWidth")], n = [t.css("paddingTop"), t.css("paddingRight"), t.css("paddingBottom"), t.css("paddingLeft")]; e < 4; e++) i[e] = parseFloat(s[e]) || 0, i[e] += parseFloat(n[e]) || 0;
            return {
                height: i[0] + i[2],
                width: i[1] + i[3]
            }
        },
        _proportionallyResize: function() {
            if (this._proportionallyResizeElements.length)
                for (var t, e = 0, i = this.helper || this.element; e < this._proportionallyResizeElements.length; e++) t = this._proportionallyResizeElements[e], this.outerDimensions || (this.outerDimensions = this._getPaddingPlusBorderDimensions(t)), t.css({
                    height: i.height() - this.outerDimensions.height || 0,
                    width: i.width() - this.outerDimensions.width || 0
                })
        },
        _renderProxy: function() {
            var t = this.element,
                e = this.options;
            this.elementOffset = t.offset(), this._helper ? (this.helper = this.helper || V("<div></div>").css({
                overflow: "hidden"
            }), this._addClass(this.helper, this._helper), this.helper.css({
                width: this.element.outerWidth(),
                height: this.element.outerHeight(),
                position: "absolute",
                left: this.elementOffset.left + "px",
                top: this.elementOffset.top + "px",
                zIndex: ++e.zIndex
            }), this.helper.appendTo("body").disableSelection()) : this.helper = this.element
        },
        _change: {
            e: function(t, e) {
                return {
                    width: this.originalSize.width + e
                }
            },
            w: function(t, e) {
                var i = this.originalSize;
                return {
                    left: this.originalPosition.left + e,
                    width: i.width - e
                }
            },
            n: function(t, e, i) {
                var s = this.originalSize;
                return {
                    top: this.originalPosition.top + i,
                    height: s.height - i
                }
            },
            s: function(t, e, i) {
                return {
                    height: this.originalSize.height + i
                }
            },
            se: function(t, e, i) {
                return V.extend(this._change.s.apply(this, arguments), this._change.e.apply(this, [t, e, i]))
            },
            sw: function(t, e, i) {
                return V.extend(this._change.s.apply(this, arguments), this._change.w.apply(this, [t, e, i]))
            },
            ne: function(t, e, i) {
                return V.extend(this._change.n.apply(this, arguments), this._change.e.apply(this, [t, e, i]))
            },
            nw: function(t, e, i) {
                return V.extend(this._change.n.apply(this, arguments), this._change.w.apply(this, [t, e, i]))
            }
        },
        _propagate: function(t, e) {
            V.ui.plugin.call(this, t, [e, this.ui()]), "resize" !== t && this._trigger(t, e, this.ui())
        },
        plugins: {},
        ui: function() {
            return {
                originalElement: this.originalElement,
                element: this.element,
                helper: this.helper,
                position: this.position,
                size: this.size,
                originalSize: this.originalSize,
                originalPosition: this.originalPosition
            }
        }
    }), V.ui.plugin.add("resizable", "animate", {
        stop: function(e) {
            var i = V(this).resizable("instance"),
                t = i.options,
                s = i._proportionallyResizeElements,
                n = (a = s.length && /textarea/i.test(s[0].nodeName)) && i._hasScroll(s[0], "left") ? 0 : i.sizeDiff.height,
                o = a ? 0 : i.sizeDiff.width,
                a = {
                    width: i.size.width - o,
                    height: i.size.height - n
                },
                o = parseFloat(i.element.css("left")) + (i.position.left - i.originalPosition.left) || null,
                n = parseFloat(i.element.css("top")) + (i.position.top - i.originalPosition.top) || null;
            i.element.animate(V.extend(a, n && o ? {
                top: n,
                left: o
            } : {}), {
                duration: t.animateDuration,
                easing: t.animateEasing,
                step: function() {
                    var t = {
                        width: parseFloat(i.element.css("width")),
                        height: parseFloat(i.element.css("height")),
                        top: parseFloat(i.element.css("top")),
                        left: parseFloat(i.element.css("left"))
                    };
                    s && s.length && V(s[0]).css({
                        width: t.width,
                        height: t.height
                    }), i._updateCache(t), i._propagate("resize", e)
                }
            })
        }
    }), V.ui.plugin.add("resizable", "containment", {
        start: function() {
            var i, s, n = V(this).resizable("instance"),
                t = n.options,
                e = n.element,
                o = t.containment,
                a = o instanceof V ? o.get(0) : /parent/.test(o) ? e.parent().get(0) : o;
            a && (n.containerElement = V(a), /document/.test(o) || o === document ? (n.containerOffset = {
                left: 0,
                top: 0
            }, n.containerPosition = {
                left: 0,
                top: 0
            }, n.parentData = {
                element: V(document),
                left: 0,
                top: 0,
                width: V(document).width(),
                height: V(document).height() || document.body.parentNode.scrollHeight
            }) : (i = V(a), s = [], V(["Top", "Right", "Left", "Bottom"]).each(function(t, e) {
                s[t] = n._num(i.css("padding" + e))
            }), n.containerOffset = i.offset(), n.containerPosition = i.position(), n.containerSize = {
                height: i.innerHeight() - s[3],
                width: i.innerWidth() - s[1]
            }, t = n.containerOffset, e = n.containerSize.height, o = n.containerSize.width, o = n._hasScroll(a, "left") ? a.scrollWidth : o, e = n._hasScroll(a) ? a.scrollHeight : e, n.parentData = {
                element: a,
                left: t.left,
                top: t.top,
                width: o,
                height: e
            }))
        },
        resize: function(t) {
            var e = V(this).resizable("instance"),
                i = e.options,
                s = e.containerOffset,
                n = e.position,
                o = e._aspectRatio || t.shiftKey,
                a = {
                    top: 0,
                    left: 0
                },
                r = e.containerElement,
                t = !0;
            r[0] !== document && /static/.test(r.css("position")) && (a = s), n.left < (e._helper ? s.left : 0) && (e.size.width = e.size.width + (e._helper ? e.position.left - s.left : e.position.left - a.left), o && (e.size.height = e.size.width / e.aspectRatio, t = !1), e.position.left = i.helper ? s.left : 0), n.top < (e._helper ? s.top : 0) && (e.size.height = e.size.height + (e._helper ? e.position.top - s.top : e.position.top), o && (e.size.width = e.size.height * e.aspectRatio, t = !1), e.position.top = e._helper ? s.top : 0), i = e.containerElement.get(0) === e.element.parent().get(0), n = /relative|absolute/.test(e.containerElement.css("position")), i && n ? (e.offset.left = e.parentData.left + e.position.left, e.offset.top = e.parentData.top + e.position.top) : (e.offset.left = e.element.offset().left, e.offset.top = e.element.offset().top), n = Math.abs(e.sizeDiff.width + (e._helper ? e.offset.left - a.left : e.offset.left - s.left)), s = Math.abs(e.sizeDiff.height + (e._helper ? e.offset.top - a.top : e.offset.top - s.top)), n + e.size.width >= e.parentData.width && (e.size.width = e.parentData.width - n, o) && (e.size.height = e.size.width / e.aspectRatio, t = !1), s + e.size.height >= e.parentData.height && (e.size.height = e.parentData.height - s, o) && (e.size.width = e.size.height * e.aspectRatio, t = !1), t || (e.position.left = e.prevPosition.left, e.position.top = e.prevPosition.top, e.size.width = e.prevSize.width, e.size.height = e.prevSize.height)
        },
        stop: function() {
            var t = V(this).resizable("instance"),
                e = t.options,
                i = t.containerOffset,
                s = t.containerPosition,
                n = t.containerElement,
                o = (r = V(t.helper)).offset(),
                a = r.outerWidth() - t.sizeDiff.width,
                r = r.outerHeight() - t.sizeDiff.height;
            t._helper && !e.animate && /relative/.test(n.css("position")) && V(this).css({
                left: o.left - s.left - i.left,
                width: a,
                height: r
            }), t._helper && !e.animate && /static/.test(n.css("position")) && V(this).css({
                left: o.left - s.left - i.left,
                width: a,
                height: r
            })
        }
    }), V.ui.plugin.add("resizable", "alsoResize", {
        start: function() {
            var t = V(this).resizable("instance").options;
            V(t.alsoResize).each(function() {
                var t = V(this);
                t.data("ui-resizable-alsoresize", {
                    width: parseFloat(t.width()),
                    height: parseFloat(t.height()),
                    left: parseFloat(t.css("left")),
                    top: parseFloat(t.css("top"))
                })
            })
        },
        resize: function(t, i) {
            var e = V(this).resizable("instance"),
                s = e.options,
                n = e.originalSize,
                o = e.originalPosition,
                a = {
                    height: e.size.height - n.height || 0,
                    width: e.size.width - n.width || 0,
                    top: e.position.top - o.top || 0,
                    left: e.position.left - o.left || 0
                };
            V(s.alsoResize).each(function() {
                var t = V(this),
                    s = V(this).data("ui-resizable-alsoresize"),
                    n = {},
                    e = t.parents(i.originalElement[0]).length ? ["width", "height"] : ["width", "height", "top", "left"];
                V.each(e, function(t, e) {
                    var i = (s[e] || 0) + (a[e] || 0);
                    i && 0 <= i && (n[e] = i || null)
                }), t.css(n)
            })
        },
        stop: function() {
            V(this).removeData("ui-resizable-alsoresize")
        }
    }), V.ui.plugin.add("resizable", "ghost", {
        start: function() {
            var t = V(this).resizable("instance"),
                e = t.size;
            t.ghost = t.originalElement.clone(), t.ghost.css({
                opacity: .25,
                display: "block",
                position: "relative",
                height: e.height,
                width: e.width,
                margin: 0,
                left: 0,
                top: 0
            }), t._addClass(t.ghost, "ui-resizable-ghost"), !1 !== V.uiBackCompat && "string" == typeof t.options.ghost && t.ghost.addClass(this.options.ghost), t.ghost.appendTo(t.helper)
        },
        resize: function() {
            var t = V(this).resizable("instance");
            t.ghost && t.ghost.css({
                position: "relative",
                height: t.size.height,
                width: t.size.width
            })
        },
        stop: function() {
            var t = V(this).resizable("instance");
            t.ghost && t.helper && t.helper.get(0).removeChild(t.ghost.get(0))
        }
    }), V.ui.plugin.add("resizable", "grid", {
        resize: function() {
            var t, e = V(this).resizable("instance"),
                i = e.options,
                s = e.size,
                n = e.originalSize,
                o = e.originalPosition,
                a = e.axis,
                r = "number" == typeof i.grid ? [i.grid, i.grid] : i.grid,
                l = r[0] || 1,
                h = r[1] || 1,
                c = Math.round((s.width - n.width) / l) * l,
                u = Math.round((s.height - n.height) / h) * h,
                d = n.width + c,
                p = n.height + u,
                f = i.maxWidth && i.maxWidth < d,
                m = i.maxHeight && i.maxHeight < p,
                g = i.minWidth && i.minWidth > d,
                s = i.minHeight && i.minHeight > p;
            i.grid = r, g && (d += l), s && (p += h), f && (d -= l), m && (p -= h), /^(se|s|e)$/.test(a) ? (e.size.width = d, e.size.height = p) : /^(ne)$/.test(a) ? (e.size.width = d, e.size.height = p, e.position.top = o.top - u) : /^(sw)$/.test(a) ? (e.size.width = d, e.size.height = p, e.position.left = o.left - c) : ((p - h <= 0 || d - l <= 0) && (t = e._getPaddingPlusBorderDimensions(this)), 0 < p - h ? (e.size.height = p, e.position.top = o.top - u) : (p = h - t.height, e.size.height = p, e.position.top = o.top + n.height - p), 0 < d - l ? (e.size.width = d, e.position.left = o.left - c) : (d = l - t.width, e.size.width = d, e.position.left = o.left + n.width - d))
        }
    }), V.ui.resizable, V.widget("ui.selectable", V.ui.mouse, {
        version: "1.13.0",
        options: {
            appendTo: "body",
            autoRefresh: !0,
            distance: 0,
            filter: "*",
            tolerance: "touch",
            selected: null,
            selecting: null,
            start: null,
            stop: null,
            unselected: null,
            unselecting: null
        },
        _create: function() {
            var i = this;
            this._addClass("ui-selectable"), this.dragged = !1, this.refresh = function() {
                i.elementPos = V(i.element[0]).offset(), i.selectees = V(i.options.filter, i.element[0]), i._addClass(i.selectees, "ui-selectee"), i.selectees.each(function() {
                    var t = V(this),
                        e = {
                            left: (e = t.offset()).left - i.elementPos.left,
                            top: e.top - i.elementPos.top
                        };
                    V.data(this, "selectable-item", {
                        element: this,
                        $element: t,
                        left: e.left,
                        top: e.top,
                        right: e.left + t.outerWidth(),
                        bottom: e.top + t.outerHeight(),
                        startselected: !1,
                        selected: t.hasClass("ui-selected"),
                        selecting: t.hasClass("ui-selecting"),
                        unselecting: t.hasClass("ui-unselecting")
                    })
                })
            }, this.refresh(), this._mouseInit(), this.helper = V("<div>"), this._addClass(this.helper, "ui-selectable-helper")
        },
        _destroy: function() {
            this.selectees.removeData("selectable-item"), this._mouseDestroy()
        },
        _mouseStart: function(i) {
            var s = this,
                t = this.options;
            this.opos = [i.pageX, i.pageY], this.elementPos = V(this.element[0]).offset(), this.options.disabled || (this.selectees = V(t.filter, this.element[0]), this._trigger("start", i), V(t.appendTo).append(this.helper), this.helper.css({
                left: i.pageX,
                top: i.pageY,
                width: 0,
                height: 0
            }), t.autoRefresh && this.refresh(), this.selectees.filter(".ui-selected").each(function() {
                var t = V.data(this, "selectable-item");
                t.startselected = !0, i.metaKey || i.ctrlKey || (s._removeClass(t.$element, "ui-selected"), t.selected = !1, s._addClass(t.$element, "ui-unselecting"), t.unselecting = !0, s._trigger("unselecting", i, {
                    unselecting: t.element
                }))
            }), V(i.target).parents().addBack().each(function() {
                var t, e = V.data(this, "selectable-item");
                if (e) return t = !i.metaKey && !i.ctrlKey || !e.$element.hasClass("ui-selected"), s._removeClass(e.$element, t ? "ui-unselecting" : "ui-selected")._addClass(e.$element, t ? "ui-selecting" : "ui-unselecting"), e.unselecting = !t, e.selecting = t, (e.selected = t) ? s._trigger("selecting", i, {
                    selecting: e.element
                }) : s._trigger("unselecting", i, {
                    unselecting: e.element
                }), !1
            }))
        },
        _mouseDrag: function(s) {
            var t, n, o, a, r, l, h;
            if (this.dragged = !0, !this.options.disabled) return o = (n = this).options, a = this.opos[0], r = this.opos[1], l = s.pageX, h = s.pageY, l < a && (t = l, l = a, a = t), h < r && (t = h, h = r, r = t), this.helper.css({
                left: a,
                top: r,
                width: l - a,
                height: h - r
            }), this.selectees.each(function() {
                var t = V.data(this, "selectable-item"),
                    e = !1,
                    i = {};
                t && t.element !== n.element[0] && (i.left = t.left + n.elementPos.left, i.right = t.right + n.elementPos.left, i.top = t.top + n.elementPos.top, i.bottom = t.bottom + n.elementPos.top, "touch" === o.tolerance ? e = !(l < i.left || i.right < a || h < i.top || i.bottom < r) : "fit" === o.tolerance && (e = a < i.left && i.right < l && r < i.top && i.bottom < h), e ? (t.selected && (n._removeClass(t.$element, "ui-selected"), t.selected = !1), t.unselecting && (n._removeClass(t.$element, "ui-unselecting"), t.unselecting = !1), t.selecting || (n._addClass(t.$element, "ui-selecting"), t.selecting = !0, n._trigger("selecting", s, {
                    selecting: t.element
                }))) : (t.selecting && ((s.metaKey || s.ctrlKey) && t.startselected ? (n._removeClass(t.$element, "ui-selecting"), t.selecting = !1, n._addClass(t.$element, "ui-selected"), t.selected = !0) : (n._removeClass(t.$element, "ui-selecting"), t.selecting = !1, t.startselected && (n._addClass(t.$element, "ui-unselecting"), t.unselecting = !0), n._trigger("unselecting", s, {
                    unselecting: t.element
                }))), !t.selected || s.metaKey || s.ctrlKey || t.startselected || (n._removeClass(t.$element, "ui-selected"), t.selected = !1, n._addClass(t.$element, "ui-unselecting"), t.unselecting = !0, n._trigger("unselecting", s, {
                    unselecting: t.element
                }))))
            }), !1
        },
        _mouseStop: function(e) {
            var i = this;
            return this.dragged = !1, V(".ui-unselecting", this.element[0]).each(function() {
                var t = V.data(this, "selectable-item");
                i._removeClass(t.$element, "ui-unselecting"), t.unselecting = !1, t.startselected = !1, i._trigger("unselected", e, {
                    unselected: t.element
                })
            }), V(".ui-selecting", this.element[0]).each(function() {
                var t = V.data(this, "selectable-item");
                i._removeClass(t.$element, "ui-selecting")._addClass(t.$element, "ui-selected"), t.selecting = !1, t.selected = !0, t.startselected = !0, i._trigger("selected", e, {
                    selected: t.element
                })
            }), this._trigger("stop", e), this.helper.remove(), !1
        }
    }), V.widget("ui.sortable", V.ui.mouse, {
        version: "1.13.0",
        widgetEventPrefix: "sort",
        ready: !1,
        options: {
            appendTo: "parent",
            axis: !1,
            connectWith: !1,
            containment: !1,
            cursor: "auto",
            cursorAt: !1,
            dropOnEmpty: !0,
            forcePlaceholderSize: !1,
            forceHelperSize: !1,
            grid: !1,
            handle: !1,
            helper: "original",
            items: "> *",
            opacity: !1,
            placeholder: !1,
            revert: !1,
            scroll: !0,
            scrollSensitivity: 20,
            scrollSpeed: 20,
            scope: "default",
            tolerance: "intersect",
            zIndex: 1e3,
            activate: null,
            beforeStop: null,
            change: null,
            deactivate: null,
            out: null,
            over: null,
            receive: null,
            remove: null,
            sort: null,
            start: null,
            stop: null,
            update: null
        },
        _isOverAxis: function(t, e, i) {
            return e <= t && t < e + i
        },
        _isFloating: function(t) {
            return /left|right/.test(t.css("float")) || /inline|table-cell/.test(t.css("display"))
        },
        _create: function() {
            this.containerCache = {}, this._addClass("ui-sortable"), this.refresh(), this.offset = this.element.offset(), this._mouseInit(), this._setHandleClassName(), this.ready = !0
        },
        _setOption: function(t, e) {
            this._super(t, e), "handle" === t && this._setHandleClassName()
        },
        _setHandleClassName: function() {
            var t = this;
            this._removeClass(this.element.find(".ui-sortable-handle"), "ui-sortable-handle"), V.each(this.items, function() {
                t._addClass(this.instance.options.handle ? this.item.find(this.instance.options.handle) : this.item, "ui-sortable-handle")
            })
        },
        _destroy: function() {
            this._mouseDestroy();
            for (var t = this.items.length - 1; 0 <= t; t--) this.items[t].item.removeData(this.widgetName + "-item");
            return this
        },
        _mouseCapture: function(t, e) {
            var i = null,
                s = !1,
                n = this;
            return !(this.reverting || this.options.disabled || "static" === this.options.type || (this._refreshItems(t), V(t.target).parents().each(function() {
                if (V.data(this, n.widgetName + "-item") === n) return i = V(this), !1
            }), !(i = V.data(t.target, n.widgetName + "-item") === n ? V(t.target) : i)) || this.options.handle && !e && (V(this.options.handle, i).find("*").addBack().each(function() {
                this === t.target && (s = !0)
            }), !s) || (this.currentItem = i, this._removeCurrentsFromItems(), 0))
        },
        _mouseStart: function(t, e, i) {
            var s, n, o = this.options;
            if ((this.currentContainer = this).refreshPositions(), this.appendTo = V("parent" !== o.appendTo ? o.appendTo : this.currentItem.parent()), this.helper = this._createHelper(t), this._cacheHelperProportions(), this._cacheMargins(), this.offset = this.currentItem.offset(), this.offset = {
                    top: this.offset.top - this.margins.top,
                    left: this.offset.left - this.margins.left
                }, V.extend(this.offset, {
                    click: {
                        left: t.pageX - this.offset.left,
                        top: t.pageY - this.offset.top
                    },
                    relative: this._getRelativeOffset()
                }), this.helper.css("position", "absolute"), this.cssPosition = this.helper.css("position"), o.cursorAt && this._adjustOffsetFromHelper(o.cursorAt), this.domPosition = {
                    prev: this.currentItem.prev()[0],
                    parent: this.currentItem.parent()[0]
                }, this.helper[0] !== this.currentItem[0] && this.currentItem.hide(), this._createPlaceholder(), this.scrollParent = this.placeholder.scrollParent(), V.extend(this.offset, {
                    parent: this._getParentOffset()
                }), o.containment && this._setContainment(), o.cursor && "auto" !== o.cursor && (n = this.document.find("body"), this.storedCursor = n.css("cursor"), n.css("cursor", o.cursor), this.storedStylesheet = V("<style>*{ cursor: " + o.cursor + " !important; }</style>").appendTo(n)), o.zIndex && (this.helper.css("zIndex") && (this._storedZIndex = this.helper.css("zIndex")), this.helper.css("zIndex", o.zIndex)), o.opacity && (this.helper.css("opacity") && (this._storedOpacity = this.helper.css("opacity")), this.helper.css("opacity", o.opacity)), this.scrollParent[0] !== this.document[0] && "HTML" !== this.scrollParent[0].tagName && (this.overflowOffset = this.scrollParent.offset()), this._trigger("start", t, this._uiHash()), this._preserveHelperProportions || this._cacheHelperProportions(), !i)
                for (s = this.containers.length - 1; 0 <= s; s--) this.containers[s]._trigger("activate", t, this._uiHash(this));
            return V.ui.ddmanager && (V.ui.ddmanager.current = this), V.ui.ddmanager && !o.dropBehaviour && V.ui.ddmanager.prepareOffsets(this, t), this.dragging = !0, this._addClass(this.helper, "ui-sortable-helper"), this.helper.parent().is(this.appendTo) || (this.helper.detach().appendTo(this.appendTo), this.offset.parent = this._getParentOffset()), this.position = this.originalPosition = this._generatePosition(t), this.originalPageX = t.pageX, this.originalPageY = t.pageY, this.lastPositionAbs = this.positionAbs = this._convertPositionTo("absolute"), this._mouseDrag(t), !0
        },
        _scroll: function(t) {
            var e = this.options,
                i = !1;
            return this.scrollParent[0] !== this.document[0] && "HTML" !== this.scrollParent[0].tagName ? (this.overflowOffset.top + this.scrollParent[0].offsetHeight - t.pageY < e.scrollSensitivity ? this.scrollParent[0].scrollTop = i = this.scrollParent[0].scrollTop + e.scrollSpeed : t.pageY - this.overflowOffset.top < e.scrollSensitivity && (this.scrollParent[0].scrollTop = i = this.scrollParent[0].scrollTop - e.scrollSpeed), this.overflowOffset.left + this.scrollParent[0].offsetWidth - t.pageX < e.scrollSensitivity ? this.scrollParent[0].scrollLeft = i = this.scrollParent[0].scrollLeft + e.scrollSpeed : t.pageX - this.overflowOffset.left < e.scrollSensitivity && (this.scrollParent[0].scrollLeft = i = this.scrollParent[0].scrollLeft - e.scrollSpeed)) : (t.pageY - this.document.scrollTop() < e.scrollSensitivity ? i = this.document.scrollTop(this.document.scrollTop() - e.scrollSpeed) : this.window.height() - (t.pageY - this.document.scrollTop()) < e.scrollSensitivity && (i = this.document.scrollTop(this.document.scrollTop() + e.scrollSpeed)), t.pageX - this.document.scrollLeft() < e.scrollSensitivity ? i = this.document.scrollLeft(this.document.scrollLeft() - e.scrollSpeed) : this.window.width() - (t.pageX - this.document.scrollLeft()) < e.scrollSensitivity && (i = this.document.scrollLeft(this.document.scrollLeft() + e.scrollSpeed))), i
        },
        _mouseDrag: function(t) {
            var e, i, s, n, o = this.options;
            if (this.position = this._generatePosition(t), this.positionAbs = this._convertPositionTo("absolute"), this.options.axis && "y" === this.options.axis || (this.helper[0].style.left = this.position.left + "px"), this.options.axis && "x" === this.options.axis || (this.helper[0].style.top = this.position.top + "px"), this._contactContainers(t), null !== this.innermostContainer)
                for (o.scroll && !1 !== this._scroll(t) && (this._refreshItemPositions(!0), V.ui.ddmanager) && !o.dropBehaviour && V.ui.ddmanager.prepareOffsets(this, t), this.dragDirection = {
                        vertical: this._getDragVerticalDirection(),
                        horizontal: this._getDragHorizontalDirection()
                    }, e = this.items.length - 1; 0 <= e; e--)
                    if (s = (i = this.items[e]).item[0], (n = this._intersectsWithPointer(i)) && i.instance === this.currentContainer && !(s === this.currentItem[0] || this.placeholder[1 === n ? "next" : "prev"]()[0] === s || V.contains(this.placeholder[0], s) || "semi-dynamic" === this.options.type && V.contains(this.element[0], s))) {
                        if (this.direction = 1 === n ? "down" : "up", "pointer" !== this.options.tolerance && !this._intersectsWithSides(i)) break;
                        this._rearrange(t, i), this._trigger("change", t, this._uiHash());
                        break
                    }
            return V.ui.ddmanager && V.ui.ddmanager.drag(this, t), this._trigger("sort", t, this._uiHash()), this.lastPositionAbs = this.positionAbs, !1
        },
        _mouseStop: function(t, e) {
            var i, s, n, o;
            if (t) return V.ui.ddmanager && !this.options.dropBehaviour && V.ui.ddmanager.drop(this, t), this.options.revert ? (s = (i = this).placeholder.offset(), o = {}, (n = this.options.axis) && "x" !== n || (o.left = s.left - this.offset.parent.left - this.margins.left + (this.offsetParent[0] === this.document[0].body ? 0 : this.offsetParent[0].scrollLeft)), n && "y" !== n || (o.top = s.top - this.offset.parent.top - this.margins.top + (this.offsetParent[0] === this.document[0].body ? 0 : this.offsetParent[0].scrollTop)), this.reverting = !0, V(this.helper).animate(o, parseInt(this.options.revert, 10) || 500, function() {
                i._clear(t)
            })) : this._clear(t, e), !1
        },
        cancel: function() {
            if (this.dragging) {
                this._mouseUp(new V.Event("mouseup", {
                    target: null
                })), "original" === this.options.helper ? (this.currentItem.css(this._storedCSS), this._removeClass(this.currentItem, "ui-sortable-helper")) : this.currentItem.show();
                for (var t = this.containers.length - 1; 0 <= t; t--) this.containers[t]._trigger("deactivate", null, this._uiHash(this)), this.containers[t].containerCache.over && (this.containers[t]._trigger("out", null, this._uiHash(this)), this.containers[t].containerCache.over = 0)
            }
            return this.placeholder && (this.placeholder[0].parentNode && this.placeholder[0].parentNode.removeChild(this.placeholder[0]), "original" !== this.options.helper && this.helper && this.helper[0].parentNode && this.helper.remove(), V.extend(this, {
                helper: null,
                dragging: !1,
                reverting: !1,
                _noFinalSort: null
            }), this.domPosition.prev ? V(this.domPosition.prev).after(this.currentItem) : V(this.domPosition.parent).prepend(this.currentItem)), this
        },
        serialize: function(e) {
            var t = this._getItemsAsjQuery(e && e.connected),
                i = [];
            return e = e || {}, V(t).each(function() {
                var t = (V(e.item || this).attr(e.attribute || "id") || "").match(e.expression || /(.+)[\-=_](.+)/);
                t && i.push((e.key || t[1] + "[]") + "=" + (e.key && e.expression ? t[1] : t[2]))
            }), !i.length && e.key && i.push(e.key + "="), i.join("&")
        },
        toArray: function(t) {
            var e = this._getItemsAsjQuery(t && t.connected),
                i = [];
            return t = t || {}, e.each(function() {
                i.push(V(t.item || this).attr(t.attribute || "id") || "")
            }), i
        },
        _intersectsWith: function(t) {
            var e = this.positionAbs.left,
                i = e + this.helperProportions.width,
                s = this.positionAbs.top,
                n = s + this.helperProportions.height,
                o = t.left,
                a = o + t.width,
                r = t.top,
                l = r + t.height,
                h = this.offset.click.top,
                c = this.offset.click.left,
                h = "x" === this.options.axis || r < s + h && s + h < l,
                c = "y" === this.options.axis || o < e + c && e + c < a;
            return "pointer" === this.options.tolerance || this.options.forcePointerForContainers || "pointer" !== this.options.tolerance && this.helperProportions[this.floating ? "width" : "height"] > t[this.floating ? "width" : "height"] ? h && c : o < e + this.helperProportions.width / 2 && i - this.helperProportions.width / 2 < a && r < s + this.helperProportions.height / 2 && n - this.helperProportions.height / 2 < l
        },
        _intersectsWithPointer: function(t) {
            var e = "x" === this.options.axis || this._isOverAxis(this.positionAbs.top + this.offset.click.top, t.top, t.height),
                t = "y" === this.options.axis || this._isOverAxis(this.positionAbs.left + this.offset.click.left, t.left, t.width);
            return !(!e || !t) && (e = this.dragDirection.vertical, t = this.dragDirection.horizontal, this.floating ? "right" === t || "down" === e ? 2 : 1 : e && ("down" === e ? 2 : 1))
        },
        _intersectsWithSides: function(t) {
            var e = this._isOverAxis(this.positionAbs.top + this.offset.click.top, t.top + t.height / 2, t.height),
                i = this._isOverAxis(this.positionAbs.left + this.offset.click.left, t.left + t.width / 2, t.width),
                s = this.dragDirection.vertical,
                t = this.dragDirection.horizontal;
            return this.floating && t ? "right" === t && i || "left" === t && !i : s && ("down" === s && e || "up" === s && !e)
        },
        _getDragVerticalDirection: function() {
            var t = this.positionAbs.top - this.lastPositionAbs.top;
            return 0 != t && (0 < t ? "down" : "up")
        },
        _getDragHorizontalDirection: function() {
            var t = this.positionAbs.left - this.lastPositionAbs.left;
            return 0 != t && (0 < t ? "right" : "left")
        },
        refresh: function(t) {
            return this._refreshItems(t), this._setHandleClassName(), this.refreshPositions(), this
        },
        _connectWith: function() {
            var t = this.options;
            return t.connectWith.constructor === String ? [t.connectWith] : t.connectWith
        },
        _getItemsAsjQuery: function(t) {
            var e, i, s, n, o = [],
                a = [],
                r = this._connectWith();
            if (r && t)
                for (e = r.length - 1; 0 <= e; e--)
                    for (i = (s = V(r[e], this.document[0])).length - 1; 0 <= i; i--)(n = V.data(s[i], this.widgetFullName)) && n !== this && !n.options.disabled && a.push(["function" == typeof n.options.items ? n.options.items.call(n.element) : V(n.options.items, n.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), n]);

            function l() {
                o.push(this)
            }
            for (a.push(["function" == typeof this.options.items ? this.options.items.call(this.element, null, {
                    options: this.options,
                    item: this.currentItem
                }) : V(this.options.items, this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), this]), e = a.length - 1; 0 <= e; e--) a[e][0].each(l);
            return V(o)
        },
        _removeCurrentsFromItems: function() {
            var i = this.currentItem.find(":data(" + this.widgetName + "-item)");
            this.items = V.grep(this.items, function(t) {
                for (var e = 0; e < i.length; e++)
                    if (i[e] === t.item[0]) return !1;
                return !0
            })
        },
        _refreshItems: function(t) {
            this.items = [], this.containers = [this];
            var e, i, s, n, o, a, r, l, h = this.items,
                c = [
                    ["function" == typeof this.options.items ? this.options.items.call(this.element[0], t, {
                        item: this.currentItem
                    }) : V(this.options.items, this.element), this]
                ],
                u = this._connectWith();
            if (u && this.ready)
                for (e = u.length - 1; 0 <= e; e--)
                    for (i = (s = V(u[e], this.document[0])).length - 1; 0 <= i; i--)(n = V.data(s[i], this.widgetFullName)) && n !== this && !n.options.disabled && (c.push(["function" == typeof n.options.items ? n.options.items.call(n.element[0], t, {
                        item: this.currentItem
                    }) : V(n.options.items, n.element), n]), this.containers.push(n));
            for (e = c.length - 1; 0 <= e; e--)
                for (o = c[e][1], l = (a = c[e][i = 0]).length; i < l; i++)(r = V(a[i])).data(this.widgetName + "-item", o), h.push({
                    item: r,
                    instance: o,
                    width: 0,
                    height: 0,
                    left: 0,
                    top: 0
                })
        },
        _refreshItemPositions: function(t) {
            for (var e, i, s = this.items.length - 1; 0 <= s; s--) e = this.items[s], this.currentContainer && e.instance !== this.currentContainer && e.item[0] !== this.currentItem[0] || (i = this.options.toleranceElement ? V(this.options.toleranceElement, e.item) : e.item, t || (e.width = i.outerWidth(), e.height = i.outerHeight()), i = i.offset(), e.left = i.left, e.top = i.top)
        },
        refreshPositions: function(t) {
            var e, i;
            if (this.floating = !!this.items.length && ("x" === this.options.axis || this._isFloating(this.items[0].item)), null !== this.innermostContainer && this._refreshItemPositions(t), this.options.custom && this.options.custom.refreshContainers) this.options.custom.refreshContainers.call(this);
            else
                for (e = this.containers.length - 1; 0 <= e; e--) i = this.containers[e].element.offset(), this.containers[e].containerCache.left = i.left, this.containers[e].containerCache.top = i.top, this.containers[e].containerCache.width = this.containers[e].element.outerWidth(), this.containers[e].containerCache.height = this.containers[e].element.outerHeight();
            return this
        },
        _createPlaceholder: function(i) {
            var s, n, o = (i = i || this).options;
            o.placeholder && o.placeholder.constructor !== String || (s = o.placeholder, n = i.currentItem[0].nodeName.toLowerCase(), o.placeholder = {
                element: function() {
                    var t = V("<" + n + ">", i.document[0]);
                    return i._addClass(t, "ui-sortable-placeholder", s || i.currentItem[0].className)._removeClass(t, "ui-sortable-helper"), "tbody" === n ? i._createTrPlaceholder(i.currentItem.find("tr").eq(0), V("<tr>", i.document[0]).appendTo(t)) : "tr" === n ? i._createTrPlaceholder(i.currentItem, t) : "img" === n && t.attr("src", i.currentItem.attr("src")), s || t.css("visibility", "hidden"), t
                },
                update: function(t, e) {
                    s && !o.forcePlaceholderSize || (e.height() && (!o.forcePlaceholderSize || "tbody" !== n && "tr" !== n) || e.height(i.currentItem.innerHeight() - parseInt(i.currentItem.css("paddingTop") || 0, 10) - parseInt(i.currentItem.css("paddingBottom") || 0, 10)), e.width()) || e.width(i.currentItem.innerWidth() - parseInt(i.currentItem.css("paddingLeft") || 0, 10) - parseInt(i.currentItem.css("paddingRight") || 0, 10))
                }
            }), i.placeholder = V(o.placeholder.element.call(i.element, i.currentItem)), i.currentItem.after(i.placeholder), o.placeholder.update(i, i.placeholder)
        },
        _createTrPlaceholder: function(t, e) {
            var i = this;
            t.children().each(function() {
                V("<td>&#160;</td>", i.document[0]).attr("colspan", V(this).attr("colspan") || 1).appendTo(e)
            })
        },
        _contactContainers: function(t) {
            for (var e, i, s, n, o, a, r, l, h, c = null, u = null, d = this.containers.length - 1; 0 <= d; d--) V.contains(this.currentItem[0], this.containers[d].element[0]) || (this._intersectsWith(this.containers[d].containerCache) ? c && V.contains(this.containers[d].element[0], c.element[0]) || (c = this.containers[d], u = d) : this.containers[d].containerCache.over && (this.containers[d]._trigger("out", t, this._uiHash(this)), this.containers[d].containerCache.over = 0));
            if (this.innermostContainer = c)
                if (1 === this.containers.length) this.containers[u].containerCache.over || (this.containers[u]._trigger("over", t, this._uiHash(this)), this.containers[u].containerCache.over = 1);
                else {
                    for (i = 1e4, s = null, n = (l = c.floating || this._isFloating(this.currentItem)) ? "left" : "top", o = l ? "width" : "height", h = l ? "pageX" : "pageY", e = this.items.length - 1; 0 <= e; e--) V.contains(this.containers[u].element[0], this.items[e].item[0]) && this.items[e].item[0] !== this.currentItem[0] && (a = this.items[e].item.offset()[n], r = !1, t[h] - a > this.items[e][o] / 2 && (r = !0), Math.abs(t[h] - a) < i) && (i = Math.abs(t[h] - a), s = this.items[e], this.direction = r ? "up" : "down");
                    (s || this.options.dropOnEmpty) && (this.currentContainer !== this.containers[u] ? (s ? this._rearrange(t, s, null, !0) : this._rearrange(t, null, this.containers[u].element, !0), this._trigger("change", t, this._uiHash()), this.containers[u]._trigger("change", t, this._uiHash(this)), this.currentContainer = this.containers[u], this.options.placeholder.update(this.currentContainer, this.placeholder), this.scrollParent = this.placeholder.scrollParent(), this.scrollParent[0] !== this.document[0] && "HTML" !== this.scrollParent[0].tagName && (this.overflowOffset = this.scrollParent.offset()), this.containers[u]._trigger("over", t, this._uiHash(this)), this.containers[u].containerCache.over = 1) : this.currentContainer.containerCache.over || (this.containers[u]._trigger("over", t, this._uiHash()), this.currentContainer.containerCache.over = 1))
                }
        },
        _createHelper: function(t) {
            var e = this.options;
            return (t = "function" == typeof e.helper ? V(e.helper.apply(this.element[0], [t, this.currentItem])) : "clone" === e.helper ? this.currentItem.clone() : this.currentItem).parents("body").length || this.appendTo[0].appendChild(t[0]), t[0] === this.currentItem[0] && (this._storedCSS = {
                width: this.currentItem[0].style.width,
                height: this.currentItem[0].style.height,
                position: this.currentItem.css("position"),
                top: this.currentItem.css("top"),
                left: this.currentItem.css("left")
            }), t[0].style.width && !e.forceHelperSize || t.width(this.currentItem.width()), t[0].style.height && !e.forceHelperSize || t.height(this.currentItem.height()), t
        },
        _adjustOffsetFromHelper: function(t) {
            "string" == typeof t && (t = t.split(" ")), "left" in (t = Array.isArray(t) ? {
                left: +t[0],
                top: +t[1] || 0
            } : t) && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
        },
        _getParentOffset: function() {
            this.offsetParent = this.helper.offsetParent();
            var t = this.offsetParent.offset();
            return "absolute" === this.cssPosition && this.scrollParent[0] !== this.document[0] && V.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop()), {
                top: (t = this.offsetParent[0] === this.document[0].body || this.offsetParent[0].tagName && "html" === this.offsetParent[0].tagName.toLowerCase() && V.ui.ie ? {
                    top: 0,
                    left: 0
                } : t).top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
            }
        },
        _getRelativeOffset: function() {
            var t;
            return "relative" !== this.cssPosition ? {
                top: 0,
                left: 0
            } : {
                top: (t = this.currentItem.position()).top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),
                left: t.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()
            }
        },
        _cacheMargins: function() {
            this.margins = {
                left: parseInt(this.currentItem.css("marginLeft"), 10) || 0,
                top: parseInt(this.currentItem.css("marginTop"), 10) || 0
            }
        },
        _cacheHelperProportions: function() {
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            }
        },
        _setContainment: function() {
            var t, e, i = this.options;
            "parent" === i.containment && (i.containment = this.helper[0].parentNode), "document" !== i.containment && "window" !== i.containment || (this.containment = [0 - this.offset.relative.left - this.offset.parent.left, 0 - this.offset.relative.top - this.offset.parent.top, "document" === i.containment ? this.document.width() : this.window.width() - this.helperProportions.width - this.margins.left, ("document" === i.containment ? this.document.height() || document.body.parentNode.scrollHeight : this.window.height() || this.document[0].body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]), /^(document|window|parent)$/.test(i.containment) || (t = V(i.containment)[0], e = V(i.containment).offset(), i = "hidden" !== V(t).css("overflow"), this.containment = [e.left + (parseInt(V(t).css("borderLeftWidth"), 10) || 0) + (parseInt(V(t).css("paddingLeft"), 10) || 0) - this.margins.left, e.top + (parseInt(V(t).css("borderTopWidth"), 10) || 0) + (parseInt(V(t).css("paddingTop"), 10) || 0) - this.margins.top, e.left + (i ? Math.max(t.scrollWidth, t.offsetWidth) : t.offsetWidth) - (parseInt(V(t).css("borderLeftWidth"), 10) || 0) - (parseInt(V(t).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left, e.top + (i ? Math.max(t.scrollHeight, t.offsetHeight) : t.offsetHeight) - (parseInt(V(t).css("borderTopWidth"), 10) || 0) - (parseInt(V(t).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top])
        },
        _convertPositionTo: function(t, e) {
            e = e || this.position;
            var i = "absolute" === t ? 1 : -1,
                s = "absolute" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && V.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                t = /(html|body)/i.test(s[0].tagName);
            return {
                top: e.top + this.offset.relative.top * i + this.offset.parent.top * i - ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : t ? 0 : s.scrollTop()) * i,
                left: e.left + this.offset.relative.left * i + this.offset.parent.left * i - ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : t ? 0 : s.scrollLeft()) * i
            }
        },
        _generatePosition: function(t) {
            var e = this.options,
                i = t.pageX,
                s = t.pageY,
                n = "absolute" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && V.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                o = /(html|body)/i.test(n[0].tagName);
            return "relative" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && this.scrollParent[0] !== this.offsetParent[0] || (this.offset.relative = this._getRelativeOffset()), this.originalPosition && (this.containment && (t.pageX - this.offset.click.left < this.containment[0] && (i = this.containment[0] + this.offset.click.left), t.pageY - this.offset.click.top < this.containment[1] && (s = this.containment[1] + this.offset.click.top), t.pageX - this.offset.click.left > this.containment[2] && (i = this.containment[2] + this.offset.click.left), t.pageY - this.offset.click.top > this.containment[3]) && (s = this.containment[3] + this.offset.click.top), e.grid) && (t = this.originalPageY + Math.round((s - this.originalPageY) / e.grid[1]) * e.grid[1], s = !this.containment || t - this.offset.click.top >= this.containment[1] && t - this.offset.click.top <= this.containment[3] ? t : t - this.offset.click.top >= this.containment[1] ? t - e.grid[1] : t + e.grid[1], t = this.originalPageX + Math.round((i - this.originalPageX) / e.grid[0]) * e.grid[0], i = !this.containment || t - this.offset.click.left >= this.containment[0] && t - this.offset.click.left <= this.containment[2] ? t : t - this.offset.click.left >= this.containment[0] ? t - e.grid[0] : t + e.grid[0]), {
                top: s - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : o ? 0 : n.scrollTop()),
                left: i - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : o ? 0 : n.scrollLeft())
            }
        },
        _rearrange: function(t, e, i, s) {
            i ? i[0].appendChild(this.placeholder[0]) : e.item[0].parentNode.insertBefore(this.placeholder[0], "down" === this.direction ? e.item[0] : e.item[0].nextSibling), this.counter = this.counter ? ++this.counter : 1;
            var n = this.counter;
            this._delay(function() {
                n === this.counter && this.refreshPositions(!s)
            })
        },
        _clear: function(t, e) {
            this.reverting = !1;
            var i, s = [];
            if (!this._noFinalSort && this.currentItem.parent().length && this.placeholder.before(this.currentItem), this._noFinalSort = null, this.helper[0] === this.currentItem[0]) {
                for (i in this._storedCSS) "auto" !== this._storedCSS[i] && "static" !== this._storedCSS[i] || (this._storedCSS[i] = "");
                this.currentItem.css(this._storedCSS), this._removeClass(this.currentItem, "ui-sortable-helper")
            } else this.currentItem.show();

            function n(e, i, s) {
                return function(t) {
                    s._trigger(e, t, i._uiHash(i))
                }
            }
            for (this.fromOutside && !e && s.push(function(t) {
                    this._trigger("receive", t, this._uiHash(this.fromOutside))
                }), !this.fromOutside && this.domPosition.prev === this.currentItem.prev().not(".ui-sortable-helper")[0] && this.domPosition.parent === this.currentItem.parent()[0] || e || s.push(function(t) {
                    this._trigger("update", t, this._uiHash())
                }), this === this.currentContainer || e || (s.push(function(t) {
                    this._trigger("remove", t, this._uiHash())
                }), s.push(function(e) {
                    return function(t) {
                        e._trigger("receive", t, this._uiHash(this))
                    }
                }.call(this, this.currentContainer)), s.push(function(e) {
                    return function(t) {
                        e._trigger("update", t, this._uiHash(this))
                    }
                }.call(this, this.currentContainer))), i = this.containers.length - 1; 0 <= i; i--) e || s.push(n("deactivate", this, this.containers[i])), this.containers[i].containerCache.over && (s.push(n("out", this, this.containers[i])), this.containers[i].containerCache.over = 0);
            if (this.storedCursor && (this.document.find("body").css("cursor", this.storedCursor), this.storedStylesheet.remove()), this._storedOpacity && this.helper.css("opacity", this._storedOpacity), this._storedZIndex && this.helper.css("zIndex", "auto" === this._storedZIndex ? "" : this._storedZIndex), this.dragging = !1, e || this._trigger("beforeStop", t, this._uiHash()), this.placeholder[0].parentNode.removeChild(this.placeholder[0]), this.cancelHelperRemoval || (this.helper[0] !== this.currentItem[0] && this.helper.remove(), this.helper = null), !e) {
                for (i = 0; i < s.length; i++) s[i].call(this, t);
                this._trigger("stop", t, this._uiHash())
            }
            return this.fromOutside = !1, !this.cancelHelperRemoval
        },
        _trigger: function() {
            !1 === V.Widget.prototype._trigger.apply(this, arguments) && this.cancel()
        },
        _uiHash: function(t) {
            var e = t || this;
            return {
                helper: e.helper,
                placeholder: e.placeholder || V([]),
                position: e.position,
                originalPosition: e.originalPosition,
                offset: e.positionAbs,
                item: e.currentItem,
                sender: t ? t.element : null
            }
        }
    }), V.widget("ui.accordion", {
        version: "1.13.0",
        options: {
            active: 0,
            animate: {},
            classes: {
                "ui-accordion-header": "ui-corner-top",
                "ui-accordion-header-collapsed": "ui-corner-all",
                "ui-accordion-content": "ui-corner-bottom"
            },
            collapsible: !1,
            event: "click",
            header: function(t) {
                return t.find("> li > :first-child").add(t.find("> :not(li)").even())
            },
            heightStyle: "auto",
            icons: {
                activeHeader: "ui-icon-triangle-1-s",
                header: "ui-icon-triangle-1-e"
            },
            activate: null,
            beforeActivate: null
        },
        hideProps: {
            borderTopWidth: "hide",
            borderBottomWidth: "hide",
            paddingTop: "hide",
            paddingBottom: "hide",
            height: "hide"
        },
        showProps: {
            borderTopWidth: "show",
            borderBottomWidth: "show",
            paddingTop: "show",
            paddingBottom: "show",
            height: "show"
        },
        _create: function() {
            var t = this.options;
            this.prevShow = this.prevHide = V(), this._addClass("ui-accordion", "ui-widget ui-helper-reset"), this.element.attr("role", "tablist"), t.collapsible || !1 !== t.active && null != t.active || (t.active = 0), this._processPanels(), t.active < 0 && (t.active += this.headers.length), this._refresh()
        },
        _getCreateEventData: function() {
            return {
                header: this.active,
                panel: this.active.length ? this.active.next() : V()
            }
        },
        _createIcons: function() {
            var t, e = this.options.icons;
            e && (t = V("<span>"), this._addClass(t, "ui-accordion-header-icon", "ui-icon " + e.header), t.prependTo(this.headers), t = this.active.children(".ui-accordion-header-icon"), this._removeClass(t, e.header)._addClass(t, null, e.activeHeader)._addClass(this.headers, "ui-accordion-icons"))
        },
        _destroyIcons: function() {
            this._removeClass(this.headers, "ui-accordion-icons"), this.headers.children(".ui-accordion-header-icon").remove()
        },
        _destroy: function() {
            var t;
            this.element.removeAttr("role"), this.headers.removeAttr("role aria-expanded aria-selected aria-controls tabIndex").removeUniqueId(), this._destroyIcons(), t = this.headers.next().css("display", "").removeAttr("role aria-hidden aria-labelledby").removeUniqueId(), "content" !== this.options.heightStyle && t.css("height", "")
        },
        _setOption: function(t, e) {
            "active" !== t ? ("event" === t && (this.options.event && this._off(this.headers, this.options.event), this._setupEvents(e)), this._super(t, e), "collapsible" !== t || e || !1 !== this.options.active || this._activate(0), "icons" === t && (this._destroyIcons(), e) && this._createIcons()) : this._activate(e)
        },
        _setOptionDisabled: function(t) {
            this._super(t), this.element.attr("aria-disabled", t), this._toggleClass(null, "ui-state-disabled", !!t), this._toggleClass(this.headers.add(this.headers.next()), null, "ui-state-disabled", !!t)
        },
        _keydown: function(t) {
            if (!t.altKey && !t.ctrlKey) {
                var e = V.ui.keyCode,
                    i = this.headers.length,
                    s = this.headers.index(t.target),
                    n = !1;
                switch (t.keyCode) {
                    case e.RIGHT:
                    case e.DOWN:
                        n = this.headers[(s + 1) % i];
                        break;
                    case e.LEFT:
                    case e.UP:
                        n = this.headers[(s - 1 + i) % i];
                        break;
                    case e.SPACE:
                    case e.ENTER:
                        this._eventHandler(t);
                        break;
                    case e.HOME:
                        n = this.headers[0];
                        break;
                    case e.END:
                        n = this.headers[i - 1]
                }
                n && (V(t.target).attr("tabIndex", -1), V(n).attr("tabIndex", 0), V(n).trigger("focus"), t.preventDefault())
            }
        },
        _panelKeyDown: function(t) {
            t.keyCode === V.ui.keyCode.UP && t.ctrlKey && V(t.currentTarget).prev().trigger("focus")
        },
        refresh: function() {
            var t = this.options;
            this._processPanels(), !1 === t.active && !0 === t.collapsible || !this.headers.length ? (t.active = !1, this.active = V()) : !1 === t.active ? this._activate(0) : this.active.length && !V.contains(this.element[0], this.active[0]) ? this.headers.length === this.headers.find(".ui-state-disabled").length ? (t.active = !1, this.active = V()) : this._activate(Math.max(0, t.active - 1)) : t.active = this.headers.index(this.active), this._destroyIcons(), this._refresh()
        },
        _processPanels: function() {
            var t = this.headers,
                e = this.panels;
            "function" == typeof this.options.header ? this.headers = this.options.header(this.element) : this.headers = this.element.find(this.options.header), this._addClass(this.headers, "ui-accordion-header ui-accordion-header-collapsed", "ui-state-default"), this.panels = this.headers.next().filter(":not(.ui-accordion-content-active)").hide(), this._addClass(this.panels, "ui-accordion-content", "ui-helper-reset ui-widget-content"), e && (this._off(t.not(this.headers)), this._off(e.not(this.panels)))
        },
        _refresh: function() {
            var i, t = this.options,
                e = t.heightStyle,
                s = this.element.parent();
            this.active = this._findActive(t.active), this._addClass(this.active, "ui-accordion-header-active", "ui-state-active")._removeClass(this.active, "ui-accordion-header-collapsed"), this._addClass(this.active.next(), "ui-accordion-content-active"), this.active.next().show(), this.headers.attr("role", "tab").each(function() {
                var t = V(this),
                    e = t.uniqueId().attr("id"),
                    i = t.next(),
                    s = i.uniqueId().attr("id");
                t.attr("aria-controls", s), i.attr("aria-labelledby", e)
            }).next().attr("role", "tabpanel"), this.headers.not(this.active).attr({
                "aria-selected": "false",
                "aria-expanded": "false",
                tabIndex: -1
            }).next().attr({
                "aria-hidden": "true"
            }).hide(), this.active.length ? this.active.attr({
                "aria-selected": "true",
                "aria-expanded": "true",
                tabIndex: 0
            }).next().attr({
                "aria-hidden": "false"
            }) : this.headers.eq(0).attr("tabIndex", 0), this._createIcons(), this._setupEvents(t.event), "fill" === e ? (i = s.height(), this.element.siblings(":visible").each(function() {
                var t = V(this),
                    e = t.css("position");
                "absolute" !== e && "fixed" !== e && (i -= t.outerHeight(!0))
            }), this.headers.each(function() {
                i -= V(this).outerHeight(!0)
            }), this.headers.next().each(function() {
                V(this).height(Math.max(0, i - V(this).innerHeight() + V(this).height()))
            }).css("overflow", "auto")) : "auto" === e && (i = 0, this.headers.next().each(function() {
                var t = V(this).is(":visible");
                t || V(this).show(), i = Math.max(i, V(this).css("height", "").height()), t || V(this).hide()
            }).height(i))
        },
        _activate: function(t) {
            (t = this._findActive(t)[0]) !== this.active[0] && (t = t || this.active[0], this._eventHandler({
                target: t,
                currentTarget: t,
                preventDefault: V.noop
            }))
        },
        _findActive: function(t) {
            return "number" == typeof t ? this.headers.eq(t) : V()
        },
        _setupEvents: function(t) {
            var i = {
                keydown: "_keydown"
            };
            t && V.each(t.split(" "), function(t, e) {
                i[e] = "_eventHandler"
            }), this._off(this.headers.add(this.headers.next())), this._on(this.headers, i), this._on(this.headers.next(), {
                keydown: "_panelKeyDown"
            }), this._hoverable(this.headers), this._focusable(this.headers)
        },
        _eventHandler: function(t) {
            var e = this.options,
                i = this.active,
                s = V(t.currentTarget),
                n = s[0] === i[0],
                o = n && e.collapsible,
                a = o ? V() : s.next(),
                r = i.next(),
                a = {
                    oldHeader: i,
                    oldPanel: r,
                    newHeader: o ? V() : s,
                    newPanel: a
                };
            t.preventDefault(), n && !e.collapsible || !1 === this._trigger("beforeActivate", t, a) || (e.active = !o && this.headers.index(s), this.active = n ? V() : s, this._toggle(a), this._removeClass(i, "ui-accordion-header-active", "ui-state-active"), e.icons && (i = i.children(".ui-accordion-header-icon"), this._removeClass(i, null, e.icons.activeHeader)._addClass(i, null, e.icons.header)), n) || (this._removeClass(s, "ui-accordion-header-collapsed")._addClass(s, "ui-accordion-header-active", "ui-state-active"), e.icons && (n = s.children(".ui-accordion-header-icon"), this._removeClass(n, null, e.icons.header)._addClass(n, null, e.icons.activeHeader)), this._addClass(s.next(), "ui-accordion-content-active"))
        },
        _toggle: function(t) {
            var e = t.newPanel,
                i = this.prevShow.length ? this.prevShow : t.oldPanel;
            this.prevShow.add(this.prevHide).stop(!0, !0), this.prevShow = e, this.prevHide = i, this.options.animate ? this._animate(e, i, t) : (i.hide(), e.show(), this._toggleComplete(t)), i.attr({
                "aria-hidden": "true"
            }), i.prev().attr({
                "aria-selected": "false",
                "aria-expanded": "false"
            }), e.length && i.length ? i.prev().attr({
                tabIndex: -1,
                "aria-expanded": "false"
            }) : e.length && this.headers.filter(function() {
                return 0 === parseInt(V(this).attr("tabIndex"), 10)
            }).attr("tabIndex", -1), e.attr("aria-hidden", "false").prev().attr({
                "aria-selected": "true",
                "aria-expanded": "true",
                tabIndex: 0
            })
        },
        _animate: function(t, i, e) {
            var s, n = this,
                o = 0,
                a = t.css("box-sizing"),
                r = t.length && (!i.length || t.index() < i.index()),
                l = this.options.animate || {},
                h = r && l.down || l,
                r = function() {
                    n._toggleComplete(e)
                },
                c = (c = "string" == typeof h ? h : c) || h.easing || l.easing,
                u = (u = "number" == typeof h ? h : u) || h.duration || l.duration;
            return i.length ? t.length ? (s = t.show().outerHeight(), i.animate(this.hideProps, {
                duration: u,
                easing: c,
                step: function(t, e) {
                    e.now = Math.round(t)
                }
            }), void t.hide().animate(this.showProps, {
                duration: u,
                easing: c,
                complete: r,
                step: function(t, e) {
                    e.now = Math.round(t), "height" !== e.prop ? "content-box" === a && (o += e.now) : "content" !== n.options.heightStyle && (e.now = Math.round(s - i.outerHeight() - o), o = 0)
                }
            })) : i.animate(this.hideProps, u, c, r) : t.animate(this.showProps, u, c, r)
        },
        _toggleComplete: function(t) {
            var e = t.oldPanel,
                i = e.prev();
            this._removeClass(e, "ui-accordion-content-active"), this._removeClass(i, "ui-accordion-header-active")._addClass(i, "ui-accordion-header-collapsed"), e.length && (e.parent()[0].className = e.parent()[0].className), this._trigger("activate", null, t)
        }
    }), V.widget("ui.menu", {
        version: "1.13.0",
        defaultElement: "<ul>",
        delay: 300,
        options: {
            icons: {
                submenu: "ui-icon-caret-1-e"
            },
            items: "> *",
            menus: "ul",
            position: {
                my: "left top",
                at: "right top"
            },
            role: "menu",
            blur: null,
            focus: null,
            select: null
        },
        _create: function() {
            this.activeMenu = this.element, this.mouseHandled = !1, this.lastMousePosition = {
                x: null,
                y: null
            }, this.element.uniqueId().attr({
                role: this.options.role,
                tabIndex: 0
            }), this._addClass("ui-menu", "ui-widget ui-widget-content"), this._on({
                "mousedown .ui-menu-item": function(t) {
                    t.preventDefault(), this._activateItem(t)
                },
                "click .ui-menu-item": function(t) {
                    var e = V(t.target),
                        i = V(V.ui.safeActiveElement(this.document[0]));
                    !this.mouseHandled && e.not(".ui-state-disabled").length && (this.select(t), t.isPropagationStopped() || (this.mouseHandled = !0), e.has(".ui-menu").length ? this.expand(t) : !this.element.is(":focus") && i.closest(".ui-menu").length && (this.element.trigger("focus", [!0]), this.active) && 1 === this.active.parents(".ui-menu").length && clearTimeout(this.timer))
                },
                "mouseenter .ui-menu-item": "_activateItem",
                "mousemove .ui-menu-item": "_activateItem",
                mouseleave: "collapseAll",
                "mouseleave .ui-menu": "collapseAll",
                focus: function(t, e) {
                    var i = this.active || this._menuItems().first();
                    e || this.focus(t, i)
                },
                blur: function(t) {
                    this._delay(function() {
                        V.contains(this.element[0], V.ui.safeActiveElement(this.document[0])) || this.collapseAll(t)
                    })
                },
                keydown: "_keydown"
            }), this.refresh(), this._on(this.document, {
                click: function(t) {
                    this._closeOnDocumentClick(t) && this.collapseAll(t, !0), this.mouseHandled = !1
                }
            })
        },
        _activateItem: function(t) {
            var e, i;
            this.previousFilter || t.clientX === this.lastMousePosition.x && t.clientY === this.lastMousePosition.y || (this.lastMousePosition = {
                x: t.clientX,
                y: t.clientY
            }, e = V(t.target).closest(".ui-menu-item"), i = V(t.currentTarget), e[0] !== i[0]) || i.is(".ui-state-active") || (this._removeClass(i.siblings().children(".ui-state-active"), null, "ui-state-active"), this.focus(t, i))
        },
        _destroy: function() {
            var t = this.element.find(".ui-menu-item").removeAttr("role aria-disabled").children(".ui-menu-item-wrapper").removeUniqueId().removeAttr("tabIndex role aria-haspopup");
            this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeAttr("role aria-labelledby aria-expanded aria-hidden aria-disabled tabIndex").removeUniqueId().show(), t.children().each(function() {
                var t = V(this);
                t.data("ui-menu-submenu-caret") && t.remove()
            })
        },
        _keydown: function(t) {
            var e, i, s, n = !0;
            switch (t.keyCode) {
                case V.ui.keyCode.PAGE_UP:
                    this.previousPage(t);
                    break;
                case V.ui.keyCode.PAGE_DOWN:
                    this.nextPage(t);
                    break;
                case V.ui.keyCode.HOME:
                    this._move("first", "first", t);
                    break;
                case V.ui.keyCode.END:
                    this._move("last", "last", t);
                    break;
                case V.ui.keyCode.UP:
                    this.previous(t);
                    break;
                case V.ui.keyCode.DOWN:
                    this.next(t);
                    break;
                case V.ui.keyCode.LEFT:
                    this.collapse(t);
                    break;
                case V.ui.keyCode.RIGHT:
                    this.active && !this.active.is(".ui-state-disabled") && this.expand(t);
                    break;
                case V.ui.keyCode.ENTER:
                case V.ui.keyCode.SPACE:
                    this._activate(t);
                    break;
                case V.ui.keyCode.ESCAPE:
                    this.collapse(t);
                    break;
                default:
                    e = this.previousFilter || "", s = n = !1, i = 96 <= t.keyCode && t.keyCode <= 105 ? (t.keyCode - 96).toString() : String.fromCharCode(t.keyCode), clearTimeout(this.filterTimer), i === e ? s = !0 : i = e + i, e = this._filterMenuItems(i), (e = s && -1 !== e.index(this.active.next()) ? this.active.nextAll(".ui-menu-item") : e).length || (i = String.fromCharCode(t.keyCode), e = this._filterMenuItems(i)), e.length ? (this.focus(t, e), this.previousFilter = i, this.filterTimer = this._delay(function() {
                        delete this.previousFilter
                    }, 1e3)) : delete this.previousFilter
            }
            n && t.preventDefault()
        },
        _activate: function(t) {
            this.active && !this.active.is(".ui-state-disabled") && (this.active.children("[aria-haspopup='true']").length ? this.expand(t) : this.select(t))
        },
        refresh: function() {
            var t, e, s = this,
                n = this.options.icons.submenu,
                i = this.element.find(this.options.menus);
            this._toggleClass("ui-menu-icons", null, !!this.element.find(".ui-icon").length), e = i.filter(":not(.ui-menu)").hide().attr({
                role: this.options.role,
                "aria-hidden": "true",
                "aria-expanded": "false"
            }).each(function() {
                var t = V(this),
                    e = t.prev(),
                    i = V("<span>").data("ui-menu-submenu-caret", !0);
                s._addClass(i, "ui-menu-icon", "ui-icon " + n), e.attr("aria-haspopup", "true").prepend(i), t.attr("aria-labelledby", e.attr("id"))
            }), this._addClass(e, "ui-menu", "ui-widget ui-widget-content ui-front"), (t = i.add(this.element).find(this.options.items)).not(".ui-menu-item").each(function() {
                var t = V(this);
                s._isDivider(t) && s._addClass(t, "ui-menu-divider", "ui-widget-content")
            }), i = (e = t.not(".ui-menu-item, .ui-menu-divider")).children().not(".ui-menu").uniqueId().attr({
                tabIndex: -1,
                role: this._itemRole()
            }), this._addClass(e, "ui-menu-item")._addClass(i, "ui-menu-item-wrapper"), t.filter(".ui-state-disabled").attr("aria-disabled", "true"), this.active && !V.contains(this.element[0], this.active[0]) && this.blur()
        },
        _itemRole: function() {
            return {
                menu: "menuitem",
                listbox: "option"
            }[this.options.role]
        },
        _setOption: function(t, e) {
            var i;
            "icons" === t && (i = this.element.find(".ui-menu-icon"), this._removeClass(i, null, this.options.icons.submenu)._addClass(i, null, e.submenu)), this._super(t, e)
        },
        _setOptionDisabled: function(t) {
            this._super(t), this.element.attr("aria-disabled", String(t)), this._toggleClass(null, "ui-state-disabled", !!t)
        },
        focus: function(t, e) {
            var i;
            this.blur(t, t && "focus" === t.type), this._scrollIntoView(e), this.active = e.first(), i = this.active.children(".ui-menu-item-wrapper"), this._addClass(i, null, "ui-state-active"), this.options.role && this.element.attr("aria-activedescendant", i.attr("id")), i = this.active.parent().closest(".ui-menu-item").children(".ui-menu-item-wrapper"), this._addClass(i, null, "ui-state-active"), t && "keydown" === t.type ? this._close() : this.timer = this._delay(function() {
                this._close()
            }, this.delay), (i = e.children(".ui-menu")).length && t && /^mouse/.test(t.type) && this._startOpening(i), this.activeMenu = e.parent(), this._trigger("focus", t, {
                item: e
            })
        },
        _scrollIntoView: function(t) {
            var e, i, s;
            this._hasScroll() && (i = parseFloat(V.css(this.activeMenu[0], "borderTopWidth")) || 0, s = parseFloat(V.css(this.activeMenu[0], "paddingTop")) || 0, e = t.offset().top - this.activeMenu.offset().top - i - s, i = this.activeMenu.scrollTop(), s = this.activeMenu.height(), t = t.outerHeight(), e < 0 ? this.activeMenu.scrollTop(i + e) : s < e + t && this.activeMenu.scrollTop(i + e - s + t))
        },
        blur: function(t, e) {
            e || clearTimeout(this.timer), this.active && (this._removeClass(this.active.children(".ui-menu-item-wrapper"), null, "ui-state-active"), this._trigger("blur", t, {
                item: this.active
            }), this.active = null)
        },
        _startOpening: function(t) {
            clearTimeout(this.timer), "true" === t.attr("aria-hidden") && (this.timer = this._delay(function() {
                this._close(), this._open(t)
            }, this.delay))
        },
        _open: function(t) {
            var e = V.extend({ of: this.active
            }, this.options.position);
            clearTimeout(this.timer), this.element.find(".ui-menu").not(t.parents(".ui-menu")).hide().attr("aria-hidden", "true"), t.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(e)
        },
        collapseAll: function(e, i) {
            clearTimeout(this.timer), this.timer = this._delay(function() {
                var t = i ? this.element : V(e && e.target).closest(this.element.find(".ui-menu"));
                t.length || (t = this.element), this._close(t), this.blur(e), this._removeClass(t.find(".ui-state-active"), null, "ui-state-active"), this.activeMenu = t
            }, i ? 0 : this.delay)
        },
        _close: function(t) {
            (t = t || (this.active ? this.active.parent() : this.element)).find(".ui-menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false")
        },
        _closeOnDocumentClick: function(t) {
            return !V(t.target).closest(".ui-menu").length
        },
        _isDivider: function(t) {
            return !/[^\-\u2014\u2013\s]/.test(t.text())
        },
        collapse: function(t) {
            var e = this.active && this.active.parent().closest(".ui-menu-item", this.element);
            e && e.length && (this._close(), this.focus(t, e))
        },
        expand: function(t) {
            var e = this.active && this._menuItems(this.active.children(".ui-menu")).first();
            e && e.length && (this._open(e.parent()), this._delay(function() {
                this.focus(t, e)
            }))
        },
        next: function(t) {
            this._move("next", "first", t)
        },
        previous: function(t) {
            this._move("prev", "last", t)
        },
        isFirstItem: function() {
            return this.active && !this.active.prevAll(".ui-menu-item").length
        },
        isLastItem: function() {
            return this.active && !this.active.nextAll(".ui-menu-item").length
        },
        _menuItems: function(t) {
            return (t || this.element).find(this.options.items).filter(".ui-menu-item")
        },
        _move: function(t, e, i) {
            var s;
            (s = this.active ? "first" === t || "last" === t ? this.active["first" === t ? "prevAll" : "nextAll"](".ui-menu-item").last() : this.active[t + "All"](".ui-menu-item").first() : s) && s.length && this.active || (s = this._menuItems(this.activeMenu)[e]()), this.focus(i, s)
        },
        nextPage: function(t) {
            var e, i, s;
            this.active ? this.isLastItem() || (this._hasScroll() ? (i = this.active.offset().top, s = this.element.innerHeight(), 0 === V.fn.jquery.indexOf("3.2.") && (s += this.element[0].offsetHeight - this.element.outerHeight()), this.active.nextAll(".ui-menu-item").each(function() {
                return (e = V(this)).offset().top - i - s < 0
            }), this.focus(t, e)) : this.focus(t, this._menuItems(this.activeMenu)[this.active ? "last" : "first"]())) : this.next(t)
        },
        previousPage: function(t) {
            var e, i, s;
            this.active ? this.isFirstItem() || (this._hasScroll() ? (i = this.active.offset().top, s = this.element.innerHeight(), 0 === V.fn.jquery.indexOf("3.2.") && (s += this.element[0].offsetHeight - this.element.outerHeight()), this.active.prevAll(".ui-menu-item").each(function() {
                return 0 < (e = V(this)).offset().top - i + s
            }), this.focus(t, e)) : this.focus(t, this._menuItems(this.activeMenu).first())) : this.next(t)
        },
        _hasScroll: function() {
            return this.element.outerHeight() < this.element.prop("scrollHeight")
        },
        select: function(t) {
            this.active = this.active || V(t.target).closest(".ui-menu-item");
            var e = {
                item: this.active
            };
            this.active.has(".ui-menu").length || this.collapseAll(t, !0), this._trigger("select", t, e)
        },
        _filterMenuItems: function(t) {
            var t = t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&"),
                e = new RegExp("^" + t, "i");
            return this.activeMenu.find(this.options.items).filter(".ui-menu-item").filter(function() {
                return e.test(String.prototype.trim.call(V(this).children(".ui-menu-item-wrapper").text()))
            })
        }
    }), V.widget("ui.autocomplete", {
        version: "1.13.0",
        defaultElement: "<input>",
        options: {
            appendTo: null,
            autoFocus: !1,
            delay: 300,
            minLength: 1,
            position: {
                my: "left top",
                at: "left bottom",
                collision: "none"
            },
            source: null,
            change: null,
            close: null,
            focus: null,
            open: null,
            response: null,
            search: null,
            select: null
        },
        requestIndex: 0,
        pending: 0,
        _create: function() {
            var i, s, n, t = "textarea" === (e = this.element[0].nodeName.toLowerCase()),
                e = "input" === e;
            this.isMultiLine = t || !e && this._isContentEditable(this.element), this.valueMethod = this.element[t || e ? "val" : "text"], this.isNewMenu = !0, this._addClass("ui-autocomplete-input"), this.element.attr("autocomplete", "off"), this._on(this.element, {
                keydown: function(t) {
                    if (this.element.prop("readOnly")) s = n = i = !0;
                    else {
                        s = n = i = !1;
                        var e = V.ui.keyCode;
                        switch (t.keyCode) {
                            case e.PAGE_UP:
                                i = !0, this._move("previousPage", t);
                                break;
                            case e.PAGE_DOWN:
                                i = !0, this._move("nextPage", t);
                                break;
                            case e.UP:
                                i = !0, this._keyEvent("previous", t);
                                break;
                            case e.DOWN:
                                i = !0, this._keyEvent("next", t);
                                break;
                            case e.ENTER:
                                this.menu.active && (i = !0, t.preventDefault(), this.menu.select(t));
                                break;
                            case e.TAB:
                                this.menu.active && this.menu.select(t);
                                break;
                            case e.ESCAPE:
                                this.menu.element.is(":visible") && (this.isMultiLine || this._value(this.term), this.close(t), t.preventDefault());
                                break;
                            default:
                                s = !0, this._searchTimeout(t)
                        }
                    }
                },
                keypress: function(t) {
                    if (i) i = !1, this.isMultiLine && !this.menu.element.is(":visible") || t.preventDefault();
                    else if (!s) {
                        var e = V.ui.keyCode;
                        switch (t.keyCode) {
                            case e.PAGE_UP:
                                this._move("previousPage", t);
                                break;
                            case e.PAGE_DOWN:
                                this._move("nextPage", t);
                                break;
                            case e.UP:
                                this._keyEvent("previous", t);
                                break;
                            case e.DOWN:
                                this._keyEvent("next", t)
                        }
                    }
                },
                input: function(t) {
                    n ? (n = !1, t.preventDefault()) : this._searchTimeout(t)
                },
                focus: function() {
                    this.selectedItem = null, this.previous = this._value()
                },
                blur: function(t) {
                    clearTimeout(this.searching), this.close(t), this._change(t)
                }
            }), this._initSource(), this.menu = V("<ul>").appendTo(this._appendTo()).menu({
                role: null
            }).hide().attr({
                unselectable: "on"
            }).menu("instance"), this._addClass(this.menu.element, "ui-autocomplete", "ui-front"), this._on(this.menu.element, {
                mousedown: function(t) {
                    t.preventDefault()
                },
                menufocus: function(t, e) {
                    var i;
                    this.isNewMenu && (this.isNewMenu = !1, t.originalEvent) && /^mouse/.test(t.originalEvent.type) ? (this.menu.blur(), this.document.one("mousemove", function() {
                        V(t.target).trigger(t.originalEvent)
                    })) : (i = e.item.data("ui-autocomplete-item"), !1 !== this._trigger("focus", t, {
                        item: i
                    }) && t.originalEvent && /^key/.test(t.originalEvent.type) && this._value(i.value), (i = e.item.attr("aria-label") || i.value) && String.prototype.trim.call(i).length && (this.liveRegion.children().hide(), V("<div>").text(i).appendTo(this.liveRegion)))
                },
                menuselect: function(t, e) {
                    var i = e.item.data("ui-autocomplete-item"),
                        s = this.previous;
                    this.element[0] !== V.ui.safeActiveElement(this.document[0]) && (this.element.trigger("focus"), this.previous = s, this._delay(function() {
                        this.previous = s, this.selectedItem = i
                    })), !1 !== this._trigger("select", t, {
                        item: i
                    }) && this._value(i.value), this.term = this._value(), this.close(t), this.selectedItem = i
                }
            }), this.liveRegion = V("<div>", {
                role: "status",
                "aria-live": "assertive",
                "aria-relevant": "additions"
            }).appendTo(this.document[0].body), this._addClass(this.liveRegion, null, "ui-helper-hidden-accessible"), this._on(this.window, {
                beforeunload: function() {
                    this.element.removeAttr("autocomplete")
                }
            })
        },
        _destroy: function() {
            clearTimeout(this.searching), this.element.removeAttr("autocomplete"), this.menu.element.remove(), this.liveRegion.remove()
        },
        _setOption: function(t, e) {
            this._super(t, e), "source" === t && this._initSource(), "appendTo" === t && this.menu.element.appendTo(this._appendTo()), "disabled" === t && e && this.xhr && this.xhr.abort()
        },
        _isEventTargetInWidget: function(t) {
            var e = this.menu.element[0];
            return t.target === this.element[0] || t.target === e || V.contains(e, t.target)
        },
        _closeOnClickOutside: function(t) {
            this._isEventTargetInWidget(t) || this.close()
        },
        _appendTo: function() {
            var t = this.options.appendTo;
            return (t = (t = t && (t.jquery || t.nodeType ? V(t) : this.document.find(t).eq(0))) && t[0] ? t : this.element.closest(".ui-front, dialog")).length ? t : this.document[0].body
        },
        _initSource: function() {
            var i, s, n = this;
            Array.isArray(this.options.source) ? (i = this.options.source, this.source = function(t, e) {
                e(V.ui.autocomplete.filter(i, t.term))
            }) : "string" == typeof this.options.source ? (s = this.options.source, this.source = function(t, e) {
                n.xhr && n.xhr.abort(), n.xhr = V.ajax({
                    url: s,
                    data: t,
                    dataType: "json",
                    success: function(t) {
                        e(t)
                    },
                    error: function() {
                        e([])
                    }
                })
            }) : this.source = this.options.source
        },
        _searchTimeout: function(s) {
            clearTimeout(this.searching), this.searching = this._delay(function() {
                var t = this.term === this._value(),
                    e = this.menu.element.is(":visible"),
                    i = s.altKey || s.ctrlKey || s.metaKey || s.shiftKey;
                t && (e || i) || (this.selectedItem = null, this.search(null, s))
            }, this.options.delay)
        },
        search: function(t, e) {
            return t = null != t ? t : this._value(), this.term = this._value(), t.length < this.options.minLength ? this.close(e) : !1 !== this._trigger("search", e) ? this._search(t) : void 0
        },
        _search: function(t) {
            this.pending++, this._addClass("ui-autocomplete-loading"), this.cancelSearch = !1, this.source({
                term: t
            }, this._response())
        },
        _response: function() {
            var e = ++this.requestIndex;
            return function(t) {
                e === this.requestIndex && this.__response(t), this.pending--, this.pending || this._removeClass("ui-autocomplete-loading")
            }.bind(this)
        },
        __response: function(t) {
            t = t && this._normalize(t), this._trigger("response", null, {
                content: t
            }), !this.options.disabled && t && t.length && !this.cancelSearch ? (this._suggest(t), this._trigger("open")) : this._close()
        },
        close: function(t) {
            this.cancelSearch = !0, this._close(t)
        },
        _close: function(t) {
            this._off(this.document, "mousedown"), this.menu.element.is(":visible") && (this.menu.element.hide(), this.menu.blur(), this.isNewMenu = !0, this._trigger("close", t))
        },
        _change: function(t) {
            this.previous !== this._value() && this._trigger("change", t, {
                item: this.selectedItem
            })
        },
        _normalize: function(t) {
            return t.length && t[0].label && t[0].value ? t : V.map(t, function(t) {
                return "string" == typeof t ? {
                    label: t,
                    value: t
                } : V.extend({}, t, {
                    label: t.label || t.value,
                    value: t.value || t.label
                })
            })
        },
        _suggest: function(t) {
            var e = this.menu.element.empty();
            this._renderMenu(e, t), this.isNewMenu = !0, this.menu.refresh(), e.show(), this._resizeMenu(), e.position(V.extend({ of: this.element
            }, this.options.position)), this.options.autoFocus && this.menu.next(), this._on(this.document, {
                mousedown: "_closeOnClickOutside"
            })
        },
        _resizeMenu: function() {
            var t = this.menu.element;
            t.outerWidth(Math.max(t.width("").outerWidth() + 1, this.element.outerWidth()))
        },
        _renderMenu: function(i, t) {
            var s = this;
            V.each(t, function(t, e) {
                s._renderItemData(i, e)
            })
        },
        _renderItemData: function(t, e) {
            return this._renderItem(t, e).data("ui-autocomplete-item", e)
        },
        _renderItem: function(t, e) {
            return V("<li>").append(V("<div>").text(e.label)).appendTo(t)
        },
        _move: function(t, e) {
            if (this.menu.element.is(":visible")) return this.menu.isFirstItem() && /^previous/.test(t) || this.menu.isLastItem() && /^next/.test(t) ? (this.isMultiLine || this._value(this.term), void this.menu.blur()) : void this.menu[t](e);
            this.search(null, e)
        },
        widget: function() {
            return this.menu.element
        },
        _value: function() {
            return this.valueMethod.apply(this.element, arguments)
        },
        _keyEvent: function(t, e) {
            this.isMultiLine && !this.menu.element.is(":visible") || (this._move(t, e), e.preventDefault())
        },
        _isContentEditable: function(t) {
            var e;
            return !!t.length && ("inherit" === (e = t.prop("contentEditable")) ? this._isContentEditable(t.parent()) : "true" === e)
        }
    }), V.extend(V.ui.autocomplete, {
        escapeRegex: function(t) {
            return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
        },
        filter: function(t, e) {
            var i = new RegExp(V.ui.autocomplete.escapeRegex(e), "i");
            return V.grep(t, function(t) {
                return i.test(t.label || t.value || t)
            })
        }
    }), V.widget("ui.autocomplete", V.ui.autocomplete, {
        options: {
            messages: {
                noResults: "No search results.",
                results: function(t) {
                    return t + (1 < t ? " results are" : " result is") + " available, use up and down arrow keys to navigate."
                }
            }
        },
        __response: function(t) {
            this._superApply(arguments), this.options.disabled || this.cancelSearch || (t = t && t.length ? this.options.messages.results(t.length) : this.options.messages.noResults, this.liveRegion.children().hide(), V("<div>").text(t).appendTo(this.liveRegion))
        }
    }), V.ui.autocomplete;
    var j, d, p, B = /ui-corner-([a-z]){2,6}/g;

    function Y() {
        this._curInst = null, this._keyEvent = !1, this._disabledInputs = [], this._datepickerShowing = !1, this._inDialog = !1, this._mainDivId = "ui-datepicker-div", this._inlineClass = "ui-datepicker-inline", this._appendClass = "ui-datepicker-append", this._triggerClass = "ui-datepicker-trigger", this._dialogClass = "ui-datepicker-dialog", this._disableClass = "ui-datepicker-disabled", this._unselectableClass = "ui-datepicker-unselectable", this._currentClass = "ui-datepicker-current-day", this._dayOverClass = "ui-datepicker-days-cell-over", this.regional = [], this.regional[""] = {
            closeText: "Done",
            prevText: "Prev",
            nextText: "Next",
            currentText: "Today",
            monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
            weekHeader: "Wk",
            dateFormat: "mm/dd/yy",
            firstDay: 0,
            isRTL: !1,
            showMonthAfterYear: !1,
            yearSuffix: "",
            selectMonthLabel: "Select month",
            selectYearLabel: "Select year"
        }, this._defaults = {
            showOn: "focus",
            showAnim: "fadeIn",
            showOptions: {},
            defaultDate: null,
            appendText: "",
            buttonText: "...",
            buttonImage: "",
            buttonImageOnly: !1,
            hideIfNoPrevNext: !1,
            navigationAsDateFormat: !1,
            gotoCurrent: !1,
            changeMonth: !1,
            changeYear: !1,
            yearRange: "c-10:c+10",
            showOtherMonths: !1,
            selectOtherMonths: !1,
            showWeek: !1,
            calculateWeek: this.iso8601Week,
            shortYearCutoff: "+10",
            minDate: null,
            maxDate: null,
            duration: "fast",
            beforeShowDay: null,
            beforeShow: null,
            onSelect: null,
            onChangeMonthYear: null,
            onClose: null,
            onUpdateDatepicker: null,
            numberOfMonths: 1,
            showCurrentAtPos: 0,
            stepMonths: 1,
            stepBigMonths: 12,
            altField: "",
            altFormat: "",
            constrainInput: !0,
            showButtonPanel: !1,
            autoSize: !1,
            disabled: !1
        }, V.extend(this._defaults, this.regional[""]), this.regional.en = V.extend(!0, {}, this.regional[""]), this.regional["en-US"] = V.extend(!0, {}, this.regional.en), this.dpDiv = q(V("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"))
    }

    function q(t) {
        var e = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
        return t.on("mouseout", e, function() {
            V(this).removeClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && V(this).removeClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && V(this).removeClass("ui-datepicker-next-hover")
        }).on("mouseover", e, U)
    }

    function U() {
        V.datepicker._isDisabledDatepicker((d.inline ? d.dpDiv.parent() : d.input)[0]) || (V(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"), V(this).addClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && V(this).addClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && V(this).addClass("ui-datepicker-next-hover"))
    }

    function f(t, e) {
        for (var i in V.extend(t, e), e) null == e[i] && (t[i] = e[i])
    }

    function m(e) {
        return function() {
            var t = this.element.val();
            e.apply(this, arguments), this._refresh(), t !== this.element.val() && this._trigger("change")
        }
    }
    V.widget("ui.controlgroup", {
        version: "1.13.0",
        defaultElement: "<div>",
        options: {
            direction: "horizontal",
            disabled: null,
            onlyVisible: !0,
            items: {
                button: "input[type=button], input[type=submit], input[type=reset], button, a",
                controlgroupLabel: ".ui-controlgroup-label",
                checkboxradio: "input[type='checkbox'], input[type='radio']",
                selectmenu: "select",
                spinner: ".ui-spinner-input"
            }
        },
        _create: function() {
            this._enhance()
        },
        _enhance: function() {
            this.element.attr("role", "toolbar"), this.refresh()
        },
        _destroy: function() {
            this._callChildMethod("destroy"), this.childWidgets.removeData("ui-controlgroup-data"), this.element.removeAttr("role"), this.options.items.controlgroupLabel && this.element.find(this.options.items.controlgroupLabel).find(".ui-controlgroup-label-contents").contents().unwrap()
        },
        _initWidgets: function() {
            var o = this,
                a = [];
            V.each(this.options.items, function(s, t) {
                var e, n;
                if (t) return "controlgroupLabel" === s ? ((e = o.element.find(t)).each(function() {
                    var t = V(this);
                    t.children(".ui-controlgroup-label-contents").length || t.contents().wrapAll("<span class='ui-controlgroup-label-contents'></span>")
                }), o._addClass(e, null, "ui-widget ui-widget-content ui-state-default"), void(a = a.concat(e.get()))) : void(V.fn[s] && (n = o["_" + s + "Options"] ? o["_" + s + "Options"]("middle") : {
                    classes: {}
                }, o.element.find(t).each(function() {
                    var t = V(this),
                        e = t[s]("instance"),
                        i = V.widget.extend({}, n);
                    "button" === s && t.parent(".ui-spinner").length || ((e = e || t[s]()[s]("instance")) && (i.classes = o._resolveClassesValues(i.classes, e)), t[s](i), i = t[s]("widget"), V.data(i[0], "ui-controlgroup-data", e || t[s]("instance")), a.push(i[0]))
                })))
            }), this.childWidgets = V(V.uniqueSort(a)), this._addClass(this.childWidgets, "ui-controlgroup-item")
        },
        _callChildMethod: function(e) {
            this.childWidgets.each(function() {
                var t = V(this).data("ui-controlgroup-data");
                t && t[e] && t[e]()
            })
        },
        _updateCornerClass: function(t, e) {
            e = this._buildSimpleOptions(e, "label").classes.label, this._removeClass(t, null, "ui-corner-top ui-corner-bottom ui-corner-left ui-corner-right ui-corner-all"), this._addClass(t, null, e)
        },
        _buildSimpleOptions: function(t, e) {
            var i = "vertical" === this.options.direction,
                s = {
                    classes: {}
                };
            return s.classes[e] = {
                middle: "",
                first: "ui-corner-" + (i ? "top" : "left"),
                last: "ui-corner-" + (i ? "bottom" : "right"),
                only: "ui-corner-all"
            }[t], s
        },
        _spinnerOptions: function(t) {
            return (t = this._buildSimpleOptions(t, "ui-spinner")).classes["ui-spinner-up"] = "", t.classes["ui-spinner-down"] = "", t
        },
        _buttonOptions: function(t) {
            return this._buildSimpleOptions(t, "ui-button")
        },
        _checkboxradioOptions: function(t) {
            return this._buildSimpleOptions(t, "ui-checkboxradio-label")
        },
        _selectmenuOptions: function(t) {
            var e = "vertical" === this.options.direction;
            return {
                width: e && "auto",
                classes: {
                    middle: {
                        "ui-selectmenu-button-open": "",
                        "ui-selectmenu-button-closed": ""
                    },
                    first: {
                        "ui-selectmenu-button-open": "ui-corner-" + (e ? "top" : "tl"),
                        "ui-selectmenu-button-closed": "ui-corner-" + (e ? "top" : "left")
                    },
                    last: {
                        "ui-selectmenu-button-open": e ? "" : "ui-corner-tr",
                        "ui-selectmenu-button-closed": "ui-corner-" + (e ? "bottom" : "right")
                    },
                    only: {
                        "ui-selectmenu-button-open": "ui-corner-top",
                        "ui-selectmenu-button-closed": "ui-corner-all"
                    }
                }[t]
            }
        },
        _resolveClassesValues: function(i, s) {
            var n = {};
            return V.each(i, function(t) {
                var e = s.options.classes[t] || "",
                    e = String.prototype.trim.call(e.replace(B, ""));
                n[t] = (e + " " + i[t]).replace(/\s+/g, " ")
            }), n
        },
        _setOption: function(t, e) {
            "direction" === t && this._removeClass("ui-controlgroup-" + this.options.direction), this._super(t, e), "disabled" !== t ? this.refresh() : this._callChildMethod(e ? "disable" : "enable")
        },
        refresh: function() {
            var n, o = this;
            this._addClass("ui-controlgroup ui-controlgroup-" + this.options.direction), "horizontal" === this.options.direction && this._addClass(null, "ui-helper-clearfix"), this._initWidgets(), n = this.childWidgets, (n = this.options.onlyVisible ? n.filter(":visible") : n).length && (V.each(["first", "last"], function(t, e) {
                var i, s = n[e]().data("ui-controlgroup-data");
                s && o["_" + s.widgetName + "Options"] ? ((i = o["_" + s.widgetName + "Options"](1 === n.length ? "only" : e)).classes = o._resolveClassesValues(i.classes, s), s.element[s.widgetName](i)) : o._updateCornerClass(n[e](), e)
            }), this._callChildMethod("refresh"))
        }
    }), V.widget("ui.checkboxradio", [V.ui.formResetMixin, {
        version: "1.13.0",
        options: {
            disabled: null,
            label: null,
            icon: !0,
            classes: {
                "ui-checkboxradio-label": "ui-corner-all",
                "ui-checkboxradio-icon": "ui-corner-all"
            }
        },
        _getCreateOptions: function() {
            var t, e = this,
                i = this._super() || {};
            return this._readType(), t = this.element.labels(), this.label = V(t[t.length - 1]), this.label.length || V.error("No label found for checkboxradio widget"), this.originalLabel = "", this.label.contents().not(this.element[0]).each(function() {
                e.originalLabel += 3 === this.nodeType ? V(this).text() : this.outerHTML
            }), this.originalLabel && (i.label = this.originalLabel), null != (t = this.element[0].disabled) && (i.disabled = t), i
        },
        _create: function() {
            var t = this.element[0].checked;
            this._bindFormResetHandler(), null == this.options.disabled && (this.options.disabled = this.element[0].disabled), this._setOption("disabled", this.options.disabled), this._addClass("ui-checkboxradio", "ui-helper-hidden-accessible"), this._addClass(this.label, "ui-checkboxradio-label", "ui-button ui-widget"), "radio" === this.type && this._addClass(this.label, "ui-checkboxradio-radio-label"), this.options.label && this.options.label !== this.originalLabel ? this._updateLabel() : this.originalLabel && (this.options.label = this.originalLabel), this._enhance(), t && this._addClass(this.label, "ui-checkboxradio-checked", "ui-state-active"), this._on({
                change: "_toggleClasses",
                focus: function() {
                    this._addClass(this.label, null, "ui-state-focus ui-visual-focus")
                },
                blur: function() {
                    this._removeClass(this.label, null, "ui-state-focus ui-visual-focus")
                }
            })
        },
        _readType: function() {
            var t = this.element[0].nodeName.toLowerCase();
            this.type = this.element[0].type, "input" === t && /radio|checkbox/.test(this.type) || V.error("Can't create checkboxradio on element.nodeName=" + t + " and element.type=" + this.type)
        },
        _enhance: function() {
            this._updateIcon(this.element[0].checked)
        },
        widget: function() {
            return this.label
        },
        _getRadioGroup: function() {
            var t = this.element[0].name,
                e = "input[name='" + V.escapeSelector(t) + "']";
            return t ? (this.form.length ? V(this.form[0].elements).filter(e) : V(e).filter(function() {
                return 0 === V(this)._form().length
            })).not(this.element) : V([])
        },
        _toggleClasses: function() {
            var t = this.element[0].checked;
            this._toggleClass(this.label, "ui-checkboxradio-checked", "ui-state-active", t), this.options.icon && "checkbox" === this.type && this._toggleClass(this.icon, null, "ui-icon-check ui-state-checked", t)._toggleClass(this.icon, null, "ui-icon-blank", !t), "radio" === this.type && this._getRadioGroup().each(function() {
                var t = V(this).checkboxradio("instance");
                t && t._removeClass(t.label, "ui-checkboxradio-checked", "ui-state-active")
            })
        },
        _destroy: function() {
            this._unbindFormResetHandler(), this.icon && (this.icon.remove(), this.iconSpace.remove())
        },
        _setOption: function(t, e) {
            "label" === t && !e || (this._super(t, e), "disabled" === t ? (this._toggleClass(this.label, null, "ui-state-disabled", e), this.element[0].disabled = e) : this.refresh())
        },
        _updateIcon: function(t) {
            var e = "ui-icon ui-icon-background ";
            this.options.icon ? (this.icon || (this.icon = V("<span>"), this.iconSpace = V("<span> </span>"), this._addClass(this.iconSpace, "ui-checkboxradio-icon-space")), "checkbox" === this.type ? (e += t ? "ui-icon-check ui-state-checked" : "ui-icon-blank", this._removeClass(this.icon, null, t ? "ui-icon-blank" : "ui-icon-check")) : e += "ui-icon-blank", this._addClass(this.icon, "ui-checkboxradio-icon", e), t || this._removeClass(this.icon, null, "ui-icon-check ui-state-checked"), this.icon.prependTo(this.label).after(this.iconSpace)) : void 0 !== this.icon && (this.icon.remove(), this.iconSpace.remove(), delete this.icon)
        },
        _updateLabel: function() {
            var t = this.label.contents().not(this.element[0]);
            this.icon && (t = t.not(this.icon[0])), (t = this.iconSpace ? t.not(this.iconSpace[0]) : t).remove(), this.label.append(this.options.label)
        },
        refresh: function() {
            var t = this.element[0].checked,
                e = this.element[0].disabled;
            this._updateIcon(t), this._toggleClass(this.label, "ui-checkboxradio-checked", "ui-state-active", t), null !== this.options.label && this._updateLabel(), e !== this.options.disabled && this._setOptions({
                disabled: e
            })
        }
    }]), V.ui.checkboxradio, V.widget("ui.button", {
        version: "1.13.0",
        defaultElement: "<button>",
        options: {
            classes: {
                "ui-button": "ui-corner-all"
            },
            disabled: null,
            icon: null,
            iconPosition: "beginning",
            label: null,
            showLabel: !0
        },
        _getCreateOptions: function() {
            var t, e = this._super() || {};
            return this.isInput = this.element.is("input"), null != (t = this.element[0].disabled) && (e.disabled = t), this.originalLabel = this.isInput ? this.element.val() : this.element.html(), this.originalLabel && (e.label = this.originalLabel), e
        },
        _create: function() {
            !this.option.showLabel & !this.options.icon && (this.options.showLabel = !0), null == this.options.disabled && (this.options.disabled = this.element[0].disabled || !1), this.hasTitle = !!this.element.attr("title"), this.options.label && this.options.label !== this.originalLabel && (this.isInput ? this.element.val(this.options.label) : this.element.html(this.options.label)), this._addClass("ui-button", "ui-widget"), this._setOption("disabled", this.options.disabled), this._enhance(), this.element.is("a") && this._on({
                keyup: function(t) {
                    t.keyCode === V.ui.keyCode.SPACE && (t.preventDefault(), this.element[0].click ? this.element[0].click() : this.element.trigger("click"))
                }
            })
        },
        _enhance: function() {
            this.element.is("button") || this.element.attr("role", "button"), this.options.icon && (this._updateIcon("icon", this.options.icon), this._updateTooltip())
        },
        _updateTooltip: function() {
            this.title = this.element.attr("title"), this.options.showLabel || this.title || this.element.attr("title", this.options.label)
        },
        _updateIcon: function(t, e) {
            var i = "iconPosition" !== t,
                s = i ? this.options.iconPosition : e,
                t = "top" === s || "bottom" === s;
            this.icon ? i && this._removeClass(this.icon, null, this.options.icon) : (this.icon = V("<span>"), this._addClass(this.icon, "ui-button-icon", "ui-icon"), this.options.showLabel || this._addClass("ui-button-icon-only")), i && this._addClass(this.icon, null, e), this._attachIcon(s), t ? (this._addClass(this.icon, null, "ui-widget-icon-block"), this.iconSpace && this.iconSpace.remove()) : (this.iconSpace || (this.iconSpace = V("<span> </span>"), this._addClass(this.iconSpace, "ui-button-icon-space")), this._removeClass(this.icon, null, "ui-wiget-icon-block"), this._attachIconSpace(s))
        },
        _destroy: function() {
            this.element.removeAttr("role"), this.icon && this.icon.remove(), this.iconSpace && this.iconSpace.remove(), this.hasTitle || this.element.removeAttr("title")
        },
        _attachIconSpace: function(t) {
            this.icon[/^(?:end|bottom)/.test(t) ? "before" : "after"](this.iconSpace)
        },
        _attachIcon: function(t) {
            this.element[/^(?:end|bottom)/.test(t) ? "append" : "prepend"](this.icon)
        },
        _setOptions: function(t) {
            var e = (void 0 === t.showLabel ? this.options : t).showLabel,
                i = (void 0 === t.icon ? this.options : t).icon;
            e || i || (t.showLabel = !0), this._super(t)
        },
        _setOption: function(t, e) {
            "icon" === t && (e ? this._updateIcon(t, e) : this.icon && (this.icon.remove(), this.iconSpace) && this.iconSpace.remove()), "iconPosition" === t && this._updateIcon(t, e), "showLabel" === t && (this._toggleClass("ui-button-icon-only", null, !e), this._updateTooltip()), "label" === t && (this.isInput ? this.element.val(e) : (this.element.html(e), this.icon && (this._attachIcon(this.options.iconPosition), this._attachIconSpace(this.options.iconPosition)))), this._super(t, e), "disabled" === t && (this._toggleClass(null, "ui-state-disabled", e), this.element[0].disabled = e) && this.element.trigger("blur")
        },
        refresh: function() {
            var t = this.element.is("input, button") ? this.element[0].disabled : this.element.hasClass("ui-button-disabled");
            t !== this.options.disabled && this._setOptions({
                disabled: t
            }), this._updateTooltip()
        }
    }), !1 !== V.uiBackCompat && (V.widget("ui.button", V.ui.button, {
        options: {
            text: !0,
            icons: {
                primary: null,
                secondary: null
            }
        },
        _create: function() {
            this.options.showLabel && !this.options.text && (this.options.showLabel = this.options.text), !this.options.showLabel && this.options.text && (this.options.text = this.options.showLabel), this.options.icon || !this.options.icons.primary && !this.options.icons.secondary ? this.options.icon && (this.options.icons.primary = this.options.icon) : this.options.icons.primary ? this.options.icon = this.options.icons.primary : (this.options.icon = this.options.icons.secondary, this.options.iconPosition = "end"), this._super()
        },
        _setOption: function(t, e) {
            "text" !== t ? ("showLabel" === t && (this.options.text = e), "icon" === t && (this.options.icons.primary = e), "icons" === t && (e.primary ? (this._super("icon", e.primary), this._super("iconPosition", "beginning")) : e.secondary && (this._super("icon", e.secondary), this._super("iconPosition", "end"))), this._superApply(arguments)) : this._super("showLabel", e)
        }
    }), V.fn.button = (j = V.fn.button, function(i) {
        var t = "string" == typeof i,
            s = Array.prototype.slice.call(arguments, 1),
            n = this;
        return t ? this.length || "instance" !== i ? this.each(function() {
            var t = V(this).attr("type"),
                e = V.data(this, "ui-" + ("checkbox" !== t && "radio" !== t ? "button" : "checkboxradio"));
            return "instance" === i ? (n = e, !1) : e ? "function" != typeof e[i] || "_" === i.charAt(0) ? V.error("no such method '" + i + "' for button widget instance") : (t = e[i].apply(e, s)) !== e && void 0 !== t ? (n = t && t.jquery ? n.pushStack(t.get()) : t, !1) : void 0 : V.error("cannot call methods on button prior to initialization; attempted to call method '" + i + "'")
        }) : n = void 0 : (s.length && (i = V.widget.extend.apply(null, [i].concat(s))), this.each(function() {
            var t = V(this).attr("type"),
                e = "checkbox" !== t && "radio" !== t ? "button" : "checkboxradio";
            (t = V.data(this, "ui-" + e)) ? (t.option(i || {}), t._init && t._init()) : "button" != e ? V(this).checkboxradio(V.extend({
                icon: !1
            }, i)) : j.call(V(this), i)
        })), n
    }), V.fn.buttonset = function() {
        return V.ui.controlgroup || V.error("Controlgroup widget missing"), "option" === arguments[0] && "items" === arguments[1] && arguments[2] ? this.controlgroup.apply(this, [arguments[0], "items.button", arguments[2]]) : "option" === arguments[0] && "items" === arguments[1] ? this.controlgroup.apply(this, [arguments[0], "items.button"]) : ("object" == typeof arguments[0] && arguments[0].items && (arguments[0].items = {
            button: arguments[0].items
        }), this.controlgroup.apply(this, arguments))
    }), V.ui.button, V.extend(V.ui, {
        datepicker: {
            version: "1.13.0"
        }
    }), V.extend(Y.prototype, {
        markerClassName: "hasDatepicker",
        maxRows: 4,
        _widgetDatepicker: function() {
            return this.dpDiv
        },
        setDefaults: function(t) {
            return f(this._defaults, t || {}), this
        },
        _attachDatepicker: function(t, e) {
            var i, s = t.nodeName.toLowerCase(),
                n = "div" === s || "span" === s;
            t.id || (this.uuid += 1, t.id = "dp" + this.uuid), (i = this._newInst(V(t), n)).settings = V.extend({}, e || {}), "input" === s ? this._connectDatepicker(t, i) : n && this._inlineDatepicker(t, i)
        },
        _newInst: function(t, e) {
            return {
                id: t[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1"),
                input: t,
                selectedDay: 0,
                selectedMonth: 0,
                selectedYear: 0,
                drawMonth: 0,
                drawYear: 0,
                inline: e,
                dpDiv: e ? q(V("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv
            }
        },
        _connectDatepicker: function(t, e) {
            var i = V(t);
            e.append = V([]), e.trigger = V([]), i.hasClass(this.markerClassName) || (this._attachments(i, e), i.addClass(this.markerClassName).on("keydown", this._doKeyDown).on("keypress", this._doKeyPress).on("keyup", this._doKeyUp), this._autoSize(e), V.data(t, "datepicker", e), e.settings.disabled && this._disableDatepicker(t))
        },
        _attachments: function(t, e) {
            var i, s = this._get(e, "appendText"),
                n = this._get(e, "isRTL");
            e.append && e.append.remove(), s && (e.append = V("<span>").addClass(this._appendClass).text(s), t[n ? "before" : "after"](e.append)), t.off("focus", this._showDatepicker), e.trigger && e.trigger.remove(), "focus" !== (i = this._get(e, "showOn")) && "both" !== i || t.on("focus", this._showDatepicker), "button" !== i && "both" !== i || (s = this._get(e, "buttonText"), i = this._get(e, "buttonImage"), this._get(e, "buttonImageOnly") ? e.trigger = V("<img>").addClass(this._triggerClass).attr({
                src: i,
                alt: s,
                title: s
            }) : (e.trigger = V("<button type='button'>").addClass(this._triggerClass), i ? e.trigger.html(V("<img>").attr({
                src: i,
                alt: s,
                title: s
            })) : e.trigger.text(s)), t[n ? "before" : "after"](e.trigger), e.trigger.on("click", function() {
                return V.datepicker._datepickerShowing && V.datepicker._lastInput === t[0] ? V.datepicker._hideDatepicker() : (V.datepicker._datepickerShowing && V.datepicker._lastInput !== t[0] && V.datepicker._hideDatepicker(), V.datepicker._showDatepicker(t[0])), !1
            }))
        },
        _autoSize: function(t) {
            var e, i, s, n, o, a;
            this._get(t, "autoSize") && !t.inline && (o = new Date(2009, 11, 20), (a = this._get(t, "dateFormat")).match(/[DM]/) && (o.setMonth((e = function(t) {
                for (n = s = i = 0; n < t.length; n++) t[n].length > i && (i = t[n].length, s = n);
                return s
            })(this._get(t, a.match(/MM/) ? "monthNames" : "monthNamesShort"))), o.setDate(e(this._get(t, a.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - o.getDay())), t.input.attr("size", this._formatDate(t, o).length))
        },
        _inlineDatepicker: function(t, e) {
            var i = V(t);
            i.hasClass(this.markerClassName) || (i.addClass(this.markerClassName).append(e.dpDiv), V.data(t, "datepicker", e), this._setDate(e, this._getDefaultDate(e), !0), this._updateDatepicker(e), this._updateAlternate(e), e.settings.disabled && this._disableDatepicker(t), e.dpDiv.css("display", "block"))
        },
        _dialogDatepicker: function(t, e, i, s, n) {
            var o, a = this._dialogInst;
            return a || (this.uuid += 1, o = "dp" + this.uuid, this._dialogInput = V("<input type='text' id='" + o + "' style='position: absolute; top: -100px; width: 0px;'/>"), this._dialogInput.on("keydown", this._doKeyDown), V("body").append(this._dialogInput), (a = this._dialogInst = this._newInst(this._dialogInput, !1)).settings = {}, V.data(this._dialogInput[0], "datepicker", a)), f(a.settings, s || {}), e = e && e.constructor === Date ? this._formatDate(a, e) : e, this._dialogInput.val(e), this._pos = n ? n.length ? n : [n.pageX, n.pageY] : null, this._pos || (o = document.documentElement.clientWidth, s = document.documentElement.clientHeight, e = document.documentElement.scrollLeft || document.body.scrollLeft, n = document.documentElement.scrollTop || document.body.scrollTop, this._pos = [o / 2 - 100 + e, s / 2 - 150 + n]), this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"), a.settings.onSelect = i, this._inDialog = !0, this.dpDiv.addClass(this._dialogClass), this._showDatepicker(this._dialogInput[0]), V.blockUI && V.blockUI(this.dpDiv), V.data(this._dialogInput[0], "datepicker", a), this
        },
        _destroyDatepicker: function(t) {
            var e, i = V(t),
                s = V.data(t, "datepicker");
            i.hasClass(this.markerClassName) && (e = t.nodeName.toLowerCase(), V.removeData(t, "datepicker"), "input" === e ? (s.append.remove(), s.trigger.remove(), i.removeClass(this.markerClassName).off("focus", this._showDatepicker).off("keydown", this._doKeyDown).off("keypress", this._doKeyPress).off("keyup", this._doKeyUp)) : "div" !== e && "span" !== e || i.removeClass(this.markerClassName).empty(), d === s) && (d = null, this._curInst = null)
        },
        _enableDatepicker: function(e) {
            var t, i = V(e),
                s = V.data(e, "datepicker");
            i.hasClass(this.markerClassName) && ("input" === (t = e.nodeName.toLowerCase()) ? (e.disabled = !1, s.trigger.filter("button").each(function() {
                this.disabled = !1
            }).end().filter("img").css({
                opacity: "1.0",
                cursor: ""
            })) : "div" !== t && "span" !== t || ((i = i.children("." + this._inlineClass)).children().removeClass("ui-state-disabled"), i.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1)), this._disabledInputs = V.map(this._disabledInputs, function(t) {
                return t === e ? null : t
            }))
        },
        _disableDatepicker: function(e) {
            var t, i = V(e),
                s = V.data(e, "datepicker");
            i.hasClass(this.markerClassName) && ("input" === (t = e.nodeName.toLowerCase()) ? (e.disabled = !0, s.trigger.filter("button").each(function() {
                this.disabled = !0
            }).end().filter("img").css({
                opacity: "0.5",
                cursor: "default"
            })) : "div" !== t && "span" !== t || ((i = i.children("." + this._inlineClass)).children().addClass("ui-state-disabled"), i.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0)), this._disabledInputs = V.map(this._disabledInputs, function(t) {
                return t === e ? null : t
            }), this._disabledInputs[this._disabledInputs.length] = e)
        },
        _isDisabledDatepicker: function(t) {
            if (t)
                for (var e = 0; e < this._disabledInputs.length; e++)
                    if (this._disabledInputs[e] === t) return !0;
            return !1
        },
        _getInst: function(t) {
            try {
                return V.data(t, "datepicker")
            } catch (t) {
                throw "Missing instance data for this datepicker"
            }
        },
        _optionDatepicker: function(t, e, i) {
            var s, n, o = this._getInst(t);
            if (2 === arguments.length && "string" == typeof e) return "defaults" === e ? V.extend({}, V.datepicker._defaults) : o ? "all" === e ? V.extend({}, o.settings) : this._get(o, e) : null;
            s = e || {}, "string" == typeof e && ((s = {})[e] = i), o && (this._curInst === o && this._hideDatepicker(), n = this._getDateDatepicker(t, !0), e = this._getMinMaxDate(o, "min"), i = this._getMinMaxDate(o, "max"), f(o.settings, s), null !== e && void 0 !== s.dateFormat && void 0 === s.minDate && (o.settings.minDate = this._formatDate(o, e)), null !== i && void 0 !== s.dateFormat && void 0 === s.maxDate && (o.settings.maxDate = this._formatDate(o, i)), "disabled" in s && (s.disabled ? this._disableDatepicker(t) : this._enableDatepicker(t)), this._attachments(V(t), o), this._autoSize(o), this._setDate(o, n), this._updateAlternate(o), this._updateDatepicker(o))
        },
        _changeDatepicker: function(t, e, i) {
            this._optionDatepicker(t, e, i)
        },
        _refreshDatepicker: function(t) {
            (t = this._getInst(t)) && this._updateDatepicker(t)
        },
        _setDateDatepicker: function(t, e) {
            (t = this._getInst(t)) && (this._setDate(t, e), this._updateDatepicker(t), this._updateAlternate(t))
        },
        _getDateDatepicker: function(t, e) {
            return (t = this._getInst(t)) && !t.inline && this._setDateFromField(t, e), t ? this._getDate(t) : null
        },
        _doKeyDown: function(t) {
            var e, i, s = V.datepicker._getInst(t.target),
                n = !0,
                o = s.dpDiv.is(".ui-datepicker-rtl");
            if (s._keyEvent = !0, V.datepicker._datepickerShowing) switch (t.keyCode) {
                case 9:
                    V.datepicker._hideDatepicker(), n = !1;
                    break;
                case 13:
                    return (i = V("td." + V.datepicker._dayOverClass + ":not(." + V.datepicker._currentClass + ")", s.dpDiv))[0] && V.datepicker._selectDay(t.target, s.selectedMonth, s.selectedYear, i[0]), (e = V.datepicker._get(s, "onSelect")) ? (i = V.datepicker._formatDate(s), e.apply(s.input ? s.input[0] : null, [i, s])) : V.datepicker._hideDatepicker(), !1;
                case 27:
                    V.datepicker._hideDatepicker();
                    break;
                case 33:
                    V.datepicker._adjustDate(t.target, t.ctrlKey ? -V.datepicker._get(s, "stepBigMonths") : -V.datepicker._get(s, "stepMonths"), "M");
                    break;
                case 34:
                    V.datepicker._adjustDate(t.target, t.ctrlKey ? +V.datepicker._get(s, "stepBigMonths") : +V.datepicker._get(s, "stepMonths"), "M");
                    break;
                case 35:
                    (t.ctrlKey || t.metaKey) && V.datepicker._clearDate(t.target), n = t.ctrlKey || t.metaKey;
                    break;
                case 36:
                    (t.ctrlKey || t.metaKey) && V.datepicker._gotoToday(t.target), n = t.ctrlKey || t.metaKey;
                    break;
                case 37:
                    (t.ctrlKey || t.metaKey) && V.datepicker._adjustDate(t.target, o ? 1 : -1, "D"), n = t.ctrlKey || t.metaKey, t.originalEvent.altKey && V.datepicker._adjustDate(t.target, t.ctrlKey ? -V.datepicker._get(s, "stepBigMonths") : -V.datepicker._get(s, "stepMonths"), "M");
                    break;
                case 38:
                    (t.ctrlKey || t.metaKey) && V.datepicker._adjustDate(t.target, -7, "D"), n = t.ctrlKey || t.metaKey;
                    break;
                case 39:
                    (t.ctrlKey || t.metaKey) && V.datepicker._adjustDate(t.target, o ? -1 : 1, "D"), n = t.ctrlKey || t.metaKey, t.originalEvent.altKey && V.datepicker._adjustDate(t.target, t.ctrlKey ? +V.datepicker._get(s, "stepBigMonths") : +V.datepicker._get(s, "stepMonths"), "M");
                    break;
                case 40:
                    (t.ctrlKey || t.metaKey) && V.datepicker._adjustDate(t.target, 7, "D"), n = t.ctrlKey || t.metaKey;
                    break;
                default:
                    n = !1
            } else 36 === t.keyCode && t.ctrlKey ? V.datepicker._showDatepicker(this) : n = !1;
            n && (t.preventDefault(), t.stopPropagation())
        },
        _doKeyPress: function(t) {
            var e, i = V.datepicker._getInst(t.target);
            if (V.datepicker._get(i, "constrainInput")) return e = V.datepicker._possibleChars(V.datepicker._get(i, "dateFormat")), i = String.fromCharCode(null == t.charCode ? t.keyCode : t.charCode), t.ctrlKey || t.metaKey || i < " " || !e || -1 < e.indexOf(i)
        },
        _doKeyUp: function(t) {
            if ((t = V.datepicker._getInst(t.target)).input.val() !== t.lastVal) try {
                V.datepicker.parseDate(V.datepicker._get(t, "dateFormat"), t.input ? t.input.val() : null, V.datepicker._getFormatConfig(t)) && (V.datepicker._setDateFromField(t), V.datepicker._updateAlternate(t), V.datepicker._updateDatepicker(t))
            } catch (t) {}
            return !0
        },
        _showDatepicker: function(t) {
            var e, i, s, n;
            "input" !== (t = t.target || t).nodeName.toLowerCase() && (t = V("input", t.parentNode)[0]), V.datepicker._isDisabledDatepicker(t) || V.datepicker._lastInput === t || (n = V.datepicker._getInst(t), V.datepicker._curInst && V.datepicker._curInst !== n && (V.datepicker._curInst.dpDiv.stop(!0, !0), n) && V.datepicker._datepickerShowing && V.datepicker._hideDatepicker(V.datepicker._curInst.input[0]), !1 !== (i = (s = V.datepicker._get(n, "beforeShow")) ? s.apply(t, [t, n]) : {}) && (f(n.settings, i), n.lastVal = null, V.datepicker._lastInput = t, V.datepicker._setDateFromField(n), V.datepicker._inDialog && (t.value = ""), V.datepicker._pos || (V.datepicker._pos = V.datepicker._findPos(t), V.datepicker._pos[1] += t.offsetHeight), e = !1, V(t).parents().each(function() {
                return !(e |= "fixed" === V(this).css("position"))
            }), s = {
                left: V.datepicker._pos[0],
                top: V.datepicker._pos[1]
            }, V.datepicker._pos = null, n.dpDiv.empty(), n.dpDiv.css({
                position: "absolute",
                display: "block",
                top: "-1000px"
            }), V.datepicker._updateDatepicker(n), s = V.datepicker._checkOffset(n, s, e), n.dpDiv.css({
                position: V.datepicker._inDialog && V.blockUI ? "static" : e ? "fixed" : "absolute",
                display: "none",
                left: s.left + "px",
                top: s.top + "px"
            }), n.inline || (i = V.datepicker._get(n, "showAnim"), s = V.datepicker._get(n, "duration"), n.dpDiv.css("z-index", function(t) {
                for (var e; t.length && t[0] !== document;) {
                    if (("absolute" === (e = t.css("position")) || "relative" === e || "fixed" === e) && (e = parseInt(t.css("zIndex"), 10), !isNaN(e)) && 0 !== e) return e;
                    t = t.parent()
                }
                return 0
            }(V(t)) + 1), V.datepicker._datepickerShowing = !0, V.effects && V.effects.effect[i] ? n.dpDiv.show(i, V.datepicker._get(n, "showOptions"), s) : n.dpDiv[i || "show"](i ? s : null), V.datepicker._shouldFocusInput(n) && n.input.trigger("focus"), V.datepicker._curInst = n)))
        },
        _updateDatepicker: function(t) {
            this.maxRows = 4, (d = t).dpDiv.empty().append(this._generateHTML(t)), this._attachHandlers(t);
            var e, i = this._getNumberOfMonths(t),
                s = i[1],
                n = t.dpDiv.find("." + this._dayOverClass + " a"),
                o = V.datepicker._get(t, "onUpdateDatepicker");
            0 < n.length && U.apply(n.get(0)), t.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""), 1 < s && t.dpDiv.addClass("ui-datepicker-multi-" + s).css("width", 17 * s + "em"), t.dpDiv[(1 !== i[0] || 1 !== i[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"), t.dpDiv[(this._get(t, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"), t === V.datepicker._curInst && V.datepicker._datepickerShowing && V.datepicker._shouldFocusInput(t) && t.input.trigger("focus"), t.yearshtml && (e = t.yearshtml, setTimeout(function() {
                e === t.yearshtml && t.yearshtml && t.dpDiv.find("select.ui-datepicker-year").first().replaceWith(t.yearshtml), e = t.yearshtml = null
            }, 0)), o && o.apply(t.input ? t.input[0] : null, [t])
        },
        _shouldFocusInput: function(t) {
            return t.input && t.input.is(":visible") && !t.input.is(":disabled") && !t.input.is(":focus")
        },
        _checkOffset: function(t, e, i) {
            var s = t.dpDiv.outerWidth(),
                n = t.dpDiv.outerHeight(),
                o = t.input ? t.input.outerWidth() : 0,
                a = t.input ? t.input.outerHeight() : 0,
                r = document.documentElement.clientWidth + (i ? 0 : V(document).scrollLeft()),
                l = document.documentElement.clientHeight + (i ? 0 : V(document).scrollTop());
            return e.left -= this._get(t, "isRTL") ? s - o : 0, e.left -= i && e.left === t.input.offset().left ? V(document).scrollLeft() : 0, e.top -= i && e.top === t.input.offset().top + a ? V(document).scrollTop() : 0, e.left -= Math.min(e.left, e.left + s > r && s < r ? Math.abs(e.left + s - r) : 0), e.top -= Math.min(e.top, e.top + n > l && n < l ? Math.abs(n + a) : 0), e
        },
        _findPos: function(t) {
            for (var e = this._getInst(t), i = this._get(e, "isRTL"); t && ("hidden" === t.type || 1 !== t.nodeType || V.expr.pseudos.hidden(t));) t = t[i ? "previousSibling" : "nextSibling"];
            return [(e = V(t).offset()).left, e.top]
        },
        _hideDatepicker: function(t) {
            var e, i, s = this._curInst;
            !s || t && s !== V.data(t, "datepicker") || this._datepickerShowing && (e = this._get(s, "showAnim"), i = this._get(s, "duration"), t = function() {
                V.datepicker._tidyDialog(s)
            }, V.effects && (V.effects.effect[e] || V.effects[e]) ? s.dpDiv.hide(e, V.datepicker._get(s, "showOptions"), i, t) : s.dpDiv["slideDown" === e ? "slideUp" : "fadeIn" === e ? "fadeOut" : "hide"](e ? i : null, t), e || t(), this._datepickerShowing = !1, (t = this._get(s, "onClose")) && t.apply(s.input ? s.input[0] : null, [s.input ? s.input.val() : "", s]), this._lastInput = null, this._inDialog && (this._dialogInput.css({
                position: "absolute",
                left: "0",
                top: "-100px"
            }), V.blockUI) && (V.unblockUI(), V("body").append(this.dpDiv)), this._inDialog = !1)
        },
        _tidyDialog: function(t) {
            t.dpDiv.removeClass(this._dialogClass).off(".ui-datepicker-calendar")
        },
        _checkExternalClick: function(t) {
            var e;
            V.datepicker._curInst && (e = V(t.target), t = V.datepicker._getInst(e[0]), !(e[0].id === V.datepicker._mainDivId || 0 !== e.parents("#" + V.datepicker._mainDivId).length || e.hasClass(V.datepicker.markerClassName) || e.closest("." + V.datepicker._triggerClass).length || !V.datepicker._datepickerShowing || V.datepicker._inDialog && V.blockUI) || e.hasClass(V.datepicker.markerClassName) && V.datepicker._curInst !== t) && V.datepicker._hideDatepicker()
        },
        _adjustDate: function(t, e, i) {
            var s = V(t),
                t = this._getInst(s[0]);
            this._isDisabledDatepicker(s[0]) || (this._adjustInstDate(t, e, i), this._updateDatepicker(t))
        },
        _gotoToday: function(t) {
            var e = V(t),
                i = this._getInst(e[0]);
            this._get(i, "gotoCurrent") && i.currentDay ? (i.selectedDay = i.currentDay, i.drawMonth = i.selectedMonth = i.currentMonth, i.drawYear = i.selectedYear = i.currentYear) : (t = new Date, i.selectedDay = t.getDate(), i.drawMonth = i.selectedMonth = t.getMonth(), i.drawYear = i.selectedYear = t.getFullYear()), this._notifyChange(i), this._adjustDate(e)
        },
        _selectMonthYear: function(t, e, i) {
            var s = V(t);
            (t = this._getInst(s[0]))["selected" + ("M" === i ? "Month" : "Year")] = t["draw" + ("M" === i ? "Month" : "Year")] = parseInt(e.options[e.selectedIndex].value, 10), this._notifyChange(t), this._adjustDate(s)
        },
        _selectDay: function(t, e, i, s) {
            var n = V(t);
            V(s).hasClass(this._unselectableClass) || this._isDisabledDatepicker(n[0]) || ((n = this._getInst(n[0])).selectedDay = n.currentDay = parseInt(V("a", s).attr("data-date")), n.selectedMonth = n.currentMonth = e, n.selectedYear = n.currentYear = i, this._selectDate(t, this._formatDate(n, n.currentDay, n.currentMonth, n.currentYear)))
        },
        _clearDate: function(t) {
            t = V(t), this._selectDate(t, "")
        },
        _selectDate: function(t, e) {
            var i = V(t),
                t = this._getInst(i[0]);
            e = null != e ? e : this._formatDate(t), t.input && t.input.val(e), this._updateAlternate(t), (i = this._get(t, "onSelect")) ? i.apply(t.input ? t.input[0] : null, [e, t]) : t.input && t.input.trigger("change"), t.inline ? this._updateDatepicker(t) : (this._hideDatepicker(), this._lastInput = t.input[0], "object" != typeof t.input[0] && t.input.trigger("focus"), this._lastInput = null)
        },
        _updateAlternate: function(t) {
            var e, i, s = this._get(t, "altField");
            s && (e = this._get(t, "altFormat") || this._get(t, "dateFormat"), i = this._getDate(t), t = this.formatDate(e, i, this._getFormatConfig(t)), V(document).find(s).val(t))
        },
        noWeekends: function(t) {
            return [0 < (t = t.getDay()) && t < 6, ""]
        },
        iso8601Week: function(t) {
            var e = new Date(t.getTime());
            return e.setDate(e.getDate() + 4 - (e.getDay() || 7)), t = e.getTime(), e.setMonth(0), e.setDate(1), Math.floor(Math.round((t - e) / 864e5) / 7) + 1
        },
        parseDate: function(e, n, t) {
            if (null == e || null == n) throw "Invalid arguments";
            if ("" === (n = "object" == typeof n ? n.toString() : n + "")) return null;
            for (var i, s, o = 0, a = "string" != typeof(a = (t ? t.shortYearCutoff : null) || this._defaults.shortYearCutoff) ? a : (new Date).getFullYear() % 100 + parseInt(a, 10), r = (t ? t.dayNamesShort : null) || this._defaults.dayNamesShort, l = (t ? t.dayNames : null) || this._defaults.dayNames, h = (t ? t.monthNamesShort : null) || this._defaults.monthNamesShort, c = (t ? t.monthNames : null) || this._defaults.monthNames, u = -1, d = -1, p = -1, f = -1, m = !1, g = function(t) {
                    return (t = y + 1 < e.length && e.charAt(y + 1) === t) && y++, t
                }, _ = function(t) {
                    var e = g(t),
                        e = "@" === t ? 14 : "!" === t ? 20 : "y" === t && e ? 4 : "o" === t ? 3 : 2,
                        e = new RegExp("^\\d{" + ("y" === t ? e : 1) + "," + e + "}");
                    if (e = n.substring(o).match(e)) return o += e[0].length, parseInt(e[0], 10);
                    throw "Missing number at position " + o
                }, v = function(t, e, i) {
                    var s = -1,
                        e = V.map(g(t) ? i : e, function(t, e) {
                            return [
                                [e, t]
                            ]
                        }).sort(function(t, e) {
                            return -(t[1].length - e[1].length)
                        });
                    if (V.each(e, function(t, e) {
                            var i = e[1];
                            if (n.substr(o, i.length).toLowerCase() === i.toLowerCase()) return s = e[0], o += i.length, !1
                        }), -1 !== s) return s + 1;
                    throw "Unknown name at position " + o
                }, b = function() {
                    if (n.charAt(o) !== e.charAt(y)) throw "Unexpected literal at position " + o;
                    o++
                }, y = 0; y < e.length; y++)
                if (m) "'" !== e.charAt(y) || g("'") ? b() : m = !1;
                else switch (e.charAt(y)) {
                    case "d":
                        p = _("d");
                        break;
                    case "D":
                        v("D", r, l);
                        break;
                    case "o":
                        f = _("o");
                        break;
                    case "m":
                        d = _("m");
                        break;
                    case "M":
                        d = v("M", h, c);
                        break;
                    case "y":
                        u = _("y");
                        break;
                    case "@":
                        u = (s = new Date(_("@"))).getFullYear(), d = s.getMonth() + 1, p = s.getDate();
                        break;
                    case "!":
                        u = (s = new Date((_("!") - this._ticksTo1970) / 1e4)).getFullYear(), d = s.getMonth() + 1, p = s.getDate();
                        break;
                    case "'":
                        g("'") ? b() : m = !0;
                        break;
                    default:
                        b()
                }
            if (o < n.length && (t = n.substr(o), !/^\s+/.test(t))) throw "Extra/unparsed characters found in date: " + t;
            if (-1 === u ? u = (new Date).getFullYear() : u < 100 && (u += (new Date).getFullYear() - (new Date).getFullYear() % 100 + (u <= a ? 0 : -100)), -1 < f)
                for (d = 1, p = f; !(p <= (i = this._getDaysInMonth(u, d - 1)));) d++, p -= i;
            if ((s = this._daylightSavingAdjust(new Date(u, d - 1, p))).getFullYear() !== u || s.getMonth() + 1 !== d || s.getDate() !== p) throw "Invalid date";
            return s
        },
        ATOM: "yy-mm-dd",
        COOKIE: "D, dd M yy",
        ISO_8601: "yy-mm-dd",
        RFC_822: "D, d M y",
        RFC_850: "DD, dd-M-y",
        RFC_1036: "D, d M y",
        RFC_1123: "D, d M yy",
        RFC_2822: "D, d M yy",
        RSS: "D, d M y",
        TICKS: "!",
        TIMESTAMP: "@",
        W3C: "yy-mm-dd",
        _ticksTo1970: 24 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)) * 60 * 60 * 1e7,
        formatDate: function(e, t, i) {
            if (!t) return "";

            function s(t, e, i) {
                var s = "" + e;
                if (c(t))
                    for (; s.length < i;) s = "0" + s;
                return s
            }

            function n(t, e, i, s) {
                return (c(t) ? s : i)[e]
            }
            var o, a = (i ? i.dayNamesShort : null) || this._defaults.dayNamesShort,
                r = (i ? i.dayNames : null) || this._defaults.dayNames,
                l = (i ? i.monthNamesShort : null) || this._defaults.monthNamesShort,
                h = (i ? i.monthNames : null) || this._defaults.monthNames,
                c = function(t) {
                    return (t = o + 1 < e.length && e.charAt(o + 1) === t) && o++, t
                },
                u = "",
                d = !1;
            if (t)
                for (o = 0; o < e.length; o++)
                    if (d) "'" !== e.charAt(o) || c("'") ? u += e.charAt(o) : d = !1;
                    else switch (e.charAt(o)) {
                        case "d":
                            u += s("d", t.getDate(), 2);
                            break;
                        case "D":
                            u += n("D", t.getDay(), a, r);
                            break;
                        case "o":
                            u += s("o", Math.round((new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime() - new Date(t.getFullYear(), 0, 0).getTime()) / 864e5), 3);
                            break;
                        case "m":
                            u += s("m", t.getMonth() + 1, 2);
                            break;
                        case "M":
                            u += n("M", t.getMonth(), l, h);
                            break;
                        case "y":
                            u += c("y") ? t.getFullYear() : (t.getFullYear() % 100 < 10 ? "0" : "") + t.getFullYear() % 100;
                            break;
                        case "@":
                            u += t.getTime();
                            break;
                        case "!":
                            u += 1e4 * t.getTime() + this._ticksTo1970;
                            break;
                        case "'":
                            c("'") ? u += "'" : d = !0;
                            break;
                        default:
                            u += e.charAt(o)
                    }
            return u
        },
        _possibleChars: function(e) {
            for (var t = "", i = !1, s = function(t) {
                    return (t = n + 1 < e.length && e.charAt(n + 1) === t) && n++, t
                }, n = 0; n < e.length; n++)
                if (i) "'" !== e.charAt(n) || s("'") ? t += e.charAt(n) : i = !1;
                else switch (e.charAt(n)) {
                    case "d":
                    case "m":
                    case "y":
                    case "@":
                        t += "0123456789";
                        break;
                    case "D":
                    case "M":
                        return null;
                    case "'":
                        s("'") ? t += "'" : i = !0;
                        break;
                    default:
                        t += e.charAt(n)
                }
            return t
        },
        _get: function(t, e) {
            return (void 0 !== t.settings[e] ? t.settings : this._defaults)[e]
        },
        _setDateFromField: function(t, e) {
            if (t.input.val() !== t.lastVal) {
                var i = this._get(t, "dateFormat"),
                    s = t.lastVal = t.input ? t.input.val() : null,
                    n = this._getDefaultDate(t),
                    o = n,
                    a = this._getFormatConfig(t);
                try {
                    o = this.parseDate(i, s, a) || n
                } catch (t) {
                    s = e ? "" : s
                }
                t.selectedDay = o.getDate(), t.drawMonth = t.selectedMonth = o.getMonth(), t.drawYear = t.selectedYear = o.getFullYear(), t.currentDay = s ? o.getDate() : 0, t.currentMonth = s ? o.getMonth() : 0, t.currentYear = s ? o.getFullYear() : 0, this._adjustInstDate(t)
            }
        },
        _getDefaultDate: function(t) {
            return this._restrictMinMax(t, this._determineDate(t, this._get(t, "defaultDate"), new Date))
        },
        _determineDate: function(r, t, e) {
            var i, s;
            return (t = (t = null == t || "" === t ? e : "string" == typeof t ? function(t) {
                try {
                    return V.datepicker.parseDate(V.datepicker._get(r, "dateFormat"), t, V.datepicker._getFormatConfig(r))
                } catch (t) {}
                for (var e = (t.toLowerCase().match(/^c/) ? V.datepicker._getDate(r) : null) || new Date, i = e.getFullYear(), s = e.getMonth(), n = e.getDate(), o = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, a = o.exec(t); a;) {
                    switch (a[2] || "d") {
                        case "d":
                        case "D":
                            n += parseInt(a[1], 10);
                            break;
                        case "w":
                        case "W":
                            n += 7 * parseInt(a[1], 10);
                            break;
                        case "m":
                        case "M":
                            s += parseInt(a[1], 10), n = Math.min(n, V.datepicker._getDaysInMonth(i, s));
                            break;
                        case "y":
                        case "Y":
                            i += parseInt(a[1], 10), n = Math.min(n, V.datepicker._getDaysInMonth(i, s))
                    }
                    a = o.exec(t)
                }
                return new Date(i, s, n)
            }(t) : "number" == typeof t ? isNaN(t) ? e : (i = t, (s = new Date).setDate(s.getDate() + i), s) : new Date(t.getTime())) && "Invalid Date" === t.toString() ? e : t) && (t.setHours(0), t.setMinutes(0), t.setSeconds(0), t.setMilliseconds(0)), this._daylightSavingAdjust(t)
        },
        _daylightSavingAdjust: function(t) {
            return t ? (t.setHours(12 < t.getHours() ? t.getHours() + 2 : 0), t) : null
        },
        _setDate: function(t, e, i) {
            var s = !e,
                n = t.selectedMonth,
                o = t.selectedYear,
                e = this._restrictMinMax(t, this._determineDate(t, e, new Date));
            t.selectedDay = t.currentDay = e.getDate(), t.drawMonth = t.selectedMonth = t.currentMonth = e.getMonth(), t.drawYear = t.selectedYear = t.currentYear = e.getFullYear(), n === t.selectedMonth && o === t.selectedYear || i || this._notifyChange(t), this._adjustInstDate(t), t.input && t.input.val(s ? "" : this._formatDate(t))
        },
        _getDate: function(t) {
            return !t.currentYear || t.input && "" === t.input.val() ? null : this._daylightSavingAdjust(new Date(t.currentYear, t.currentMonth, t.currentDay))
        },
        _attachHandlers: function(t) {
            var e = this._get(t, "stepMonths"),
                i = "#" + t.id.replace(/\\\\/g, "\\");
            t.dpDiv.find("[data-handler]").map(function() {
                var t = {
                    prev: function() {
                        V.datepicker._adjustDate(i, -e, "M")
                    },
                    next: function() {
                        V.datepicker._adjustDate(i, +e, "M")
                    },
                    hide: function() {
                        V.datepicker._hideDatepicker()
                    },
                    today: function() {
                        V.datepicker._gotoToday(i)
                    },
                    selectDay: function() {
                        return V.datepicker._selectDay(i, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1
                    },
                    selectMonth: function() {
                        return V.datepicker._selectMonthYear(i, this, "M"), !1
                    },
                    selectYear: function() {
                        return V.datepicker._selectMonthYear(i, this, "Y"), !1
                    }
                };
                V(this).on(this.getAttribute("data-event"), t[this.getAttribute("data-handler")])
            })
        },
        _generateHTML: function(t) {
            var e, i, s, n, o, F, z, L, W, a, r, R, l, h, c, u, d, p, f, m, g, _, $, v, b, y, w, j, B, x, C, k, D = new Date,
                Y = this._daylightSavingAdjust(new Date(D.getFullYear(), D.getMonth(), D.getDate())),
                T = this._get(t, "isRTL"),
                q = this._get(t, "showButtonPanel"),
                E = this._get(t, "hideIfNoPrevNext"),
                S = this._get(t, "navigationAsDateFormat"),
                I = this._getNumberOfMonths(t),
                P = this._get(t, "showCurrentAtPos"),
                D = this._get(t, "stepMonths"),
                U = 1 !== I[0] || 1 !== I[1],
                M = this._daylightSavingAdjust(t.currentDay ? new Date(t.currentYear, t.currentMonth, t.currentDay) : new Date(9999, 9, 9)),
                A = this._getMinMaxDate(t, "min"),
                N = this._getMinMaxDate(t, "max"),
                O = t.drawMonth - P,
                H = t.drawYear;
            if (O < 0 && (O += 12, H--), N)
                for (e = this._daylightSavingAdjust(new Date(N.getFullYear(), N.getMonth() - I[0] * I[1] + 1, N.getDate())), e = A && e < A ? A : e; this._daylightSavingAdjust(new Date(H, O, 1)) > e;) --O < 0 && (O = 11, H--);
            for (t.drawMonth = O, t.drawYear = H, P = this._get(t, "prevText"), P = S ? this.formatDate(P, this._daylightSavingAdjust(new Date(H, O - D, 1)), this._getFormatConfig(t)) : P, i = this._canAdjustMonth(t, -1, H, O) ? V("<a>").attr({
                    class: "ui-datepicker-prev ui-corner-all",
                    "data-handler": "prev",
                    "data-event": "click",
                    title: P
                }).append(V("<span>").addClass("ui-icon ui-icon-circle-triangle-" + (T ? "e" : "w")).text(P))[0].outerHTML : E ? "" : V("<a>").attr({
                    class: "ui-datepicker-prev ui-corner-all ui-state-disabled",
                    title: P
                }).append(V("<span>").addClass("ui-icon ui-icon-circle-triangle-" + (T ? "e" : "w")).text(P))[0].outerHTML, P = this._get(t, "nextText"), P = S ? this.formatDate(P, this._daylightSavingAdjust(new Date(H, O + D, 1)), this._getFormatConfig(t)) : P, s = this._canAdjustMonth(t, 1, H, O) ? V("<a>").attr({
                    class: "ui-datepicker-next ui-corner-all",
                    "data-handler": "next",
                    "data-event": "click",
                    title: P
                }).append(V("<span>").addClass("ui-icon ui-icon-circle-triangle-" + (T ? "w" : "e")).text(P))[0].outerHTML : E ? "" : V("<a>").attr({
                    class: "ui-datepicker-next ui-corner-all ui-state-disabled",
                    title: P
                }).append(V("<span>").attr("class", "ui-icon ui-icon-circle-triangle-" + (T ? "w" : "e")).text(P))[0].outerHTML, D = this._get(t, "currentText"), E = this._get(t, "gotoCurrent") && t.currentDay ? M : Y, D = S ? this.formatDate(D, E, this._getFormatConfig(t)) : D, P = "", t.inline || (P = V("<button>").attr({
                    type: "button",
                    class: "ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all",
                    "data-handler": "hide",
                    "data-event": "click"
                }).text(this._get(t, "closeText"))[0].outerHTML), S = "", q && (S = V("<div class='ui-datepicker-buttonpane ui-widget-content'>").append(T ? P : "").append(this._isInRange(t, E) ? V("<button>").attr({
                    type: "button",
                    class: "ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all",
                    "data-handler": "today",
                    "data-event": "click"
                }).text(D) : "").append(T ? "" : P)[0].outerHTML), n = parseInt(this._get(t, "firstDay"), 10), n = isNaN(n) ? 0 : n, o = this._get(t, "showWeek"), F = this._get(t, "dayNames"), z = this._get(t, "dayNamesMin"), L = this._get(t, "monthNames"), W = this._get(t, "monthNamesShort"), a = this._get(t, "beforeShowDay"), r = this._get(t, "showOtherMonths"), R = this._get(t, "selectOtherMonths"), l = this._getDefaultDate(t), h = "", u = 0; u < I[0]; u++) {
                for (d = "", this.maxRows = 4, p = 0; p < I[1]; p++) {
                    if (f = this._daylightSavingAdjust(new Date(H, O, t.selectedDay)), m = " ui-corner-all", g = "", U) {
                        if (g += "<div class='ui-datepicker-group", 1 < I[1]) switch (p) {
                            case 0:
                                g += " ui-datepicker-group-first", m = " ui-corner-" + (T ? "right" : "left");
                                break;
                            case I[1] - 1:
                                g += " ui-datepicker-group-last", m = " ui-corner-" + (T ? "left" : "right");
                                break;
                            default:
                                g += " ui-datepicker-group-middle", m = ""
                        }
                        g += "'>"
                    }
                    for (g += "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" + m + "'>" + (/all|left/.test(m) && 0 === u ? T ? s : i : "") + (/all|right/.test(m) && 0 === u ? T ? i : s : "") + this._generateMonthYearHeader(t, O, H, A, N, 0 < u || 0 < p, L, W) + "</div><table class='ui-datepicker-calendar'><thead><tr>", _ = o ? "<th class='ui-datepicker-week-col'>" + this._get(t, "weekHeader") + "</th>" : "", c = 0; c < 7; c++) _ += "<th scope='col'" + (5 <= (c + n + 6) % 7 ? " class='ui-datepicker-week-end'" : "") + "><span title='" + F[$ = (c + n) % 7] + "'>" + z[$] + "</span></th>";
                    for (g += _ + "</tr></thead><tbody>", b = this._getDaysInMonth(H, O), H === t.selectedYear && O === t.selectedMonth && (t.selectedDay = Math.min(t.selectedDay, b)), v = (this._getFirstDayOfMonth(H, O) - n + 7) % 7, b = Math.ceil((v + b) / 7), y = U && this.maxRows > b ? this.maxRows : b, this.maxRows = y, w = this._daylightSavingAdjust(new Date(H, O, 1 - v)), j = 0; j < y; j++) {
                        for (g += "<tr>", B = o ? "<td class='ui-datepicker-week-col'>" + this._get(t, "calculateWeek")(w) + "</td>" : "", c = 0; c < 7; c++) x = a ? a.apply(t.input ? t.input[0] : null, [w]) : [!0, ""], k = (C = w.getMonth() !== O) && !R || !x[0] || A && w < A || N && N < w, B += "<td class='" + (5 <= (c + n + 6) % 7 ? " ui-datepicker-week-end" : "") + (C ? " ui-datepicker-other-month" : "") + (w.getTime() === f.getTime() && O === t.selectedMonth && t._keyEvent || l.getTime() === w.getTime() && l.getTime() === f.getTime() ? " " + this._dayOverClass : "") + (k ? " " + this._unselectableClass + " ui-state-disabled" : "") + (C && !r ? "" : " " + x[1] + (w.getTime() === M.getTime() ? " " + this._currentClass : "") + (w.getTime() === Y.getTime() ? " ui-datepicker-today" : "")) + "'" + (C && !r || !x[2] ? "" : " title='" + x[2].replace(/'/g, "&#39;") + "'") + (k ? "" : " data-handler='selectDay' data-event='click' data-month='" + w.getMonth() + "' data-year='" + w.getFullYear() + "'") + ">" + (C && !r ? "&#xa0;" : k ? "<span class='ui-state-default'>" + w.getDate() + "</span>" : "<a class='ui-state-default" + (w.getTime() === Y.getTime() ? " ui-state-highlight" : "") + (w.getTime() === M.getTime() ? " ui-state-active" : "") + (C ? " ui-priority-secondary" : "") + "' href='#' aria-current='" + (w.getTime() === M.getTime() ? "true" : "false") + "' data-date='" + w.getDate() + "'>" + w.getDate() + "</a>") + "</td>", w.setDate(w.getDate() + 1), w = this._daylightSavingAdjust(w);
                        g += B + "</tr>"
                    }
                    11 < ++O && (O = 0, H++), d += g += "</tbody></table>" + (U ? "</div>" + (0 < I[0] && p === I[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : "")
                }
                h += d
            }
            return h += S, t._keyEvent = !1, h
        },
        _generateMonthYearHeader: function(t, e, i, s, n, o, a, r) {
            var l, h, c, u, d, p, f = this._get(t, "changeMonth"),
                m = this._get(t, "changeYear"),
                g = this._get(t, "showMonthAfterYear"),
                _ = this._get(t, "selectMonthLabel"),
                v = this._get(t, "selectYearLabel"),
                b = "<div class='ui-datepicker-title'>",
                y = "";
            if (o || !f) y += "<span class='ui-datepicker-month'>" + a[e] + "</span>";
            else {
                for (l = s && s.getFullYear() === i, h = n && n.getFullYear() === i, y += "<select class='ui-datepicker-month' aria-label='" + _ + "' data-handler='selectMonth' data-event='change'>", c = 0; c < 12; c++)(!l || c >= s.getMonth()) && (!h || c <= n.getMonth()) && (y += "<option value='" + c + "'" + (c === e ? " selected='selected'" : "") + ">" + r[c] + "</option>");
                y += "</select>"
            }
            if (g || (b += y + (!o && f && m ? "" : "&#xa0;")), !t.yearshtml)
                if (t.yearshtml = "", o || !m) b += "<span class='ui-datepicker-year'>" + i + "</span>";
                else {
                    for (a = this._get(t, "yearRange").split(":"), u = (new Date).getFullYear(), d = (_ = function(t) {
                            return t = t.match(/c[+\-].*/) ? i + parseInt(t.substring(1), 10) : t.match(/[+\-].*/) ? u + parseInt(t, 10) : parseInt(t, 10), isNaN(t) ? u : t
                        })(a[0]), p = Math.max(d, _(a[1] || "")), d = s ? Math.max(d, s.getFullYear()) : d, p = n ? Math.min(p, n.getFullYear()) : p, t.yearshtml += "<select class='ui-datepicker-year' aria-label='" + v + "' data-handler='selectYear' data-event='change'>"; d <= p; d++) t.yearshtml += "<option value='" + d + "'" + (d === i ? " selected='selected'" : "") + ">" + d + "</option>";
                    t.yearshtml += "</select>", b += t.yearshtml, t.yearshtml = null
                }
            return b += this._get(t, "yearSuffix"), g && (b += (!o && f && m ? "" : "&#xa0;") + y), b + "</div>"
        },
        _adjustInstDate: function(t, e, i) {
            var s = t.selectedYear + ("Y" === i ? e : 0),
                n = t.selectedMonth + ("M" === i ? e : 0),
                e = Math.min(t.selectedDay, this._getDaysInMonth(s, n)) + ("D" === i ? e : 0),
                e = this._restrictMinMax(t, this._daylightSavingAdjust(new Date(s, n, e)));
            t.selectedDay = e.getDate(), t.drawMonth = t.selectedMonth = e.getMonth(), t.drawYear = t.selectedYear = e.getFullYear(), "M" !== i && "Y" !== i || this._notifyChange(t)
        },
        _restrictMinMax: function(t, e) {
            var i = this._getMinMaxDate(t, "min"),
                e = i && e < i ? i : e;
            return (t = this._getMinMaxDate(t, "max")) && t < e ? t : e
        },
        _notifyChange: function(t) {
            var e = this._get(t, "onChangeMonthYear");
            e && e.apply(t.input ? t.input[0] : null, [t.selectedYear, t.selectedMonth + 1, t])
        },
        _getNumberOfMonths: function(t) {
            return null == (t = this._get(t, "numberOfMonths")) ? [1, 1] : "number" == typeof t ? [1, t] : t
        },
        _getMinMaxDate: function(t, e) {
            return this._determineDate(t, this._get(t, e + "Date"), null)
        },
        _getDaysInMonth: function(t, e) {
            return 32 - this._daylightSavingAdjust(new Date(t, e, 32)).getDate()
        },
        _getFirstDayOfMonth: function(t, e) {
            return new Date(t, e, 1).getDay()
        },
        _canAdjustMonth: function(t, e, i, s) {
            var n = this._getNumberOfMonths(t),
                n = this._daylightSavingAdjust(new Date(i, s + (e < 0 ? e : n[0] * n[1]), 1));
            return e < 0 && n.setDate(this._getDaysInMonth(n.getFullYear(), n.getMonth())), this._isInRange(t, n)
        },
        _isInRange: function(t, e) {
            var i = this._getMinMaxDate(t, "min"),
                s = this._getMinMaxDate(t, "max"),
                n = null,
                o = null,
                a = this._get(t, "yearRange");
            return a && (t = a.split(":"), a = (new Date).getFullYear(), n = parseInt(t[0], 10), o = parseInt(t[1], 10), t[0].match(/[+\-].*/) && (n += a), t[1].match(/[+\-].*/)) && (o += a), (!i || e.getTime() >= i.getTime()) && (!s || e.getTime() <= s.getTime()) && (!n || e.getFullYear() >= n) && (!o || e.getFullYear() <= o)
        },
        _getFormatConfig: function(t) {
            var e = this._get(t, "shortYearCutoff");
            return {
                shortYearCutoff: "string" != typeof e ? e : (new Date).getFullYear() % 100 + parseInt(e, 10),
                dayNamesShort: this._get(t, "dayNamesShort"),
                dayNames: this._get(t, "dayNames"),
                monthNamesShort: this._get(t, "monthNamesShort"),
                monthNames: this._get(t, "monthNames")
            }
        },
        _formatDate: function(t, e, i, s) {
            return e || (t.currentDay = t.selectedDay, t.currentMonth = t.selectedMonth, t.currentYear = t.selectedYear), e = e ? "object" == typeof e ? e : this._daylightSavingAdjust(new Date(s, i, e)) : this._daylightSavingAdjust(new Date(t.currentYear, t.currentMonth, t.currentDay)), this.formatDate(this._get(t, "dateFormat"), e, this._getFormatConfig(t))
        }
    }), V.fn.datepicker = function(t) {
        if (!this.length) return this;
        V.datepicker.initialized || (V(document).on("mousedown", V.datepicker._checkExternalClick), V.datepicker.initialized = !0), 0 === V("#" + V.datepicker._mainDivId).length && V("body").append(V.datepicker.dpDiv);
        var e = Array.prototype.slice.call(arguments, 1);
        return "string" == typeof t && ("isDisabled" === t || "getDate" === t || "widget" === t) || "option" === t && 2 === arguments.length && "string" == typeof arguments[1] ? V.datepicker["_" + t + "Datepicker"].apply(V.datepicker, [this[0]].concat(e)) : this.each(function() {
            "string" == typeof t ? V.datepicker["_" + t + "Datepicker"].apply(V.datepicker, [this].concat(e)) : V.datepicker._attachDatepicker(this, t)
        })
    }, V.datepicker = new Y, V.datepicker.initialized = !1, V.datepicker.uuid = (new Date).getTime(), V.datepicker.version = "1.13.0", V.datepicker, V.widget("ui.dialog", {
        version: "1.13.0",
        options: {
            appendTo: "body",
            autoOpen: !0,
            buttons: [],
            classes: {
                "ui-dialog": "ui-corner-all",
                "ui-dialog-titlebar": "ui-corner-all"
            },
            closeOnEscape: !0,
            closeText: "Close",
            draggable: !0,
            hide: null,
            height: "auto",
            maxHeight: null,
            maxWidth: null,
            minHeight: 150,
            minWidth: 150,
            modal: !1,
            position: {
                my: "center",
                at: "center",
                of: window,
                collision: "fit",
                using: function(t) {
                    var e = V(this).css(t).offset().top;
                    e < 0 && V(this).css("top", t.top - e)
                }
            },
            resizable: !0,
            show: null,
            title: null,
            width: 300,
            beforeClose: null,
            close: null,
            drag: null,
            dragStart: null,
            dragStop: null,
            focus: null,
            open: null,
            resize: null,
            resizeStart: null,
            resizeStop: null
        },
        sizeRelatedOptions: {
            buttons: !0,
            height: !0,
            maxHeight: !0,
            maxWidth: !0,
            minHeight: !0,
            minWidth: !0,
            width: !0
        },
        resizableRelatedOptions: {
            maxHeight: !0,
            maxWidth: !0,
            minHeight: !0,
            minWidth: !0
        },
        _create: function() {
            this.originalCss = {
                display: this.element[0].style.display,
                width: this.element[0].style.width,
                minHeight: this.element[0].style.minHeight,
                maxHeight: this.element[0].style.maxHeight,
                height: this.element[0].style.height
            }, this.originalPosition = {
                parent: this.element.parent(),
                index: this.element.parent().children().index(this.element)
            }, this.originalTitle = this.element.attr("title"), null == this.options.title && null != this.originalTitle && (this.options.title = this.originalTitle), this.options.disabled && (this.options.disabled = !1), this._createWrapper(), this.element.show().removeAttr("title").appendTo(this.uiDialog), this._addClass("ui-dialog-content", "ui-widget-content"), this._createTitlebar(), this._createButtonPane(), this.options.draggable && V.fn.draggable && this._makeDraggable(), this.options.resizable && V.fn.resizable && this._makeResizable(), this._isOpen = !1, this._trackFocus()
        },
        _init: function() {
            this.options.autoOpen && this.open()
        },
        _appendTo: function() {
            var t = this.options.appendTo;
            return t && (t.jquery || t.nodeType) ? V(t) : this.document.find(t || "body").eq(0)
        },
        _destroy: function() {
            var t, e = this.originalPosition;
            this._untrackInstance(), this._destroyOverlay(), this.element.removeUniqueId().css(this.originalCss).detach(), this.uiDialog.remove(), this.originalTitle && this.element.attr("title", this.originalTitle), (t = e.parent.children().eq(e.index)).length && t[0] !== this.element[0] ? t.before(this.element) : e.parent.append(this.element)
        },
        widget: function() {
            return this.uiDialog
        },
        disable: V.noop,
        enable: V.noop,
        close: function(t) {
            var e = this;
            this._isOpen && !1 !== this._trigger("beforeClose", t) && (this._isOpen = !1, this._focusedElement = null, this._destroyOverlay(), this._untrackInstance(), this.opener.filter(":focusable").trigger("focus").length || V.ui.safeBlur(V.ui.safeActiveElement(this.document[0])), this._hide(this.uiDialog, this.options.hide, function() {
                e._trigger("close", t)
            }))
        },
        isOpen: function() {
            return this._isOpen
        },
        moveToTop: function() {
            this._moveToTop()
        },
        _moveToTop: function(t, e) {
            var i = !1,
                s = this.uiDialog.siblings(".ui-front:visible").map(function() {
                    return +V(this).css("z-index")
                }).get();
            return (s = Math.max.apply(null, s)) >= +this.uiDialog.css("z-index") && (this.uiDialog.css("z-index", s + 1), i = !0), i && !e && this._trigger("focus", t), i
        },
        open: function() {
            var t = this;
            this._isOpen ? this._moveToTop() && this._focusTabbable() : (this._isOpen = !0, this.opener = V(V.ui.safeActiveElement(this.document[0])), this._size(), this._position(), this._createOverlay(), this._moveToTop(null, !0), this.overlay && this.overlay.css("z-index", this.uiDialog.css("z-index") - 1), this._show(this.uiDialog, this.options.show, function() {
                t._focusTabbable(), t._trigger("focus")
            }), this._makeFocusTarget(), this._trigger("open"))
        },
        _focusTabbable: function() {
            var t = this._focusedElement;
            (t = (t = (t = (t = (t = t || this.element.find("[autofocus]")).length ? t : this.element.find(":tabbable")).length ? t : this.uiDialogButtonPane.find(":tabbable")).length ? t : this.uiDialogTitlebarClose.filter(":tabbable")).length ? t : this.uiDialog).eq(0).trigger("focus")
        },
        _restoreTabbableFocus: function() {
            var t = V.ui.safeActiveElement(this.document[0]);
            this.uiDialog[0] === t || V.contains(this.uiDialog[0], t) || this._focusTabbable()
        },
        _keepFocus: function(t) {
            t.preventDefault(), this._restoreTabbableFocus(), this._delay(this._restoreTabbableFocus)
        },
        _createWrapper: function() {
            this.uiDialog = V("<div>").hide().attr({
                tabIndex: -1,
                role: "dialog"
            }).appendTo(this._appendTo()), this._addClass(this.uiDialog, "ui-dialog", "ui-widget ui-widget-content ui-front"), this._on(this.uiDialog, {
                keydown: function(t) {
                    var e, i, s;
                    this.options.closeOnEscape && !t.isDefaultPrevented() && t.keyCode && t.keyCode === V.ui.keyCode.ESCAPE ? (t.preventDefault(), this.close(t)) : t.keyCode !== V.ui.keyCode.TAB || t.isDefaultPrevented() || (e = this.uiDialog.find(":tabbable"), i = e.first(), s = e.last(), t.target !== s[0] && t.target !== this.uiDialog[0] || t.shiftKey ? t.target !== i[0] && t.target !== this.uiDialog[0] || !t.shiftKey || (this._delay(function() {
                        s.trigger("focus")
                    }), t.preventDefault()) : (this._delay(function() {
                        i.trigger("focus")
                    }), t.preventDefault()))
                },
                mousedown: function(t) {
                    this._moveToTop(t) && this._focusTabbable()
                }
            }), this.element.find("[aria-describedby]").length || this.uiDialog.attr({
                "aria-describedby": this.element.uniqueId().attr("id")
            })
        },
        _createTitlebar: function() {
            var t;
            this.uiDialogTitlebar = V("<div>"), this._addClass(this.uiDialogTitlebar, "ui-dialog-titlebar", "ui-widget-header ui-helper-clearfix"), this._on(this.uiDialogTitlebar, {
                mousedown: function(t) {
                    V(t.target).closest(".ui-dialog-titlebar-close") || this.uiDialog.trigger("focus")
                }
            }), this.uiDialogTitlebarClose = V("<button type='button'></button>").button({
                label: V("<a>").text(this.options.closeText).html(),
                icon: "ui-icon-closethick",
                showLabel: !1
            }).appendTo(this.uiDialogTitlebar), this._addClass(this.uiDialogTitlebarClose, "ui-dialog-titlebar-close"), this._on(this.uiDialogTitlebarClose, {
                click: function(t) {
                    t.preventDefault(), this.close(t)
                }
            }), t = V("<span>").uniqueId().prependTo(this.uiDialogTitlebar), this._addClass(t, "ui-dialog-title"), this._title(t), this.uiDialogTitlebar.prependTo(this.uiDialog), this.uiDialog.attr({
                "aria-labelledby": t.attr("id")
            })
        },
        _title: function(t) {
            this.options.title ? t.text(this.options.title) : t.html("&#160;")
        },
        _createButtonPane: function() {
            this.uiDialogButtonPane = V("<div>"), this._addClass(this.uiDialogButtonPane, "ui-dialog-buttonpane", "ui-widget-content ui-helper-clearfix"), this.uiButtonSet = V("<div>").appendTo(this.uiDialogButtonPane), this._addClass(this.uiButtonSet, "ui-dialog-buttonset"), this._createButtons()
        },
        _createButtons: function() {
            var s = this,
                t = this.options.buttons;
            this.uiDialogButtonPane.remove(), this.uiButtonSet.empty(), V.isEmptyObject(t) || Array.isArray(t) && !t.length ? this._removeClass(this.uiDialog, "ui-dialog-buttons") : (V.each(t, function(t, e) {
                var i;
                e = V.extend({
                    type: "button"
                }, e = "function" == typeof e ? {
                    click: e,
                    text: t
                } : e), i = e.click, t = {
                    icon: e.icon,
                    iconPosition: e.iconPosition,
                    showLabel: e.showLabel,
                    icons: e.icons,
                    text: e.text
                }, delete e.click, delete e.icon, delete e.iconPosition, delete e.showLabel, delete e.icons, "boolean" == typeof e.text && delete e.text, V("<button></button>", e).button(t).appendTo(s.uiButtonSet).on("click", function() {
                    i.apply(s.element[0], arguments)
                })
            }), this._addClass(this.uiDialog, "ui-dialog-buttons"), this.uiDialogButtonPane.appendTo(this.uiDialog))
        },
        _makeDraggable: function() {
            var n = this,
                o = this.options;

            function a(t) {
                return {
                    position: t.position,
                    offset: t.offset
                }
            }
            this.uiDialog.draggable({
                cancel: ".ui-dialog-content, .ui-dialog-titlebar-close",
                handle: ".ui-dialog-titlebar",
                containment: "document",
                start: function(t, e) {
                    n._addClass(V(this), "ui-dialog-dragging"), n._blockFrames(), n._trigger("dragStart", t, a(e))
                },
                drag: function(t, e) {
                    n._trigger("drag", t, a(e))
                },
                stop: function(t, e) {
                    var i = e.offset.left - n.document.scrollLeft(),
                        s = e.offset.top - n.document.scrollTop();
                    o.position = {
                        my: "left top",
                        at: "left" + (0 <= i ? "+" : "") + i + " top" + (0 <= s ? "+" : "") + s,
                        of: n.window
                    }, n._removeClass(V(this), "ui-dialog-dragging"), n._unblockFrames(), n._trigger("dragStop", t, a(e))
                }
            })
        },
        _makeResizable: function() {
            var n = this,
                o = this.options,
                t = o.resizable,
                e = this.uiDialog.css("position"),
                t = "string" == typeof t ? t : "n,e,s,w,se,sw,ne,nw";

            function a(t) {
                return {
                    originalPosition: t.originalPosition,
                    originalSize: t.originalSize,
                    position: t.position,
                    size: t.size
                }
            }
            this.uiDialog.resizable({
                cancel: ".ui-dialog-content",
                containment: "document",
                alsoResize: this.element,
                maxWidth: o.maxWidth,
                maxHeight: o.maxHeight,
                minWidth: o.minWidth,
                minHeight: this._minHeight(),
                handles: t,
                start: function(t, e) {
                    n._addClass(V(this), "ui-dialog-resizing"), n._blockFrames(), n._trigger("resizeStart", t, a(e))
                },
                resize: function(t, e) {
                    n._trigger("resize", t, a(e))
                },
                stop: function(t, e) {
                    var i = (s = n.uiDialog.offset()).left - n.document.scrollLeft(),
                        s = s.top - n.document.scrollTop();
                    o.height = n.uiDialog.height(), o.width = n.uiDialog.width(), o.position = {
                        my: "left top",
                        at: "left" + (0 <= i ? "+" : "") + i + " top" + (0 <= s ? "+" : "") + s,
                        of: n.window
                    }, n._removeClass(V(this), "ui-dialog-resizing"), n._unblockFrames(), n._trigger("resizeStop", t, a(e))
                }
            }).css("position", e)
        },
        _trackFocus: function() {
            this._on(this.widget(), {
                focusin: function(t) {
                    this._makeFocusTarget(), this._focusedElement = V(t.target)
                }
            })
        },
        _makeFocusTarget: function() {
            this._untrackInstance(), this._trackingInstances().unshift(this)
        },
        _untrackInstance: function() {
            var t = this._trackingInstances(),
                e = V.inArray(this, t); - 1 !== e && t.splice(e, 1)
        },
        _trackingInstances: function() {
            var t = this.document.data("ui-dialog-instances");
            return t || this.document.data("ui-dialog-instances", t = []), t
        },
        _minHeight: function() {
            var t = this.options;
            return "auto" === t.height ? t.minHeight : Math.min(t.minHeight, t.height)
        },
        _position: function() {
            var t = this.uiDialog.is(":visible");
            t || this.uiDialog.show(), this.uiDialog.position(this.options.position), t || this.uiDialog.hide()
        },
        _setOptions: function(t) {
            var i = this,
                s = !1,
                n = {};
            V.each(t, function(t, e) {
                i._setOption(t, e), t in i.sizeRelatedOptions && (s = !0), t in i.resizableRelatedOptions && (n[t] = e)
            }), s && (this._size(), this._position()), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", n)
        },
        _setOption: function(t, e) {
            var i, s = this.uiDialog;
            "disabled" !== t && (this._super(t, e), "appendTo" === t && this.uiDialog.appendTo(this._appendTo()), "buttons" === t && this._createButtons(), "closeText" === t && this.uiDialogTitlebarClose.button({
                label: V("<a>").text("" + this.options.closeText).html()
            }), "draggable" === t && ((i = s.is(":data(ui-draggable)")) && !e && s.draggable("destroy"), !i) && e && this._makeDraggable(), "position" === t && this._position(), "resizable" === t && ((i = s.is(":data(ui-resizable)")) && !e && s.resizable("destroy"), i && "string" == typeof e && s.resizable("option", "handles", e), i || !1 === e || this._makeResizable()), "title" === t) && this._title(this.uiDialogTitlebar.find(".ui-dialog-title"))
        },
        _size: function() {
            var t, e, i, s = this.options;
            this.element.show().css({
                width: "auto",
                minHeight: 0,
                maxHeight: "none",
                height: 0
            }), s.minWidth > s.width && (s.width = s.minWidth), t = this.uiDialog.css({
                height: "auto",
                width: s.width
            }).outerHeight(), e = Math.max(0, s.minHeight - t), i = "number" == typeof s.maxHeight ? Math.max(0, s.maxHeight - t) : "none", "auto" === s.height ? this.element.css({
                minHeight: e,
                maxHeight: i,
                height: "auto"
            }) : this.element.height(Math.max(0, s.height - t)), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", "minHeight", this._minHeight())
        },
        _blockFrames: function() {
            this.iframeBlocks = this.document.find("iframe").map(function() {
                var t = V(this);
                return V("<div>").css({
                    position: "absolute",
                    width: t.outerWidth(),
                    height: t.outerHeight()
                }).appendTo(t.parent()).offset(t.offset())[0]
            })
        },
        _unblockFrames: function() {
            this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks)
        },
        _allowInteraction: function(t) {
            return !!V(t.target).closest(".ui-dialog").length || !!V(t.target).closest(".ui-datepicker").length
        },
        _createOverlay: function() {
            var i, s;
            this.options.modal && (i = V.fn.jquery.substring(0, 4), s = !0, this._delay(function() {
                s = !1
            }), this.document.data("ui-dialog-overlays") || this.document.on("focusin.ui-dialog", function(t) {
                var e;
                s || (e = this._trackingInstances()[0])._allowInteraction(t) || (t.preventDefault(), e._focusTabbable(), "3.4." !== i && "3.5." !== i) || e._delay(e._restoreTabbableFocus)
            }.bind(this)), this.overlay = V("<div>").appendTo(this._appendTo()), this._addClass(this.overlay, null, "ui-widget-overlay ui-front"), this._on(this.overlay, {
                mousedown: "_keepFocus"
            }), this.document.data("ui-dialog-overlays", (this.document.data("ui-dialog-overlays") || 0) + 1))
        },
        _destroyOverlay: function() {
            var t;
            this.options.modal && this.overlay && ((t = this.document.data("ui-dialog-overlays") - 1) ? this.document.data("ui-dialog-overlays", t) : (this.document.off("focusin.ui-dialog"), this.document.removeData("ui-dialog-overlays")), this.overlay.remove(), this.overlay = null)
        }
    }), !1 !== V.uiBackCompat && V.widget("ui.dialog", V.ui.dialog, {
        options: {
            dialogClass: ""
        },
        _createWrapper: function() {
            this._super(), this.uiDialog.addClass(this.options.dialogClass)
        },
        _setOption: function(t, e) {
            "dialogClass" === t && this.uiDialog.removeClass(this.options.dialogClass).addClass(e), this._superApply(arguments)
        }
    }), V.ui.dialog, V.widget("ui.progressbar", {
        version: "1.13.0",
        options: {
            classes: {
                "ui-progressbar": "ui-corner-all",
                "ui-progressbar-value": "ui-corner-left",
                "ui-progressbar-complete": "ui-corner-right"
            },
            max: 100,
            value: 0,
            change: null,
            complete: null
        },
        min: 0,
        _create: function() {
            this.oldValue = this.options.value = this._constrainedValue(), this.element.attr({
                role: "progressbar",
                "aria-valuemin": this.min
            }), this._addClass("ui-progressbar", "ui-widget ui-widget-content"), this.valueDiv = V("<div>").appendTo(this.element), this._addClass(this.valueDiv, "ui-progressbar-value", "ui-widget-header"), this._refreshValue()
        },
        _destroy: function() {
            this.element.removeAttr("role aria-valuemin aria-valuemax aria-valuenow"), this.valueDiv.remove()
        },
        value: function(t) {
            if (void 0 === t) return this.options.value;
            this.options.value = this._constrainedValue(t), this._refreshValue()
        },
        _constrainedValue: function(t) {
            return void 0 === t && (t = this.options.value), this.indeterminate = !1 === t, "number" != typeof t && (t = 0), !this.indeterminate && Math.min(this.options.max, Math.max(this.min, t))
        },
        _setOptions: function(t) {
            var e = t.value;
            delete t.value, this._super(t), this.options.value = this._constrainedValue(e), this._refreshValue()
        },
        _setOption: function(t, e) {
            "max" === t && (e = Math.max(this.min, e)), this._super(t, e)
        },
        _setOptionDisabled: function(t) {
            this._super(t), this.element.attr("aria-disabled", t), this._toggleClass(null, "ui-state-disabled", !!t)
        },
        _percentage: function() {
            return this.indeterminate ? 100 : 100 * (this.options.value - this.min) / (this.options.max - this.min)
        },
        _refreshValue: function() {
            var t = this.options.value,
                e = this._percentage();
            this.valueDiv.toggle(this.indeterminate || t > this.min).width(e.toFixed(0) + "%"), this._toggleClass(this.valueDiv, "ui-progressbar-complete", null, t === this.options.max)._toggleClass("ui-progressbar-indeterminate", null, this.indeterminate), this.indeterminate ? (this.element.removeAttr("aria-valuenow"), this.overlayDiv || (this.overlayDiv = V("<div>").appendTo(this.valueDiv), this._addClass(this.overlayDiv, "ui-progressbar-overlay"))) : (this.element.attr({
                "aria-valuemax": this.options.max,
                "aria-valuenow": t
            }), this.overlayDiv && (this.overlayDiv.remove(), this.overlayDiv = null)), this.oldValue !== t && (this.oldValue = t, this._trigger("change")), t === this.options.max && this._trigger("complete")
        }
    }), V.widget("ui.selectmenu", [V.ui.formResetMixin, {
        version: "1.13.0",
        defaultElement: "<select>",
        options: {
            appendTo: null,
            classes: {
                "ui-selectmenu-button-open": "ui-corner-top",
                "ui-selectmenu-button-closed": "ui-corner-all"
            },
            disabled: null,
            icons: {
                button: "ui-icon-triangle-1-s"
            },
            position: {
                my: "left top",
                at: "left bottom",
                collision: "none"
            },
            width: !1,
            change: null,
            close: null,
            focus: null,
            open: null,
            select: null
        },
        _create: function() {
            var t = this.element.uniqueId().attr("id");
            this.ids = {
                element: t,
                button: t + "-button",
                menu: t + "-menu"
            }, this._drawButton(), this._drawMenu(), this._bindFormResetHandler(), this._rendered = !1, this.menuItems = V()
        },
        _drawButton: function() {
            var t, e = this,
                i = this._parseOption(this.element.find("option:selected"), this.element[0].selectedIndex);
            this.labels = this.element.labels().attr("for", this.ids.button), this._on(this.labels, {
                click: function(t) {
                    this.button.trigger("focus"), t.preventDefault()
                }
            }), this.element.hide(), this.button = V("<span>", {
                tabindex: this.options.disabled ? -1 : 0,
                id: this.ids.button,
                role: "combobox",
                "aria-expanded": "false",
                "aria-autocomplete": "list",
                "aria-owns": this.ids.menu,
                "aria-haspopup": "true",
                title: this.element.attr("title")
            }).insertAfter(this.element), this._addClass(this.button, "ui-selectmenu-button ui-selectmenu-button-closed", "ui-button ui-widget"), t = V("<span>").appendTo(this.button), this._addClass(t, "ui-selectmenu-icon", "ui-icon " + this.options.icons.button), this.buttonItem = this._renderButtonItem(i).appendTo(this.button), !1 !== this.options.width && this._resizeButton(), this._on(this.button, this._buttonEvents), this.button.one("focusin", function() {
                e._rendered || e._refreshMenu()
            })
        },
        _drawMenu: function() {
            var i = this;
            this.menu = V("<ul>", {
                "aria-hidden": "true",
                "aria-labelledby": this.ids.button,
                id: this.ids.menu
            }), this.menuWrap = V("<div>").append(this.menu), this._addClass(this.menuWrap, "ui-selectmenu-menu", "ui-front"), this.menuWrap.appendTo(this._appendTo()), this.menuInstance = this.menu.menu({
                classes: {
                    "ui-menu": "ui-corner-bottom"
                },
                role: "listbox",
                select: function(t, e) {
                    t.preventDefault(), i._setSelection(), i._select(e.item.data("ui-selectmenu-item"), t)
                },
                focus: function(t, e) {
                    e = e.item.data("ui-selectmenu-item"), null != i.focusIndex && e.index !== i.focusIndex && (i._trigger("focus", t, {
                        item: e
                    }), i.isOpen || i._select(e, t)), i.focusIndex = e.index, i.button.attr("aria-activedescendant", i.menuItems.eq(e.index).attr("id"))
                }
            }).menu("instance"), this.menuInstance._off(this.menu, "mouseleave"), this.menuInstance._closeOnDocumentClick = function() {
                return !1
            }, this.menuInstance._isDivider = function() {
                return !1
            }
        },
        refresh: function() {
            this._refreshMenu(), this.buttonItem.replaceWith(this.buttonItem = this._renderButtonItem(this._getSelectedItem().data("ui-selectmenu-item") || {})), null === this.options.width && this._resizeButton()
        },
        _refreshMenu: function() {
            var t = this.element.find("option");
            this.menu.empty(), this._parseOptions(t), this._renderMenu(this.menu, this.items), this.menuInstance.refresh(), this.menuItems = this.menu.find("li").not(".ui-selectmenu-optgroup").find(".ui-menu-item-wrapper"), this._rendered = !0, t.length && (t = this._getSelectedItem(), this.menuInstance.focus(null, t), this._setAria(t.data("ui-selectmenu-item")), this._setOption("disabled", this.element.prop("disabled")))
        },
        open: function(t) {
            this.options.disabled || (this._rendered ? (this._removeClass(this.menu.find(".ui-state-active"), null, "ui-state-active"), this.menuInstance.focus(null, this._getSelectedItem())) : this._refreshMenu(), this.menuItems.length && (this.isOpen = !0, this._toggleAttr(), this._resizeMenu(), this._position(), this._on(this.document, this._documentClick), this._trigger("open", t)))
        },
        _position: function() {
            this.menuWrap.position(V.extend({ of: this.button
            }, this.options.position))
        },
        close: function(t) {
            this.isOpen && (this.isOpen = !1, this._toggleAttr(), this.range = null, this._off(this.document), this._trigger("close", t))
        },
        widget: function() {
            return this.button
        },
        menuWidget: function() {
            return this.menu
        },
        _renderButtonItem: function(t) {
            var e = V("<span>");
            return this._setText(e, t.label), this._addClass(e, "ui-selectmenu-text"), e
        },
        _renderMenu: function(s, t) {
            var n = this,
                o = "";
            V.each(t, function(t, e) {
                var i;
                e.optgroup !== o && (i = V("<li>", {
                    text: e.optgroup
                }), n._addClass(i, "ui-selectmenu-optgroup", "ui-menu-divider" + (e.element.parent("optgroup").prop("disabled") ? " ui-state-disabled" : "")), i.appendTo(s), o = e.optgroup), n._renderItemData(s, e)
            })
        },
        _renderItemData: function(t, e) {
            return this._renderItem(t, e).data("ui-selectmenu-item", e)
        },
        _renderItem: function(t, e) {
            var i = V("<li>"),
                s = V("<div>", {
                    title: e.element.attr("title")
                });
            return e.disabled && this._addClass(i, null, "ui-state-disabled"), this._setText(s, e.label), i.append(s).appendTo(t)
        },
        _setText: function(t, e) {
            e ? t.text(e) : t.html("&#160;")
        },
        _move: function(t, e) {
            var i, s = ".ui-menu-item";
            this.isOpen ? i = this.menuItems.eq(this.focusIndex).parent("li") : (i = this.menuItems.eq(this.element[0].selectedIndex).parent("li"), s += ":not(.ui-state-disabled)"), (s = "first" === t || "last" === t ? i["first" === t ? "prevAll" : "nextAll"](s).eq(-1) : i[t + "All"](s).eq(0)).length && this.menuInstance.focus(e, s)
        },
        _getSelectedItem: function() {
            return this.menuItems.eq(this.element[0].selectedIndex).parent("li")
        },
        _toggle: function(t) {
            this[this.isOpen ? "close" : "open"](t)
        },
        _setSelection: function() {
            var t;
            this.range && (window.getSelection ? ((t = window.getSelection()).removeAllRanges(), t.addRange(this.range)) : this.range.select(), this.button.focus())
        },
        _documentClick: {
            mousedown: function(t) {
                !this.isOpen || V(t.target).closest(".ui-selectmenu-menu, #" + V.escapeSelector(this.ids.button)).length || this.close(t)
            }
        },
        _buttonEvents: {
            mousedown: function() {
                var t;
                window.getSelection ? (t = window.getSelection()).rangeCount && (this.range = t.getRangeAt(0)) : this.range = document.selection.createRange()
            },
            click: function(t) {
                this._setSelection(), this._toggle(t)
            },
            keydown: function(t) {
                var e = !0;
                switch (t.keyCode) {
                    case V.ui.keyCode.TAB:
                    case V.ui.keyCode.ESCAPE:
                        this.close(t), e = !1;
                        break;
                    case V.ui.keyCode.ENTER:
                        this.isOpen && this._selectFocusedItem(t);
                        break;
                    case V.ui.keyCode.UP:
                        t.altKey ? this._toggle(t) : this._move("prev", t);
                        break;
                    case V.ui.keyCode.DOWN:
                        t.altKey ? this._toggle(t) : this._move("next", t);
                        break;
                    case V.ui.keyCode.SPACE:
                        this.isOpen ? this._selectFocusedItem(t) : this._toggle(t);
                        break;
                    case V.ui.keyCode.LEFT:
                        this._move("prev", t);
                        break;
                    case V.ui.keyCode.RIGHT:
                        this._move("next", t);
                        break;
                    case V.ui.keyCode.HOME:
                    case V.ui.keyCode.PAGE_UP:
                        this._move("first", t);
                        break;
                    case V.ui.keyCode.END:
                    case V.ui.keyCode.PAGE_DOWN:
                        this._move("last", t);
                        break;
                    default:
                        this.menu.trigger(t), e = !1
                }
                e && t.preventDefault()
            }
        },
        _selectFocusedItem: function(t) {
            var e = this.menuItems.eq(this.focusIndex).parent("li");
            e.hasClass("ui-state-disabled") || this._select(e.data("ui-selectmenu-item"), t)
        },
        _select: function(t, e) {
            var i = this.element[0].selectedIndex;
            this.element[0].selectedIndex = t.index, this.buttonItem.replaceWith(this.buttonItem = this._renderButtonItem(t)), this._setAria(t), this._trigger("select", e, {
                item: t
            }), t.index !== i && this._trigger("change", e, {
                item: t
            }), this.close(e)
        },
        _setAria: function(t) {
            t = this.menuItems.eq(t.index).attr("id"), this.button.attr({
                "aria-labelledby": t,
                "aria-activedescendant": t
            }), this.menu.attr("aria-activedescendant", t)
        },
        _setOption: function(t, e) {
            var i;
            "icons" === t && (i = this.button.find("span.ui-icon"), this._removeClass(i, null, this.options.icons.button)._addClass(i, null, e.button)), this._super(t, e), "appendTo" === t && this.menuWrap.appendTo(this._appendTo()), "width" === t && this._resizeButton()
        },
        _setOptionDisabled: function(t) {
            this._super(t), this.menuInstance.option("disabled", t), this.button.attr("aria-disabled", t), this._toggleClass(this.button, null, "ui-state-disabled", t), this.element.prop("disabled", t), t ? (this.button.attr("tabindex", -1), this.close()) : this.button.attr("tabindex", 0)
        },
        _appendTo: function() {
            var t = this.options.appendTo;
            return (t = (t = t && (t.jquery || t.nodeType ? V(t) : this.document.find(t).eq(0))) && t[0] ? t : this.element.closest(".ui-front, dialog")).length ? t : this.document[0].body
        },
        _toggleAttr: function() {
            this.button.attr("aria-expanded", this.isOpen), this._removeClass(this.button, "ui-selectmenu-button-" + (this.isOpen ? "closed" : "open"))._addClass(this.button, "ui-selectmenu-button-" + (this.isOpen ? "open" : "closed"))._toggleClass(this.menuWrap, "ui-selectmenu-open", null, this.isOpen), this.menu.attr("aria-hidden", !this.isOpen)
        },
        _resizeButton: function() {
            var t = this.options.width;
            !1 !== t ? (null === t && (t = this.element.show().outerWidth(), this.element.hide()), this.button.outerWidth(t)) : this.button.css("width", "")
        },
        _resizeMenu: function() {
            this.menu.outerWidth(Math.max(this.button.outerWidth(), this.menu.width("").outerWidth() + 1))
        },
        _getCreateOptions: function() {
            var t = this._super();
            return t.disabled = this.element.prop("disabled"), t
        },
        _parseOptions: function(t) {
            var i = this,
                s = [];
            t.each(function(t, e) {
                e.hidden || s.push(i._parseOption(V(e), t))
            }), this.items = s
        },
        _parseOption: function(t, e) {
            var i = t.parent("optgroup");
            return {
                element: t,
                index: e,
                value: t.val(),
                label: t.text(),
                optgroup: i.attr("label") || "",
                disabled: i.prop("disabled") || t.prop("disabled")
            }
        },
        _destroy: function() {
            this._unbindFormResetHandler(), this.menuWrap.remove(), this.button.remove(), this.element.show(), this.element.removeUniqueId(), this.labels.attr("for", this.ids.element)
        }
    }]), V.widget("ui.slider", V.ui.mouse, {
        version: "1.13.0",
        widgetEventPrefix: "slide",
        options: {
            animate: !1,
            classes: {
                "ui-slider": "ui-corner-all",
                "ui-slider-handle": "ui-corner-all",
                "ui-slider-range": "ui-corner-all ui-widget-header"
            },
            distance: 0,
            max: 100,
            min: 0,
            orientation: "horizontal",
            range: !1,
            step: 1,
            value: 0,
            values: null,
            change: null,
            slide: null,
            start: null,
            stop: null
        },
        numPages: 5,
        _create: function() {
            this._keySliding = !1, this._mouseSliding = !1, this._animateOff = !0, this._handleIndex = null, this._detectOrientation(), this._mouseInit(), this._calculateNewMax(), this._addClass("ui-slider ui-slider-" + this.orientation, "ui-widget ui-widget-content"), this._refresh(), this._animateOff = !1
        },
        _refresh: function() {
            this._createRange(), this._createHandles(), this._setupEvents(), this._refreshValue()
        },
        _createHandles: function() {
            var t, e = this.options,
                i = this.element.find(".ui-slider-handle"),
                s = [],
                n = e.values && e.values.length || 1;
            for (i.length > n && (i.slice(n).remove(), i = i.slice(0, n)), t = i.length; t < n; t++) s.push("<span tabindex='0'></span>");
            this.handles = i.add(V(s.join("")).appendTo(this.element)), this._addClass(this.handles, "ui-slider-handle", "ui-state-default"), this.handle = this.handles.eq(0), this.handles.each(function(t) {
                V(this).data("ui-slider-handle-index", t).attr("tabIndex", 0)
            })
        },
        _createRange: function() {
            var t = this.options;
            t.range ? (!0 === t.range && (t.values ? t.values.length && 2 !== t.values.length ? t.values = [t.values[0], t.values[0]] : Array.isArray(t.values) && (t.values = t.values.slice(0)) : t.values = [this._valueMin(), this._valueMin()]), this.range && this.range.length ? (this._removeClass(this.range, "ui-slider-range-min ui-slider-range-max"), this.range.css({
                left: "",
                bottom: ""
            })) : (this.range = V("<div>").appendTo(this.element), this._addClass(this.range, "ui-slider-range")), "min" !== t.range && "max" !== t.range || this._addClass(this.range, "ui-slider-range-" + t.range)) : (this.range && this.range.remove(), this.range = null)
        },
        _setupEvents: function() {
            this._off(this.handles), this._on(this.handles, this._handleEvents), this._hoverable(this.handles), this._focusable(this.handles)
        },
        _destroy: function() {
            this.handles.remove(), this.range && this.range.remove(), this._mouseDestroy()
        },
        _mouseCapture: function(t) {
            var i, s, n, o, e, a, r = this,
                l = this.options;
            return !l.disabled && (this.elementSize = {
                width: this.element.outerWidth(),
                height: this.element.outerHeight()
            }, this.elementOffset = this.element.offset(), a = {
                x: t.pageX,
                y: t.pageY
            }, i = this._normValueFromMouse(a), s = this._valueMax() - this._valueMin() + 1, this.handles.each(function(t) {
                var e = Math.abs(i - r.values(t));
                (e < s || s === e && (t === r._lastChangedValue || r.values(t) === l.min)) && (s = e, n = V(this), o = t)
            }), !1 !== this._start(t, o)) && (this._mouseSliding = !0, this._handleIndex = o, this._addClass(n, null, "ui-state-active"), n.trigger("focus"), e = n.offset(), a = !V(t.target).parents().addBack().is(".ui-slider-handle"), this._clickOffset = a ? {
                left: 0,
                top: 0
            } : {
                left: t.pageX - e.left - n.width() / 2,
                top: t.pageY - e.top - n.height() / 2 - (parseInt(n.css("borderTopWidth"), 10) || 0) - (parseInt(n.css("borderBottomWidth"), 10) || 0) + (parseInt(n.css("marginTop"), 10) || 0)
            }, this.handles.hasClass("ui-state-hover") || this._slide(t, o, i), this._animateOff = !0)
        },
        _mouseStart: function() {
            return !0
        },
        _mouseDrag: function(t) {
            var e = {
                    x: t.pageX,
                    y: t.pageY
                },
                e = this._normValueFromMouse(e);
            return this._slide(t, this._handleIndex, e), !1
        },
        _mouseStop: function(t) {
            return this._removeClass(this.handles, null, "ui-state-active"), this._mouseSliding = !1, this._stop(t, this._handleIndex), this._change(t, this._handleIndex), this._handleIndex = null, this._clickOffset = null, this._animateOff = !1
        },
        _detectOrientation: function() {
            this.orientation = "vertical" === this.options.orientation ? "vertical" : "horizontal"
        },
        _normValueFromMouse: function(t) {
            var e;
            return (t = 1 < (t = (t = "horizontal" === this.orientation ? (e = this.elementSize.width, t.x - this.elementOffset.left - (this._clickOffset ? this._clickOffset.left : 0)) : (e = this.elementSize.height, t.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0))) / e) ? 1 : t) < 0 && (t = 0), "vertical" === this.orientation && (t = 1 - t), e = this._valueMax() - this._valueMin(), e = this._valueMin() + t * e, this._trimAlignValue(e)
        },
        _uiHash: function(t, e, i) {
            var s = {
                handle: this.handles[t],
                handleIndex: t,
                value: void 0 !== e ? e : this.value()
            };
            return this._hasMultipleValues() && (s.value = void 0 !== e ? e : this.values(t), s.values = i || this.values()), s
        },
        _hasMultipleValues: function() {
            return this.options.values && this.options.values.length
        },
        _start: function(t, e) {
            return this._trigger("start", t, this._uiHash(e))
        },
        _slide: function(t, e, i) {
            var s, n = this.value(),
                o = this.values();
            this._hasMultipleValues() && (s = this.values(e ? 0 : 1), n = this.values(e), 2 === this.options.values.length && !0 === this.options.range && (i = 0 === e ? Math.min(s, i) : Math.max(s, i)), o[e] = i), i !== n && !1 !== this._trigger("slide", t, this._uiHash(e, i, o)) && (this._hasMultipleValues() ? this.values(e, i) : this.value(i))
        },
        _stop: function(t, e) {
            this._trigger("stop", t, this._uiHash(e))
        },
        _change: function(t, e) {
            this._keySliding || this._mouseSliding || (this._lastChangedValue = e, this._trigger("change", t, this._uiHash(e)))
        },
        value: function(t) {
            return arguments.length ? (this.options.value = this._trimAlignValue(t), this._refreshValue(), void this._change(null, 0)) : this._value()
        },
        values: function(t, e) {
            var i, s, n;
            if (1 < arguments.length) this.options.values[t] = this._trimAlignValue(e), this._refreshValue(), this._change(null, t);
            else {
                if (!arguments.length) return this._values();
                if (!Array.isArray(t)) return this._hasMultipleValues() ? this._values(t) : this.value();
                for (i = this.options.values, s = t, n = 0; n < i.length; n += 1) i[n] = this._trimAlignValue(s[n]), this._change(null, n);
                this._refreshValue()
            }
        },
        _setOption: function(t, e) {
            var i, s = 0;
            switch ("range" === t && !0 === this.options.range && ("min" === e ? (this.options.value = this._values(0), this.options.values = null) : "max" === e && (this.options.value = this._values(this.options.values.length - 1), this.options.values = null)), Array.isArray(this.options.values) && (s = this.options.values.length), this._super(t, e), t) {
                case "orientation":
                    this._detectOrientation(), this._removeClass("ui-slider-horizontal ui-slider-vertical")._addClass("ui-slider-" + this.orientation), this._refreshValue(), this.options.range && this._refreshRange(e), this.handles.css("horizontal" === e ? "bottom" : "left", "");
                    break;
                case "value":
                    this._animateOff = !0, this._refreshValue(), this._change(null, 0), this._animateOff = !1;
                    break;
                case "values":
                    for (this._animateOff = !0, this._refreshValue(), i = s - 1; 0 <= i; i--) this._change(null, i);
                    this._animateOff = !1;
                    break;
                case "step":
                case "min":
                case "max":
                    this._animateOff = !0, this._calculateNewMax(), this._refreshValue(), this._animateOff = !1;
                    break;
                case "range":
                    this._animateOff = !0, this._refresh(), this._animateOff = !1
            }
        },
        _setOptionDisabled: function(t) {
            this._super(t), this._toggleClass(null, "ui-state-disabled", !!t)
        },
        _value: function() {
            var t = this.options.value;
            return this._trimAlignValue(t)
        },
        _values: function(t) {
            var e, i;
            if (arguments.length) return t = this.options.values[t], this._trimAlignValue(t);
            if (this._hasMultipleValues()) {
                for (e = this.options.values.slice(), i = 0; i < e.length; i += 1) e[i] = this._trimAlignValue(e[i]);
                return e
            }
            return []
        },
        _trimAlignValue: function(t) {
            var e, i;
            return t <= this._valueMin() ? this._valueMin() : t >= this._valueMax() ? this._valueMax() : (e = 0 < this.options.step ? this.options.step : 1, t -= i = (t - this._valueMin()) % e, 2 * Math.abs(i) >= e && (t += 0 < i ? e : -e), parseFloat(t.toFixed(5)))
        },
        _calculateNewMax: function() {
            var t = this.options.max,
                e = this._valueMin(),
                i = this.options.step;
            (t = Math.round((t - e) / i) * i + e) > this.options.max && (t -= i), this.max = parseFloat(t.toFixed(this._precision()))
        },
        _precision: function() {
            var t = this._precisionOf(this.options.step);
            return null !== this.options.min ? Math.max(t, this._precisionOf(this.options.min)) : t
        },
        _precisionOf: function(t) {
            var e = t.toString();
            return -1 === (t = e.indexOf(".")) ? 0 : e.length - t - 1
        },
        _valueMin: function() {
            return this.options.min
        },
        _valueMax: function() {
            return this.max
        },
        _refreshRange: function(t) {
            "vertical" === t && this.range.css({
                width: "",
                left: ""
            }), "horizontal" === t && this.range.css({
                height: "",
                bottom: ""
            })
        },
        _refreshValue: function() {
            var e, i, t, s, n, o = this.options.range,
                a = this.options,
                r = this,
                l = !this._animateOff && a.animate,
                h = {};
            this._hasMultipleValues() ? this.handles.each(function(t) {
                i = (r.values(t) - r._valueMin()) / (r._valueMax() - r._valueMin()) * 100, h["horizontal" === r.orientation ? "left" : "bottom"] = i + "%", V(this).stop(1, 1)[l ? "animate" : "css"](h, a.animate), !0 === r.options.range && ("horizontal" === r.orientation ? (0 === t && r.range.stop(1, 1)[l ? "animate" : "css"]({
                    left: i + "%"
                }, a.animate), 1 === t && r.range[l ? "animate" : "css"]({
                    width: i - e + "%"
                }, {
                    queue: !1,
                    duration: a.animate
                })) : (0 === t && r.range.stop(1, 1)[l ? "animate" : "css"]({
                    bottom: i + "%"
                }, a.animate), 1 === t && r.range[l ? "animate" : "css"]({
                    height: i - e + "%"
                }, {
                    queue: !1,
                    duration: a.animate
                }))), e = i
            }) : (t = this.value(), s = this._valueMin(), n = this._valueMax(), i = n !== s ? (t - s) / (n - s) * 100 : 0, h["horizontal" === this.orientation ? "left" : "bottom"] = i + "%", this.handle.stop(1, 1)[l ? "animate" : "css"](h, a.animate), "min" === o && "horizontal" === this.orientation && this.range.stop(1, 1)[l ? "animate" : "css"]({
                width: i + "%"
            }, a.animate), "max" === o && "horizontal" === this.orientation && this.range.stop(1, 1)[l ? "animate" : "css"]({
                width: 100 - i + "%"
            }, a.animate), "min" === o && "vertical" === this.orientation && this.range.stop(1, 1)[l ? "animate" : "css"]({
                height: i + "%"
            }, a.animate), "max" === o && "vertical" === this.orientation && this.range.stop(1, 1)[l ? "animate" : "css"]({
                height: 100 - i + "%"
            }, a.animate))
        },
        _handleEvents: {
            keydown: function(t) {
                var e, i, s, n = V(t.target).data("ui-slider-handle-index");
                switch (t.keyCode) {
                    case V.ui.keyCode.HOME:
                    case V.ui.keyCode.END:
                    case V.ui.keyCode.PAGE_UP:
                    case V.ui.keyCode.PAGE_DOWN:
                    case V.ui.keyCode.UP:
                    case V.ui.keyCode.RIGHT:
                    case V.ui.keyCode.DOWN:
                    case V.ui.keyCode.LEFT:
                        if (t.preventDefault(), !this._keySliding && (this._keySliding = !0, this._addClass(V(t.target), null, "ui-state-active"), !1 === this._start(t, n))) return
                }
                switch (s = this.options.step, e = i = this._hasMultipleValues() ? this.values(n) : this.value(), t.keyCode) {
                    case V.ui.keyCode.HOME:
                        i = this._valueMin();
                        break;
                    case V.ui.keyCode.END:
                        i = this._valueMax();
                        break;
                    case V.ui.keyCode.PAGE_UP:
                        i = this._trimAlignValue(e + (this._valueMax() - this._valueMin()) / this.numPages);
                        break;
                    case V.ui.keyCode.PAGE_DOWN:
                        i = this._trimAlignValue(e - (this._valueMax() - this._valueMin()) / this.numPages);
                        break;
                    case V.ui.keyCode.UP:
                    case V.ui.keyCode.RIGHT:
                        if (e === this._valueMax()) return;
                        i = this._trimAlignValue(e + s);
                        break;
                    case V.ui.keyCode.DOWN:
                    case V.ui.keyCode.LEFT:
                        if (e === this._valueMin()) return;
                        i = this._trimAlignValue(e - s)
                }
                this._slide(t, n, i)
            },
            keyup: function(t) {
                var e = V(t.target).data("ui-slider-handle-index");
                this._keySliding && (this._keySliding = !1, this._stop(t, e), this._change(t, e), this._removeClass(V(t.target), null, "ui-state-active"))
            }
        }
    }), V.widget("ui.spinner", {
        version: "1.13.0",
        defaultElement: "<input>",
        widgetEventPrefix: "spin",
        options: {
            classes: {
                "ui-spinner": "ui-corner-all",
                "ui-spinner-down": "ui-corner-br",
                "ui-spinner-up": "ui-corner-tr"
            },
            culture: null,
            icons: {
                down: "ui-icon-triangle-1-s",
                up: "ui-icon-triangle-1-n"
            },
            incremental: !0,
            max: null,
            min: null,
            numberFormat: null,
            page: 10,
            step: 1,
            change: null,
            spin: null,
            start: null,
            stop: null
        },
        _create: function() {
            this._setOption("max", this.options.max), this._setOption("min", this.options.min), this._setOption("step", this.options.step), "" !== this.value() && this._value(this.element.val(), !0), this._draw(), this._on(this._events), this._refresh(), this._on(this.window, {
                beforeunload: function() {
                    this.element.removeAttr("autocomplete")
                }
            })
        },
        _getCreateOptions: function() {
            var s = this._super(),
                n = this.element;
            return V.each(["min", "max", "step"], function(t, e) {
                var i = n.attr(e);
                null != i && i.length && (s[e] = i)
            }), s
        },
        _events: {
            keydown: function(t) {
                this._start(t) && this._keydown(t) && t.preventDefault()
            },
            keyup: "_stop",
            focus: function() {
                this.previous = this.element.val()
            },
            blur: function(t) {
                this.cancelBlur ? delete this.cancelBlur : (this._stop(), this._refresh(), this.previous !== this.element.val() && this._trigger("change", t))
            },
            mousewheel: function(t, e) {
                var i = V.ui.safeActiveElement(this.document[0]);
                if (this.element[0] === i && e) {
                    if (!this.spinning && !this._start(t)) return !1;
                    this._spin((0 < e ? 1 : -1) * this.options.step, t), clearTimeout(this.mousewheelTimer), this.mousewheelTimer = this._delay(function() {
                        this.spinning && this._stop(t)
                    }, 100), t.preventDefault()
                }
            },
            "mousedown .ui-spinner-button": function(t) {
                var e;

                function i() {
                    this.element[0] !== V.ui.safeActiveElement(this.document[0]) && (this.element.trigger("focus"), this.previous = e, this._delay(function() {
                        this.previous = e
                    }))
                }
                e = this.element[0] === V.ui.safeActiveElement(this.document[0]) ? this.previous : this.element.val(), t.preventDefault(), i.call(this), this.cancelBlur = !0, this._delay(function() {
                    delete this.cancelBlur, i.call(this)
                }), !1 !== this._start(t) && this._repeat(null, V(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t)
            },
            "mouseup .ui-spinner-button": "_stop",
            "mouseenter .ui-spinner-button": function(t) {
                if (V(t.currentTarget).hasClass("ui-state-active")) return !1 !== this._start(t) && void this._repeat(null, V(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t)
            },
            "mouseleave .ui-spinner-button": "_stop"
        },
        _enhance: function() {
            this.uiSpinner = this.element.attr("autocomplete", "off").wrap("<span>").parent().append("<a></a><a></a>")
        },
        _draw: function() {
            this._enhance(), this._addClass(this.uiSpinner, "ui-spinner", "ui-widget ui-widget-content"), this._addClass("ui-spinner-input"), this.element.attr("role", "spinbutton"), this.buttons = this.uiSpinner.children("a").attr("tabIndex", -1).attr("aria-hidden", !0).button({
                classes: {
                    "ui-button": ""
                }
            }), this._removeClass(this.buttons, "ui-corner-all"), this._addClass(this.buttons.first(), "ui-spinner-button ui-spinner-up"), this._addClass(this.buttons.last(), "ui-spinner-button ui-spinner-down"), this.buttons.first().button({
                icon: this.options.icons.up,
                showLabel: !1
            }), this.buttons.last().button({
                icon: this.options.icons.down,
                showLabel: !1
            }), this.buttons.height() > Math.ceil(.5 * this.uiSpinner.height()) && 0 < this.uiSpinner.height() && this.uiSpinner.height(this.uiSpinner.height())
        },
        _keydown: function(t) {
            var e = this.options,
                i = V.ui.keyCode;
            switch (t.keyCode) {
                case i.UP:
                    return this._repeat(null, 1, t), !0;
                case i.DOWN:
                    return this._repeat(null, -1, t), !0;
                case i.PAGE_UP:
                    return this._repeat(null, e.page, t), !0;
                case i.PAGE_DOWN:
                    return this._repeat(null, -e.page, t), !0
            }
            return !1
        },
        _start: function(t) {
            return !(!this.spinning && !1 === this._trigger("start", t)) && (this.counter || (this.counter = 1), this.spinning = !0)
        },
        _repeat: function(t, e, i) {
            t = t || 500, clearTimeout(this.timer), this.timer = this._delay(function() {
                this._repeat(40, e, i)
            }, t), this._spin(e * this.options.step, i)
        },
        _spin: function(t, e) {
            var i = this.value() || 0;
            this.counter || (this.counter = 1), i = this._adjustValue(i + t * this._increment(this.counter)), this.spinning && !1 === this._trigger("spin", e, {
                value: i
            }) || (this._value(i), this.counter++)
        },
        _increment: function(t) {
            var e = this.options.incremental;
            return e ? "function" == typeof e ? e(t) : Math.floor(t * t * t / 5e4 - t * t / 500 + 17 * t / 200 + 1) : 1
        },
        _precision: function() {
            var t = this._precisionOf(this.options.step);
            return null !== this.options.min ? Math.max(t, this._precisionOf(this.options.min)) : t
        },
        _precisionOf: function(t) {
            var e = t.toString();
            return -1 === (t = e.indexOf(".")) ? 0 : e.length - t - 1
        },
        _adjustValue: function(t) {
            var e = this.options,
                i = null !== e.min ? e.min : 0;
            return t = i + Math.round((t - i) / e.step) * e.step, t = parseFloat(t.toFixed(this._precision())), null !== e.max && t > e.max ? e.max : null !== e.min && t < e.min ? e.min : t
        },
        _stop: function(t) {
            this.spinning && (clearTimeout(this.timer), clearTimeout(this.mousewheelTimer), this.counter = 0, this.spinning = !1, this._trigger("stop", t))
        },
        _setOption: function(t, e) {
            var i;
            "culture" === t || "numberFormat" === t ? (i = this._parse(this.element.val()), this.options[t] = e, this.element.val(this._format(i))) : ("max" !== t && "min" !== t && "step" !== t || "string" == typeof e && (e = this._parse(e)), "icons" === t && (i = this.buttons.first().find(".ui-icon"), this._removeClass(i, null, this.options.icons.up), this._addClass(i, null, e.up), i = this.buttons.last().find(".ui-icon"), this._removeClass(i, null, this.options.icons.down), this._addClass(i, null, e.down)), this._super(t, e))
        },
        _setOptionDisabled: function(t) {
            this._super(t), this._toggleClass(this.uiSpinner, null, "ui-state-disabled", !!t), this.element.prop("disabled", !!t), this.buttons.button(t ? "disable" : "enable")
        },
        _setOptions: m(function(t) {
            this._super(t)
        }),
        _parse: function(t) {
            return "" === (t = "string" == typeof t && "" !== t ? window.Globalize && this.options.numberFormat ? Globalize.parseFloat(t, 10, this.options.culture) : +t : t) || isNaN(t) ? null : t
        },
        _format: function(t) {
            return "" === t ? "" : window.Globalize && this.options.numberFormat ? Globalize.format(t, this.options.numberFormat, this.options.culture) : t
        },
        _refresh: function() {
            this.element.attr({
                "aria-valuemin": this.options.min,
                "aria-valuemax": this.options.max,
                "aria-valuenow": this._parse(this.element.val())
            })
        },
        isValid: function() {
            var t = this.value();
            return null !== t && t === this._adjustValue(t)
        },
        _value: function(t, e) {
            var i;
            "" !== t && null !== (i = this._parse(t)) && (e || (i = this._adjustValue(i)), t = this._format(i)), this.element.val(t), this._refresh()
        },
        _destroy: function() {
            this.element.prop("disabled", !1).removeAttr("autocomplete role aria-valuemin aria-valuemax aria-valuenow"), this.uiSpinner.replaceWith(this.element)
        },
        stepUp: m(function(t) {
            this._stepUp(t)
        }),
        _stepUp: function(t) {
            this._start() && (this._spin((t || 1) * this.options.step), this._stop())
        },
        stepDown: m(function(t) {
            this._stepDown(t)
        }),
        _stepDown: function(t) {
            this._start() && (this._spin((t || 1) * -this.options.step), this._stop())
        },
        pageUp: m(function(t) {
            this._stepUp((t || 1) * this.options.page)
        }),
        pageDown: m(function(t) {
            this._stepDown((t || 1) * this.options.page)
        }),
        value: function(t) {
            if (!arguments.length) return this._parse(this.element.val());
            m(this._value).call(this, t)
        },
        widget: function() {
            return this.uiSpinner
        }
    }), !1 !== V.uiBackCompat && V.widget("ui.spinner", V.ui.spinner, {
        _enhance: function() {
            this.uiSpinner = this.element.attr("autocomplete", "off").wrap(this._uiSpinnerHtml()).parent().append(this._buttonHtml())
        },
        _uiSpinnerHtml: function() {
            return "<span>"
        },
        _buttonHtml: function() {
            return "<a></a><a></a>"
        }
    }), V.ui.spinner, V.widget("ui.tabs", {
        version: "1.13.0",
        delay: 300,
        options: {
            active: null,
            classes: {
                "ui-tabs": "ui-corner-all",
                "ui-tabs-nav": "ui-corner-all",
                "ui-tabs-panel": "ui-corner-bottom",
                "ui-tabs-tab": "ui-corner-top"
            },
            collapsible: !1,
            event: "click",
            heightStyle: "content",
            hide: null,
            show: null,
            activate: null,
            beforeActivate: null,
            beforeLoad: null,
            load: null
        },
        _isLocal: (p = /#.*$/, function(t) {
            var e = t.href.replace(p, ""),
                i = location.href.replace(p, "");
            try {
                e = decodeURIComponent(e)
            } catch (t) {}
            try {
                i = decodeURIComponent(i)
            } catch (t) {}
            return 1 < t.hash.length && e === i
        }),
        _create: function() {
            var e = this,
                t = this.options;
            this.running = !1, this._addClass("ui-tabs", "ui-widget ui-widget-content"), this._toggleClass("ui-tabs-collapsible", null, t.collapsible), this._processTabs(), t.active = this._initialActive(), Array.isArray(t.disabled) && (t.disabled = V.uniqueSort(t.disabled.concat(V.map(this.tabs.filter(".ui-state-disabled"), function(t) {
                return e.tabs.index(t)
            }))).sort()), !1 !== this.options.active && this.anchors.length ? this.active = this._findActive(t.active) : this.active = V(), this._refresh(), this.active.length && this.load(t.active)
        },
        _initialActive: function() {
            var i = this.options.active,
                t = this.options.collapsible,
                s = location.hash.substring(1);
            return null === i && (s && this.tabs.each(function(t, e) {
                if (V(e).attr("aria-controls") === s) return i = t, !1
            }), null !== (i = null === i ? this.tabs.index(this.tabs.filter(".ui-tabs-active")) : i) && -1 !== i || (i = !!this.tabs.length && 0)), !1 !== i && -1 === (i = this.tabs.index(this.tabs.eq(i))) && (i = !t && 0), i = !t && !1 === i && this.anchors.length ? 0 : i
        },
        _getCreateEventData: function() {
            return {
                tab: this.active,
                panel: this.active.length ? this._getPanelForTab(this.active) : V()
            }
        },
        _tabKeydown: function(t) {
            var e = V(V.ui.safeActiveElement(this.document[0])).closest("li"),
                i = this.tabs.index(e),
                s = !0;
            if (!this._handlePageNav(t)) {
                switch (t.keyCode) {
                    case V.ui.keyCode.RIGHT:
                    case V.ui.keyCode.DOWN:
                        i++;
                        break;
                    case V.ui.keyCode.UP:
                    case V.ui.keyCode.LEFT:
                        s = !1, i--;
                        break;
                    case V.ui.keyCode.END:
                        i = this.anchors.length - 1;
                        break;
                    case V.ui.keyCode.HOME:
                        i = 0;
                        break;
                    case V.ui.keyCode.SPACE:
                        return t.preventDefault(), clearTimeout(this.activating), void this._activate(i);
                    case V.ui.keyCode.ENTER:
                        return t.preventDefault(), clearTimeout(this.activating), void this._activate(i !== this.options.active && i);
                    default:
                        return
                }
                t.preventDefault(), clearTimeout(this.activating), i = this._focusNextTab(i, s), t.ctrlKey || t.metaKey || (e.attr("aria-selected", "false"), this.tabs.eq(i).attr("aria-selected", "true"), this.activating = this._delay(function() {
                    this.option("active", i)
                }, this.delay))
            }
        },
        _panelKeydown: function(t) {
            this._handlePageNav(t) || t.ctrlKey && t.keyCode === V.ui.keyCode.UP && (t.preventDefault(), this.active.trigger("focus"))
        },
        _handlePageNav: function(t) {
            return t.altKey && t.keyCode === V.ui.keyCode.PAGE_UP ? (this._activate(this._focusNextTab(this.options.active - 1, !1)), !0) : t.altKey && t.keyCode === V.ui.keyCode.PAGE_DOWN ? (this._activate(this._focusNextTab(this.options.active + 1, !0)), !0) : void 0
        },
        _findNextTab: function(t, e) {
            for (var i = this.tabs.length - 1; - 1 !== V.inArray(t = (t = i < t ? 0 : t) < 0 ? i : t, this.options.disabled);) t = e ? t + 1 : t - 1;
            return t
        },
        _focusNextTab: function(t, e) {
            return t = this._findNextTab(t, e), this.tabs.eq(t).trigger("focus"), t
        },
        _setOption: function(t, e) {
            "active" !== t ? (this._super(t, e), "collapsible" === t && (this._toggleClass("ui-tabs-collapsible", null, e), e || !1 !== this.options.active || this._activate(0)), "event" === t && this._setupEvents(e), "heightStyle" === t && this._setupHeightStyle(e)) : this._activate(e)
        },
        _sanitizeSelector: function(t) {
            return t ? t.replace(/[!"$%&'()*+,.\/:;<=>?@\[\]\^`{|}~]/g, "\\$&") : ""
        },
        refresh: function() {
            var t = this.options,
                e = this.tablist.children(":has(a[href])");
            t.disabled = V.map(e.filter(".ui-state-disabled"), function(t) {
                return e.index(t)
            }), this._processTabs(), !1 !== t.active && this.anchors.length ? this.active.length && !V.contains(this.tablist[0], this.active[0]) ? this.tabs.length === t.disabled.length ? (t.active = !1, this.active = V()) : this._activate(this._findNextTab(Math.max(0, t.active - 1), !1)) : t.active = this.tabs.index(this.active) : (t.active = !1, this.active = V()), this._refresh()
        },
        _refresh: function() {
            this._setOptionDisabled(this.options.disabled), this._setupEvents(this.options.event), this._setupHeightStyle(this.options.heightStyle), this.tabs.not(this.active).attr({
                "aria-selected": "false",
                "aria-expanded": "false",
                tabIndex: -1
            }), this.panels.not(this._getPanelForTab(this.active)).hide().attr({
                "aria-hidden": "true"
            }), this.active.length ? (this.active.attr({
                "aria-selected": "true",
                "aria-expanded": "true",
                tabIndex: 0
            }), this._addClass(this.active, "ui-tabs-active", "ui-state-active"), this._getPanelForTab(this.active).show().attr({
                "aria-hidden": "false"
            })) : this.tabs.eq(0).attr("tabIndex", 0)
        },
        _processTabs: function() {
            var l = this,
                t = this.tabs,
                e = this.anchors,
                i = this.panels;
            this.tablist = this._getList().attr("role", "tablist"), this._addClass(this.tablist, "ui-tabs-nav", "ui-helper-reset ui-helper-clearfix ui-widget-header"), this.tablist.on("mousedown" + this.eventNamespace, "> li", function(t) {
                V(this).is(".ui-state-disabled") && t.preventDefault()
            }).on("focus" + this.eventNamespace, ".ui-tabs-anchor", function() {
                V(this).closest("li").is(".ui-state-disabled") && this.blur()
            }), this.tabs = this.tablist.find("> li:has(a[href])").attr({
                role: "tab",
                tabIndex: -1
            }), this._addClass(this.tabs, "ui-tabs-tab", "ui-state-default"), this.anchors = this.tabs.map(function() {
                return V("a", this)[0]
            }).attr({
                tabIndex: -1
            }), this._addClass(this.anchors, "ui-tabs-anchor"), this.panels = V(), this.anchors.each(function(t, e) {
                var i, s, n, o = V(e).uniqueId().attr("id"),
                    a = V(e).closest("li"),
                    r = a.attr("aria-controls");
                l._isLocal(e) ? (n = (i = e.hash).substring(1), s = l.element.find(l._sanitizeSelector(i))) : (n = a.attr("aria-controls") || V({}).uniqueId()[0].id, (s = l.element.find(i = "#" + n)).length || (s = l._createPanel(n)).insertAfter(l.panels[t - 1] || l.tablist), s.attr("aria-live", "polite")), s.length && (l.panels = l.panels.add(s)), r && a.data("ui-tabs-aria-controls", r), a.attr({
                    "aria-controls": n,
                    "aria-labelledby": o
                }), s.attr("aria-labelledby", o)
            }), this.panels.attr("role", "tabpanel"), this._addClass(this.panels, "ui-tabs-panel", "ui-widget-content"), t && (this._off(t.not(this.tabs)), this._off(e.not(this.anchors)), this._off(i.not(this.panels)))
        },
        _getList: function() {
            return this.tablist || this.element.find("ol, ul").eq(0)
        },
        _createPanel: function(t) {
            return V("<div>").attr("id", t).data("ui-tabs-destroy", !0)
        },
        _setOptionDisabled: function(t) {
            var e, i;
            for (Array.isArray(t) && (t.length ? t.length === this.anchors.length && (t = !0) : t = !1), i = 0; e = this.tabs[i]; i++) e = V(e), !0 === t || -1 !== V.inArray(i, t) ? (e.attr("aria-disabled", "true"), this._addClass(e, null, "ui-state-disabled")) : (e.removeAttr("aria-disabled"), this._removeClass(e, null, "ui-state-disabled"));
            this.options.disabled = t, this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !0 === t)
        },
        _setupEvents: function(t) {
            var i = {};
            t && V.each(t.split(" "), function(t, e) {
                i[e] = "_eventHandler"
            }), this._off(this.anchors.add(this.tabs).add(this.panels)), this._on(!0, this.anchors, {
                click: function(t) {
                    t.preventDefault()
                }
            }), this._on(this.anchors, i), this._on(this.tabs, {
                keydown: "_tabKeydown"
            }), this._on(this.panels, {
                keydown: "_panelKeydown"
            }), this._focusable(this.tabs), this._hoverable(this.tabs)
        },
        _setupHeightStyle: function(t) {
            var i, e = this.element.parent();
            "fill" === t ? (i = e.height(), i -= this.element.outerHeight() - this.element.height(), this.element.siblings(":visible").each(function() {
                var t = V(this),
                    e = t.css("position");
                "absolute" !== e && "fixed" !== e && (i -= t.outerHeight(!0))
            }), this.element.children().not(this.panels).each(function() {
                i -= V(this).outerHeight(!0)
            }), this.panels.each(function() {
                V(this).height(Math.max(0, i - V(this).innerHeight() + V(this).height()))
            }).css("overflow", "auto")) : "auto" === t && (i = 0, this.panels.each(function() {
                i = Math.max(i, V(this).height("").height())
            }).height(i))
        },
        _eventHandler: function(t) {
            var e = this.options,
                i = this.active,
                s = V(t.currentTarget).closest("li"),
                n = s[0] === i[0],
                o = n && e.collapsible,
                a = o ? V() : this._getPanelForTab(s),
                r = i.length ? this._getPanelForTab(i) : V(),
                i = {
                    oldTab: i,
                    oldPanel: r,
                    newTab: o ? V() : s,
                    newPanel: a
                };
            t.preventDefault(), s.hasClass("ui-state-disabled") || s.hasClass("ui-tabs-loading") || this.running || n && !e.collapsible || !1 === this._trigger("beforeActivate", t, i) || (e.active = !o && this.tabs.index(s), this.active = n ? V() : s, this.xhr && this.xhr.abort(), r.length || a.length || V.error("jQuery UI Tabs: Mismatching fragment identifier."), a.length && this.load(this.tabs.index(s), t), this._toggle(t, i))
        },
        _toggle: function(t, e) {
            var i = this,
                s = e.newPanel,
                n = e.oldPanel;

            function o() {
                i.running = !1, i._trigger("activate", t, e)
            }

            function a() {
                i._addClass(e.newTab.closest("li"), "ui-tabs-active", "ui-state-active"), s.length && i.options.show ? i._show(s, i.options.show, o) : (s.show(), o())
            }
            this.running = !0, n.length && this.options.hide ? this._hide(n, this.options.hide, function() {
                i._removeClass(e.oldTab.closest("li"), "ui-tabs-active", "ui-state-active"), a()
            }) : (this._removeClass(e.oldTab.closest("li"), "ui-tabs-active", "ui-state-active"), n.hide(), a()), n.attr("aria-hidden", "true"), e.oldTab.attr({
                "aria-selected": "false",
                "aria-expanded": "false"
            }), s.length && n.length ? e.oldTab.attr("tabIndex", -1) : s.length && this.tabs.filter(function() {
                return 0 === V(this).attr("tabIndex")
            }).attr("tabIndex", -1), s.attr("aria-hidden", "false"), e.newTab.attr({
                "aria-selected": "true",
                "aria-expanded": "true",
                tabIndex: 0
            })
        },
        _activate: function(t) {
            (t = this._findActive(t))[0] !== this.active[0] && (t = (t = t.length ? t : this.active).find(".ui-tabs-anchor")[0], this._eventHandler({
                target: t,
                currentTarget: t,
                preventDefault: V.noop
            }))
        },
        _findActive: function(t) {
            return !1 === t ? V() : this.tabs.eq(t)
        },
        _getIndex: function(t) {
            return "string" == typeof t ? this.anchors.index(this.anchors.filter("[href$='" + V.escapeSelector(t) + "']")) : t
        },
        _destroy: function() {
            this.xhr && this.xhr.abort(), this.tablist.removeAttr("role").off(this.eventNamespace), this.anchors.removeAttr("role tabIndex").removeUniqueId(), this.tabs.add(this.panels).each(function() {
                V.data(this, "ui-tabs-destroy") ? V(this).remove() : V(this).removeAttr("role tabIndex aria-live aria-busy aria-selected aria-labelledby aria-hidden aria-expanded")
            }), this.tabs.each(function() {
                var t = V(this),
                    e = t.data("ui-tabs-aria-controls");
                e ? t.attr("aria-controls", e).removeData("ui-tabs-aria-controls") : t.removeAttr("aria-controls")
            }), this.panels.show(), "content" !== this.options.heightStyle && this.panels.css("height", "")
        },
        enable: function(i) {
            var t = this.options.disabled;
            !1 !== t && (t = void 0 !== i && (i = this._getIndex(i), Array.isArray(t) ? V.map(t, function(t) {
                return t !== i ? t : null
            }) : V.map(this.tabs, function(t, e) {
                return e !== i ? e : null
            })), this._setOptionDisabled(t))
        },
        disable: function(t) {
            var e = this.options.disabled;
            if (!0 !== e) {
                if (void 0 === t) e = !0;
                else {
                    if (t = this._getIndex(t), -1 !== V.inArray(t, e)) return;
                    e = Array.isArray(e) ? V.merge([t], e).sort() : [t]
                }
                this._setOptionDisabled(e)
            }
        },
        load: function(t, s) {
            function n(t, e) {
                "abort" === e && o.panels.stop(!1, !0), o._removeClass(i, "ui-tabs-loading"), a.removeAttr("aria-busy"), t === o.xhr && delete o.xhr
            }
            t = this._getIndex(t);
            var o = this,
                i = this.tabs.eq(t),
                t = i.find(".ui-tabs-anchor"),
                a = this._getPanelForTab(i),
                r = {
                    tab: i,
                    panel: a
                };
            this._isLocal(t[0]) || (this.xhr = V.ajax(this._ajaxSettings(t, s, r)), this.xhr && "canceled" !== this.xhr.statusText && (this._addClass(i, "ui-tabs-loading"), a.attr("aria-busy", "true"), this.xhr.done(function(t, e, i) {
                setTimeout(function() {
                    a.html(t), o._trigger("load", s, r), n(i, e)
                }, 1)
            }).fail(function(t, e) {
                setTimeout(function() {
                    n(t, e)
                }, 1)
            })))
        },
        _ajaxSettings: function(t, i, s) {
            var n = this;
            return {
                url: t.attr("href").replace(/#.*$/, ""),
                beforeSend: function(t, e) {
                    return n._trigger("beforeLoad", i, V.extend({
                        jqXHR: t,
                        ajaxSettings: e
                    }, s))
                }
            }
        },
        _getPanelForTab: function(t) {
            return t = V(t).attr("aria-controls"), this.element.find(this._sanitizeSelector("#" + t))
        }
    }), !1 !== V.uiBackCompat && V.widget("ui.tabs", V.ui.tabs, {
        _processTabs: function() {
            this._superApply(arguments), this._addClass(this.tabs, "ui-tab")
        }
    }), V.ui.tabs, V.widget("ui.tooltip", {
        version: "1.13.0",
        options: {
            classes: {
                "ui-tooltip": "ui-corner-all ui-widget-shadow"
            },
            content: function() {
                var t = V(this).attr("title");
                return V("<a>").text(t).html()
            },
            hide: !0,
            items: "[title]:not([disabled])",
            position: {
                my: "left top+15",
                at: "left bottom",
                collision: "flipfit flip"
            },
            show: !0,
            track: !1,
            close: null,
            open: null
        },
        _addDescribedBy: function(t, e) {
            var i = (t.attr("aria-describedby") || "").split(/\s+/);
            i.push(e), t.data("ui-tooltip-id", e).attr("aria-describedby", String.prototype.trim.call(i.join(" ")))
        },
        _removeDescribedBy: function(t) {
            var e = t.data("ui-tooltip-id"),
                i = (t.attr("aria-describedby") || "").split(/\s+/); - 1 !== (e = V.inArray(e, i)) && i.splice(e, 1), t.removeData("ui-tooltip-id"), (i = String.prototype.trim.call(i.join(" "))) ? t.attr("aria-describedby", i) : t.removeAttr("aria-describedby")
        },
        _create: function() {
            this._on({
                mouseover: "open",
                focusin: "open"
            }), this.tooltips = {}, this.parents = {}, this.liveRegion = V("<div>").attr({
                role: "log",
                "aria-live": "assertive",
                "aria-relevant": "additions"
            }).appendTo(this.document[0].body), this._addClass(this.liveRegion, null, "ui-helper-hidden-accessible"), this.disabledTitles = V([])
        },
        _setOption: function(t, e) {
            var i = this;
            this._super(t, e), "content" === t && V.each(this.tooltips, function(t, e) {
                i._updateContent(e.element)
            })
        },
        _setOptionDisabled: function(t) {
            this[t ? "_disable" : "_enable"]()
        },
        _disable: function() {
            var s = this;
            V.each(this.tooltips, function(t, e) {
                var i = V.Event("blur");
                i.target = i.currentTarget = e.element[0], s.close(i, !0)
            }), this.disabledTitles = this.disabledTitles.add(this.element.find(this.options.items).addBack().filter(function() {
                var t = V(this);
                if (t.is("[title]")) return t.data("ui-tooltip-title", t.attr("title")).removeAttr("title")
            }))
        },
        _enable: function() {
            this.disabledTitles.each(function() {
                var t = V(this);
                t.data("ui-tooltip-title") && t.attr("title", t.data("ui-tooltip-title"))
            }), this.disabledTitles = V([])
        },
        open: function(t) {
            var i = this,
                e = V(t ? t.target : this.element).closest(this.options.items);
            e.length && !e.data("ui-tooltip-id") && (e.attr("title") && e.data("ui-tooltip-title", e.attr("title")), e.data("ui-tooltip-open", !0), t && "mouseover" === t.type && e.parents().each(function() {
                var t, e = V(this);
                e.data("ui-tooltip-open") && ((t = V.Event("blur")).target = t.currentTarget = this, i.close(t, !0)), e.attr("title") && (e.uniqueId(), i.parents[this.id] = {
                    element: this,
                    title: e.attr("title")
                }, e.attr("title", ""))
            }), this._registerCloseHandlers(t, e), this._updateContent(e, t))
        },
        _updateContent: function(e, i) {
            var t = this.options.content,
                s = this,
                n = i ? i.type : null;
            if ("string" == typeof t || t.nodeType || t.jquery) return this._open(i, e, t);
            (t = t.call(e[0], function(t) {
                s._delay(function() {
                    e.data("ui-tooltip-open") && (i && (i.type = n), this._open(i, e, t))
                })
            })) && this._open(i, e, t)
        },
        _open: function(t, e, i) {
            var s, n, o, a = V.extend({}, this.options.position);

            function r(t) {
                a.of = t, n.is(":hidden") || n.position(a)
            }
            i && ((s = this._find(e)) ? s.tooltip.find(".ui-tooltip-content").html(i) : (e.is("[title]") && (t && "mouseover" === t.type ? e.attr("title", "") : e.removeAttr("title")), s = this._tooltip(e), n = s.tooltip, this._addDescribedBy(e, n.attr("id")), n.find(".ui-tooltip-content").html(i), this.liveRegion.children().hide(), (i = V("<div>").html(n.find(".ui-tooltip-content").html())).removeAttr("name").find("[name]").removeAttr("name"), i.removeAttr("id").find("[id]").removeAttr("id"), i.appendTo(this.liveRegion), this.options.track && t && /^mouse/.test(t.type) ? (this._on(this.document, {
                mousemove: r
            }), r(t)) : n.position(V.extend({ of: e
            }, this.options.position)), n.hide(), this._show(n, this.options.show), this.options.track && this.options.show && this.options.show.delay && (o = this.delayedShow = setInterval(function() {
                n.is(":visible") && (r(a.of), clearInterval(o))
            }, 13)), this._trigger("open", t, {
                tooltip: n
            })))
        },
        _registerCloseHandlers: function(t, e) {
            var i = {
                keyup: function(t) {
                    t.keyCode === V.ui.keyCode.ESCAPE && ((t = V.Event(t)).currentTarget = e[0], this.close(t, !0))
                }
            };
            e[0] !== this.element[0] && (i.remove = function() {
                this._removeTooltip(this._find(e).tooltip)
            }), t && "mouseover" !== t.type || (i.mouseleave = "close"), t && "focusin" !== t.type || (i.focusout = "close"), this._on(!0, e, i)
        },
        close: function(t) {
            var e, i = this,
                s = V(t ? t.currentTarget : this.element),
                n = this._find(s);
            n ? (e = n.tooltip, n.closing || (clearInterval(this.delayedShow), s.data("ui-tooltip-title") && !s.attr("title") && s.attr("title", s.data("ui-tooltip-title")), this._removeDescribedBy(s), n.hiding = !0, e.stop(!0), this._hide(e, this.options.hide, function() {
                i._removeTooltip(V(this))
            }), s.removeData("ui-tooltip-open"), this._off(s, "mouseleave focusout keyup"), s[0] !== this.element[0] && this._off(s, "remove"), this._off(this.document, "mousemove"), t && "mouseleave" === t.type && V.each(this.parents, function(t, e) {
                V(e.element).attr("title", e.title), delete i.parents[t]
            }), n.closing = !0, this._trigger("close", t, {
                tooltip: e
            }), n.hiding) || (n.closing = !1)) : s.removeData("ui-tooltip-open")
        },
        _tooltip: function(t) {
            var e = V("<div>").attr("role", "tooltip"),
                i = V("<div>").appendTo(e),
                s = e.uniqueId().attr("id");
            return this._addClass(i, "ui-tooltip-content"), this._addClass(e, "ui-tooltip", "ui-widget ui-widget-content"), e.appendTo(this._appendTo(t)), this.tooltips[s] = {
                element: t,
                tooltip: e
            }
        },
        _find: function(t) {
            return (t = t.data("ui-tooltip-id")) ? this.tooltips[t] : null
        },
        _removeTooltip: function(t) {
            clearInterval(this.delayedShow), t.remove(), delete this.tooltips[t.attr("id")]
        },
        _appendTo: function(t) {
            return (t = t.closest(".ui-front, dialog")).length ? t : this.document[0].body
        },
        _destroy: function() {
            var s = this;
            V.each(this.tooltips, function(t, e) {
                var i = V.Event("blur"),
                    e = e.element;
                i.target = i.currentTarget = e[0], s.close(i, !0), V("#" + t).remove(), e.data("ui-tooltip-title") && (e.attr("title") || e.attr("title", e.data("ui-tooltip-title")), e.removeData("ui-tooltip-title"))
            }), this.liveRegion.remove()
        }
    }), !1 !== V.uiBackCompat && V.widget("ui.tooltip", V.ui.tooltip, {
        options: {
            tooltipClass: null
        },
        _tooltip: function() {
            var t = this._superApply(arguments);
            return this.options.tooltipClass && t.tooltip.addClass(this.options.tooltipClass), t
        }
    }), V.ui.tooltip;
    var g = V,
        _ = {},
        K = _.toString,
        X = /^([\-+])=\s*(\d+\.?\d*)/,
        Q = [{
            re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
            parse: function(t) {
                return [t[1], t[2], t[3], t[4]]
            }
        }, {
            re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
            parse: function(t) {
                return [2.55 * t[1], 2.55 * t[2], 2.55 * t[3], t[4]]
            }
        }, {
            re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})?/,
            parse: function(t) {
                return [parseInt(t[1], 16), parseInt(t[2], 16), parseInt(t[3], 16), t[4] ? (parseInt(t[4], 16) / 255).toFixed(2) : 1]
            }
        }, {
            re: /#([a-f0-9])([a-f0-9])([a-f0-9])([a-f0-9])?/,
            parse: function(t) {
                return [parseInt(t[1] + t[1], 16), parseInt(t[2] + t[2], 16), parseInt(t[3] + t[3], 16), t[4] ? (parseInt(t[4] + t[4], 16) / 255).toFixed(2) : 1]
            }
        }, {
            re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
            space: "hsla",
            parse: function(t) {
                return [t[1], t[2] / 100, t[3] / 100, t[4]]
            }
        }],
        v = g.Color = function(t, e, i, s) {
            return new g.Color.fn.parse(t, e, i, s)
        },
        b = {
            rgba: {
                props: {
                    red: {
                        idx: 0,
                        type: "byte"
                    },
                    green: {
                        idx: 1,
                        type: "byte"
                    },
                    blue: {
                        idx: 2,
                        type: "byte"
                    }
                }
            },
            hsla: {
                props: {
                    hue: {
                        idx: 0,
                        type: "degrees"
                    },
                    saturation: {
                        idx: 1,
                        type: "percent"
                    },
                    lightness: {
                        idx: 2,
                        type: "percent"
                    }
                }
            }
        },
        G = {
            byte: {
                floor: !0,
                max: 255
            },
            percent: {
                max: 1
            },
            degrees: {
                mod: 360,
                floor: !0
            }
        },
        J = v.support = {},
        y = g("<p>")[0],
        w = g.each;

    function D(t) {
        return null == t ? t + "" : "object" == typeof t ? _[K.call(t)] || "object" : typeof t
    }

    function T(t, e, i) {
        var s = G[e.type] || {};
        return null == t ? i || !e.def ? null : e.def : (t = s.floor ? ~~t : parseFloat(t), isNaN(t) ? e.def : s.mod ? (t + s.mod) % s.mod : Math.min(s.max, Math.max(0, t)))
    }

    function Z(s) {
        var n = v(),
            o = n._rgba = [];
        return s = s.toLowerCase(), w(Q, function(t, e) {
            var i = (i = e.re.exec(s)) && e.parse(i),
                e = e.space || "rgba";
            if (i) return i = n[e](i), n[b[e].cache] = i[b[e].cache], o = n._rgba = i._rgba, !1
        }), o.length ? ("0,0,0,0" === o.join() && g.extend(o, I.transparent), n) : I[s]
    }

    function E(t, e, i) {
        return 6 * (i = (i + 1) % 1) < 1 ? t + (e - t) * i * 6 : 2 * i < 1 ? e : 3 * i < 2 ? t + (e - t) * (2 / 3 - i) * 6 : t
    }
    y.style.cssText = "background-color:rgba(1,1,1,.5)", J.rgba = -1 < y.style.backgroundColor.indexOf("rgba"), w(b, function(t, e) {
        e.cache = "_" + t, e.props.alpha = {
            idx: 3,
            type: "percent",
            def: 1
        }
    }), g.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(t, e) {
        _["[object " + e + "]"] = e.toLowerCase()
    }), (v.fn = g.extend(v.prototype, {
        parse: function(n, t, e, i) {
            if (void 0 === n) return this._rgba = [null, null, null, null], this;
            (n.jquery || n.nodeType) && (n = g(n).css(t), t = void 0);
            var o = this,
                s = D(n),
                a = this._rgba = [];
            return void 0 !== t && (n = [n, t, e, i], s = "array"), "string" === s ? this.parse(Z(n) || I._default) : "array" === s ? (w(b.rgba.props, function(t, e) {
                a[e.idx] = T(n[e.idx], e)
            }), this) : "object" === s ? (w(b, n instanceof v ? function(t, e) {
                n[e.cache] && (o[e.cache] = n[e.cache].slice())
            } : function(t, i) {
                var s = i.cache;
                w(i.props, function(t, e) {
                    if (!o[s] && i.to) {
                        if ("alpha" === t || null == n[t]) return;
                        o[s] = i.to(o._rgba)
                    }
                    o[s][e.idx] = T(n[t], e, !0)
                }), o[s] && g.inArray(null, o[s].slice(0, 3)) < 0 && (null == o[s][3] && (o[s][3] = 1), i.from) && (o._rgba = i.from(o[s]))
            }), this) : void 0
        },
        is: function(t) {
            var n = v(t),
                o = !0,
                a = this;
            return w(b, function(t, e) {
                var i, s = n[e.cache];
                return s && (i = a[e.cache] || e.to && e.to(a._rgba) || [], w(e.props, function(t, e) {
                    if (null != s[e.idx]) return o = s[e.idx] === i[e.idx]
                })), o
            }), o
        },
        _space: function() {
            var i = [],
                s = this;
            return w(b, function(t, e) {
                s[e.cache] && i.push(t)
            }), i.pop()
        },
        transition: function(t, a) {
            var e = (h = v(t))._space(),
                i = b[e],
                r = (t = 0 === this.alpha() ? v("transparent") : this)[i.cache] || i.to(t._rgba),
                l = r.slice(),
                h = h[i.cache];
            return w(i.props, function(t, e) {
                var i = e.idx,
                    s = r[i],
                    n = h[i],
                    o = G[e.type] || {};
                null !== n && (null === s ? l[i] = n : (o.mod && (n - s > o.mod / 2 ? s += o.mod : s - n > o.mod / 2 && (s -= o.mod)), l[i] = T((n - s) * a + s, e)))
            }), this[e](l)
        },
        blend: function(t) {
            var e, i, s;
            return 1 === this._rgba[3] ? this : (e = this._rgba.slice(), i = e.pop(), s = v(t)._rgba, v(g.map(e, function(t, e) {
                return (1 - i) * s[e] + i * t
            })))
        },
        toRgbaString: function() {
            var t = "rgba(",
                e = g.map(this._rgba, function(t, e) {
                    return null != t ? t : 2 < e ? 1 : 0
                });
            return 1 === e[3] && (e.pop(), t = "rgb("), t + e.join() + ")"
        },
        toHslaString: function() {
            var t = "hsla(",
                e = g.map(this.hsla(), function(t, e) {
                    return null == t && (t = 2 < e ? 1 : 0), e && e < 3 ? Math.round(100 * t) + "%" : t
                });
            return 1 === e[3] && (e.pop(), t = "hsl("), t + e.join() + ")"
        },
        toHexString: function(t) {
            var e = this._rgba.slice(),
                i = e.pop();
            return t && e.push(~~(255 * i)), "#" + g.map(e, function(t) {
                return 1 === (t = (t || 0).toString(16)).length ? "0" + t : t
            }).join("")
        },
        toString: function() {
            return 0 === this._rgba[3] ? "transparent" : this.toRgbaString()
        }
    })).parse.prototype = v.fn, b.hsla.to = function(t) {
        var e, i, s, n, o, a, r, l;
        return null == t[0] || null == t[1] || null == t[2] ? [null, null, null, t[3]] : (e = t[0] / 255, r = t[1] / 255, i = t[2] / 255, s = t[3], a = (n = Math.max(e, r, i)) - (o = Math.min(e, r, i)), t = .5 * (l = n + o), r = o === n ? 0 : e === n ? 60 * (r - i) / a + 360 : r === n ? 60 * (i - e) / a + 120 : 60 * (e - r) / a + 240, l = 0 == a ? 0 : t <= .5 ? a / l : a / (2 - l), [Math.round(r) % 360, l, t, null == s ? 1 : s])
    }, b.hsla.from = function(t) {
        var e, i, s;
        return null == t[0] || null == t[1] || null == t[2] ? [null, null, null, t[3]] : (e = t[0] / 360, i = t[1], s = t[2], t = t[3], s = 2 * s - (i = s <= .5 ? s * (1 + i) : s + i - s * i), [Math.round(255 * E(s, i, e + 1 / 3)), Math.round(255 * E(s, i, e)), Math.round(255 * E(s, i, e - 1 / 3)), t])
    }, w(b, function(r, t) {
        var e = t.props,
            o = t.cache,
            a = t.to,
            l = t.from;
        v.fn[r] = function(t) {
            var i, s, n;
            return a && !this[o] && (this[o] = a(this._rgba)), void 0 === t ? this[o].slice() : (i = D(t), s = "array" === i || "object" === i ? t : arguments, n = this[o].slice(), w(e, function(t, e) {
                null == (t = s["object" === i ? t : e.idx]) && (t = n[e.idx]), n[e.idx] = T(t, e)
            }), l ? ((t = v(l(n)))[o] = n, t) : v(n))
        }, w(e, function(o, a) {
            v.fn[o] || (v.fn[o] = function(t) {
                var e = D(t),
                    i = "alpha" === o ? this._hsla ? "hsla" : "rgba" : r,
                    s = this[i](),
                    n = s[a.idx];
                return "undefined" === e ? n : ("function" === e && (e = D(t = t.call(this, n))), null == t && a.empty ? this : ("string" === e && (e = X.exec(t)) && (t = n + parseFloat(e[2]) * ("+" === e[1] ? 1 : -1)), s[a.idx] = t, this[i](s)))
            })
        })
    }), (v.hook = function(t) {
        t = t.split(" "), w(t, function(t, o) {
            g.cssHooks[o] = {
                set: function(t, e) {
                    var i, s, n = "";
                    if ("transparent" !== e && ("string" !== D(e) || (i = Z(e)))) {
                        if (e = v(i || e), !J.rgba && 1 !== e._rgba[3]) {
                            for (s = "backgroundColor" === o ? t.parentNode : t;
                                ("" === n || "transparent" === n) && s && s.style;) try {
                                n = g.css(s, "backgroundColor"), s = s.parentNode
                            } catch (t) {}
                            e = e.blend(n && "transparent" !== n ? n : "_default")
                        }
                        e = e.toRgbaString()
                    }
                    try {
                        t.style[o] = e
                    } catch (t) {}
                }
            }, g.fx.step[o] = function(t) {
                t.colorInit || (t.start = v(t.elem, o), t.end = v(t.end), t.colorInit = !0), g.cssHooks[o].set(t.elem, t.start.transition(t.end, t.pos))
            }
        })
    })("backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor"), g.cssHooks.borderColor = {
        expand: function(i) {
            var s = {};
            return w(["Top", "Right", "Bottom", "Left"], function(t, e) {
                s["border" + e + "Color"] = i
            }), s
        }
    };
    var tt, et, it, st, nt, ot, at, rt, lt, S, I = g.Color.names = {
            aqua: "#00ffff",
            black: "#000000",
            blue: "#0000ff",
            fuchsia: "#ff00ff",
            gray: "#808080",
            green: "#008000",
            lime: "#00ff00",
            maroon: "#800000",
            navy: "#000080",
            olive: "#808000",
            purple: "#800080",
            red: "#ff0000",
            silver: "#c0c0c0",
            teal: "#008080",
            white: "#ffffff",
            yellow: "#ffff00",
            transparent: [null, null, null, 0],
            _default: "#ffffff"
        },
        P = "ui-effects-",
        M = "ui-effects-style",
        A = "ui-effects-animated";

    function ht(t) {
        var e, i, s = t.ownerDocument.defaultView ? t.ownerDocument.defaultView.getComputedStyle(t, null) : t.currentStyle,
            n = {};
        if (s && s.length && s[0] && s[s[0]])
            for (i = s.length; i--;) "string" == typeof s[e = s[i]] && (n[e.replace(/-([\da-z])/gi, function(t, e) {
                return e.toUpperCase()
            })] = s[e]);
        else
            for (e in s) "string" == typeof s[e] && (n[e] = s[e]);
        return n
    }

    function N(t, e, i, s) {
        return t = {
            effect: t = V.isPlainObject(t) ? (e = t).effect : t
        }, "function" == typeof(e = null == e ? {} : e) && (s = e, i = null, e = {}), "number" != typeof e && !V.fx.speeds[e] || (s = i, i = e, e = {}), "function" == typeof i && (s = i, i = null), e && V.extend(t, e), i = i || e.duration, t.duration = V.fx.off ? 0 : "number" == typeof i ? i : i in V.fx.speeds ? V.fx.speeds[i] : V.fx.speeds._default, t.complete = s || e.complete, t
    }

    function O(t) {
        return !t || "number" == typeof t || V.fx.speeds[t] || "string" == typeof t && !V.effects.effect[t] || "function" == typeof t || "object" == typeof t && !t.effect
    }

    function ct(t, e) {
        var i = e.outerWidth(),
            e = e.outerHeight(),
            t = /^rect\((-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto)\)$/.exec(t) || ["", 0, i, e, 0];
        return {
            top: parseFloat(t[1]) || 0,
            right: "auto" === t[2] ? i : parseFloat(t[2]),
            bottom: "auto" === t[3] ? e : parseFloat(t[3]),
            left: parseFloat(t[4]) || 0
        }
    }
    V.effects = {
        effect: {}
    }, st = ["add", "remove", "toggle"], nt = {
        border: 1,
        borderBottom: 1,
        borderColor: 1,
        borderLeft: 1,
        borderRight: 1,
        borderTop: 1,
        borderWidth: 1,
        margin: 1,
        padding: 1
    }, V.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function(t, e) {
        V.fx.step[e] = function(t) {
            ("none" !== t.end && !t.setAttr || 1 === t.pos && !t.setAttr) && (g.style(t.elem, e, t.end), t.setAttr = !0)
        }
    }), V.fn.addBack || (V.fn.addBack = function(t) {
        return this.add(null == t ? this.prevObject : this.prevObject.filter(t))
    }), V.effects.animateClass = function(n, t, e, i) {
        var o = V.speed(t, e, i);
        return this.queue(function() {
            function t() {
                V.each(st, function(t, e) {
                    n[e] && i[e + "Class"](n[e])
                })
            }
            var i = V(this),
                e = i.attr("class") || "",
                s = (s = o.children ? i.find("*").addBack() : i).map(function() {
                    return {
                        el: V(this),
                        start: ht(this)
                    }
                });
            t(), s = s.map(function() {
                return this.end = ht(this.el[0]), this.diff = function(t, e) {
                    var i, s, n = {};
                    for (i in e) s = e[i], t[i] === s || nt[i] || !V.fx.step[i] && isNaN(parseFloat(s)) || (n[i] = s);
                    return n
                }(this.start, this.end), this
            }), i.attr("class", e), s = s.map(function() {
                var t = this,
                    e = V.Deferred(),
                    i = V.extend({}, o, {
                        queue: !1,
                        complete: function() {
                            e.resolve(t)
                        }
                    });
                return this.el.animate(this.diff, i), e.promise()
            }), V.when.apply(V, s.get()).done(function() {
                t(), V.each(arguments, function() {
                    var e = this.el;
                    V.each(this.diff, function(t) {
                        e.css(t, "")
                    })
                }), o.complete.call(i[0])
            })
        })
    }, V.fn.extend({
        addClass: (it = V.fn.addClass, function(t, e, i, s) {
            return e ? V.effects.animateClass.call(this, {
                add: t
            }, e, i, s) : it.apply(this, arguments)
        }),
        removeClass: (et = V.fn.removeClass, function(t, e, i, s) {
            return 1 < arguments.length ? V.effects.animateClass.call(this, {
                remove: t
            }, e, i, s) : et.apply(this, arguments)
        }),
        toggleClass: (tt = V.fn.toggleClass, function(t, e, i, s, n) {
            return "boolean" == typeof e || void 0 === e ? i ? V.effects.animateClass.call(this, e ? {
                add: t
            } : {
                remove: t
            }, i, s, n) : tt.apply(this, arguments) : V.effects.animateClass.call(this, {
                toggle: t
            }, e, i, s)
        }),
        switchClass: function(t, e, i, s, n) {
            return V.effects.animateClass.call(this, {
                add: e,
                remove: t
            }, i, s, n)
        }
    }), V.expr && V.expr.pseudos && V.expr.pseudos.animated && (V.expr.pseudos.animated = (ot = V.expr.pseudos.animated, function(t) {
        return !!V(t).data(A) || ot(t)
    })), !1 !== V.uiBackCompat && V.extend(V.effects, {
        save: function(t, e) {
            for (var i = 0, s = e.length; i < s; i++) null !== e[i] && t.data(P + e[i], t[0].style[e[i]])
        },
        restore: function(t, e) {
            for (var i, s = 0, n = e.length; s < n; s++) null !== e[s] && (i = t.data(P + e[s]), t.css(e[s], i))
        },
        setMode: function(t, e) {
            return "toggle" === e ? t.is(":hidden") ? "show" : "hide" : e
        },
        createWrapper: function(i) {
            if (i.parent().is(".ui-effects-wrapper")) return i.parent();
            var s = {
                    width: i.outerWidth(!0),
                    height: i.outerHeight(!0),
                    float: i.css("float")
                },
                t = V("<div></div>").addClass("ui-effects-wrapper").css({
                    fontSize: "100%",
                    background: "transparent",
                    border: "none",
                    margin: 0,
                    padding: 0
                }),
                e = {
                    width: i.width(),
                    height: i.height()
                },
                n = document.activeElement;
            try {
                n.id
            } catch (t) {
                n = document.body
            }
            return i.wrap(t), i[0] !== n && !V.contains(i[0], n) || V(n).trigger("focus"), t = i.parent(), "static" === i.css("position") ? (t.css({
                position: "relative"
            }), i.css({
                position: "relative"
            })) : (V.extend(s, {
                position: i.css("position"),
                zIndex: i.css("z-index")
            }), V.each(["top", "left", "bottom", "right"], function(t, e) {
                s[e] = i.css(e), isNaN(parseInt(s[e], 10)) && (s[e] = "auto")
            }), i.css({
                position: "relative",
                top: 0,
                left: 0,
                right: "auto",
                bottom: "auto"
            })), i.css(e), t.css(s).show()
        },
        removeWrapper: function(t) {
            var e = document.activeElement;
            return t.parent().is(".ui-effects-wrapper") && (t.parent().replaceWith(t), t[0] !== e && !V.contains(t[0], e) || V(e).trigger("focus")), t
        }
    }), V.extend(V.effects, {
        version: "1.13.0",
        define: function(t, e, i) {
            return i || (i = e, e = "effect"), V.effects.effect[t] = i, V.effects.effect[t].mode = e, i
        },
        scaledDimensions: function(t, e, i) {
            var s;
            return 0 === e ? {
                height: 0,
                width: 0,
                outerHeight: 0,
                outerWidth: 0
            } : (s = "horizontal" !== i ? (e || 100) / 100 : 1, e = "vertical" !== i ? (e || 100) / 100 : 1, {
                height: t.height() * e,
                width: t.width() * s,
                outerHeight: t.outerHeight() * e,
                outerWidth: t.outerWidth() * s
            })
        },
        clipToBox: function(t) {
            return {
                width: t.clip.right - t.clip.left,
                height: t.clip.bottom - t.clip.top,
                left: t.clip.left,
                top: t.clip.top
            }
        },
        unshift: function(t, e, i) {
            var s = t.queue();
            1 < e && s.splice.apply(s, [1, 0].concat(s.splice(e, i))), t.dequeue()
        },
        saveStyle: function(t) {
            t.data(M, t[0].style.cssText)
        },
        restoreStyle: function(t) {
            t[0].style.cssText = t.data(M) || "", t.removeData(M)
        },
        mode: function(t, e) {
            return t = t.is(":hidden"), "toggle" === e && (e = t ? "show" : "hide"), (t ? "hide" === e : "show" === e) ? "none" : e
        },
        getBaseline: function(t, e) {
            var i, s;
            switch (t[0]) {
                case "top":
                    i = 0;
                    break;
                case "middle":
                    i = .5;
                    break;
                case "bottom":
                    i = 1;
                    break;
                default:
                    i = t[0] / e.height
            }
            switch (t[1]) {
                case "left":
                    s = 0;
                    break;
                case "center":
                    s = .5;
                    break;
                case "right":
                    s = 1;
                    break;
                default:
                    s = t[1] / e.width
            }
            return {
                x: s,
                y: i
            }
        },
        createPlaceholder: function(t) {
            var e, i = t.css("position"),
                s = t.position();
            return t.css({
                marginTop: t.css("marginTop"),
                marginBottom: t.css("marginBottom"),
                marginLeft: t.css("marginLeft"),
                marginRight: t.css("marginRight")
            }).outerWidth(t.outerWidth()).outerHeight(t.outerHeight()), /^(static|relative)/.test(i) && (i = "absolute", e = V("<" + t[0].nodeName + ">").insertAfter(t).css({
                display: /^(inline|ruby)/.test(t.css("display")) ? "inline-block" : "block",
                visibility: "hidden",
                marginTop: t.css("marginTop"),
                marginBottom: t.css("marginBottom"),
                marginLeft: t.css("marginLeft"),
                marginRight: t.css("marginRight"),
                float: t.css("float")
            }).outerWidth(t.outerWidth()).outerHeight(t.outerHeight()).addClass("ui-effects-placeholder"), t.data(P + "placeholder", e)), t.css({
                position: i,
                left: s.left,
                top: s.top
            }), e
        },
        removePlaceholder: function(t) {
            var e = P + "placeholder",
                i = t.data(e);
            i && (i.remove(), t.removeData(e))
        },
        cleanUp: function(t) {
            V.effects.restoreStyle(t), V.effects.removePlaceholder(t)
        },
        setTransition: function(s, t, n, o) {
            return o = o || {}, V.each(t, function(t, e) {
                var i = s.cssUnit(e);
                0 < i[0] && (o[e] = i[0] * n + i[1])
            }), o
        }
    }), V.fn.extend({
        effect: function() {
            function t(t) {
                var e = V(this),
                    i = V.effects.mode(e, r) || o;
                e.data(A, !0), l.push(i), o && ("show" === i || i === o && "hide" === i) && e.show(), o && "none" === i || V.effects.saveStyle(e), "function" == typeof t && t()
            }
            var s = N.apply(this, arguments),
                n = V.effects.effect[s.effect],
                o = n.mode,
                e = s.queue,
                i = e || "fx",
                a = s.complete,
                r = s.mode,
                l = [];
            return V.fx.off || !n ? r ? this[r](s.duration, a) : this.each(function() {
                a && a.call(this)
            }) : !1 === e ? this.each(t).each(h) : this.queue(i, t).queue(i, h);

            function h(t) {
                var e = V(this);

                function i() {
                    "function" == typeof a && a.call(e[0]), "function" == typeof t && t()
                }
                s.mode = l.shift(), !1 === V.uiBackCompat || o ? "none" === s.mode ? (e[r](), i()) : n.call(e[0], s, function() {
                    e.removeData(A), V.effects.cleanUp(e), "hide" === s.mode && e.hide(), i()
                }) : (e.is(":hidden") ? "hide" === r : "show" === r) ? (e[r](), i()) : n.call(e[0], s, i)
            }
        },
        show: (lt = V.fn.show, function(t) {
            return O(t) ? lt.apply(this, arguments) : ((t = N.apply(this, arguments)).mode = "show", this.effect.call(this, t))
        }),
        hide: (rt = V.fn.hide, function(t) {
            return O(t) ? rt.apply(this, arguments) : ((t = N.apply(this, arguments)).mode = "hide", this.effect.call(this, t))
        }),
        toggle: (at = V.fn.toggle, function(t) {
            return O(t) || "boolean" == typeof t ? at.apply(this, arguments) : ((t = N.apply(this, arguments)).mode = "toggle", this.effect.call(this, t))
        }),
        cssUnit: function(t) {
            var i = this.css(t),
                s = [];
            return V.each(["em", "px", "%", "pt"], function(t, e) {
                0 < i.indexOf(e) && (s = [parseFloat(i), e])
            }), s
        },
        cssClip: function(t) {
            return t ? this.css("clip", "rect(" + t.top + "px " + t.right + "px " + t.bottom + "px " + t.left + "px)") : ct(this.css("clip"), this)
        },
        transfer: function(t, e) {
            var i = V(this),
                s = "fixed" === (r = V(t.to)).css("position"),
                n = V("body"),
                o = s ? n.scrollTop() : 0,
                a = s ? n.scrollLeft() : 0,
                n = {
                    top: (n = r.offset()).top - o,
                    left: n.left - a,
                    height: r.innerHeight(),
                    width: r.innerWidth()
                },
                r = i.offset(),
                l = V("<div class='ui-effects-transfer'></div>");
            l.appendTo("body").addClass(t.className).css({
                top: r.top - o,
                left: r.left - a,
                height: i.innerHeight(),
                width: i.innerWidth(),
                position: s ? "fixed" : "absolute"
            }).animate(n, t.duration, t.easing, function() {
                l.remove(), "function" == typeof e && e()
            })
        }
    }), V.fx.step.clip = function(t) {
        t.clipInit || (t.start = V(t.elem).cssClip(), "string" == typeof t.end && (t.end = ct(t.end, t.elem)), t.clipInit = !0), V(t.elem).cssClip({
            top: t.pos * (t.end.top - t.start.top) + t.start.top,
            right: t.pos * (t.end.right - t.start.right) + t.start.right,
            bottom: t.pos * (t.end.bottom - t.start.bottom) + t.start.bottom,
            left: t.pos * (t.end.left - t.start.left) + t.start.left
        })
    }, S = {}, V.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function(e, t) {
        S[t] = function(t) {
            return Math.pow(t, e + 2)
        }
    }), V.extend(S, {
        Sine: function(t) {
            return 1 - Math.cos(t * Math.PI / 2)
        },
        Circ: function(t) {
            return 1 - Math.sqrt(1 - t * t)
        },
        Elastic: function(t) {
            return 0 === t || 1 === t ? t : -Math.pow(2, 8 * (t - 1)) * Math.sin((80 * (t - 1) - 7.5) * Math.PI / 15)
        },
        Back: function(t) {
            return t * t * (3 * t - 2)
        },
        Bounce: function(t) {
            for (var e, i = 4; t < ((e = Math.pow(2, --i)) - 1) / 11;);
            return 1 / Math.pow(4, 3 - i) - 7.5625 * Math.pow((3 * e - 2) / 22 - t, 2)
        }
    }), V.each(S, function(t, e) {
        V.easing["easeIn" + t] = e, V.easing["easeOut" + t] = function(t) {
            return 1 - e(1 - t)
        }, V.easing["easeInOut" + t] = function(t) {
            return t < .5 ? e(2 * t) / 2 : 1 - e(-2 * t + 2) / 2
        }
    }), y = V.effects, V.effects.define("blind", "hide", function(t, e) {
        var i = {
                up: ["bottom", "top"],
                vertical: ["bottom", "top"],
                down: ["top", "bottom"],
                left: ["right", "left"],
                horizontal: ["right", "left"],
                right: ["left", "right"]
            },
            s = V(this),
            n = t.direction || "up",
            o = s.cssClip(),
            a = {
                clip: V.extend({}, o)
            },
            r = V.effects.createPlaceholder(s);
        a.clip[i[n][0]] = a.clip[i[n][1]], "show" === t.mode && (s.cssClip(a.clip), r && r.css(V.effects.clipToBox(a)), a.clip = o), r && r.animate(V.effects.clipToBox(a), t.duration, t.easing), s.animate(a, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: e
        })
    }), V.effects.define("bounce", function(t, e) {
        var i, s, n = V(this),
            o = t.mode,
            a = "hide" === o,
            r = "show" === o,
            l = t.direction || "up",
            h = t.distance,
            c = t.times || 5,
            u = t.duration / (o = 2 * c + (r || a ? 1 : 0)),
            d = t.easing,
            p = "up" === l || "down" === l ? "top" : "left",
            f = "up" === l || "left" === l,
            m = 0,
            t = n.queue().length;
        for (V.effects.createPlaceholder(n), l = n.css(p), h = h || n["top" == p ? "outerHeight" : "outerWidth"]() / 3, r && ((s = {
                opacity: 1
            })[p] = l, n.css("opacity", 0).css(p, f ? 2 * -h : 2 * h).animate(s, u, d)), a && (h /= Math.pow(2, c - 1)), (s = {})[p] = l; m < c; m++)(i = {})[p] = (f ? "-=" : "+=") + h, n.animate(i, u, d).animate(s, u, d), h = a ? 2 * h : h / 2;
        a && ((i = {
            opacity: 0
        })[p] = (f ? "-=" : "+=") + h, n.animate(i, u, d)), n.queue(e), V.effects.unshift(n, t, 1 + o)
    }), V.effects.define("clip", "hide", function(t, e) {
        var i = {},
            s = V(this),
            n = (o = "both" === (a = t.direction || "vertical")) || "horizontal" === a,
            o = o || "vertical" === a,
            a = s.cssClip();
        i.clip = {
            top: o ? (a.bottom - a.top) / 2 : a.top,
            right: n ? (a.right - a.left) / 2 : a.right,
            bottom: o ? (a.bottom - a.top) / 2 : a.bottom,
            left: n ? (a.right - a.left) / 2 : a.left
        }, V.effects.createPlaceholder(s), "show" === t.mode && (s.cssClip(i.clip), i.clip = a), s.animate(i, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: e
        })
    }), V.effects.define("drop", "hide", function(t, e) {
        var i = V(this),
            s = "show" === t.mode,
            n = t.direction || "left",
            o = "up" === n || "down" === n ? "top" : "left",
            a = "up" === n || "left" === n ? "-=" : "+=",
            r = "+=" == a ? "-=" : "+=",
            l = {
                opacity: 0
            };
        V.effects.createPlaceholder(i), n = t.distance || i["top" == o ? "outerHeight" : "outerWidth"](!0) / 2, l[o] = a + n, s && (i.css(l), l[o] = r + n, l.opacity = 1), i.animate(l, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: e
        })
    }), V.effects.define("explode", "hide", function(t, e) {
        var i, s, n, o, a, r, l = t.pieces ? Math.round(Math.sqrt(t.pieces)) : 3,
            h = l,
            c = V(this),
            u = "show" === t.mode,
            d = c.show().css("visibility", "hidden").offset(),
            p = Math.ceil(c.outerWidth() / h),
            f = Math.ceil(c.outerHeight() / l),
            m = [];

        function g() {
            m.push(this), m.length === l * h && (c.css({
                visibility: "visible"
            }), V(m).remove(), e())
        }
        for (i = 0; i < l; i++)
            for (o = d.top + i * f, r = i - (l - 1) / 2, s = 0; s < h; s++) n = d.left + s * p, a = s - (h - 1) / 2, c.clone().appendTo("body").wrap("<div></div>").css({
                position: "absolute",
                visibility: "visible",
                left: -s * p,
                top: -i * f
            }).parent().addClass("ui-effects-explode").css({
                position: "absolute",
                overflow: "hidden",
                width: p,
                height: f,
                left: n + (u ? a * p : 0),
                top: o + (u ? r * f : 0),
                opacity: u ? 0 : 1
            }).animate({
                left: n + (u ? 0 : a * p),
                top: o + (u ? 0 : r * f),
                opacity: u ? 1 : 0
            }, t.duration || 500, t.easing, g)
    }), V.effects.define("fade", "toggle", function(t, e) {
        var i = "show" === t.mode;
        V(this).css("opacity", i ? 0 : 1).animate({
            opacity: i ? 1 : 0
        }, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: e
        })
    }), V.effects.define("fold", "hide", function(e, t) {
        var i = V(this),
            s = "show" === (f = e.mode),
            n = "hide" === f,
            o = e.size || 15,
            a = /([0-9]+)%/.exec(o),
            r = e.horizFirst ? ["right", "bottom"] : ["bottom", "right"],
            l = e.duration / 2,
            h = V.effects.createPlaceholder(i),
            c = i.cssClip(),
            u = {
                clip: V.extend({}, c)
            },
            d = {
                clip: V.extend({}, c)
            },
            p = [c[r[0]], c[r[1]]],
            f = i.queue().length;
        a && (o = parseInt(a[1], 10) / 100 * p[n ? 0 : 1]), u.clip[r[0]] = o, d.clip[r[0]] = o, d.clip[r[1]] = 0, s && (i.cssClip(d.clip), h && h.css(V.effects.clipToBox(d)), d.clip = c), i.queue(function(t) {
            h && h.animate(V.effects.clipToBox(u), l, e.easing).animate(V.effects.clipToBox(d), l, e.easing), t()
        }).animate(u, l, e.easing).animate(d, l, e.easing).queue(t), V.effects.unshift(i, f, 4)
    }), V.effects.define("highlight", "show", function(t, e) {
        var i = V(this),
            s = {
                backgroundColor: i.css("backgroundColor")
            };
        "hide" === t.mode && (s.opacity = 0), V.effects.saveStyle(i), i.css({
            backgroundImage: "none",
            backgroundColor: t.color || "#ffff99"
        }).animate(s, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: e
        })
    }), V.effects.define("size", function(s, e) {
        var n, i = V(this),
            t = ["fontSize"],
            o = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"],
            a = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"],
            r = s.mode,
            l = "effect" !== r,
            h = s.scale || "both",
            c = s.origin || ["middle", "center"],
            u = i.css("position"),
            d = i.position(),
            p = V.effects.scaledDimensions(i),
            f = s.from || p,
            m = s.to || V.effects.scaledDimensions(i, 0);
        V.effects.createPlaceholder(i), "show" === r && (r = f, f = m, m = r), n = {
            from: {
                y: f.height / p.height,
                x: f.width / p.width
            },
            to: {
                y: m.height / p.height,
                x: m.width / p.width
            }
        }, "box" !== h && "both" !== h || (n.from.y !== n.to.y && (f = V.effects.setTransition(i, o, n.from.y, f), m = V.effects.setTransition(i, o, n.to.y, m)), n.from.x !== n.to.x && (f = V.effects.setTransition(i, a, n.from.x, f), m = V.effects.setTransition(i, a, n.to.x, m))), "content" !== h && "both" !== h || n.from.y !== n.to.y && (f = V.effects.setTransition(i, t, n.from.y, f), m = V.effects.setTransition(i, t, n.to.y, m)), c && (c = V.effects.getBaseline(c, p), f.top = (p.outerHeight - f.outerHeight) * c.y + d.top, f.left = (p.outerWidth - f.outerWidth) * c.x + d.left, m.top = (p.outerHeight - m.outerHeight) * c.y + d.top, m.left = (p.outerWidth - m.outerWidth) * c.x + d.left), delete f.outerHeight, delete f.outerWidth, i.css(f), "content" !== h && "both" !== h || (o = o.concat(["marginTop", "marginBottom"]).concat(t), a = a.concat(["marginLeft", "marginRight"]), i.find("*[width]").each(function() {
            var t = V(this),
                e = {
                    height: (i = V.effects.scaledDimensions(t)).height * n.from.y,
                    width: i.width * n.from.x,
                    outerHeight: i.outerHeight * n.from.y,
                    outerWidth: i.outerWidth * n.from.x
                },
                i = {
                    height: i.height * n.to.y,
                    width: i.width * n.to.x,
                    outerHeight: i.height * n.to.y,
                    outerWidth: i.width * n.to.x
                };
            n.from.y !== n.to.y && (e = V.effects.setTransition(t, o, n.from.y, e), i = V.effects.setTransition(t, o, n.to.y, i)), n.from.x !== n.to.x && (e = V.effects.setTransition(t, a, n.from.x, e), i = V.effects.setTransition(t, a, n.to.x, i)), l && V.effects.saveStyle(t), t.css(e), t.animate(i, s.duration, s.easing, function() {
                l && V.effects.restoreStyle(t)
            })
        })), i.animate(m, {
            queue: !1,
            duration: s.duration,
            easing: s.easing,
            complete: function() {
                var t = i.offset();
                0 === m.opacity && i.css("opacity", f.opacity), l || (i.css("position", "static" === u ? "relative" : u).offset(t), V.effects.saveStyle(i)), e()
            }
        })
    }), V.effects.define("scale", function(t, e) {
        var i = V(this),
            s = t.mode,
            s = parseInt(t.percent, 10) || (0 === parseInt(t.percent, 10) || "effect" !== s ? 0 : 100),
            s = V.extend(!0, {
                from: V.effects.scaledDimensions(i),
                to: V.effects.scaledDimensions(i, s, t.direction || "both"),
                origin: t.origin || ["middle", "center"]
            }, t);
        t.fade && (s.from.opacity = 1, s.to.opacity = 0), V.effects.effect.size.call(this, s, e)
    }), V.effects.define("puff", "hide", function(t, e) {
        t = V.extend(!0, {}, t, {
            fade: !0,
            percent: parseInt(t.percent, 10) || 150
        }), V.effects.effect.scale.call(this, t, e)
    }), V.effects.define("pulsate", "show", function(t, e) {
        var i = V(this),
            s = "show" === (l = t.mode),
            n = 2 * (t.times || 5) + (s || "hide" === l ? 1 : 0),
            o = t.duration / n,
            a = 0,
            r = 1,
            l = i.queue().length;
        for (!s && i.is(":visible") || (i.css("opacity", 0).show(), a = 1); r < n; r++) i.animate({
            opacity: a
        }, o, t.easing), a = 1 - a;
        i.animate({
            opacity: a
        }, o, t.easing), i.queue(e), V.effects.unshift(i, l, 1 + n)
    }), V.effects.define("shake", function(t, e) {
        var i = 1,
            s = V(this),
            n = t.direction || "left",
            o = t.distance || 20,
            a = t.times || 3,
            r = 2 * a + 1,
            l = Math.round(t.duration / r),
            h = "up" === n || "down" === n ? "top" : "left",
            c = "up" === n || "left" === n,
            u = {},
            d = {},
            p = {},
            n = s.queue().length;
        for (V.effects.createPlaceholder(s), u[h] = (c ? "-=" : "+=") + o, d[h] = (c ? "+=" : "-=") + 2 * o, p[h] = (c ? "-=" : "+=") + 2 * o, s.animate(u, l, t.easing); i < a; i++) s.animate(d, l, t.easing).animate(p, l, t.easing);
        s.animate(d, l, t.easing).animate(u, l / 2, t.easing).queue(e), V.effects.unshift(s, n, 1 + r)
    }), V.effects.define("slide", "show", function(t, e) {
        var i, s, n = V(this),
            o = {
                up: ["bottom", "top"],
                down: ["top", "bottom"],
                left: ["right", "left"],
                right: ["left", "right"]
            },
            a = t.mode,
            r = t.direction || "left",
            l = "up" === r || "down" === r ? "top" : "left",
            h = "up" === r || "left" === r,
            c = t.distance || n["top" == l ? "outerHeight" : "outerWidth"](!0),
            u = {};
        V.effects.createPlaceholder(n), i = n.cssClip(), s = n.position()[l], u[l] = (h ? -1 : 1) * c + s, u.clip = n.cssClip(), u.clip[o[r][1]] = u.clip[o[r][0]], "show" === a && (n.cssClip(u.clip), n.css(l, u[l]), u.clip = i, u[l] = s), n.animate(u, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: e
        })
    }), !1 !== V.uiBackCompat && V.effects.define("transfer", function(t, e) {
        V(this).transfer(t, e)
    })
}),
function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = t || self).Sortable = e()
}(this, function() {
    "use strict";

    function e(e, t) {
        var i, s = Object.keys(e);
        return Object.getOwnPropertySymbols && (i = Object.getOwnPropertySymbols(e), t && (i = i.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        })), s.push.apply(s, i)), s
    }

    function P(s) {
        for (var t = 1; t < arguments.length; t++) {
            var n = null != arguments[t] ? arguments[t] : {};
            t % 2 ? e(Object(n), !0).forEach(function(t) {
                var e, i = s;
                t = n[e = t], e in i ? Object.defineProperty(i, e, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : i[e] = t
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(s, Object.getOwnPropertyDescriptors(n)) : e(Object(n)).forEach(function(t) {
                Object.defineProperty(s, t, Object.getOwnPropertyDescriptor(n, t))
            })
        }
        return s
    }

    function s(t) {
        return (s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        })(t)
    }

    function r() {
        return (r = Object.assign || function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var i, s = arguments[e];
                for (i in s) Object.prototype.hasOwnProperty.call(s, i) && (t[i] = s[i])
            }
            return t
        }).apply(this, arguments)
    }

    function d(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var i = 0, s = new Array(e); i < e; i++) s[i] = t[i];
        return s
    }

    function t(t) {
        if ("undefined" != typeof window && window.navigator) return !!navigator.userAgent.match(t)
    }
    var b = t(/(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i),
        C = t(/Edge/i),
        f = t(/firefox/i),
        m = t(/safari/i) && !t(/chrome/i) && !t(/android/i),
        i = t(/iP(ad|od|hone)/i),
        g = t(/chrome/i) && t(/android/i),
        k = {
            capture: !1,
            passive: !1
        };

    function l(t, e, i) {
        t.addEventListener(e, i, !b && k)
    }

    function o(t, e, i) {
        t.removeEventListener(e, i, !b && k)
    }

    function D(t, e) {
        if (e && (">" === e[0] && (e = e.substring(1)), t)) try {
            return t.matches ? t.matches(e) : t.msMatchesSelector ? t.msMatchesSelector(e) : t.webkitMatchesSelector && t.webkitMatchesSelector(e)
        } catch (t) {}
    }

    function M(t, e, i, s) {
        if (t) {
            i = i || document;
            do {
                if (null != e && (">" !== e[0] || t.parentNode === i) && D(t, e) || s && t === i) return t
            } while (t !== i && (t = (n = t).host && n !== document && n.host.nodeType ? n.host : n.parentNode))
        }
        var n;
        return null
    }
    var T, V = /\s+/g;

    function A(t, e, i) {
        var s;
        t && e && (t.classList ? t.classList[i ? "add" : "remove"](e) : (s = (" " + t.className + " ").replace(V, " ").replace(" " + e + " ", " "), t.className = (s + (i ? " " + e : "")).replace(V, " ")))
    }

    function N(t, e, i) {
        var s = t && t.style;
        if (s) {
            if (void 0 === i) return document.defaultView && document.defaultView.getComputedStyle ? i = document.defaultView.getComputedStyle(t, "") : t.currentStyle && (i = t.currentStyle), void 0 === e ? i : i[e];
            s[e = e in s || -1 !== e.indexOf("webkit") ? e : "-webkit-" + e] = i + ("string" == typeof i ? "" : "px")
        }
    }

    function p(t, e) {
        var i = "";
        if ("string" == typeof t) i = t;
        else
            do {
                var s = N(t, "transform")
            } while (s && "none" !== s && (i = s + " " + i), !e && (t = t.parentNode));
        var n = window.DOMMatrix || window.WebKitCSSMatrix || window.CSSMatrix || window.MSCSSMatrix;
        return n && new n(i)
    }

    function K(t, e, i) {
        if (t) {
            var s = t.getElementsByTagName(e),
                n = 0,
                o = s.length;
            if (i)
                for (; n < o; n++) i(s[n], n);
            return s
        }
        return []
    }

    function E() {
        return document.scrollingElement || document.documentElement
    }

    function O(t, e, i, s, n) {
        if (t.getBoundingClientRect || t === window) {
            var o, a, r, l, h, c, u = t !== window && t.parentNode && t !== E() ? (a = (o = t.getBoundingClientRect()).top, r = o.left, l = o.bottom, h = o.right, c = o.height, o.width) : (r = a = 0, l = window.innerHeight, h = window.innerWidth, c = window.innerHeight, window.innerWidth);
            if ((e || i) && t !== window && (n = n || t.parentNode, !b))
                do {
                    if (n && n.getBoundingClientRect && ("none" !== N(n, "transform") || i && "static" !== N(n, "position"))) {
                        var d = n.getBoundingClientRect();
                        a -= d.top + parseInt(N(n, "border-top-width")), r -= d.left + parseInt(N(n, "border-left-width")), l = a + o.height, h = r + o.width;
                        break
                    }
                } while (n = n.parentNode);
            return s && t !== window && (s = (e = p(n || t)) && e.a, t = e && e.d, e) && (l = (a /= t) + (c /= t), h = (r /= s) + (u /= s)), {
                top: a,
                left: r,
                bottom: l,
                right: h,
                width: u,
                height: c
            }
        }
    }

    function X(t, e, i) {
        for (var s = S(t, !0), n = O(t)[e]; s;) {
            var o = O(s)[i];
            if (!("top" === i || "left" === i ? o <= n : n <= o)) return s;
            if (s === E()) break;
            s = S(s, !1)
        }
        return !1
    }

    function Q(t, e, i, s) {
        for (var n = 0, o = 0, a = t.children; o < a.length;) {
            if ("none" !== a[o].style.display && a[o] !== U.ghost && (s || a[o] !== U.dragged) && M(a[o], i.draggable, t, !1)) {
                if (n === e) return a[o];
                n++
            }
            o++
        }
        return null
    }

    function G(t, e) {
        for (var i = t.lastElementChild; i && (i === U.ghost || "none" === N(i, "display") || e && !D(i, e));) i = i.previousElementSibling;
        return i || null
    }

    function H(t, e) {
        var i = 0;
        if (!t || !t.parentNode) return -1;
        for (; t = t.previousElementSibling;) "TEMPLATE" === t.nodeName.toUpperCase() || t === U.clone || e && !D(t, e) || i++;
        return i
    }

    function J(t) {
        var e = 0,
            i = 0,
            s = E();
        if (t)
            do {
                var n = (o = p(t)).a,
                    o = o.d
            } while (e += t.scrollLeft * n, i += t.scrollTop * o, t !== s && (t = t.parentNode));
        return [e, i]
    }

    function S(t, e) {
        if (t && t.getBoundingClientRect) {
            var i = t,
                s = !1;
            do {
                if (i.clientWidth < i.scrollWidth || i.clientHeight < i.scrollHeight) {
                    var n = N(i);
                    if (i.clientWidth < i.scrollWidth && ("auto" == n.overflowX || "scroll" == n.overflowX) || i.clientHeight < i.scrollHeight && ("auto" == n.overflowY || "scroll" == n.overflowY)) {
                        if (!i.getBoundingClientRect || i === document.body) return E();
                        if (s || e) return i;
                        s = !0
                    }
                }
            } while (i = i.parentNode)
        }
        return E()
    }

    function Z(t, e) {
        return Math.round(t.top) === Math.round(e.top) && Math.round(t.left) === Math.round(e.left) && Math.round(t.height) === Math.round(e.height) && Math.round(t.width) === Math.round(e.width)
    }

    function tt(e, i) {
        return function() {
            var t;
            T || (1 === (t = arguments).length ? e.call(this, t[0]) : e.apply(this, t), T = setTimeout(function() {
                T = void 0
            }, i))
        }
    }

    function et(t, e, i) {
        t.scrollLeft += e, t.scrollTop += i
    }

    function it(t) {
        var e = window.Polymer,
            i = window.jQuery || window.Zepto;
        return e && e.dom ? e.dom(t).cloneNode(!0) : i ? i(t).clone(!0)[0] : t.cloneNode(!0)
    }

    function st(t, e) {
        N(t, "position", "absolute"), N(t, "top", e.top), N(t, "left", e.left), N(t, "width", e.width), N(t, "height", e.height)
    }

    function nt(t) {
        N(t, "position", ""), N(t, "top", ""), N(t, "left", ""), N(t, "width", ""), N(t, "height", "")
    }
    var F = "Sortable" + (new Date).getTime();
    var ot = [],
        at = {
            initializeByDefault: !0
        },
        rt = {
            mount: function(e) {
                for (var t in at) !at.hasOwnProperty(t) || t in e || (e[t] = at[t]);
                ot.forEach(function(t) {
                    if (t.pluginName === e.pluginName) throw "Sortable: Cannot mount plugin ".concat(e.pluginName, " more than once")
                }), ot.push(e)
            },
            pluginEvent: function(e, i, s) {
                var t = this,
                    n = (this.eventCanceled = !1, s.cancel = function() {
                        t.eventCanceled = !0
                    }, e + "Global");
                ot.forEach(function(t) {
                    i[t.pluginName] && (i[t.pluginName][n] && i[t.pluginName][n](P({
                        sortable: i
                    }, s)), i.options[t.pluginName]) && i[t.pluginName][e] && i[t.pluginName][e](P({
                        sortable: i
                    }, s))
                })
            },
            initializePlugins: function(i, s, n, t) {
                for (var e in ot.forEach(function(t) {
                        var e = t.pluginName;
                        (i.options[e] || t.initializeByDefault) && ((t = new t(i, s, i.options)).sortable = i, t.options = i.options, i[e] = t, r(n, t.defaults))
                    }), i.options) {
                    var o;
                    i.options.hasOwnProperty(e) && void 0 !== (o = this.modifyOption(i, e, i.options[e])) && (i.options[e] = o)
                }
            },
            getEventProperties: function(e, i) {
                var s = {};
                return ot.forEach(function(t) {
                    "function" == typeof t.eventProperties && r(s, t.eventProperties.call(i[t.pluginName], e))
                }), s
            },
            modifyOption: function(e, i, s) {
                var n;
                return ot.forEach(function(t) {
                    e[t.pluginName] && t.optionListeners && "function" == typeof t.optionListeners[i] && (n = t.optionListeners[i].call(e[t.pluginName], s))
                }), n
            }
        };

    function lt(t) {
        var e = t.sortable,
            i = t.rootEl,
            s = t.name,
            n = t.targetEl,
            o = t.cloneEl,
            a = t.toEl,
            r = t.fromEl,
            l = t.oldIndex,
            h = t.newIndex,
            c = t.oldDraggableIndex,
            u = t.newDraggableIndex,
            d = t.originalEvent,
            p = t.putSortable,
            f = t.extraEventProperties;
        if (e = e || i && i[F]) {
            var m, g = e.options,
                t = "on" + s.charAt(0).toUpperCase() + s.substr(1);
            !window.CustomEvent || b || C ? (m = document.createEvent("Event")).initEvent(s, !0, !0) : m = new CustomEvent(s, {
                bubbles: !0,
                cancelable: !0
            }), m.to = a || i, m.from = r || i, m.item = n || i, m.clone = o, m.oldIndex = l, m.newIndex = h, m.oldDraggableIndex = c, m.newDraggableIndex = u, m.originalEvent = d, m.pullMode = p ? p.lastPutMode : void 0;
            var _, v = P(P({}, f), rt.getEventProperties(s, e));
            for (_ in v) m[_] = v[_];
            i && i.dispatchEvent(m), g[t] && g[t].call(e, m)
        }
    }

    function z(t, e, i) {
        var s = (i = 2 < arguments.length && void 0 !== i ? i : {}).evt,
            i = function(t, e) {
                if (null == t) return {};
                var i, s = function(t, e) {
                    if (null == t) return {};
                    for (var i, s = {}, n = Object.keys(t), o = 0; o < n.length; o++) i = n[o], 0 <= e.indexOf(i) || (s[i] = t[i]);
                    return s
                }(t, e);
                if (Object.getOwnPropertySymbols)
                    for (var n = Object.getOwnPropertySymbols(t), o = 0; o < n.length; o++) i = n[o], 0 <= e.indexOf(i) || Object.prototype.propertyIsEnumerable.call(t, i) && (s[i] = t[i]);
                return s
            }(i, ht);
        rt.pluginEvent.bind(U)(t, e, P({
            dragEl: W,
            parentEl: R,
            ghostEl: $,
            rootEl: j,
            nextEl: ft,
            lastDownEl: mt,
            cloneEl: a,
            cloneHidden: n,
            dragStarted: kt,
            putSortable: q,
            activeSortable: U.active,
            originalEvent: s,
            oldIndex: gt,
            oldDraggableIndex: _t,
            newIndex: B,
            newDraggableIndex: Y,
            hideGhostForTarget: dt,
            unhideGhostForTarget: pt,
            cloneNowHidden: function() {
                n = !0
            },
            cloneNowShown: function() {
                n = !1
            },
            dispatchSortableEvent: function(t) {
                L({
                    sortable: e,
                    name: t,
                    originalEvent: s
                })
            }
        }, i))
    }
    var ht = ["evt"];

    function L(t) {
        lt(P({
            putSortable: q,
            cloneEl: a,
            targetEl: W,
            rootEl: j,
            oldIndex: gt,
            oldDraggableIndex: _t,
            newIndex: B,
            newDraggableIndex: Y
        }, t))
    }

    function ct(t, e) {
        var i = N(t),
            s = parseInt(i.width) - parseInt(i.paddingLeft) - parseInt(i.paddingRight) - parseInt(i.borderLeftWidth) - parseInt(i.borderRightWidth),
            n = Q(t, 0, e),
            o = Q(t, 1, e),
            a = n && N(n),
            r = o && N(o),
            l = a && parseInt(a.marginLeft) + parseInt(a.marginRight) + O(n).width,
            t = r && parseInt(r.marginLeft) + parseInt(r.marginRight) + O(o).width;
        return "flex" === i.display ? "column" === i.flexDirection || "column-reverse" === i.flexDirection ? "vertical" : "horizontal" : "grid" === i.display ? i.gridTemplateColumns.split(" ").length <= 1 ? "vertical" : "horizontal" : n && a.float && "none" !== a.float ? (e = "left" === a.float ? "left" : "right", !o || "both" !== r.clear && r.clear !== e ? "horizontal" : "vertical") : n && ("block" === a.display || "flex" === a.display || "table" === a.display || "grid" === a.display || s <= l && "none" === i[Lt] || o && "none" === i[Lt] && s < l + t) ? "vertical" : "horizontal"
    }

    function ut(t) {
        function r(o, a) {
            return function(t, e, i, s) {
                var n = t.options.group.name && e.options.group.name && t.options.group.name === e.options.group.name;
                return !(null != o || !a && !n) || null != o && !1 !== o && (a && "clone" === o ? o : "function" == typeof o ? r(o(t, e, i, s), a)(t, e, i, s) : (e = (a ? t : e).options.group.name, !0 === o || "string" == typeof o && o === e || o.join && -1 < o.indexOf(e)))
            }
        }
        var e = {},
            i = t.group;
        i && "object" == s(i) || (i = {
            name: i
        }), e.name = i.name, e.checkPull = r(i.pull, !0), e.checkPut = r(i.put), e.revertClone = i.revertClone, t.group = e
    }

    function dt() {
        !Rt && $ && N($, "display", "none")
    }

    function pt() {
        !Rt && $ && N($, "display", "")
    }
    var W, R, $, j, ft, mt, a, n, gt, B, _t, Y, vt, q, bt, h, yt, wt, xt, Ct, kt, Dt, Tt, Et, c, St = !1,
        It = !1,
        Pt = [],
        Mt = !1,
        At = !1,
        Nt = [],
        Ot = !1,
        Ht = [],
        Ft = "undefined" != typeof document,
        zt = i,
        Lt = C || b ? "cssFloat" : "float",
        Wt = Ft && !g && !i && "draggable" in document.createElement("div"),
        Rt = function() {
            var t;
            if (Ft) return !b && ((t = document.createElement("x")).style.cssText = "pointer-events:auto", "auto" === t.style.pointerEvents)
        }();

    function $t(t) {
        if (W) {
            t = t.touches ? t.touches[0] : t;
            n = t.clientX, o = t.clientY, Pt.some(function(t) {
                var e, i, s = t[F].options.emptyInsertThreshold;
                if (s && !G(t)) return e = O(t), i = n >= e.left - s && n <= e.right + s, s = o >= e.top - s && o <= e.bottom + s, i && s ? a = t : void 0
            });
            var e = a;
            if (e) {
                var i, s = {};
                for (i in t) t.hasOwnProperty(i) && (s[i] = t[i]);
                s.target = s.rootEl = e, s.preventDefault = void 0, s.stopPropagation = void 0, e[F]._onDragOver(s)
            }
        }
        var n, o, a
    }

    function jt(t) {
        W && W.parentNode[F]._isOutsideThisEl(t.target)
    }

    function U(t, e) {
        if (!t || !t.nodeType || 1 !== t.nodeType) throw "Sortable: `el` must be an HTMLElement, not ".concat({}.toString.call(t));
        this.el = t, this.options = e = r({}, e), t[F] = this;
        var i, s, n, o, a = {
            group: null,
            sort: !0,
            disabled: !1,
            store: null,
            handle: null,
            draggable: /^[uo]l$/i.test(t.nodeName) ? ">li" : ">*",
            swapThreshold: 1,
            invertSwap: !1,
            invertedSwapThreshold: null,
            removeCloneOnHide: !0,
            direction: function() {
                return ct(t, this.options)
            },
            ghostClass: "sortable-ghost",
            chosenClass: "sortable-chosen",
            dragClass: "sortable-drag",
            ignore: "a, img",
            filter: null,
            preventOnFilter: !0,
            animation: 0,
            easing: null,
            setData: function(t, e) {
                t.setData("Text", e.textContent)
            },
            dropBubble: !1,
            dragoverBubble: !1,
            dataIdAttr: "data-id",
            delay: 0,
            delayOnTouchOnly: !1,
            touchStartThreshold: (Number.parseInt ? Number : window).parseInt(window.devicePixelRatio, 10) || 1,
            forceFallback: !1,
            fallbackClass: "sortable-fallback",
            fallbackOnBody: !1,
            fallbackTolerance: 0,
            fallbackOffset: {
                x: 0,
                y: 0
            },
            supportPointer: !1 !== U.supportPointer && "PointerEvent" in window && !m,
            emptyInsertThreshold: 5
        };
        for (i in rt.initializePlugins(this, t, a), a) i in e || (e[i] = a[i]);
        for (s in ut(e), this) "_" === s.charAt(0) && "function" == typeof this[s] && (this[s] = this[s].bind(this));
        this.nativeDraggable = !e.forceFallback && Wt, this.nativeDraggable && (this.options.touchStartThreshold = 1), e.supportPointer ? l(t, "pointerdown", this._onTapStart) : (l(t, "mousedown", this._onTapStart), l(t, "touchstart", this._onTapStart)), this.nativeDraggable && (l(t, "dragover", this), l(t, "dragenter", this)), Pt.push(this.el), e.store && e.store.get && this.sort(e.store.get(this) || []), r(this, (o = [], {
            captureAnimationState: function() {
                o = [], this.options.animation && [].slice.call(this.el.children).forEach(function(t) {
                    var e, i;
                    "none" !== N(t, "display") && t !== U.ghost && (o.push({
                        target: t,
                        rect: O(t)
                    }), e = P({}, o[o.length - 1].rect), t.thisAnimationDuration && (i = p(t, !0)) && (e.top -= i.f, e.left -= i.e), t.fromRect = e)
                })
            },
            addAnimationState: function(t) {
                o.push(t)
            },
            removeAnimationState: function(t) {
                o.splice(function(t, e) {
                    for (var i in t)
                        if (t.hasOwnProperty(i))
                            for (var s in e)
                                if (e.hasOwnProperty(s) && e[s] === t[i][s]) return Number(i);
                    return -1
                }(o, {
                    target: t
                }), 1)
            },
            animateAll: function(t) {
                var h, c, u = this;
                this.options.animation ? (h = !1, c = 0, o.forEach(function(t) {
                    var e = 0,
                        i = t.target,
                        s = i.fromRect,
                        n = O(i),
                        o = i.prevFromRect,
                        a = i.prevToRect,
                        r = t.rect,
                        l = p(i, !0);
                    l && (n.top -= l.f, n.left -= l.e), i.toRect = n, i.thisAnimationDuration && Z(o, n) && !Z(s, n) && (r.top - n.top) / (r.left - n.left) == (s.top - n.top) / (s.left - n.left) && (t = r, l = o, o = a, a = u.options, e = Math.sqrt(Math.pow(l.top - t.top, 2) + Math.pow(l.left - t.left, 2)) / Math.sqrt(Math.pow(l.top - o.top, 2) + Math.pow(l.left - o.left, 2)) * a.animation), Z(n, s) || (i.prevFromRect = s, i.prevToRect = n, e = e || u.options.animation, u.animate(i, r, n, e)), e && (h = !0, c = Math.max(c, e), clearTimeout(i.animationResetTimer), i.animationResetTimer = setTimeout(function() {
                        i.animationTime = 0, i.prevFromRect = null, i.fromRect = null, i.prevToRect = null, i.thisAnimationDuration = null
                    }, e), i.thisAnimationDuration = e)
                }), clearTimeout(n), h ? n = setTimeout(function() {
                    "function" == typeof t && t()
                }, c) : "function" == typeof t && t(), o = []) : (clearTimeout(n), "function" == typeof t && t())
            },
            animate: function(t, e, i, s) {
                var n, o;
                s && (N(t, "transition", ""), N(t, "transform", ""), n = (o = p(this.el)) && o.a, o = o && o.d, n = (e.left - i.left) / (n || 1), o = (e.top - i.top) / (o || 1), t.animatingX = !!n, t.animatingY = !!o, N(t, "transform", "translate3d(" + n + "px," + o + "px,0)"), this.forRepaintDummy = t.offsetWidth, N(t, "transition", "transform " + s + "ms" + (this.options.easing ? " " + this.options.easing : "")), N(t, "transform", "translate3d(0,0,0)"), "number" == typeof t.animated && clearTimeout(t.animated), t.animated = setTimeout(function() {
                    N(t, "transition", ""), N(t, "transform", ""), t.animated = !1, t.animatingX = !1, t.animatingY = !1
                }, s))
            }
        }))
    }

    function Bt(t, e, i, s, n, o, a, r) {
        var l, h, c = t[F],
            u = c.options.onMove;
        return !window.CustomEvent || b || C ? (l = document.createEvent("Event")).initEvent("move", !0, !0) : l = new CustomEvent("move", {
            bubbles: !0,
            cancelable: !0
        }), l.to = e, l.from = t, l.dragged = i, l.draggedRect = s, l.related = n || e, l.relatedRect = o || O(e), l.willInsertAfter = r, l.originalEvent = a, t.dispatchEvent(l), u ? u.call(c, l, a) : h
    }

    function Yt(t) {
        t.draggable = !1
    }

    function qt() {
        Ot = !1
    }

    function Ut(t) {
        return setTimeout(t, 0)
    }

    function Vt(t) {
        return clearTimeout(t)
    }
    Ft && !g && document.addEventListener("click", function(t) {
        if (It) return t.preventDefault(), t.stopPropagation && t.stopPropagation(), t.stopImmediatePropagation && t.stopImmediatePropagation(), It = !1
    }, !0), U.prototype = {
        constructor: U,
        _isOutsideThisEl: function(t) {
            this.el.contains(t) || t === this.el || (Dt = null)
        },
        _getDirection: function(t, e) {
            return "function" == typeof this.options.direction ? this.options.direction.call(this, t, e, W) : this.options.direction
        },
        _onTapStart: function(e) {
            if (e.cancelable) {
                var i = this,
                    s = this.el,
                    t = this.options,
                    n = t.preventOnFilter,
                    o = e.type,
                    a = e.touches && e.touches[0] || e.pointerType && "touch" === e.pointerType && e,
                    r = (a || e).target,
                    l = e.target.shadowRoot && (e.path && e.path[0] || e.composedPath && e.composedPath()[0]) || r,
                    h = t.filter,
                    c = s;
                Ht.length = 0;
                for (var u = c.getElementsByTagName("input"), d = u.length; d--;) {
                    var p = u[d];
                    p.checked && Ht.push(p)
                }
                if (!W && !(/mousedown|pointerdown/.test(o) && 0 !== e.button || t.disabled) && !l.isContentEditable && (this.nativeDraggable || !m || !r || "SELECT" !== r.tagName.toUpperCase()) && !((r = M(r, t.draggable, s, !1)) && r.animated || mt === r)) {
                    if (gt = H(r), _t = H(r, t.draggable), "function" == typeof h) {
                        if (h.call(this, e, r, this)) return L({
                            sortable: i,
                            rootEl: l,
                            name: "filter",
                            targetEl: r,
                            toEl: s,
                            fromEl: s
                        }), z("filter", i, {
                            evt: e
                        }), void(n && e.cancelable && e.preventDefault())
                    } else if (h = h && h.split(",").some(function(t) {
                            if (t = M(l, t.trim(), s, !1)) return L({
                                sortable: i,
                                rootEl: t,
                                name: "filter",
                                targetEl: r,
                                fromEl: s,
                                toEl: s
                            }), z("filter", i, {
                                evt: e
                            }), !0
                        })) return void(n && e.cancelable && e.preventDefault());
                    t.handle && !M(l, t.handle, s, !1) || this._prepareDragStart(e, a, r)
                }
            }
        },
        _prepareDragStart: function(t, e, i) {
            var s, n = this,
                o = n.el,
                a = n.options,
                r = o.ownerDocument;
            i && !W && i.parentNode === o && (s = O(i), j = o, R = (W = i).parentNode, ft = W.nextSibling, mt = i, vt = a.group, bt = {
                target: U.dragged = W,
                clientX: (e || t).clientX,
                clientY: (e || t).clientY
            }, xt = bt.clientX - s.left, Ct = bt.clientY - s.top, this._lastX = (e || t).clientX, this._lastY = (e || t).clientY, W.style["will-change"] = "all", s = function() {
                z("delayEnded", n, {
                    evt: t
                }), U.eventCanceled ? n._onDrop() : (n._disableDelayedDragEvents(), !f && n.nativeDraggable && (W.draggable = !0), n._triggerDragStart(t, e), L({
                    sortable: n,
                    name: "choose",
                    originalEvent: t
                }), A(W, a.chosenClass, !0))
            }, a.ignore.split(",").forEach(function(t) {
                K(W, t.trim(), Yt)
            }), l(r, "dragover", $t), l(r, "mousemove", $t), l(r, "touchmove", $t), l(r, "mouseup", n._onDrop), l(r, "touchend", n._onDrop), l(r, "touchcancel", n._onDrop), f && this.nativeDraggable && (this.options.touchStartThreshold = 4, W.draggable = !0), z("delayStart", this, {
                evt: t
            }), !a.delay || a.delayOnTouchOnly && !e || this.nativeDraggable && (C || b) ? s() : U.eventCanceled ? this._onDrop() : (l(r, "mouseup", n._disableDelayedDrag), l(r, "touchend", n._disableDelayedDrag), l(r, "touchcancel", n._disableDelayedDrag), l(r, "mousemove", n._delayedDragTouchMoveHandler), l(r, "touchmove", n._delayedDragTouchMoveHandler), a.supportPointer && l(r, "pointermove", n._delayedDragTouchMoveHandler), n._dragStartTimer = setTimeout(s, a.delay)))
        },
        _delayedDragTouchMoveHandler: function(t) {
            t = t.touches ? t.touches[0] : t, Math.max(Math.abs(t.clientX - this._lastX), Math.abs(t.clientY - this._lastY)) >= Math.floor(this.options.touchStartThreshold / (this.nativeDraggable && window.devicePixelRatio || 1)) && this._disableDelayedDrag()
        },
        _disableDelayedDrag: function() {
            W && Yt(W), clearTimeout(this._dragStartTimer), this._disableDelayedDragEvents()
        },
        _disableDelayedDragEvents: function() {
            var t = this.el.ownerDocument;
            o(t, "mouseup", this._disableDelayedDrag), o(t, "touchend", this._disableDelayedDrag), o(t, "touchcancel", this._disableDelayedDrag), o(t, "mousemove", this._delayedDragTouchMoveHandler), o(t, "touchmove", this._delayedDragTouchMoveHandler), o(t, "pointermove", this._delayedDragTouchMoveHandler)
        },
        _triggerDragStart: function(t, e) {
            e = e || "touch" == t.pointerType && t, !this.nativeDraggable || e ? this.options.supportPointer ? l(document, "pointermove", this._onTouchMove) : l(document, e ? "touchmove" : "mousemove", this._onTouchMove) : (l(W, "dragend", this), l(j, "dragstart", this._onDragStart));
            try {
                document.selection ? Ut(function() {
                    document.selection.empty()
                }) : window.getSelection().removeAllRanges()
            } catch (t) {}
        },
        _dragStarted: function(t, e) {
            var i;
            St = !1, j && W ? (z("dragStarted", this, {
                evt: e
            }), this.nativeDraggable && l(document, "dragover", jt), i = this.options, t || A(W, i.dragClass, !1), A(W, i.ghostClass, !0), U.active = this, t && this._appendGhost(), L({
                sortable: this,
                name: "start",
                originalEvent: e
            })) : this._nulling()
        },
        _emulateDragOver: function() {
            if (h) {
                this._lastX = h.clientX, this._lastY = h.clientY, dt();
                for (var t = document.elementFromPoint(h.clientX, h.clientY), e = t; t && t.shadowRoot && (t = t.shadowRoot.elementFromPoint(h.clientX, h.clientY)) !== e;) e = t;
                if (W.parentNode[F]._isOutsideThisEl(t), e)
                    do {
                        if (e[F] && e[F]._onDragOver({
                                clientX: h.clientX,
                                clientY: h.clientY,
                                target: t,
                                rootEl: e
                            }) && !this.options.dragoverBubble) break
                    } while (e = (t = e).parentNode);
                pt()
            }
        },
        _onTouchMove: function(t) {
            if (bt) {
                var e = (r = this.options).fallbackTolerance,
                    i = r.fallbackOffset,
                    s = t.touches ? t.touches[0] : t,
                    n = $ && p($, !0),
                    o = $ && n && n.a,
                    a = $ && n && n.d,
                    r = zt && c && J(c),
                    o = (s.clientX - bt.clientX + i.x) / (o || 1) + (r ? r[0] - Nt[0] : 0) / (o || 1),
                    a = (s.clientY - bt.clientY + i.y) / (a || 1) + (r ? r[1] - Nt[1] : 0) / (a || 1);
                if (!U.active && !St) {
                    if (e && Math.max(Math.abs(s.clientX - this._lastX), Math.abs(s.clientY - this._lastY)) < e) return;
                    this._onDragStart(t, !0)
                }
                $ && (n ? (n.e += o - (yt || 0), n.f += a - (wt || 0)) : n = {
                    a: 1,
                    b: 0,
                    c: 0,
                    d: 1,
                    e: o,
                    f: a
                }, n = "matrix(".concat(n.a, ",").concat(n.b, ",").concat(n.c, ",").concat(n.d, ",").concat(n.e, ",").concat(n.f, ")"), N($, "webkitTransform", n), N($, "mozTransform", n), N($, "msTransform", n), N($, "transform", n), yt = o, wt = a, h = s), t.cancelable && t.preventDefault()
            }
        },
        _appendGhost: function() {
            if (!$) {
                var t = this.options.fallbackOnBody ? document.body : j,
                    e = O(W, !0, zt, !0, t),
                    i = this.options;
                if (zt) {
                    for (c = t;
                        "static" === N(c, "position") && "none" === N(c, "transform") && c !== document;) c = c.parentNode;
                    c !== document.body && c !== document.documentElement ? (c === document && (c = E()), e.top += c.scrollTop, e.left += c.scrollLeft) : c = E(), Nt = J(c)
                }
                A($ = W.cloneNode(!0), i.ghostClass, !1), A($, i.fallbackClass, !0), A($, i.dragClass, !0), N($, "transition", ""), N($, "transform", ""), N($, "box-sizing", "border-box"), N($, "margin", 0), N($, "top", e.top), N($, "left", e.left), N($, "width", e.width), N($, "height", e.height), N($, "opacity", "0.8"), N($, "position", zt ? "absolute" : "fixed"), N($, "zIndex", "100000"), N($, "pointerEvents", "none"), U.ghost = $, t.appendChild($), N($, "transform-origin", xt / parseInt($.style.width) * 100 + "% " + Ct / parseInt($.style.height) * 100 + "%")
            }
        },
        _onDragStart: function(t, e) {
            var i = this,
                s = t.dataTransfer,
                n = i.options;
            z("dragStart", this, {
                evt: t
            }), U.eventCanceled ? this._onDrop() : (z("setupClone", this), U.eventCanceled || ((a = it(W)).removeAttribute("id"), a.draggable = !1, a.style["will-change"] = "", this._hideClone(), A(a, this.options.chosenClass, !1), U.clone = a), i.cloneId = Ut(function() {
                z("clone", i), U.eventCanceled || (i.options.removeCloneOnHide || j.insertBefore(a, W), i._hideClone(), L({
                    sortable: i,
                    name: "clone"
                }))
            }), e || A(W, n.dragClass, !0), e ? (It = !0, i._loopId = setInterval(i._emulateDragOver, 50)) : (o(document, "mouseup", i._onDrop), o(document, "touchend", i._onDrop), o(document, "touchcancel", i._onDrop), s && (s.effectAllowed = "move", n.setData) && n.setData.call(i, s, W), l(document, "drop", i), N(W, "transform", "translateZ(0)")), St = !0, i._dragStartId = Ut(i._dragStarted.bind(i, e, t)), l(document, "selectstart", i), kt = !0, m && N(document.body, "user-select", "none"))
        },
        _onDragOver: function(c) {
            var i, s, n, t, o = this.el,
                a = c.target,
                e = this.options,
                r = e.group,
                l = U.active,
                h = vt === r,
                u = e.sort,
                d = q || l,
                p = this,
                f = !1;
            if (!Ot) {
                if (void 0 !== c.preventDefault && c.cancelable && c.preventDefault(), a = M(a, e.draggable, o, !0), T("dragOver"), U.eventCanceled) return f;
                if (W.contains(c.target) || a.animated && a.animatingX && a.animatingY || p._ignoreWhileAnimating === a) return S(!1);
                if (It = !1, l && !e.disabled && (h ? u || (s = R !== j) : q === this || (this.lastPutMode = vt.checkPull(this, l, W, c)) && r.checkPut(this, l, W, c))) {
                    if (n = "vertical" === this._getDirection(c, a), i = O(W), T("dragOverValid"), U.eventCanceled) return f;
                    if (s) return R = j, E(), this._hideClone(), T("revert"), U.eventCanceled || (ft ? j.insertBefore(W, ft) : j.appendChild(W)), S(!0);
                    if ((v = G(o, e.draggable)) && (y = c, w = n, D = O(G((D = this).el, D.options.draggable)), !(w ? y.clientX > D.right + 10 || y.clientX <= D.right && y.clientY > D.bottom && y.clientX >= D.left : y.clientX > D.right && y.clientY > D.top || y.clientX <= D.right && y.clientY > D.bottom + 10) || v.animated)) {
                        if (v && (w = c, y = n, D = O(Q((D = this).el, 0, D.options, !0)), y ? w.clientX < D.left - 10 || w.clientY < D.top && w.clientX < D.right : w.clientY < D.top - 10 || w.clientY < D.bottom && w.clientX < D.left)) {
                            if ((C = Q(o, 0, e, !0)) === W) return S(!1);
                            if (b = O(a = C), !1 !== Bt(j, o, W, i, a, b, c, !1)) return E(), o.insertBefore(W, C), R = o, I(), S(!0)
                        } else if (a.parentNode === o) {
                            var m, g, _, v, b = O(a),
                                y = W.parentNode !== o,
                                w = (w = W.animated && W.toRect || i, D = a.animated && a.toRect || b, x = (t = n) ? w.left : w.top, r = t ? w.right : w.bottom, v = t ? w.width : w.height, C = t ? D.left : D.top, w = t ? D.right : D.bottom, D = t ? D.width : D.height, !(x === C || r === w || x + v / 2 === C + D / 2)),
                                x = n ? "top" : "left",
                                C = (v = X(a, "top", "top") || X(W, "top", "top")) ? v.scrollTop : void 0;
                            if (Dt !== a && (g = b[x], Mt = !1, At = !w && e.invertSwap || y), 0 !== (m = function(t, e, i, s, n, o, a, r) {
                                    var l = s ? c.clientY : c.clientX,
                                        h = s ? i.height : i.width,
                                        t = s ? i.top : i.left,
                                        s = s ? i.bottom : i.right,
                                        i = !1;
                                    if (!a)
                                        if (r && Et < h * n) {
                                            if (Mt = !Mt && (1 === Tt ? t + h * o / 2 < l : l < s - h * o / 2) || Mt) i = !0;
                                            else if (1 === Tt ? l < t + Et : s - Et < l) return -Tt
                                        } else if (t + h * (1 - n) / 2 < l && l < s - h * (1 - n) / 2) return r = e, H(W) < H(r) ? 1 : -1;
                                    return (i = i || a) && (l < t + h * o / 2 || s - h * o / 2 < l) ? t + h / 2 < l ? 1 : -1 : 0
                                }(0, a, b, n, w ? 1 : e.swapThreshold, null == e.invertedSwapThreshold ? e.swapThreshold : e.invertedSwapThreshold, At, Dt === a)))
                                for (var k = H(W);
                                    (_ = R.children[k -= m]) && ("none" === N(_, "display") || _ === $););
                            if (0 === m || _ === a) return S(!1);
                            Tt = m;
                            var D = (Dt = a).nextElementSibling,
                                y = !1;
                            if (!1 !== (w = Bt(j, o, W, i, a, b, c, y = 1 === m))) return 1 !== w && -1 !== w || (y = 1 === w), Ot = !0, setTimeout(qt, 30), E(), y && !D ? o.appendChild(W) : a.parentNode.insertBefore(W, y ? D : a), v && et(v, 0, C - v.scrollTop), R = W.parentNode, void 0 === g || At || (Et = Math.abs(g - O(a)[x])), I(), S(!0)
                        }
                    } else {
                        if (v === W) return S(!1);
                        if ((a = v && o === c.target ? v : a) && (b = O(a)), !1 !== Bt(j, o, W, i, a, b, c, !!a)) return E(), v && v.nextSibling ? o.insertBefore(W, v.nextSibling) : o.appendChild(W), R = o, I(), S(!0)
                    }
                    if (o.contains(W)) return S(!1)
                }
                return !1
            }

            function T(t, e) {
                z(t, p, P({
                    evt: c,
                    isOwner: h,
                    axis: n ? "vertical" : "horizontal",
                    revert: s,
                    dragRect: i,
                    targetRect: b,
                    canSort: u,
                    fromSortable: d,
                    target: a,
                    completed: S,
                    onMove: function(t, e) {
                        return Bt(j, o, W, i, t, O(t), c, e)
                    },
                    changed: I
                }, e))
            }

            function E() {
                T("dragOverAnimationCapture"), p.captureAnimationState(), p !== d && d.captureAnimationState()
            }

            function S(t) {
                return T("dragOverCompleted", {
                    insertion: t
                }), t && (h ? l._hideClone() : l._showClone(p), p !== d && (A(W, (q || l).options.ghostClass, !1), A(W, e.ghostClass, !0)), q !== p && p !== U.active ? q = p : p === U.active && (q = q && null), d === p && (p._ignoreWhileAnimating = a), p.animateAll(function() {
                    T("dragOverAnimationComplete"), p._ignoreWhileAnimating = null
                }), p !== d) && (d.animateAll(), d._ignoreWhileAnimating = null), (a === W && !W.animated || a === o && !a.animated) && (Dt = null), e.dragoverBubble || c.rootEl || a === document || (W.parentNode[F]._isOutsideThisEl(c.target), t) || $t(c), !e.dragoverBubble && c.stopPropagation && c.stopPropagation(), f = !0
            }

            function I() {
                B = H(W), Y = H(W, e.draggable), L({
                    sortable: p,
                    name: "change",
                    toEl: o,
                    newIndex: B,
                    newDraggableIndex: Y,
                    originalEvent: c
                })
            }
        },
        _ignoreWhileAnimating: null,
        _offMoveEvents: function() {
            o(document, "mousemove", this._onTouchMove), o(document, "touchmove", this._onTouchMove), o(document, "pointermove", this._onTouchMove), o(document, "dragover", $t), o(document, "mousemove", $t), o(document, "touchmove", $t)
        },
        _offUpEvents: function() {
            var t = this.el.ownerDocument;
            o(t, "mouseup", this._onDrop), o(t, "touchend", this._onDrop), o(t, "pointerup", this._onDrop), o(t, "touchcancel", this._onDrop), o(document, "selectstart", this)
        },
        _onDrop: function(t) {
            var e = this.el,
                i = this.options;
            B = H(W), Y = H(W, i.draggable), z("drop", this, {
                evt: t
            }), R = W && W.parentNode, B = H(W), Y = H(W, i.draggable), U.eventCanceled || (Mt = At = St = !1, clearInterval(this._loopId), clearTimeout(this._dragStartTimer), Vt(this.cloneId), Vt(this._dragStartId), this.nativeDraggable && (o(document, "drop", this), o(e, "dragstart", this._onDragStart)), this._offMoveEvents(), this._offUpEvents(), m && N(document.body, "user-select", ""), N(W, "transform", ""), t && (kt && (t.cancelable && t.preventDefault(), i.dropBubble || t.stopPropagation()), $ && $.parentNode && $.parentNode.removeChild($), (j === R || q && "clone" !== q.lastPutMode) && a && a.parentNode && a.parentNode.removeChild(a), W) && (this.nativeDraggable && o(W, "dragend", this), Yt(W), W.style["will-change"] = "", kt && !St && A(W, (q || this).options.ghostClass, !1), A(W, this.options.chosenClass, !1), L({
                sortable: this,
                name: "unchoose",
                toEl: R,
                newIndex: null,
                newDraggableIndex: null,
                originalEvent: t
            }), j !== R ? (0 <= B && (L({
                rootEl: R,
                name: "add",
                toEl: R,
                fromEl: j,
                originalEvent: t
            }), L({
                sortable: this,
                name: "remove",
                toEl: R,
                originalEvent: t
            }), L({
                rootEl: R,
                name: "sort",
                toEl: R,
                fromEl: j,
                originalEvent: t
            }), L({
                sortable: this,
                name: "sort",
                toEl: R,
                originalEvent: t
            })), q && q.save()) : B !== gt && 0 <= B && (L({
                sortable: this,
                name: "update",
                toEl: R,
                originalEvent: t
            }), L({
                sortable: this,
                name: "sort",
                toEl: R,
                originalEvent: t
            })), U.active) && (null != B && -1 !== B || (B = gt, Y = _t), L({
                sortable: this,
                name: "end",
                toEl: R,
                originalEvent: t
            }), this.save())), this._nulling()
        },
        _nulling: function() {
            z("nulling", this), j = W = R = $ = ft = a = mt = n = bt = h = kt = B = Y = gt = _t = Dt = Tt = q = vt = U.dragged = U.ghost = U.clone = U.active = null, Ht.forEach(function(t) {
                t.checked = !0
            }), Ht.length = yt = wt = 0
        },
        handleEvent: function(t) {
            switch (t.type) {
                case "drop":
                case "dragend":
                    this._onDrop(t);
                    break;
                case "dragenter":
                case "dragover":
                    W && (this._onDragOver(t), (e = t).dataTransfer && (e.dataTransfer.dropEffect = "move"), e.cancelable) && e.preventDefault();
                    break;
                case "selectstart":
                    t.preventDefault()
            }
            var e
        },
        toArray: function() {
            for (var t, e = [], i = this.el.children, s = 0, n = i.length, o = this.options; s < n; s++) M(t = i[s], o.draggable, this.el, !1) && e.push(t.getAttribute(o.dataIdAttr) || function(t) {
                for (var e = t.tagName + t.className + t.src + t.href + t.textContent, i = e.length, s = 0; i--;) s += e.charCodeAt(i);
                return s.toString(36)
            }(t));
            return e
        },
        sort: function(t, e) {
            var i = {},
                s = this.el;
            this.toArray().forEach(function(t, e) {
                M(e = s.children[e], this.options.draggable, s, !1) && (i[t] = e)
            }, this), e && this.captureAnimationState(), t.forEach(function(t) {
                i[t] && (s.removeChild(i[t]), s.appendChild(i[t]))
            }), e && this.animateAll()
        },
        save: function() {
            var t = this.options.store;
            t && t.set && t.set(this)
        },
        closest: function(t, e) {
            return M(t, e || this.options.draggable, this.el, !1)
        },
        option: function(t, e) {
            var i = this.options;
            if (void 0 === e) return i[t];
            var s = rt.modifyOption(this, t, e);
            i[t] = void 0 !== s ? s : e, "group" === t && ut(i)
        },
        destroy: function() {
            z("destroy", this);
            var t = this.el;
            t[F] = null, o(t, "mousedown", this._onTapStart), o(t, "touchstart", this._onTapStart), o(t, "pointerdown", this._onTapStart), this.nativeDraggable && (o(t, "dragover", this), o(t, "dragenter", this)), Array.prototype.forEach.call(t.querySelectorAll("[draggable]"), function(t) {
                t.removeAttribute("draggable")
            }), this._onDrop(), this._disableDelayedDragEvents(), Pt.splice(Pt.indexOf(this.el), 1), this.el = t = null
        },
        _hideClone: function() {
            n || (z("hideClone", this), U.eventCanceled) || (N(a, "display", "none"), this.options.removeCloneOnHide && a.parentNode && a.parentNode.removeChild(a), n = !0)
        },
        _showClone: function(t) {
            "clone" === t.lastPutMode ? n && (z("showClone", this), U.eventCanceled || (W.parentNode != j || this.options.group.revertClone ? ft ? j.insertBefore(a, ft) : j.appendChild(a) : j.insertBefore(a, W), this.options.group.revertClone && this.animate(W, a), N(a, "display", ""), n = !1)) : this._hideClone()
        }
    }, Ft && l(document, "touchmove", function(t) {
        (U.active || St) && t.cancelable && t.preventDefault()
    }), U.utils = {
        on: l,
        off: o,
        css: N,
        find: K,
        is: function(t, e) {
            return !!M(t, e, t, !1)
        },
        extend: function(t, e) {
            if (t && e)
                for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
            return t
        },
        throttle: tt,
        closest: M,
        toggleClass: A,
        clone: it,
        index: H,
        nextTick: Ut,
        cancelNextTick: Vt,
        detectDirection: ct,
        getChild: Q
    }, U.get = function(t) {
        return t[F]
    }, U.mount = function() {
        for (var t = arguments.length, e = new Array(t), i = 0; i < t; i++) e[i] = arguments[i];
        (e = e[0].constructor === Array ? e[0] : e).forEach(function(t) {
            if (!t.prototype || !t.prototype.constructor) throw "Sortable: Mounted plugin must be a constructor function, not ".concat({}.toString.call(t));
            t.utils && (U.utils = P(P({}, U.utils), t.utils)), rt.mount(t)
        })
    }, U.create = function(t, e) {
        return new U(t, e)
    };
    var Kt, Xt, Qt, Gt, Jt, Zt, I = [],
        te = !(U.version = "1.15.0");

    function ee() {
        I.forEach(function(t) {
            clearInterval(t.pid)
        }), I = []
    }

    function ie() {
        clearInterval(Zt)
    }
    var u, se = tt(function(i, t, e, s) {
        if (t.scroll) {
            var n, o = (i.touches ? i.touches[0] : i).clientX,
                a = (i.touches ? i.touches[0] : i).clientY,
                r = t.scrollSensitivity,
                l = t.scrollSpeed,
                h = E(),
                c = !1,
                u = 0,
                d = Kt = Xt !== e && (Xt = e, ee(), Kt = t.scroll, n = t.scrollFn, !0 === Kt) ? S(e, !0) : Kt;
            do {
                var p = d,
                    f = (D = O(p)).top,
                    m = D.bottom,
                    g = D.left,
                    _ = D.right,
                    v = D.width,
                    b = D.height,
                    y = void 0,
                    w = p.scrollWidth,
                    x = p.scrollHeight,
                    C = N(p),
                    k = p.scrollLeft,
                    D = p.scrollTop,
                    C = p === h ? (y = v < w && ("auto" === C.overflowX || "scroll" === C.overflowX || "visible" === C.overflowX), b < x && ("auto" === C.overflowY || "scroll" === C.overflowY || "visible" === C.overflowY)) : (y = v < w && ("auto" === C.overflowX || "scroll" === C.overflowX), b < x && ("auto" === C.overflowY || "scroll" === C.overflowY)),
                    k = y && (Math.abs(_ - o) <= r && k + v < w) - (Math.abs(g - o) <= r && !!k),
                    D = C && (Math.abs(m - a) <= r && D + b < x) - (Math.abs(f - a) <= r && !!D);
                if (!I[u])
                    for (var T = 0; T <= u; T++) I[T] || (I[T] = {});
                I[u].vx == k && I[u].vy == D && I[u].el === p || (I[u].el = p, I[u].vx = k, I[u].vy = D, clearInterval(I[u].pid), 0 == k && 0 == D) || (c = !0, I[u].pid = setInterval(function() {
                    s && 0 === this.layer && U.active._onTouchMove(Jt);
                    var t = I[this.layer].vy ? I[this.layer].vy * l : 0,
                        e = I[this.layer].vx ? I[this.layer].vx * l : 0;
                    "function" == typeof n && "continue" !== n.call(U.dragged.parentNode[F], e, t, i, Jt, I[this.layer].el) || et(I[this.layer].el, e, t)
                }.bind({
                    layer: u
                }), 24)), u++
            } while (t.bubbleScroll && d !== h && (d = S(d, !1)));
            te = c
        }
    }, 30);

    function ne() {}

    function oe() {}
    ne.prototype = {
        startIndex: null,
        dragStart: function(t) {
            t = t.oldDraggableIndex, this.startIndex = t
        },
        onSpill: function(t) {
            var e = t.dragEl,
                i = t.putSortable;
            this.sortable.captureAnimationState(), i && i.captureAnimationState(), (t = Q(this.sortable.el, this.startIndex, this.options)) ? this.sortable.el.insertBefore(e, t) : this.sortable.el.appendChild(e), this.sortable.animateAll(), i && i.animateAll()
        },
        drop: g = function(t) {
            var e = t.originalEvent,
                i = t.putSortable,
                s = t.dragEl,
                n = t.activeSortable,
                o = t.dispatchSortableEvent,
                a = t.hideGhostForTarget,
                t = t.unhideGhostForTarget;
            e && (n = i || n, a(), e = e.changedTouches && e.changedTouches.length ? e.changedTouches[0] : e, e = document.elementFromPoint(e.clientX, e.clientY), t(), n) && !n.el.contains(e) && (o("spill"), this.onSpill({
                dragEl: s,
                putSortable: i
            }))
        }
    }, r(ne, {
        pluginName: "revertOnSpill"
    }), oe.prototype = {
        onSpill: function(t) {
            var e = t.dragEl;
            (t = t.putSortable || this.sortable).captureAnimationState(), e.parentNode && e.parentNode.removeChild(e), t.animateAll()
        },
        drop: g
    }, r(oe, {
        pluginName: "removeOnSpill"
    });
    var ae, _, v, re, le, y = [],
        w = [],
        he = !1,
        x = !1,
        ce = !1;

    function ue(i, s) {
        w.forEach(function(t, e) {
            (e = s.children[t.sortableIndex + (i ? Number(e) : 0)]) ? s.insertBefore(t, e): s.appendChild(t)
        })
    }

    function de() {
        y.forEach(function(t) {
            t !== v && t.parentNode && t.parentNode.removeChild(t)
        })
    }
    return U.mount(new function() {
        function t() {
            for (var t in this.defaults = {
                    scroll: !0,
                    forceAutoScrollFallback: !1,
                    scrollSensitivity: 30,
                    scrollSpeed: 10,
                    bubbleScroll: !0
                }, this) "_" === t.charAt(0) && "function" == typeof this[t] && (this[t] = this[t].bind(this))
        }
        return t.prototype = {
            dragStarted: function(t) {
                t = t.originalEvent, this.sortable.nativeDraggable ? l(document, "dragover", this._handleAutoScroll) : this.options.supportPointer ? l(document, "pointermove", this._handleFallbackAutoScroll) : t.touches ? l(document, "touchmove", this._handleFallbackAutoScroll) : l(document, "mousemove", this._handleFallbackAutoScroll)
            },
            dragOverCompleted: function(t) {
                t = t.originalEvent, this.options.dragOverBubble || t.rootEl || this._handleAutoScroll(t)
            },
            drop: function() {
                this.sortable.nativeDraggable ? o(document, "dragover", this._handleAutoScroll) : (o(document, "pointermove", this._handleFallbackAutoScroll), o(document, "touchmove", this._handleFallbackAutoScroll), o(document, "mousemove", this._handleFallbackAutoScroll)), ie(), ee(), clearTimeout(T), T = void 0
            },
            nulling: function() {
                Jt = Xt = Kt = te = Zt = Qt = Gt = null, I.length = 0
            },
            _handleFallbackAutoScroll: function(t) {
                this._handleAutoScroll(t, !0)
            },
            _handleAutoScroll: function(e, i) {
                var s, n = this,
                    o = (e.touches ? e.touches[0] : e).clientX,
                    a = (e.touches ? e.touches[0] : e).clientY,
                    t = document.elementFromPoint(o, a);
                Jt = e, i || this.options.forceAutoScrollFallback || C || b || m ? (se(e, this.options, t, i), s = S(t, !0), !te || Zt && o === Qt && a === Gt || (Zt && ie(), Zt = setInterval(function() {
                    var t = S(document.elementFromPoint(o, a), !0);
                    t !== s && (s = t, ee()), se(e, n.options, t, i)
                }, 10), Qt = o, Gt = a)) : this.options.bubbleScroll && S(t, !0) !== E() ? se(e, this.options, S(t, !1), !1) : ee()
            }
        }, r(t, {
            pluginName: "scroll",
            initializeByDefault: !0
        })
    }), U.mount(oe, ne), U.mount(new function() {
        function t() {
            this.defaults = {
                swapClass: "sortable-swap-highlight"
            }
        }
        return t.prototype = {
            dragStart: function(t) {
                t = t.dragEl, u = t
            },
            dragOverValid: function(t) {
                var e = t.completed,
                    i = t.target,
                    s = t.onMove,
                    n = t.activeSortable,
                    o = t.changed,
                    a = t.cancel;
                n.options.swap && (t = this.sortable.el, n = this.options, i && i !== t && (t = u, u = !1 !== s(i) ? (A(i, n.swapClass, !0), i) : null, t) && t !== u && A(t, n.swapClass, !1), o(), e(!0), a())
            },
            drop: function(t) {
                var e, i, s = t.activeSortable,
                    n = t.putSortable,
                    o = t.dragEl,
                    a = n || this.sortable,
                    r = this.options;
                u && A(u, r.swapClass, !1), u && (r.swap || n && n.options.swap) && o !== u && (a.captureAnimationState(), a !== s && s.captureAnimationState(), i = u, t = (e = o).parentNode, r = i.parentNode, t && r && !t.isEqualNode(i) && !r.isEqualNode(e) && (n = H(e), o = H(i), t.isEqualNode(r) && n < o && o++, t.insertBefore(i, t.children[n]), r.insertBefore(e, r.children[o])), a.animateAll(), a !== s) && s.animateAll()
            },
            nulling: function() {
                u = null
            }
        }, r(t, {
            pluginName: "swap",
            eventProperties: function() {
                return {
                    swapItem: u
                }
            }
        })
    }), U.mount(new function() {
        function t(s) {
            for (var t in this) "_" === t.charAt(0) && "function" == typeof this[t] && (this[t] = this[t].bind(this));
            s.options.avoidImplicitDeselect || (s.options.supportPointer ? l(document, "pointerup", this._deselectMultiDrag) : (l(document, "mouseup", this._deselectMultiDrag), l(document, "touchend", this._deselectMultiDrag))), l(document, "keydown", this._checkKeyDown), l(document, "keyup", this._checkKeyUp), this.defaults = {
                selectedClass: "sortable-selected",
                multiDragKey: null,
                avoidImplicitDeselect: !1,
                setData: function(t, e) {
                    var i = "";
                    y.length && _ === s ? y.forEach(function(t, e) {
                        i += (e ? ", " : "") + t.textContent
                    }) : i = e.textContent, t.setData("Text", i)
                }
            }
        }
        return t.prototype = {
            multiDragKeyDown: !1,
            isMultiDrag: !1,
            delayStartGlobal: function(t) {
                t = t.dragEl, v = t
            },
            delayEnded: function() {
                this.isMultiDrag = ~y.indexOf(v)
            },
            setupClone: function(t) {
                var e = t.sortable,
                    t = t.cancel;
                if (this.isMultiDrag) {
                    for (var i = 0; i < y.length; i++) w.push(it(y[i])), w[i].sortableIndex = y[i].sortableIndex, w[i].draggable = !1, w[i].style["will-change"] = "", A(w[i], this.options.selectedClass, !1), y[i] === v && A(w[i], this.options.chosenClass, !1);
                    e._hideClone(), t()
                }
            },
            clone: function(t) {
                var e = t.sortable,
                    i = t.rootEl,
                    s = t.dispatchSortableEvent,
                    t = t.cancel;
                this.isMultiDrag && !this.options.removeCloneOnHide && y.length && _ === e && (ue(!0, i), s("clone"), t())
            },
            showClone: function(t) {
                var e = t.cloneNowShown,
                    i = t.rootEl,
                    t = t.cancel;
                this.isMultiDrag && (ue(!1, i), w.forEach(function(t) {
                    N(t, "display", "")
                }), e(), le = !1, t())
            },
            hideClone: function(t) {
                var e = this,
                    i = (t.sortable, t.cloneNowHidden),
                    t = t.cancel;
                this.isMultiDrag && (w.forEach(function(t) {
                    N(t, "display", "none"), e.options.removeCloneOnHide && t.parentNode && t.parentNode.removeChild(t)
                }), i(), le = !0, t())
            },
            dragStartGlobal: function(t) {
                t.sortable, !this.isMultiDrag && _ && _.multiDrag._deselectMultiDrag(), y.forEach(function(t) {
                    t.sortableIndex = H(t)
                }), y = y.sort(function(t, e) {
                    return t.sortableIndex - e.sortableIndex
                }), ce = !0
            },
            dragStarted: function(t) {
                var e, i = this,
                    t = t.sortable;
                this.isMultiDrag && (this.options.sort && (t.captureAnimationState(), this.options.animation) && (y.forEach(function(t) {
                    t !== v && N(t, "position", "absolute")
                }), e = O(v, !1, !0, !0), y.forEach(function(t) {
                    t !== v && st(t, e)
                }), he = x = !0), t.animateAll(function() {
                    he = x = !1, i.options.animation && y.forEach(function(t) {
                        nt(t)
                    }), i.options.sort && de()
                }))
            },
            dragOver: function(t) {
                var e = t.target,
                    i = t.completed,
                    t = t.cancel;
                x && ~y.indexOf(e) && (i(!1), t())
            },
            revert: function(t) {
                var i, s, e = t.fromSortable,
                    n = t.rootEl,
                    o = t.sortable,
                    a = t.dragRect;
                1 < y.length && (y.forEach(function(t) {
                    o.addAnimationState({
                        target: t,
                        rect: x ? O(t) : a
                    }), nt(t), t.fromRect = a, e.removeAnimationState(t)
                }), x = !1, i = !this.options.removeCloneOnHide, s = n, y.forEach(function(t, e) {
                    (e = s.children[t.sortableIndex + (i ? Number(e) : 0)]) ? s.insertBefore(t, e): s.appendChild(t)
                }))
            },
            dragOverCompleted: function(t) {
                var e, i = t.sortable,
                    s = t.isOwner,
                    n = t.insertion,
                    o = t.activeSortable,
                    a = t.parentEl,
                    r = t.putSortable,
                    t = this.options;
                n && (s && o._hideClone(), he = !1, t.animation && 1 < y.length && (x || !s && !o.options.sort && !r) && (e = O(v, !1, !0, !0), y.forEach(function(t) {
                    t !== v && (st(t, e), a.appendChild(t))
                }), x = !0), s || (x || de(), 1 < y.length ? (s = le, o._showClone(i), o.options.animation && !le && s && w.forEach(function(t) {
                    o.addAnimationState({
                        target: t,
                        rect: re
                    }), t.fromRect = re, t.thisAnimationDuration = null
                })) : o._showClone(i)))
            },
            dragOverAnimationCapture: function(t) {
                var e = t.dragRect,
                    i = t.isOwner,
                    t = t.activeSortable;
                y.forEach(function(t) {
                    t.thisAnimationDuration = null
                }), t.options.animation && !i && t.multiDrag.isMultiDrag && (re = r({}, e), e = p(v, !0), re.top -= e.f, re.left -= e.e)
            },
            dragOverAnimationComplete: function() {
                x && (x = !1, de())
            },
            drop: function(t) {
                var e = t.originalEvent,
                    i = t.rootEl,
                    s = t.parentEl,
                    n = t.sortable,
                    o = t.dispatchSortableEvent,
                    a = t.oldIndex,
                    r = t.putSortable,
                    l = r || this.sortable;
                if (e) {
                    var h, c, u, d = this.options,
                        p = s.children;
                    if (!ce)
                        if (d.multiDragKey && !this.multiDragKeyDown && this._deselectMultiDrag(), A(v, d.selectedClass, !~y.indexOf(v)), ~y.indexOf(v)) y.splice(y.indexOf(v), 1), ae = null, lt({
                            sortable: n,
                            rootEl: i,
                            name: "deselect",
                            targetEl: v,
                            originalEvent: e
                        });
                        else {
                            if (y.push(v), lt({
                                    sortable: n,
                                    rootEl: i,
                                    name: "select",
                                    targetEl: v,
                                    originalEvent: e
                                }), e.shiftKey && ae && n.el.contains(ae)) {
                                var f = H(ae),
                                    t = H(v);
                                if (~f && ~t && f !== t)
                                    for (var m, g = f < t ? (m = f, t) : (m = t, f + 1); m < g; m++) ~y.indexOf(p[m]) || (A(p[m], d.selectedClass, !0), y.push(p[m]), lt({
                                        sortable: n,
                                        rootEl: i,
                                        name: "select",
                                        targetEl: p[m],
                                        originalEvent: e
                                    }))
                            } else ae = v;
                            _ = l
                        }
                    ce && this.isMultiDrag && (x = !1, (s[F].options.sort || s !== i) && 1 < y.length && (h = O(v), c = H(v, ":not(." + this.options.selectedClass + ")"), !he && d.animation && (v.thisAnimationDuration = null), l.captureAnimationState(), he || (d.animation && (v.fromRect = h, y.forEach(function(t) {
                        var e;
                        t.thisAnimationDuration = null, t !== v && (e = x ? O(t) : h, t.fromRect = e, l.addAnimationState({
                            target: t,
                            rect: e
                        }))
                    })), de(), y.forEach(function(t) {
                        p[c] ? s.insertBefore(t, p[c]) : s.appendChild(t), c++
                    }), a === H(v) && (u = !1, y.forEach(function(t) {
                        t.sortableIndex !== H(t) && (u = !0)
                    }), u) && o("update")), y.forEach(function(t) {
                        nt(t)
                    }), l.animateAll()), _ = l), (i === s || r && "clone" !== r.lastPutMode) && w.forEach(function(t) {
                        t.parentNode && t.parentNode.removeChild(t)
                    })
                }
            },
            nullingGlobal: function() {
                this.isMultiDrag = ce = !1, w.length = 0
            },
            destroyGlobal: function() {
                this._deselectMultiDrag(), o(document, "pointerup", this._deselectMultiDrag), o(document, "mouseup", this._deselectMultiDrag), o(document, "touchend", this._deselectMultiDrag), o(document, "keydown", this._checkKeyDown), o(document, "keyup", this._checkKeyUp)
            },
            _deselectMultiDrag: function(t) {
                if (!(void 0 !== ce && ce || _ !== this.sortable || t && M(t.target, this.options.draggable, this.sortable.el, !1) || t && 0 !== t.button))
                    for (; y.length;) {
                        var e = y[0];
                        A(e, this.options.selectedClass, !1), y.shift(), lt({
                            sortable: this.sortable,
                            rootEl: this.sortable.el,
                            name: "deselect",
                            targetEl: e,
                            originalEvent: t
                        })
                    }
            },
            _checkKeyDown: function(t) {
                t.key === this.options.multiDragKey && (this.multiDragKeyDown = !0)
            },
            _checkKeyUp: function(t) {
                t.key === this.options.multiDragKey && (this.multiDragKeyDown = !1)
            }
        }, r(t, {
            pluginName: "multiDrag",
            utils: {
                select: function(t) {
                    var e = t.parentNode[F];
                    e && e.options.multiDrag && !~y.indexOf(t) && (_ && _ !== e && (_.multiDrag._deselectMultiDrag(), _ = e), A(t, e.options.selectedClass, !0), y.push(t))
                },
                deselect: function(t) {
                    var e = t.parentNode[F],
                        i = y.indexOf(t);
                    e && e.options.multiDrag && ~i && (A(t, e.options.selectedClass, !1), y.splice(i, 1))
                }
            },
            eventProperties: function() {
                var t, i = this,
                    s = [],
                    n = [];
                return y.forEach(function(t) {
                    var e;
                    s.push({
                        multiDragElement: t,
                        index: t.sortableIndex
                    }), e = x && t !== v ? -1 : x ? H(t, ":not(." + i.options.selectedClass + ")") : H(t), n.push({
                        multiDragElement: t,
                        index: e
                    })
                }), {
                    items: function(t) {
                        if (Array.isArray(t)) return d(t)
                    }(t = y) || function() {
                        if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
                    }() || function(t) {
                        var e;
                        if (t) return "string" == typeof t ? d(t, void 0) : "Map" === (e = "Object" === (e = Object.prototype.toString.call(t).slice(8, -1)) && t.constructor ? t.constructor.name : e) || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? d(t, void 0) : void 0
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }(),
                    clones: [].concat(w),
                    oldIndicies: s,
                    newIndicies: n
                }
            },
            optionListeners: {
                multiDragKey: function(t) {
                    return "ctrl" === (t = t.toLowerCase()) ? t = "Control" : 1 < t.length && (t = t.charAt(0).toUpperCase() + t.substr(1)), t
                }
            }
        })
    }), U
}),
function(t) {
    function e(t, e) {
        var i, s;
        1 < t.originalEvent.touches.length || (t.preventDefault(), i = t.originalEvent.changedTouches[0], (s = document.createEvent("MouseEvents")).initMouseEvent(e, !0, !0, window, 1, i.screenX, i.screenY, i.clientX, i.clientY, !1, !1, !1, !1, 0, null), t.target.dispatchEvent(s))
    }
    var i, s, n, o;
    t.support.touch = "ontouchend" in document, t.support.touch && (s = t.ui.mouse.prototype, n = s._mouseInit, o = s._mouseDestroy, s._touchStart = function(t) {
        !i && this._mouseCapture(t.originalEvent.changedTouches[0]) && (i = !0, this._touchMoved = !1, e(t, "mouseover"), e(t, "mousemove"), e(t, "mousedown"))
    }, s._touchMove = function(t) {
        i && (this._touchMoved = !0, e(t, "mousemove"))
    }, s._touchEnd = function(t) {
        i && (e(t, "mouseup"), e(t, "mouseout"), this._touchMoved || e(t, "click"), i = !1)
    }, s._mouseInit = function() {
        this.element.bind({
            touchstart: t.proxy(this, "_touchStart"),
            touchmove: t.proxy(this, "_touchMove"),
            touchend: t.proxy(this, "_touchEnd")
        }), n.call(this)
    }, s._mouseDestroy = function() {
        this.element.unbind({
            touchstart: t.proxy(this, "_touchStart"),
            touchmove: t.proxy(this, "_touchMove"),
            touchend: t.proxy(this, "_touchEnd")
        }), o.call(this)
    })
}(jQuery),
function(e) {
    "function" == typeof define && define.amd ? define(["jquery"], function(t) {
        return e(t, document, window, navigator)
    }) : "object" == typeof exports ? e(require("jquery"), document, window, navigator) : e(jQuery, document, window, navigator)
}(function(o, a, r, t, l) {
    function e(t, e, i) {
        this.VERSION = "2.2.0", this.input = t, this.plugin_count = i, this.old_to = this.old_from = this.update_tm = this.calc_count = this.current_plugin = 0, this.raf_id = this.old_min_interval = null, this.no_diapason = this.force_redraw = this.dragging = !1, this.has_tab_index = !0, this.is_update = this.is_key = !1, this.is_start = !0, this.is_click = this.is_resize = this.is_active = this.is_finish = !1, e = e || {}, this.$cache = {
            win: o(r),
            body: o(a.body),
            input: o(t),
            cont: null,
            rs: null,
            min: null,
            max: null,
            from: null,
            to: null,
            single: null,
            bar: null,
            line: null,
            s_single: null,
            s_from: null,
            s_to: null,
            shad_single: null,
            shad_from: null,
            shad_to: null,
            edge: null,
            grid: null,
            grid_labels: []
        }, this.coords = {
            x_gap: 0,
            x_pointer: 0,
            w_rs: 0,
            w_rs_old: 0,
            w_handle: 0,
            p_gap: 0,
            p_gap_left: 0,
            p_gap_right: 0,
            p_step: 0,
            p_pointer: 0,
            p_handle: 0,
            p_single_fake: 0,
            p_single_real: 0,
            p_from_fake: 0,
            p_from_real: 0,
            p_to_fake: 0,
            p_to_real: 0,
            p_bar_x: 0,
            p_bar_w: 0,
            grid_gap: 0,
            big_num: 0,
            big: [],
            big_w: [],
            big_p: [],
            big_x: []
        }, this.labels = {
            w_min: 0,
            w_max: 0,
            w_from: 0,
            w_to: 0,
            w_single: 0,
            p_min: 0,
            p_max: 0,
            p_from_fake: 0,
            p_from_left: 0,
            p_to_fake: 0,
            p_to_left: 0,
            p_single_fake: 0,
            p_single_left: 0
        };
        var s, n = this.$cache.input;
        for (s in t = n.prop("value"), i = {
                type: "single",
                min: 10,
                max: 100,
                from: null,
                to: null,
                step: 1,
                min_interval: 0,
                max_interval: 0,
                drag_interval: !1,
                values: [],
                p_values: [],
                from_fixed: !1,
                from_min: null,
                from_max: null,
                from_shadow: !1,
                to_fixed: !1,
                to_min: null,
                to_max: null,
                to_shadow: !1,
                prettify_enabled: !0,
                prettify_separator: " ",
                prettify: null,
                force_edges: !1,
                keyboard: !0,
                grid: !1,
                grid_margin: !0,
                grid_num: 4,
                grid_snap: !1,
                hide_min_max: !1,
                hide_from_to: !1,
                prefix: "",
                postfix: "",
                max_postfix: "",
                decorate_both: !0,
                values_separator: " — ",
                input_values_separator: ";",
                disable: !1,
                block: !1,
                extra_classes: "",
                scope: null,
                onStart: null,
                onChange: null,
                onFinish: null,
                onUpdate: null
            }, "INPUT" !== n[0].nodeName && console && console.warn && console.warn("Base element should be <input>!", n[0]), (n = {
                type: n.data("type"),
                min: n.data("min"),
                max: n.data("max"),
                from: n.data("from"),
                to: n.data("to"),
                step: n.data("step"),
                min_interval: n.data("minInterval"),
                max_interval: n.data("maxInterval"),
                drag_interval: n.data("dragInterval"),
                values: n.data("values"),
                from_fixed: n.data("fromFixed"),
                from_min: n.data("fromMin"),
                from_max: n.data("fromMax"),
                from_shadow: n.data("fromShadow"),
                to_fixed: n.data("toFixed"),
                to_min: n.data("toMin"),
                to_max: n.data("toMax"),
                to_shadow: n.data("toShadow"),
                prettify_enabled: n.data("prettifyEnabled"),
                prettify_separator: n.data("prettifySeparator"),
                force_edges: n.data("forceEdges"),
                keyboard: n.data("keyboard"),
                grid: n.data("grid"),
                grid_margin: n.data("gridMargin"),
                grid_num: n.data("gridNum"),
                grid_snap: n.data("gridSnap"),
                hide_min_max: n.data("hideMinMax"),
                hide_from_to: n.data("hideFromTo"),
                prefix: n.data("prefix"),
                postfix: n.data("postfix"),
                max_postfix: n.data("maxPostfix"),
                decorate_both: n.data("decorateBoth"),
                values_separator: n.data("valuesSeparator"),
                input_values_separator: n.data("inputValuesSeparator"),
                disable: n.data("disable"),
                block: n.data("block"),
                extra_classes: n.data("extraClasses")
            }).values = n.values && n.values.split(","), n) !n.hasOwnProperty(s) || n[s] !== l && "" !== n[s] || delete n[s];
        t !== l && "" !== t && ((t = t.split(n.input_values_separator || e.input_values_separator || ";"))[0] && t[0] == +t[0] && (t[0] = +t[0]), t[1] && t[1] == +t[1] && (t[1] = +t[1]), e && e.values && e.values.length ? (i.from = t[0] && e.values.indexOf(t[0]), i.to = t[1] && e.values.indexOf(t[1])) : (i.from = t[0] && +t[0], i.to = t[1] && +t[1])), o.extend(i, e), o.extend(i, n), this.options = i, this.update_check = {}, this.validate(), this.result = {
            input: this.$cache.input,
            slider: null,
            min: this.options.min,
            max: this.options.max,
            from: this.options.from,
            from_percent: 0,
            from_value: null,
            to: this.options.to,
            to_percent: 0,
            to_value: null
        }, this.init()
    }
    var i, s = 0,
        n = (t = t.userAgent, i = /msie\s\d+/i, 0 < t.search(i) && (t = (t = i.exec(t).toString()).split(" ")[1]) < 9 && (o("html").addClass("lt-ie9"), !0));
    Function.prototype.bind || (Function.prototype.bind = function(i) {
        var s = this,
            n = [].slice;
        if ("function" != typeof s) throw new TypeError;
        var o = n.call(arguments, 1),
            a = function() {
                var t, e;
                return this instanceof a ? ((t = function() {}).prototype = s.prototype, t = new t, e = s.apply(t, o.concat(n.call(arguments))), Object(e) === e ? e : t) : s.apply(i, o.concat(n.call(arguments)))
            };
        return a
    }), Array.prototype.indexOf || (Array.prototype.indexOf = function(t, e) {
        if (null == this) throw new TypeError('"this" is null or not defined');
        var i = Object(this),
            s = i.length >>> 0;
        if (0 != s) {
            var n = +e || 0;
            if (!(s <= (n = 1 / 0 === Math.abs(n) ? 0 : n)))
                for (n = Math.max(0 <= n ? n : s - Math.abs(n), 0); n < s;) {
                    if (n in i && i[n] === t) return n;
                    n++
                }
        }
        return -1
    });
    e.prototype = {
        init: function(t) {
            this.no_diapason = !1, this.coords.p_step = this.convertToPercent(this.options.step, !0), this.target = "base", this.toggleInput(), this.append(), this.setMinMax(), t ? (this.force_redraw = !0, this.calc(!0), this.callOnUpdate()) : (this.force_redraw = !0, this.calc(!0), this.callOnStart()), this.updateScene()
        },
        append: function() {
            this.$cache.input.before('<span class="irs js-irs-' + this.plugin_count + " " + this.options.extra_classes + '"></span>'), this.$cache.input.prop("readonly", !0), this.$cache.cont = this.$cache.input.prev(), this.result.slider = this.$cache.cont, this.$cache.cont.html('<span class="irs"><span class="irs-line" tabindex="0"><span class="irs-line-left"></span><span class="irs-line-mid"></span><span class="irs-line-right"></span></span><span class="irs-min">0</span><span class="irs-max">1</span><span class="irs-from">0</span><span class="irs-to">0</span><span class="irs-single">0</span></span><span class="irs-grid"></span><span class="irs-bar"></span>'), this.$cache.rs = this.$cache.cont.find(".irs"), this.$cache.min = this.$cache.cont.find(".irs-min"), this.$cache.max = this.$cache.cont.find(".irs-max"), this.$cache.from = this.$cache.cont.find(".irs-from"), this.$cache.to = this.$cache.cont.find(".irs-to"), this.$cache.single = this.$cache.cont.find(".irs-single"), this.$cache.bar = this.$cache.cont.find(".irs-bar"), this.$cache.line = this.$cache.cont.find(".irs-line"), this.$cache.grid = this.$cache.cont.find(".irs-grid"), "single" === this.options.type ? (this.$cache.cont.append('<span class="irs-bar-edge"></span><span class="irs-shadow shadow-single"></span><span class="irs-slider single"></span>'), this.$cache.edge = this.$cache.cont.find(".irs-bar-edge"), this.$cache.s_single = this.$cache.cont.find(".single"), this.$cache.from[0].style.visibility = "hidden", this.$cache.to[0].style.visibility = "hidden", this.$cache.shad_single = this.$cache.cont.find(".shadow-single")) : (this.$cache.cont.append('<span class="irs-shadow shadow-from"></span><span class="irs-shadow shadow-to"></span><span class="irs-slider from"></span><span class="irs-slider to"></span>'), this.$cache.s_from = this.$cache.cont.find(".from"), this.$cache.s_to = this.$cache.cont.find(".to"), this.$cache.shad_from = this.$cache.cont.find(".shadow-from"), this.$cache.shad_to = this.$cache.cont.find(".shadow-to"), this.setTopHandler()), this.options.hide_from_to && (this.$cache.from[0].style.display = "none", this.$cache.to[0].style.display = "none", this.$cache.single[0].style.display = "none"), this.appendGrid(), this.options.disable ? (this.appendDisableMask(), this.$cache.input[0].disabled = !0) : (this.$cache.input[0].disabled = !1, this.removeDisableMask(), this.bindEvents()), this.options.disable || (this.options.block ? this.appendDisableMask() : this.removeDisableMask()), this.options.drag_interval && (this.$cache.bar[0].style.cursor = "ew-resize")
        },
        setTopHandler: function() {
            var t = this.options.max,
                e = this.options.to;
            this.options.from > this.options.min && e === t ? this.$cache.s_from.addClass("type_last") : e < t && this.$cache.s_to.addClass("type_last")
        },
        changeLevel: function(t) {
            switch (t) {
                case "single":
                    this.coords.p_gap = this.toFixed(this.coords.p_pointer - this.coords.p_single_fake), this.$cache.s_single.addClass("state_hover");
                    break;
                case "from":
                    this.coords.p_gap = this.toFixed(this.coords.p_pointer - this.coords.p_from_fake), this.$cache.s_from.addClass("state_hover"), this.$cache.s_from.addClass("type_last"), this.$cache.s_to.removeClass("type_last");
                    break;
                case "to":
                    this.coords.p_gap = this.toFixed(this.coords.p_pointer - this.coords.p_to_fake), this.$cache.s_to.addClass("state_hover"), this.$cache.s_to.addClass("type_last"), this.$cache.s_from.removeClass("type_last");
                    break;
                case "both":
                    this.coords.p_gap_left = this.toFixed(this.coords.p_pointer - this.coords.p_from_fake), this.coords.p_gap_right = this.toFixed(this.coords.p_to_fake - this.coords.p_pointer), this.$cache.s_to.removeClass("type_last"), this.$cache.s_from.removeClass("type_last")
            }
        },
        appendDisableMask: function() {
            this.$cache.cont.append('<span class="irs-disable-mask"></span>'), this.$cache.cont.addClass("irs-disabled")
        },
        removeDisableMask: function() {
            this.$cache.cont.remove(".irs-disable-mask"), this.$cache.cont.removeClass("irs-disabled")
        },
        remove: function() {
            this.$cache.cont.remove(), this.$cache.cont = null, this.$cache.line.off("keydown.irs_" + this.plugin_count), this.$cache.body.off("touchmove.irs_" + this.plugin_count), this.$cache.body.off("mousemove.irs_" + this.plugin_count), this.$cache.win.off("touchend.irs_" + this.plugin_count), this.$cache.win.off("mouseup.irs_" + this.plugin_count), n && (this.$cache.body.off("mouseup.irs_" + this.plugin_count), this.$cache.body.off("mouseleave.irs_" + this.plugin_count)), this.$cache.grid_labels = [], this.coords.big = [], this.coords.big_w = [], this.coords.big_p = [], this.coords.big_x = [], cancelAnimationFrame(this.raf_id)
        },
        bindEvents: function() {
            this.no_diapason || (this.$cache.body.on("touchmove.irs_" + this.plugin_count, this.pointerMove.bind(this)), this.$cache.body.on("mousemove.irs_" + this.plugin_count, this.pointerMove.bind(this)), this.$cache.win.on("touchend.irs_" + this.plugin_count, this.pointerUp.bind(this)), this.$cache.win.on("mouseup.irs_" + this.plugin_count, this.pointerUp.bind(this)), this.$cache.line.on("touchstart.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.line.on("mousedown.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.line.on("focus.irs_" + this.plugin_count, this.pointerFocus.bind(this)), this.options.drag_interval && "double" === this.options.type ? (this.$cache.bar.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, "both")), this.$cache.bar.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, "both"))) : (this.$cache.bar.on("touchstart.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.bar.on("mousedown.irs_" + this.plugin_count, this.pointerClick.bind(this, "click"))), ("single" === this.options.type ? (this.$cache.single.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, "single")), this.$cache.s_single.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, "single")), this.$cache.shad_single.on("touchstart.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.single.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, "single")), this.$cache.s_single.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, "single")), this.$cache.edge.on("mousedown.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.shad_single) : (this.$cache.single.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, null)), this.$cache.single.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, null)), this.$cache.from.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, "from")), this.$cache.s_from.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, "from")), this.$cache.to.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, "to")), this.$cache.s_to.on("touchstart.irs_" + this.plugin_count, this.pointerDown.bind(this, "to")), this.$cache.shad_from.on("touchstart.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.shad_to.on("touchstart.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.from.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, "from")), this.$cache.s_from.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, "from")), this.$cache.to.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, "to")), this.$cache.s_to.on("mousedown.irs_" + this.plugin_count, this.pointerDown.bind(this, "to")), this.$cache.shad_from.on("mousedown.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.$cache.shad_to)).on("mousedown.irs_" + this.plugin_count, this.pointerClick.bind(this, "click")), this.options.keyboard && this.$cache.line.on("keydown.irs_" + this.plugin_count, this.key.bind(this, "keyboard")), n && (this.$cache.body.on("mouseup.irs_" + this.plugin_count, this.pointerUp.bind(this)), this.$cache.body.on("mouseleave.irs_" + this.plugin_count, this.pointerUp.bind(this))))
        },
        pointerFocus: function(t) {
            var e;
            this.target || (t = (e = "single" === this.options.type ? this.$cache.single : this.$cache.from).offset().left, t += e.width() / 2 - 1, this.pointerClick("single", {
                preventDefault: function() {},
                pageX: t
            }))
        },
        pointerMove: function(t) {
            this.dragging && (this.coords.x_pointer = (t.pageX || t.originalEvent.touches && t.originalEvent.touches[0].pageX) - this.coords.x_gap, this.calc())
        },
        pointerUp: function(t) {
            this.current_plugin === this.plugin_count && this.is_active && (this.is_active = !1, this.$cache.cont.find(".state_hover").removeClass("state_hover"), this.force_redraw = !0, n && o("*").prop("unselectable", !1), this.updateScene(), this.restoreOriginalMinInterval(), (o.contains(this.$cache.cont[0], t.target) || this.dragging) && this.callOnFinish(), this.dragging = !1)
        },
        pointerDown: function(t, e) {
            e.preventDefault();
            var i = e.pageX || e.originalEvent.touches && e.originalEvent.touches[0].pageX;
            2 !== e.button && ("both" === t && this.setTempMinInterval(), t = t || this.target || "from", this.current_plugin = this.plugin_count, this.target = t, this.dragging = this.is_active = !0, this.coords.x_gap = this.$cache.rs.offset().left, this.coords.x_pointer = i - this.coords.x_gap, this.calcPointerPercent(), this.changeLevel(t), n && o("*").prop("unselectable", !0), this.$cache.line.trigger("focus"), this.updateScene())
        },
        pointerClick: function(t, e) {
            e.preventDefault();
            var i = e.pageX || e.originalEvent.touches && e.originalEvent.touches[0].pageX;
            2 !== e.button && (this.current_plugin = this.plugin_count, this.target = t, this.is_click = !0, this.coords.x_gap = this.$cache.rs.offset().left, this.coords.x_pointer = +(i - this.coords.x_gap).toFixed(), this.force_redraw = !0, this.calc(), this.$cache.line.trigger("focus"))
        },
        key: function(t, e) {
            if (!(this.current_plugin !== this.plugin_count || e.altKey || e.ctrlKey || e.shiftKey || e.metaKey)) {
                switch (e.which) {
                    case 83:
                    case 65:
                    case 40:
                    case 37:
                        e.preventDefault(), this.moveByKey(!1);
                        break;
                    case 87:
                    case 68:
                    case 38:
                    case 39:
                        e.preventDefault(), this.moveByKey(!0)
                }
                return !0
            }
        },
        moveByKey: function(t) {
            var e = this.coords.p_pointer,
                i = (this.options.max - this.options.min) / 100,
                i = this.options.step / i;
            this.coords.x_pointer = this.toFixed(this.coords.w_rs / 100 * (t ? e + i : e - i)), this.is_key = !0, this.calc()
        },
        setMinMax: function() {
            var t, e;
            this.options && (this.options.hide_min_max ? (this.$cache.min[0].style.display = "none", this.$cache.max[0].style.display = "none") : (this.options.values.length ? (this.$cache.min.html(this.decorate(this.options.p_values[this.options.min])), this.$cache.max.html(this.decorate(this.options.p_values[this.options.max]))) : (t = this._prettify(this.options.min), e = this._prettify(this.options.max), this.result.min_pretty = t, this.result.max_pretty = e, this.$cache.min.html(this.decorate(t, this.options.min)), this.$cache.max.html(this.decorate(e, this.options.max))), this.labels.w_min = this.$cache.min.outerWidth(!1), this.labels.w_max = this.$cache.max.outerWidth(!1)))
        },
        setTempMinInterval: function() {
            var t = this.result.to - this.result.from;
            null === this.old_min_interval && (this.old_min_interval = this.options.min_interval), this.options.min_interval = t
        },
        restoreOriginalMinInterval: function() {
            null !== this.old_min_interval && (this.options.min_interval = this.old_min_interval, this.old_min_interval = null)
        },
        calc: function(t) {
            if (this.options && (this.calc_count++, 10 !== this.calc_count && !t || (this.calc_count = 0, this.coords.w_rs = this.$cache.rs.outerWidth(!1), this.calcHandlePercent()), this.coords.w_rs)) {
                switch (this.calcPointerPercent(), t = this.getHandleX(), "both" === this.target && (this.coords.p_gap = 0, t = this.getHandleX()), "click" === this.target && (this.coords.p_gap = this.coords.p_handle / 2, t = this.getHandleX(), this.target = this.options.drag_interval ? "both_one" : this.chooseHandle(t)), this.target) {
                    case "base":
                        var e = (this.options.max - this.options.min) / 100;
                        t = (this.result.from - this.options.min) / e, e = (this.result.to - this.options.min) / e, this.coords.p_single_real = this.toFixed(t), this.coords.p_from_real = this.toFixed(t), this.coords.p_to_real = this.toFixed(e), this.coords.p_single_real = this.checkDiapason(this.coords.p_single_real, this.options.from_min, this.options.from_max), this.coords.p_from_real = this.checkDiapason(this.coords.p_from_real, this.options.from_min, this.options.from_max), this.coords.p_to_real = this.checkDiapason(this.coords.p_to_real, this.options.to_min, this.options.to_max), this.coords.p_single_fake = this.convertToFakePercent(this.coords.p_single_real), this.coords.p_from_fake = this.convertToFakePercent(this.coords.p_from_real), this.coords.p_to_fake = this.convertToFakePercent(this.coords.p_to_real), this.target = null;
                        break;
                    case "single":
                        this.options.from_fixed || (this.coords.p_single_real = this.convertToRealPercent(t), this.coords.p_single_real = this.calcWithStep(this.coords.p_single_real), this.coords.p_single_real = this.checkDiapason(this.coords.p_single_real, this.options.from_min, this.options.from_max), this.coords.p_single_fake = this.convertToFakePercent(this.coords.p_single_real));
                        break;
                    case "from":
                        this.options.from_fixed || (this.coords.p_from_real = this.convertToRealPercent(t), this.coords.p_from_real = this.calcWithStep(this.coords.p_from_real), this.coords.p_from_real > this.coords.p_to_real && (this.coords.p_from_real = this.coords.p_to_real), this.coords.p_from_real = this.checkDiapason(this.coords.p_from_real, this.options.from_min, this.options.from_max), this.coords.p_from_real = this.checkMinInterval(this.coords.p_from_real, this.coords.p_to_real, "from"), this.coords.p_from_real = this.checkMaxInterval(this.coords.p_from_real, this.coords.p_to_real, "from"), this.coords.p_from_fake = this.convertToFakePercent(this.coords.p_from_real));
                        break;
                    case "to":
                        this.options.to_fixed || (this.coords.p_to_real = this.convertToRealPercent(t), this.coords.p_to_real = this.calcWithStep(this.coords.p_to_real), this.coords.p_to_real < this.coords.p_from_real && (this.coords.p_to_real = this.coords.p_from_real), this.coords.p_to_real = this.checkDiapason(this.coords.p_to_real, this.options.to_min, this.options.to_max), this.coords.p_to_real = this.checkMinInterval(this.coords.p_to_real, this.coords.p_from_real, "to"), this.coords.p_to_real = this.checkMaxInterval(this.coords.p_to_real, this.coords.p_from_real, "to"), this.coords.p_to_fake = this.convertToFakePercent(this.coords.p_to_real));
                        break;
                    case "both":
                        this.options.from_fixed || this.options.to_fixed || (t = this.toFixed(t + .001 * this.coords.p_handle), this.coords.p_from_real = this.convertToRealPercent(t) - this.coords.p_gap_left, this.coords.p_from_real = this.calcWithStep(this.coords.p_from_real), this.coords.p_from_real = this.checkDiapason(this.coords.p_from_real, this.options.from_min, this.options.from_max), this.coords.p_from_real = this.checkMinInterval(this.coords.p_from_real, this.coords.p_to_real, "from"), this.coords.p_from_fake = this.convertToFakePercent(this.coords.p_from_real), this.coords.p_to_real = this.convertToRealPercent(t) + this.coords.p_gap_right, this.coords.p_to_real = this.calcWithStep(this.coords.p_to_real), this.coords.p_to_real = this.checkDiapason(this.coords.p_to_real, this.options.to_min, this.options.to_max), this.coords.p_to_real = this.checkMinInterval(this.coords.p_to_real, this.coords.p_from_real, "to"), this.coords.p_to_fake = this.convertToFakePercent(this.coords.p_to_real));
                        break;
                    case "both_one":
                        var i, s;
                        this.options.from_fixed || this.options.to_fixed || (e = (s = this.convertToRealPercent(t)) - (i = (t = this.result.to_percent - this.result.from_percent) / 2), s += i, 100 < (s = e < 0 ? (e = 0) + t : s) && (e = (s = 100) - t), this.coords.p_from_real = this.calcWithStep(e), this.coords.p_from_real = this.checkDiapason(this.coords.p_from_real, this.options.from_min, this.options.from_max), this.coords.p_from_fake = this.convertToFakePercent(this.coords.p_from_real), this.coords.p_to_real = this.calcWithStep(s), this.coords.p_to_real = this.checkDiapason(this.coords.p_to_real, this.options.to_min, this.options.to_max), this.coords.p_to_fake = this.convertToFakePercent(this.coords.p_to_real))
                }
                "single" === this.options.type ? (this.coords.p_bar_x = this.coords.p_handle / 2, this.coords.p_bar_w = this.coords.p_single_fake, this.result.from_percent = this.coords.p_single_real, this.result.from = this.convertToValue(this.coords.p_single_real), this.result.from_pretty = this._prettify(this.result.from), this.options.values.length && (this.result.from_value = this.options.values[this.result.from])) : (this.coords.p_bar_x = this.toFixed(this.coords.p_from_fake + this.coords.p_handle / 2), this.coords.p_bar_w = this.toFixed(this.coords.p_to_fake - this.coords.p_from_fake), this.result.from_percent = this.coords.p_from_real, this.result.from = this.convertToValue(this.coords.p_from_real), this.result.from_pretty = this._prettify(this.result.from), this.result.to_percent = this.coords.p_to_real, this.result.to = this.convertToValue(this.coords.p_to_real), this.result.to_pretty = this._prettify(this.result.to), this.options.values.length && (this.result.from_value = this.options.values[this.result.from], this.result.to_value = this.options.values[this.result.to])), this.calcMinMax(), this.calcLabels()
            }
        },
        calcPointerPercent: function() {
            this.coords.w_rs ? (this.coords.x_pointer < 0 || isNaN(this.coords.x_pointer) ? this.coords.x_pointer = 0 : this.coords.x_pointer > this.coords.w_rs && (this.coords.x_pointer = this.coords.w_rs), this.coords.p_pointer = this.toFixed(this.coords.x_pointer / this.coords.w_rs * 100)) : this.coords.p_pointer = 0
        },
        convertToRealPercent: function(t) {
            return t / (100 - this.coords.p_handle) * 100
        },
        convertToFakePercent: function(t) {
            return t / 100 * (100 - this.coords.p_handle)
        },
        getHandleX: function() {
            var t = 100 - this.coords.p_handle,
                e = this.toFixed(this.coords.p_pointer - this.coords.p_gap);
            return e < 0 ? e = 0 : t < e && (e = t), e
        },
        calcHandlePercent: function() {
            this.coords.w_handle = ("single" === this.options.type ? this.$cache.s_single : this.$cache.s_from).outerWidth(!1), this.coords.p_handle = this.toFixed(this.coords.w_handle / this.coords.w_rs * 100)
        },
        chooseHandle: function(t) {
            return "single" === this.options.type ? "single" : t >= this.coords.p_from_real + (this.coords.p_to_real - this.coords.p_from_real) / 2 ? this.options.to_fixed ? "from" : "to" : this.options.from_fixed ? "to" : "from"
        },
        calcMinMax: function() {
            this.coords.w_rs && (this.labels.p_min = this.labels.w_min / this.coords.w_rs * 100, this.labels.p_max = this.labels.w_max / this.coords.w_rs * 100)
        },
        calcLabels: function() {
            this.coords.w_rs && !this.options.hide_from_to && ("single" === this.options.type ? (this.labels.w_single = this.$cache.single.outerWidth(!1), this.labels.p_single_fake = this.labels.w_single / this.coords.w_rs * 100, this.labels.p_single_left = this.coords.p_single_fake + this.coords.p_handle / 2 - this.labels.p_single_fake / 2) : (this.labels.w_from = this.$cache.from.outerWidth(!1), this.labels.p_from_fake = this.labels.w_from / this.coords.w_rs * 100, this.labels.p_from_left = this.coords.p_from_fake + this.coords.p_handle / 2 - this.labels.p_from_fake / 2, this.labels.p_from_left = this.toFixed(this.labels.p_from_left), this.labels.p_from_left = this.checkEdges(this.labels.p_from_left, this.labels.p_from_fake), this.labels.w_to = this.$cache.to.outerWidth(!1), this.labels.p_to_fake = this.labels.w_to / this.coords.w_rs * 100, this.labels.p_to_left = this.coords.p_to_fake + this.coords.p_handle / 2 - this.labels.p_to_fake / 2, this.labels.p_to_left = this.toFixed(this.labels.p_to_left), this.labels.p_to_left = this.checkEdges(this.labels.p_to_left, this.labels.p_to_fake), this.labels.w_single = this.$cache.single.outerWidth(!1), this.labels.p_single_fake = this.labels.w_single / this.coords.w_rs * 100, this.labels.p_single_left = (this.labels.p_from_left + this.labels.p_to_left + this.labels.p_to_fake) / 2 - this.labels.p_single_fake / 2, this.labels.p_single_left = this.toFixed(this.labels.p_single_left)), this.labels.p_single_left = this.checkEdges(this.labels.p_single_left, this.labels.p_single_fake))
        },
        updateScene: function() {
            this.raf_id && (cancelAnimationFrame(this.raf_id), this.raf_id = null), clearTimeout(this.update_tm), this.update_tm = null, this.options && (this.drawHandles(), this.is_active ? this.raf_id = requestAnimationFrame(this.updateScene.bind(this)) : this.update_tm = setTimeout(this.updateScene.bind(this), 300))
        },
        drawHandles: function() {
            this.coords.w_rs = this.$cache.rs.outerWidth(!1), this.coords.w_rs && (this.coords.w_rs !== this.coords.w_rs_old && (this.target = "base", this.is_resize = !0), this.coords.w_rs === this.coords.w_rs_old && !this.force_redraw || (this.setMinMax(), this.calc(!0), this.drawLabels(), this.options.grid && (this.calcGridMargin(), this.calcGridLabels()), this.force_redraw = !0, this.coords.w_rs_old = this.coords.w_rs, this.drawShadow()), this.coords.w_rs) && (this.dragging || this.force_redraw || this.is_key) && ((this.old_from !== this.result.from || this.old_to !== this.result.to || this.force_redraw || this.is_key) && (this.drawLabels(), this.$cache.bar[0].style.left = this.coords.p_bar_x + "%", this.$cache.bar[0].style.width = this.coords.p_bar_w + "%", "single" === this.options.type ? this.$cache.s_single[0].style.left = this.coords.p_single_fake + "%" : (this.$cache.s_from[0].style.left = this.coords.p_from_fake + "%", this.$cache.s_to[0].style.left = this.coords.p_to_fake + "%", this.old_from === this.result.from && !this.force_redraw || (this.$cache.from[0].style.left = this.labels.p_from_left + "%"), this.old_to === this.result.to && !this.force_redraw || (this.$cache.to[0].style.left = this.labels.p_to_left + "%")), this.$cache.single[0].style.left = this.labels.p_single_left + "%", this.writeToInput(), this.old_from === this.result.from && this.old_to === this.result.to || this.is_start || (this.$cache.input.trigger("change"), this.$cache.input.trigger("input")), this.old_from = this.result.from, this.old_to = this.result.to, this.is_resize || this.is_update || this.is_start || this.is_finish || this.callOnChange(), (this.is_key || this.is_click) && (this.is_click = this.is_key = !1, this.callOnFinish()), this.is_finish = this.is_resize = this.is_update = !1), this.force_redraw = this.is_click = this.is_key = this.is_start = !1)
        },
        drawLabels: function() {
            var t, e, i, s;
            this.options && (t = this.options.values.length, i = this.options.p_values, this.options.hide_from_to || ("single" === this.options.type ? (t = t ? this.decorate(i[this.result.from]) : (e = this._prettify(this.result.from), this.decorate(e, this.result.from)), this.$cache.single.html(t), this.calcLabels(), this.$cache.min[0].style.visibility = this.labels.p_single_left < this.labels.p_min + 1 ? "hidden" : "visible", this.$cache.max[0].style.visibility = this.labels.p_single_left + this.labels.p_single_fake > 100 - this.labels.p_max - 1 ? "hidden" : "visible") : (i = t ? (this.options.decorate_both ? (t = this.decorate(i[this.result.from]), t = (t += this.options.values_separator) + this.decorate(i[this.result.to])) : t = this.decorate(i[this.result.from] + this.options.values_separator + i[this.result.to]), e = this.decorate(i[this.result.from]), this.decorate(i[this.result.to])) : (e = this._prettify(this.result.from), i = this._prettify(this.result.to), this.options.decorate_both ? (t = this.decorate(e, this.result.from), t = (t += this.options.values_separator) + this.decorate(i, this.result.to)) : t = this.decorate(e + this.options.values_separator + i, this.result.to), e = this.decorate(e, this.result.from), this.decorate(i, this.result.to)), this.$cache.single.html(t), this.$cache.from.html(e), this.$cache.to.html(i), this.calcLabels(), t = Math.min(this.labels.p_single_left, this.labels.p_from_left), e = this.labels.p_single_left + this.labels.p_single_fake, i = this.labels.p_to_left + this.labels.p_to_fake, s = Math.max(e, i), this.labels.p_from_left + this.labels.p_from_fake >= this.labels.p_to_left ? (this.$cache.from[0].style.visibility = "hidden", this.$cache.to[0].style.visibility = "hidden", this.$cache.single[0].style.visibility = "visible", s = this.result.from === this.result.to ? ("from" === this.target ? this.$cache.from[0].style.visibility = "visible" : "to" === this.target ? this.$cache.to[0].style.visibility = "visible" : this.target || (this.$cache.from[0].style.visibility = "visible"), this.$cache.single[0].style.visibility = "hidden", i) : (this.$cache.from[0].style.visibility = "hidden", this.$cache.to[0].style.visibility = "hidden", this.$cache.single[0].style.visibility = "visible", Math.max(e, i))) : (this.$cache.from[0].style.visibility = "visible", this.$cache.to[0].style.visibility = "visible", this.$cache.single[0].style.visibility = "hidden"), this.$cache.min[0].style.visibility = t < this.labels.p_min + 1 ? "hidden" : "visible", this.$cache.max[0].style.visibility = s > 100 - this.labels.p_max - 1 ? "hidden" : "visible")))
        },
        drawShadow: function() {
            var t = this.options,
                e = this.$cache,
                i = "number" == typeof t.from_min && !isNaN(t.from_min),
                s = "number" == typeof t.from_max && !isNaN(t.from_max),
                n = "number" == typeof t.to_min && !isNaN(t.to_min),
                o = "number" == typeof t.to_max && !isNaN(t.to_max);
            "single" === t.type ? t.from_shadow && (i || s) ? (i = this.convertToPercent(i ? t.from_min : t.min), s = this.convertToPercent(s ? t.from_max : t.max) - i, i = this.toFixed(i - this.coords.p_handle / 100 * i), s = this.toFixed(s - this.coords.p_handle / 100 * s), i += this.coords.p_handle / 2, e.shad_single[0].style.display = "block", e.shad_single[0].style.left = i + "%", e.shad_single[0].style.width = s + "%") : e.shad_single[0].style.display = "none" : (t.from_shadow && (i || s) ? (i = this.convertToPercent(i ? t.from_min : t.min), s = this.convertToPercent(s ? t.from_max : t.max) - i, i = this.toFixed(i - this.coords.p_handle / 100 * i), s = this.toFixed(s - this.coords.p_handle / 100 * s), i += this.coords.p_handle / 2, e.shad_from[0].style.display = "block", e.shad_from[0].style.left = i + "%", e.shad_from[0].style.width = s + "%") : e.shad_from[0].style.display = "none", t.to_shadow && (n || o) ? (n = this.convertToPercent(n ? t.to_min : t.min), t = this.convertToPercent(o ? t.to_max : t.max) - n, n = this.toFixed(n - this.coords.p_handle / 100 * n), t = this.toFixed(t - this.coords.p_handle / 100 * t), n += this.coords.p_handle / 2, e.shad_to[0].style.display = "block", e.shad_to[0].style.left = n + "%", e.shad_to[0].style.width = t + "%") : e.shad_to[0].style.display = "none")
        },
        writeToInput: function() {
            "single" === this.options.type ? (this.options.values.length ? this.$cache.input.prop("value", this.result.from_value) : this.$cache.input.prop("value", this.result.from), this.$cache.input.data("from", this.result.from)) : (this.options.values.length ? this.$cache.input.prop("value", this.result.from_value + this.options.input_values_separator + this.result.to_value) : this.$cache.input.prop("value", this.result.from + this.options.input_values_separator + this.result.to), this.$cache.input.data("from", this.result.from), this.$cache.input.data("to", this.result.to))
        },
        callOnStart: function() {
            this.writeToInput(), this.options.onStart && "function" == typeof this.options.onStart && (this.options.scope ? this.options.onStart.call(this.options.scope, this.result) : this.options.onStart(this.result))
        },
        callOnChange: function() {
            this.writeToInput(), this.options.onChange && "function" == typeof this.options.onChange && (this.options.scope ? this.options.onChange.call(this.options.scope, this.result) : this.options.onChange(this.result))
        },
        callOnFinish: function() {
            this.writeToInput(), this.options.onFinish && "function" == typeof this.options.onFinish && (this.options.scope ? this.options.onFinish.call(this.options.scope, this.result) : this.options.onFinish(this.result))
        },
        callOnUpdate: function() {
            this.writeToInput(), this.options.onUpdate && "function" == typeof this.options.onUpdate && (this.options.scope ? this.options.onUpdate.call(this.options.scope, this.result) : this.options.onUpdate(this.result))
        },
        toggleInput: function() {
            this.$cache.input.toggleClass("irs-hidden-input"), this.has_tab_index ? this.$cache.input.prop("tabindex", -1) : this.$cache.input.removeProp("tabindex"), this.has_tab_index = !this.has_tab_index
        },
        convertToPercent: function(t, e) {
            var i = this.options.max - this.options.min;
            return i ? this.toFixed((e ? t : t - this.options.min) / (i / 100)) : (this.no_diapason = !0, 0)
        },
        convertToValue: function(t) {
            var e, i, s = this.options.min,
                n = this.options.max,
                o = s.toString().split(".")[1],
                a = n.toString().split(".")[1],
                r = 0,
                l = 0;
            return 0 === t ? this.options.min : 100 === t ? this.options.max : (o && (r = e = o.length), a && (r = i = a.length), e && i && (r = i <= e ? e : i), s < 0 && (s = +(s + (l = Math.abs(s))).toFixed(r), n = +(n + l).toFixed(r)), t = (n - s) / 100 * t + s, t = (s = this.options.step.toString().split(".")[1]) ? +t.toFixed(s.length) : +(t = (t /= this.options.step) * this.options.step).toFixed(0), l && (t -= l), (l = s ? +t.toFixed(s.length) : this.toFixed(t)) < this.options.min ? l = this.options.min : l > this.options.max && (l = this.options.max), l)
        },
        calcWithStep: function(t) {
            var e = Math.round(t / this.coords.p_step) * this.coords.p_step;
            return 100 < e && (e = 100), this.toFixed(e = 100 === t ? 100 : e)
        },
        checkMinInterval: function(t, e, i) {
            var s = this.options;
            return s.min_interval ? (t = this.convertToValue(t), e = this.convertToValue(e), "from" === i ? e - t < s.min_interval && (t = e - s.min_interval) : t - e < s.min_interval && (t = e + s.min_interval), this.convertToPercent(t)) : t
        },
        checkMaxInterval: function(t, e, i) {
            var s = this.options;
            return s.max_interval ? (t = this.convertToValue(t), e = this.convertToValue(e), "from" === i ? e - t > s.max_interval && (t = e - s.max_interval) : t - e > s.max_interval && (t = e + s.max_interval), this.convertToPercent(t)) : t
        },
        checkDiapason: function(t, e, i) {
            t = this.convertToValue(t);
            var s = this.options;
            return "number" != typeof e && (e = s.min), (i = "number" != typeof i ? s.max : i) < (t = t < e ? e : t) && (t = i), this.convertToPercent(t)
        },
        toFixed: function(t) {
            return +(t = t.toFixed(20))
        },
        _prettify: function(t) {
            return this.options.prettify_enabled ? (this.options.prettify && "function" == typeof this.options.prettify ? this.options : this).prettify(t) : t
        },
        prettify: function(t) {
            return t.toString().replace(/(\d{1,3}(?=(?:\d\d\d)+(?!\d)))/g, "$1" + this.options.prettify_separator)
        },
        checkEdges: function(t, e) {
            return this.options.force_edges && (t < 0 ? t = 0 : 100 - e < t && (t = 100 - e)), this.toFixed(t)
        },
        validate: function() {
            var t, e = this.options,
                i = this.result,
                s = e.values,
                n = s.length;
            if ("string" == typeof e.min && (e.min = +e.min), "string" == typeof e.max && (e.max = +e.max), "string" == typeof e.from && (e.from = +e.from), "string" == typeof e.to && (e.to = +e.to), "string" == typeof e.step && (e.step = +e.step), "string" == typeof e.from_min && (e.from_min = +e.from_min), "string" == typeof e.from_max && (e.from_max = +e.from_max), "string" == typeof e.to_min && (e.to_min = +e.to_min), "string" == typeof e.to_max && (e.to_max = +e.to_max), "string" == typeof e.grid_num && (e.grid_num = +e.grid_num), e.max < e.min && (e.max = e.min), n)
                for (e.p_values = [], e.min = 0, e.max = n - 1, e.step = 1, e.grid_num = e.max, e.grid_snap = !0, t = 0; t < n; t++) {
                    var o = +s[t],
                        o = isNaN(o) ? s[t] : (s[t] = o, this._prettify(o));
                    e.p_values.push(o)
                }
            "number" == typeof e.from && !isNaN(e.from) || (e.from = e.min), "number" == typeof e.to && !isNaN(e.to) || (e.to = e.max), "single" === e.type ? (e.from < e.min && (e.from = e.min), e.from > e.max && (e.from = e.max)) : (e.from < e.min && (e.from = e.min), e.from > e.max && (e.from = e.max), e.to < e.min && (e.to = e.min), e.to > e.max && (e.to = e.max), this.update_check.from && (this.update_check.from !== e.from && e.from > e.to && (e.from = e.to), this.update_check.to !== e.to) && e.to < e.from && (e.to = e.from), e.from > e.to && (e.from = e.to), e.to < e.from && (e.to = e.from)), ("number" != typeof e.step || isNaN(e.step) || !e.step || e.step < 0) && (e.step = 1), "number" == typeof e.from_min && e.from < e.from_min && (e.from = e.from_min), "number" == typeof e.from_max && e.from > e.from_max && (e.from = e.from_max), "number" == typeof e.to_min && e.to < e.to_min && (e.to = e.to_min), "number" == typeof e.to_max && e.from > e.to_max && (e.to = e.to_max), i && (i.min !== e.min && (i.min = e.min), i.max !== e.max && (i.max = e.max), (i.from < i.min || i.from > i.max) && (i.from = e.from), i.to < i.min || i.to > i.max) && (i.to = e.to), ("number" != typeof e.min_interval || isNaN(e.min_interval) || !e.min_interval || e.min_interval < 0) && (e.min_interval = 0), ("number" != typeof e.max_interval || isNaN(e.max_interval) || !e.max_interval || e.max_interval < 0) && (e.max_interval = 0), e.min_interval && e.min_interval > e.max - e.min && (e.min_interval = e.max - e.min), e.max_interval && e.max_interval > e.max - e.min && (e.max_interval = e.max - e.min)
        },
        decorate: function(t, e) {
            var i = "",
                s = this.options;
            return s.prefix && (i += s.prefix), i += t, s.max_postfix && (s.values.length && t === s.p_values[s.max] ? (i += s.max_postfix, s.postfix && (i += " ")) : e === s.max && (i += s.max_postfix, s.postfix) && (i += " ")), s.postfix && (i += s.postfix), i
        },
        updateFrom: function() {
            this.result.from = this.options.from, this.result.from_percent = this.convertToPercent(this.result.from), this.result.from_pretty = this._prettify(this.result.from), this.options.values && (this.result.from_value = this.options.values[this.result.from])
        },
        updateTo: function() {
            this.result.to = this.options.to, this.result.to_percent = this.convertToPercent(this.result.to), this.result.to_pretty = this._prettify(this.result.to), this.options.values && (this.result.to_value = this.options.values[this.result.to])
        },
        updateResult: function() {
            this.result.min = this.options.min, this.result.max = this.options.max, this.updateFrom(), this.updateTo()
        },
        appendGrid: function() {
            if (this.options.grid) {
                var t, e = this.options,
                    i = e.max - e.min,
                    s = e.grid_num,
                    n = 4,
                    o = "";
                for (this.calcGridMargin(), t = e.grid_snap ? 50 < i ? (s = 50 / e.step, this.toFixed(e.step / .5)) : (s = i / e.step, this.toFixed(e.step / (i / 100))) : this.toFixed(100 / s), 4 < s && (n = 3), 7 < s && (n = 2), 14 < s && (n = 1), 28 < s && (n = 0), i = 0; i < s + 1; i++) {
                    for (var a = n, r = this.toFixed(t * i), l = (100 < r && (r = 100), ((this.coords.big[i] = r) - t * (i - 1)) / (a + 1)), h = 1; h <= a && 0 !== r; h++) o += '<span class="irs-grid-pol small" style="left: ' + this.toFixed(r - l * h) + '%"></span>';
                    o += '<span class="irs-grid-pol" style="left: ' + r + '%"></span>', h = this.convertToValue(r), o += '<span class="irs-grid-text js-grid-text-' + i + '" style="left: ' + r + '%">' + (h = e.values.length ? e.p_values[h] : this._prettify(h)) + "</span>"
                }
                this.coords.big_num = Math.ceil(s + 1), this.$cache.cont.addClass("irs-with-grid"), this.$cache.grid.html(o), this.cacheGridLabels()
            }
        },
        cacheGridLabels: function() {
            for (var t = this.coords.big_num, e = 0; e < t; e++) {
                var i = this.$cache.grid.find(".js-grid-text-" + e);
                this.$cache.grid_labels.push(i)
            }
            this.calcGridLabels()
        },
        calcGridLabels: function() {
            for (var t = [], e = [], i = this.coords.big_num, s = 0; s < i; s++) this.coords.big_w[s] = this.$cache.grid_labels[s].outerWidth(!1), this.coords.big_p[s] = this.toFixed(this.coords.big_w[s] / this.coords.w_rs * 100), this.coords.big_x[s] = this.toFixed(this.coords.big_p[s] / 2), t[s] = this.toFixed(this.coords.big[s] - this.coords.big_x[s]), e[s] = this.toFixed(t[s] + this.coords.big_p[s]);
            for (this.options.force_edges && (t[0] < -this.coords.grid_gap && (t[0] = -this.coords.grid_gap, e[0] = this.toFixed(t[0] + this.coords.big_p[0]), this.coords.big_x[0] = this.coords.grid_gap), e[i - 1] > 100 + this.coords.grid_gap) && (e[i - 1] = 100 + this.coords.grid_gap, t[i - 1] = this.toFixed(e[i - 1] - this.coords.big_p[i - 1]), this.coords.big_x[i - 1] = this.toFixed(this.coords.big_p[i - 1] - this.coords.grid_gap)), this.calcGridCollision(2, t, e), this.calcGridCollision(4, t, e), s = 0; s < i; s++) t = this.$cache.grid_labels[s][0], this.coords.big_x[s] !== Number.POSITIVE_INFINITY && (t.style.marginLeft = -this.coords.big_x[s] + "%")
        },
        calcGridCollision: function(t, e, i) {
            for (var s = this.coords.big_num, n = 0; n < s; n += t) {
                var o = n + t / 2;
                if (s <= o) break;
                this.$cache.grid_labels[o][0].style.visibility = i[n] <= e[o] ? "visible" : "hidden"
            }
        },
        calcGridMargin: function() {
            this.options.grid_margin && (this.coords.w_rs = this.$cache.rs.outerWidth(!1), this.coords.w_rs) && (this.coords.w_handle = ("single" === this.options.type ? this.$cache.s_single : this.$cache.s_from).outerWidth(!1), this.coords.p_handle = this.toFixed(this.coords.w_handle / this.coords.w_rs * 100), this.coords.grid_gap = this.toFixed(this.coords.p_handle / 2 - .1), this.$cache.grid[0].style.width = this.toFixed(100 - this.coords.p_handle) + "%", this.$cache.grid[0].style.left = this.coords.grid_gap + "%")
        },
        update: function(t) {
            this.input && (this.is_update = !0, this.options.from = this.result.from, this.options.to = this.result.to, this.update_check.from = this.result.from, this.update_check.to = this.result.to, this.options = o.extend(this.options, t), this.validate(), this.updateResult(t), this.toggleInput(), this.remove(), this.init(!0))
        },
        reset: function() {
            this.input && (this.updateResult(), this.update())
        },
        destroy: function() {
            this.input && (this.toggleInput(), this.$cache.input.prop("readonly", !1), o.data(this.input, "ionRangeSlider", null), this.remove(), this.options = this.input = null)
        }
    }, o.fn.ionRangeSlider = function(t) {
        return this.each(function() {
            o.data(this, "ionRangeSlider") || o.data(this, "ionRangeSlider", new e(this, t, s++))
        })
    };
    for (var h = 0, c = ["ms", "moz", "webkit", "o"], u = 0; u < c.length && !r.requestAnimationFrame; ++u) r.requestAnimationFrame = r[c[u] + "RequestAnimationFrame"], r.cancelAnimationFrame = r[c[u] + "CancelAnimationFrame"] || r[c[u] + "CancelRequestAnimationFrame"];
    r.requestAnimationFrame || (r.requestAnimationFrame = function(t, e) {
        var i = (new Date).getTime(),
            s = Math.max(0, 16 - (i - h)),
            n = r.setTimeout(function() {
                t(i + s)
            }, s);
        return h = i + s, n
    }), r.cancelAnimationFrame || (r.cancelAnimationFrame = function(t) {
        clearTimeout(t)
    })
});