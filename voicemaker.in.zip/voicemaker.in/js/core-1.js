let twoFactorAuth, $mainAudioplayer, $backgroundAudio = $("<audio>"),
    $multiVoiceFileAudio = $("<audio>"),
    $multiVoiceAudio = $("<audio>"),
    $projectsAudio = $("<audio>"),
    $voicesModalAudio = $("<audio>"),
    $stickyAudio, $pronunciationAudio = $("<audio>"),
    updateMultiVoiceTimeout, prevVoice, $voicesSampleAudio = $("<audio>");
const ProviderTypes = {
        AI101: "ai101",
        AI102: "ai102",
        AI103: "ai103",
        AI104: "ai104",
        AI105: "ai105",
        AI106: "ai106",
        AI112: "ai112",
        AI113: "ai113",
        PRO_PLUS: "pro-plus",
        PRO1: "pro1",
        PRO2: "pro2"
    },
    voiceCategoryTypes = {
        PRO_VOICES: "pro-voices",
        USER_VOICES: "user-voices",
        CUSTOM_VOICES: "custom-voices",
        DEFAULT_VOICES: "default-voices"
    };
let voice = {
    _id: null,
    Engine: "neural",
    Provider: "pro1",
    outputFormat: "mp3",
    effect: "default",
    master_VC: "advanced_v2",
    speed: 0,
    master_volume: 0,
    pitch: 0,
    voice: "Thomas",
    voiceApiname: "pro1-Thomas",
    sampleRate: "48000",
    text: null,
    textType: null,
    path: null,
    project: null,
    languageCode: "multi-lang",
    language: "Multilingual",
    voiceCategory: voiceCategoryTypes.PRO_VOICES,
    gender: null,
    color: null,
    style: null,
    stability: null,
    clarity: null,
    speakerBoost: !1
};
const ProEngineTypes = {
    HIGH_RES: "high-res",
    TURBO: "turbo"
};
var ajaxSpinner = '<div class="ajaxSpinner"><div class="spinner-grow spinner-grow-sm" role="status"><span class="sr-only">Loading...</span></div></div>';
let saveFileParams, speech_link, fileContent, selectedFavoriteLanguage, project, favoriteLanguages, allLanguages, userLanguages, customLanguages, proLanguages, defaultLanguages, prevSelectedLanguage, pro1Languages;
var token = document.querySelector('meta[name="csrf-token"]').getAttribute("content");
let addedMultiVoices = [],
    editSelected, multivoiceEnabled = !1,
    multivoiceBackground, saveRunning, nonLoggedVoice, textLimit, voiceProfile, highResTooltip, turboTooltip;
const proIcon = `<svg width="10" height="12" viewBox="0 0 10 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path
    d="M5.49999 1L1.04672 6.34393C0.872316 6.55321 0.785114 6.65785 0.783781 6.74623C0.782622 6.82306 0.816858 6.89615 0.87662 6.94445C0.945366 7 1.08158 7 1.35401 7H4.99999L4.49999 11L8.95326 5.65607C9.12767 5.44679 9.21487 5.34215 9.2162 5.25377C9.21736 5.17694 9.18313 5.10385 9.12336 5.05555C9.05462 5 8.9184 5 8.64598 5H4.99999L5.49999 1Z"
    stroke="#FCFCFD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg>`,
    stripePublicKey = "pk_live_51IbChqKf3GpBm2BQXxTlhElBG9DRXXOL0JiBTuWLj9axuFzTg9JXoGrAzJmD4LFufm11gUWiTYeFSFps1TExGj2k001GpuNWYk",
    razorPublicKey = "rzp_live_UlRoKGjnvVhcaJ",
    paypalClientId = "AQOoVTh8iKSMDCkFro_5B8AeR4tpoXo_gMJVpG_l3Wx28KClNpTeJJW_FCAhJEcc_9FKn1mK0q-myP3Q";
! function(n) {
    function r(e, t) {
        this.init(e, t)
    }
    let o = "hwt";
    r.prototype = {
        init: function(e, t) {
            this.$el = e, "function" === this.getType(t) && (t = {
                highlight: t
            }), "custom" === this.getType(t) ? (this.highlight = t, this.generate()) : console.error("valid config object not provided")
        },
        getType: function(e) {
            var t = typeof e;
            if (!e) return "falsey";
            if (Array.isArray(e)) return 2 === e.length && "number" == typeof e[0] && "number" == typeof e[1] ? "range" : "array";
            if ("object" == t) {
                if (e instanceof RegExp) return "regexp";
                if (e.hasOwnProperty("highlight")) return "custom"
            } else if ("function" == t || "string" == t) return t;
            return "other"
        },
        generate: function() {
            switch (this.$el.addClass("hwt-input hwt-content").on("input." + o, this.handleInput.bind(this)).on("scroll." + o, this.handleScroll.bind(this)), this.$highlights = n("<div>", {
                class: "hwt-highlights hwt-content"
            }), this.$backdrop = n("<div>", {
                class: o + "-backdrop"
            }).append(this.$highlights), this.$container = n("<div>", {
                class: o + "-container"
            }).insertAfter(this.$el).append(this.$backdrop, this.$el).on("scroll", this.blockContainerScroll.bind(this)), this.browser = this.detectBrowser(), this.browser) {
                case "firefox":
                    this.fixFirefox();
                    break;
                case "ios":
                    this.fixIOS()
            }
            this.isGenerated = !0, this.handleInput()
        },
        detectBrowser: function() {
            var e = window.navigator.userAgent.toLowerCase();
            return -1 !== e.indexOf("firefox") ? "firefox" : e.match(/msie|trident\/7|edge/) ? "ie" : e.match(/ipad|iphone|ipod/) && -1 === e.indexOf("windows phone") ? "ios" : "other"
        },
        fixFirefox: function() {
            var e = this.$highlights.css(["padding-top", "padding-right", "padding-bottom", "padding-left"]),
                t = this.$highlights.css(["border-top-width", "border-right-width", "border-bottom-width", "border-left-width"]);
            this.$highlights.css({
                padding: "0",
                "border-width": "0"
            }), this.$backdrop.css({
                "margin-top": "+=" + e["padding-top"],
                "margin-right": "+=" + e["padding-right"],
                "margin-bottom": "+=" + e["padding-bottom"],
                "margin-left": "+=" + e["padding-left"]
            }).css({
                "margin-top": "+=" + t["border-top-width"],
                "margin-right": "+=" + t["border-right-width"],
                "margin-bottom": "+=" + t["border-bottom-width"],
                "margin-left": "+=" + t["border-left-width"]
            })
        },
        fixIOS: function() {
            this.$highlights.css({
                "padding-left": "+=3px",
                "padding-right": "+=3px"
            })
        },
        handleInput: function() {
            var e = this.$el.val(),
                e = this.getRanges(e, this.highlight),
                e = this.removeStaggeredRanges(e),
                e = this.getBoundaries(e);
            this.renderMarks(e)
        },
        getRanges: function(e, t) {
            switch (this.getType(t)) {
                case "array":
                    return this.getArrayRanges(e, t);
                case "function":
                    return this.getFunctionRanges(e, t);
                case "regexp":
                    return this.getRegExpRanges(e, t);
                case "string":
                    return this.getStringRanges(e, t);
                case "range":
                    return this.getRangeRanges(e, t);
                case "custom":
                    return this.getCustomRanges(e, t);
                default:
                    if (!t) return [];
                    console.error("unrecognized highlight type")
            }
        },
        getArrayRanges: function(e, t) {
            t = t.map(this.getRanges.bind(this, e));
            return Array.prototype.concat.apply([], t)
        },
        getFunctionRanges: function(e, t) {
            return this.getRanges(e, t(e))
        },
        getRegExpRanges: function(e, t) {
            for (var i, n = []; null !== (i = t.exec(e)) && (n.push([i.index, i.index + i[0].length]), t.global););
            return n
        },
        getStringRanges: function(e, t) {
            var i = [],
                n = e.toLowerCase(),
                r = t.toLowerCase();
            let o = 0;
            for (; - 1 !== (o = n.indexOf(r, o));) i.push([o, o + r.length]), o += r.length;
            return i
        },
        getRangeRanges: function(e, t) {
            return [t]
        },
        getCustomRanges: function(e, t) {
            e = this.getRanges(e, t.highlight);
            return t.className && e.forEach(function(e) {
                e.className ? e.className = t.className + " " + e.className : e.className = t.className
            }), e
        },
        removeStaggeredRanges: function(e) {
            let i = [];
            return e.forEach(function(t) {
                i.some(function(e) {
                    return (t[0] > e[0] && t[0] < e[1]) != (t[1] > e[0] && t[1] < e[1])
                }) || i.push(t)
            }), i
        },
        getBoundaries: function(e) {
            let t = [];
            return e.forEach(function(e) {
                t.push({
                    type: "start",
                    index: e[0],
                    className: e.className
                }), t.push({
                    type: "stop",
                    index: e[1]
                })
            }), this.sortBoundaries(t), t
        },
        sortBoundaries: function(e) {
            e.sort(function(e, t) {
                return e.index !== t.index ? t.index - e.index : "stop" === e.type && "start" === t.type ? 1 : "start" === e.type && "stop" === t.type ? -1 : 0
            })
        },
        renderMarks: function(i) {
            let n = this.$el.val();
            i.forEach(function(e, t) {
                let i;
                i = "start" === e.type ? "{{hwt-mark-start|" + t + "}}" : "{{hwt-mark-stop}}", n = n.slice(0, e.index) + i + n.slice(e.index)
            }), n = (n = n.replace(/\n(\{\{hwt-mark-stop\}\})?$/, "\n\n$1")).replace(/</g, "&lt;").replace(/>/g, "&gt;"), n = (n = (n = "ie" === this.browser ? n.replace(/ /g, " <wbr>") : n).replace(/\{\{hwt-mark-start\|(\d+)\}\}/g, function(e, t) {
                t = i[+t].className;
                return t ? '<mark class="' + t + '">' : "<mark>"
            })).replace(/\{\{hwt-mark-stop\}\}/g, "</mark>"), this.$highlights.html(n)
        },
        handleScroll: function() {
            var e = this.$el.scrollTop(),
                e = (this.$backdrop.scrollTop(e), this.$el.scrollLeft());
            this.$backdrop.css("transform", 0 < e ? "translateX(" + -e + "px)" : "")
        },
        blockContainerScroll: function() {
            this.$container.scrollLeft(0)
        },
        destroy: function() {
            this.$backdrop.remove(), this.$el.unwrap().removeClass("hwt-text hwt-input").off(o).removeData(o)
        }
    }, n.fn.highlightWithinTextarea = function(i) {
        return this.each(function() {
            var e = n(this);
            let t = e.data(o);
            if ("string" == typeof i)
                if (t) switch (i) {
                    case "update":
                        t.handleInput();
                        break;
                    case "destroy":
                        t.destroy();
                        break;
                    default:
                        console.error("unrecognized method string")
                } else console.error("plugin must be instantiated first");
                else t && t.destroy(), (t = new r(e, i)).isGenerated && e.data(o, t)
        })
    }
}(jQuery);